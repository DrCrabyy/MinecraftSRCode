package net.minecraft.block.dispenser;

import net.minecraft.block.AbstractRailBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.enums.RailShape;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPointer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class MinecartDispenserBehavior extends ItemDispenserBehavior {
	private final ItemDispenserBehavior fallbackBehavior = new ItemDispenserBehavior();
	private final EntityType<? extends AbstractMinecartEntity> minecartEntityType;

	public MinecartDispenserBehavior(EntityType<? extends AbstractMinecartEntity> minecartEntityType) {
		this.minecartEntityType = minecartEntityType;
	}

	@Override
	public ItemStack dispenseSilently(BlockPointer pointer, ItemStack stack) {
		Direction lv = pointer.state().get(DispenserBlock.FACING);
		ServerWorld lv2 = pointer.world();
		Vec3d lv3 = pointer.centerPos();
		double d = lv3.getX() + (double)lv.getOffsetX() * 1.125;
		double e = Math.floor(lv3.getY()) + (double)lv.getOffsetY();
		double f = lv3.getZ() + (double)lv.getOffsetZ() * 1.125;
		BlockPos lv4 = pointer.pos().offset(lv);
		BlockState lv5 = lv2.getBlockState(lv4);
		double g;
		if (lv5.isIn(BlockTags.RAILS)) {
			if (getRailShape(lv5).isAscending()) {
				g = 0.6;
			} else {
				g = 0.1;
			}
		} else {
			if (!lv5.isAir()) {
				return this.fallbackBehavior.dispense(pointer, stack);
			}

			BlockState lv6 = lv2.getBlockState(lv4.down());
			if (!lv6.isIn(BlockTags.RAILS)) {
				return this.fallbackBehavior.dispense(pointer, stack);
			}

			if (lv != Direction.DOWN && getRailShape(lv6).isAscending()) {
				g = -0.4;
			} else {
				g = -0.9;
			}
		}

		Vec3d lv7 = new Vec3d(d, e + g, f);
		AbstractMinecartEntity lv8 = AbstractMinecartEntity.create(lv2, lv7.x, lv7.y, lv7.z, this.minecartEntityType, SpawnReason.DISPENSER, stack, null);
		if (lv8 != null) {
			lv2.spawnEntity(lv8);
			stack.decrement(1);
		}

		return stack;
	}

	private static RailShape getRailShape(BlockState state) {
		return state.getBlock() instanceof AbstractRailBlock lv ? state.get(lv.getShapeProperty()) : RailShape.NORTH_SOUTH;
	}

	@Override
	protected void playSound(BlockPointer pointer) {
		pointer.world().syncWorldEvent(1000, pointer.pos(), 0);
	}
}
