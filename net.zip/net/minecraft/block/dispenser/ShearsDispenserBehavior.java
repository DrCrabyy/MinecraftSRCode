package net.minecraft.block.dispenser;

import net.minecraft.block.BeehiveBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.entity.BeehiveBlockEntity.BeeState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Shearable;
import net.minecraft.item.ItemStack;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPointer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.event.GameEvent;

public class ShearsDispenserBehavior extends FallibleItemDispenserBehavior {
	@Override
	protected ItemStack dispenseSilently(BlockPointer pointer, ItemStack stack) {
		ServerWorld lv = pointer.world();
		if (!lv.isClient()) {
			BlockPos lv2 = pointer.pos().offset(pointer.state().get(DispenserBlock.FACING));
			this.setSuccess(tryShearBlock(lv, lv2) || tryShearEntity(lv, lv2, stack));
			if (this.isSuccess()) {
				stack.damage(1, lv, null, item -> {
				});
			}
		}

		return stack;
	}

	private static boolean tryShearBlock(ServerWorld world, BlockPos pos) {
		BlockState lv = world.getBlockState(pos);
		if (lv.isIn(BlockTags.BEEHIVES, state -> state.contains(BeehiveBlock.HONEY_LEVEL) && state.getBlock() instanceof BeehiveBlock)) {
			int i = (Integer)lv.get(BeehiveBlock.HONEY_LEVEL);
			if (i >= 5) {
				world.playSound(null, pos, SoundEvents.BLOCK_BEEHIVE_SHEAR, SoundCategory.BLOCKS, 1.0F, 1.0F);
				BeehiveBlock.dropHoneycomb(world, pos);
				((BeehiveBlock)lv.getBlock()).takeHoney(world, lv, pos, null, BeeState.BEE_RELEASED);
				world.emitGameEvent(null, GameEvent.SHEAR, pos);
				return true;
			}
		}

		return false;
	}

	private static boolean tryShearEntity(ServerWorld world, BlockPos pos, ItemStack shears) {
		for (LivingEntity lv : world.getEntitiesByClass(LivingEntity.class, new Box(pos), EntityPredicates.EXCEPT_SPECTATOR)) {
			if (lv instanceof Shearable lv2 && lv2.isShearable()) {
				lv2.sheared(world, SoundCategory.BLOCKS, shears);
				world.emitGameEvent(null, GameEvent.SHEAR, pos);
				return true;
			}
		}

		return false;
	}
}
