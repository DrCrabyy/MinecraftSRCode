package net.minecraft.block.dispenser;

import net.minecraft.block.DispenserBlock;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ProjectileItem;
import net.minecraft.item.ProjectileItem.Settings;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPointer;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Position;

public class ProjectileDispenserBehavior extends ItemDispenserBehavior {
	private final ProjectileItem projectile;
	private final Settings projectileSettings;

	public ProjectileDispenserBehavior(Item item) {
		if (item instanceof ProjectileItem lv) {
			this.projectile = lv;
			this.projectileSettings = lv.getProjectileSettings();
		} else {
			throw new IllegalArgumentException(item + " not instance of " + ProjectileItem.class.getSimpleName());
		}
	}

	@Override
	public ItemStack dispenseSilently(BlockPointer pointer, ItemStack stack) {
		ServerWorld lv = pointer.world();
		Direction lv2 = pointer.state().get(DispenserBlock.FACING);
		Position lv3 = this.projectileSettings.positionFunction().getDispensePosition(pointer, lv2);
		ProjectileEntity.spawnWithVelocity(
			this.projectile.createEntity(lv, lv3, stack, lv2),
			lv,
			stack,
			(double)lv2.getOffsetX(),
			(double)lv2.getOffsetY(),
			(double)lv2.getOffsetZ(),
			this.projectileSettings.power(),
			this.projectileSettings.uncertainty()
		);
		stack.decrement(1);
		return stack;
	}

	@Override
	protected void playSound(BlockPointer pointer) {
		pointer.world().syncWorldEvent(this.projectileSettings.overrideDispenseEvent().orElse(1002), pointer.pos(), 0);
	}
}
