package net.minecraft.block.dispenser;

import net.minecraft.block.DispenserBlock;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPointer;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Position;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.world.World;

public class ItemDispenserBehavior implements DispenserBehavior {
	private static final int field_51916 = 6;

	@Override
	public final ItemStack dispense(BlockPointer pointer, ItemStack stack) {
		ItemStack lv = this.dispenseSilently(pointer, stack);
		this.playSound(pointer);
		this.spawnParticles(pointer, pointer.state().get(DispenserBlock.FACING));
		return lv;
	}

	protected ItemStack dispenseSilently(BlockPointer pointer, ItemStack stack) {
		Direction lv = pointer.state().get(DispenserBlock.FACING);
		Position lv2 = DispenserBlock.getOutputLocation(pointer);
		ItemStack lv3 = stack.split(1);
		spawnItem(pointer.world(), lv3, 6, lv, lv2);
		return stack;
	}

	public static void spawnItem(World world, ItemStack stack, int speed, Direction side, Position pos) {
		double d = pos.getX();
		double e = pos.getY();
		double f = pos.getZ();
		if (side.getAxis() == Axis.Y) {
			e -= 0.125;
		} else {
			e -= 0.15625;
		}

		ItemEntity lv = new ItemEntity(world, d, e, f, stack);
		double g = world.random.nextDouble() * 0.1 + 0.2;
		lv.setVelocity(
			world.random.nextTriangular((double)side.getOffsetX() * g, 0.0172275 * (double)speed),
			world.random.nextTriangular(0.2, 0.0172275 * (double)speed),
			world.random.nextTriangular((double)side.getOffsetZ() * g, 0.0172275 * (double)speed)
		);
		world.spawnEntity(lv);
	}

	protected void playSound(BlockPointer pointer) {
		syncDispensesEvent(pointer);
	}

	protected void spawnParticles(BlockPointer pointer, Direction side) {
		syncActivatesEvent(pointer, side);
	}

	private static void syncDispensesEvent(BlockPointer pointer) {
		pointer.world().syncWorldEvent(1000, pointer.pos(), 0);
	}

	private static void syncActivatesEvent(BlockPointer pointer, Direction side) {
		pointer.world().syncWorldEvent(2000, pointer.pos(), side.getId());
	}

	protected ItemStack decrementStackWithRemainder(BlockPointer pointer, ItemStack stack, ItemStack remainder) {
		stack.decrement(1);
		if (stack.isEmpty()) {
			return remainder;
		} else {
			this.addStackOrSpawn(pointer, remainder);
			return stack;
		}
	}

	private void addStackOrSpawn(BlockPointer pointer, ItemStack stack) {
		ItemStack lv = pointer.blockEntity().addToFirstFreeSlot(stack);
		if (!lv.isEmpty()) {
			Direction lv2 = pointer.state().get(DispenserBlock.FACING);
			spawnItem(pointer.world(), lv, 6, lv2, DispenserBlock.getOutputLocation(pointer));
			syncDispensesEvent(pointer);
			syncActivatesEvent(pointer, lv2);
		}
	}
}
