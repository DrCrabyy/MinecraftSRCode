package net.minecraft.block;

import com.google.common.annotations.VisibleForTesting;
import com.mojang.serialization.MapCodec;
import java.util.Optional;
import java.util.function.BiPredicate;
import java.util.function.Predicate;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.enums.Thickness;
import net.minecraft.entity.Entity;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.function.BooleanBiFunction;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.Direction.AxisDirection;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.event.GameEvent.Emitter;
import net.minecraft.world.tick.ScheduledTickView;

public class PointedDripstoneBlock extends Block implements Falling, Waterloggable {
	public static final MapCodec<PointedDripstoneBlock> CODEC = createCodec(PointedDripstoneBlock::new);
	public static final EnumProperty<Direction> VERTICAL_DIRECTION = Properties.VERTICAL_DIRECTION;
	public static final EnumProperty<Thickness> THICKNESS = Properties.THICKNESS;
	public static final BooleanProperty WATERLOGGED = Properties.WATERLOGGED;
	private static final int field_31205 = 11;
	private static final int field_31207 = 2;
	private static final float field_31208 = 0.02F;
	private static final float field_31209 = 0.12F;
	private static final int field_31210 = 11;
	private static final float WATER_DRIP_CHANCE = 0.17578125F;
	private static final float LAVA_DRIP_CHANCE = 0.05859375F;
	private static final double field_31213 = 0.6;
	private static final float field_31214 = 1.0F;
	private static final int field_31215 = 40;
	private static final int field_31200 = 6;
	private static final float field_31201 = 2.0F;
	private static final int field_31202 = 2;
	private static final float field_33566 = 5.0F;
	private static final float field_33567 = 0.011377778F;
	private static final int MAX_STALACTITE_GROWTH = 7;
	private static final int STALACTITE_FLOOR_SEARCH_RANGE = 10;
	private static final VoxelShape TIP_MERGE_SHAPE = Block.method_66404(6.0, 0.0, 16.0);
	private static final VoxelShape UP_TIP_SHAPE = Block.method_66404(6.0, 0.0, 11.0);
	private static final VoxelShape DOWN_TIP_SHAPE = Block.method_66404(6.0, 5.0, 16.0);
	private static final VoxelShape BASE_SHAPE = Block.method_66404(8.0, 0.0, 16.0);
	private static final VoxelShape FRUSTUM_SHAPE = Block.method_66404(10.0, 0.0, 16.0);
	private static final VoxelShape MIDDLE_SHAPE = Block.method_66404(12.0, 0.0, 16.0);
	private static final double field_31203 = DOWN_TIP_SHAPE.getMin(Axis.Y);
	private static final float field_31204 = (float)MIDDLE_SHAPE.getMin(Axis.X);
	private static final VoxelShape DRIP_COLLISION_SHAPE = Block.method_66404(4.0, 0.0, 16.0);

	@Override
	public MapCodec<PointedDripstoneBlock> getCodec() {
		return CODEC;
	}

	public PointedDripstoneBlock(Settings settings) {
		super(settings);
		this.setDefaultState(
			this.stateManager.getDefaultState().with(VERTICAL_DIRECTION, Direction.UP).with(THICKNESS, Thickness.TIP).with(WATERLOGGED, Boolean.valueOf(false))
		);
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(VERTICAL_DIRECTION, THICKNESS, WATERLOGGED);
	}

	@Override
	protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
		return canPlaceAtWithDirection(world, pos, state.get(VERTICAL_DIRECTION));
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		if ((Boolean)state.get(WATERLOGGED)) {
			tickView.scheduleFluidTick(pos, Fluids.WATER, Fluids.WATER.getTickRate(world));
		}

		if (direction != Direction.UP && direction != Direction.DOWN) {
			return state;
		} else {
			Direction lv = state.get(VERTICAL_DIRECTION);
			if (lv == Direction.DOWN && tickView.getBlockTickScheduler().isQueued(pos, this)) {
				return state;
			} else if (direction == lv.getOpposite() && !this.canPlaceAt(state, world, pos)) {
				if (lv == Direction.DOWN) {
					tickView.scheduleBlockTick(pos, this, 2);
				} else {
					tickView.scheduleBlockTick(pos, this, 1);
				}

				return state;
			} else {
				boolean bl = state.get(THICKNESS) == Thickness.TIP_MERGE;
				Thickness lv2 = getThickness(world, pos, lv, bl);
				return state.with(THICKNESS, lv2);
			}
		}
	}

	@Override
	protected void onProjectileHit(World world, BlockState state, BlockHitResult hit, ProjectileEntity projectile) {
		if (!world.isClient) {
			BlockPos lv = hit.getBlockPos();
			if (world instanceof ServerWorld lv2
				&& projectile.canModifyAt(lv2, lv)
				&& projectile.canBreakBlocks(lv2)
				&& projectile instanceof TridentEntity
				&& projectile.getVelocity().length() > 0.6) {
				world.breakBlock(lv, true);
			}
		}
	}

	@Override
	public void onLandedUpon(World world, BlockState state, BlockPos pos, Entity entity, float fallDistance) {
		if (state.get(VERTICAL_DIRECTION) == Direction.UP && state.get(THICKNESS) == Thickness.TIP) {
			entity.handleFallDamage(fallDistance + 2.0F, 2.0F, world.getDamageSources().stalagmite());
		} else {
			super.onLandedUpon(world, state, pos, entity, fallDistance);
		}
	}

	@Override
	public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
		if (canDrip(state)) {
			float f = random.nextFloat();
			if (!(f > 0.12F)) {
				getFluid(world, pos, state).filter(fluid -> f < 0.02F || isFluidLiquid(fluid.fluid)).ifPresent(fluid -> createParticle(world, pos, state, fluid.fluid));
			}
		}
	}

	@Override
	protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		if (isPointingUp(state) && !this.canPlaceAt(state, world, pos)) {
			world.breakBlock(pos, true);
		} else {
			spawnFallingBlock(state, world, pos);
		}
	}

	@Override
	protected void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		dripTick(state, world, pos, random.nextFloat());
		if (random.nextFloat() < 0.011377778F && isHeldByPointedDripstone(state, world, pos)) {
			tryGrow(state, world, pos, random);
		}
	}

	@VisibleForTesting
	public static void dripTick(BlockState state, ServerWorld world, BlockPos pos, float dripChance) {
		if (!(dripChance > 0.17578125F) || !(dripChance > 0.05859375F)) {
			if (isHeldByPointedDripstone(state, world, pos)) {
				Optional<PointedDripstoneBlock.DrippingFluid> optional = getFluid(world, pos, state);
				if (!optional.isEmpty()) {
					Fluid lv = ((PointedDripstoneBlock.DrippingFluid)optional.get()).fluid;
					float g;
					if (lv == Fluids.WATER) {
						g = 0.17578125F;
					} else {
						if (lv != Fluids.LAVA) {
							return;
						}

						g = 0.05859375F;
					}

					if (!(dripChance >= g)) {
						BlockPos lv2 = getTipPos(state, world, pos, 11, false);
						if (lv2 != null) {
							if (((PointedDripstoneBlock.DrippingFluid)optional.get()).sourceState.isOf(Blocks.MUD) && lv == Fluids.WATER) {
								BlockState lv3 = Blocks.CLAY.getDefaultState();
								world.setBlockState(((PointedDripstoneBlock.DrippingFluid)optional.get()).pos, lv3);
								Block.pushEntitiesUpBeforeBlockChange(
									((PointedDripstoneBlock.DrippingFluid)optional.get()).sourceState, lv3, world, ((PointedDripstoneBlock.DrippingFluid)optional.get()).pos
								);
								world.emitGameEvent(GameEvent.BLOCK_CHANGE, ((PointedDripstoneBlock.DrippingFluid)optional.get()).pos, Emitter.of(lv3));
								world.syncWorldEvent(1504, lv2, 0);
							} else {
								BlockPos lv4 = getCauldronPos(world, lv2, lv);
								if (lv4 != null) {
									world.syncWorldEvent(1504, lv2, 0);
									int i = lv2.getY() - lv4.getY();
									int j = 50 + i;
									BlockState lv5 = world.getBlockState(lv4);
									world.scheduleBlockTick(lv4, lv5.getBlock(), j);
								}
							}
						}
					}
				}
			}
		}
	}

	@Nullable
	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		WorldAccess lv = ctx.getWorld();
		BlockPos lv2 = ctx.getBlockPos();
		Direction lv3 = ctx.getVerticalPlayerLookDirection().getOpposite();
		Direction lv4 = getDirectionToPlaceAt(lv, lv2, lv3);
		if (lv4 == null) {
			return null;
		} else {
			boolean bl = !ctx.shouldCancelInteraction();
			Thickness lv5 = getThickness(lv, lv2, lv4, bl);
			return lv5 == null
				? null
				: this.getDefaultState()
					.with(VERTICAL_DIRECTION, lv4)
					.with(THICKNESS, lv5)
					.with(WATERLOGGED, Boolean.valueOf(lv.getFluidState(lv2).getFluid() == Fluids.WATER));
		}
	}

	@Override
	protected FluidState getFluidState(BlockState state) {
		return state.get(WATERLOGGED) ? Fluids.WATER.getStill(false) : super.getFluidState(state);
	}

	@Override
	protected VoxelShape getCullingShape(BlockState state) {
		return VoxelShapes.empty();
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		VoxelShape lv = switch ((Thickness)state.get(THICKNESS)) {
			case TIP_MERGE -> TIP_MERGE_SHAPE;
			case TIP -> state.get(VERTICAL_DIRECTION) == Direction.DOWN ? DOWN_TIP_SHAPE : UP_TIP_SHAPE;
			case FRUSTUM -> BASE_SHAPE;
			case MIDDLE -> FRUSTUM_SHAPE;
			case BASE -> MIDDLE_SHAPE;
			default -> throw new MatchException(null, null);
		};
		return lv.offset(state.getModelOffset(pos));
	}

	@Override
	protected boolean isShapeFullCube(BlockState state, BlockView world, BlockPos pos) {
		return false;
	}

	@Override
	protected float getMaxHorizontalModelOffset() {
		return field_31204;
	}

	@Override
	public void onDestroyedOnLanding(World world, BlockPos pos, FallingBlockEntity fallingBlockEntity) {
		if (!fallingBlockEntity.isSilent()) {
			world.syncWorldEvent(1045, pos, 0);
		}
	}

	@Override
	public DamageSource getDamageSource(Entity attacker) {
		return attacker.getDamageSources().fallingStalactite(attacker);
	}

	private static void spawnFallingBlock(BlockState state, ServerWorld world, BlockPos pos) {
		Mutable lv = pos.mutableCopy();
		BlockState lv2 = state;

		while (isPointingDown(lv2)) {
			FallingBlockEntity lv3 = FallingBlockEntity.spawnFromBlock(world, lv, lv2);
			if (isTip(lv2, true)) {
				int i = Math.max(1 + pos.getY() - lv.getY(), 6);
				float f = 1.0F * (float)i;
				lv3.setHurtEntities(f, 40);
				break;
			}

			lv.move(Direction.DOWN);
			lv2 = world.getBlockState(lv);
		}
	}

	@VisibleForTesting
	public static void tryGrow(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		BlockState lv = world.getBlockState(pos.up(1));
		BlockState lv2 = world.getBlockState(pos.up(2));
		if (canGrow(lv, lv2)) {
			BlockPos lv3 = getTipPos(state, world, pos, 7, false);
			if (lv3 != null) {
				BlockState lv4 = world.getBlockState(lv3);
				if (canDrip(lv4) && canGrow(lv4, world, lv3)) {
					if (random.nextBoolean()) {
						tryGrow(world, lv3, Direction.DOWN);
					} else {
						tryGrowStalagmite(world, lv3);
					}
				}
			}
		}
	}

	private static void tryGrowStalagmite(ServerWorld world, BlockPos pos) {
		Mutable lv = pos.mutableCopy();

		for (int i = 0; i < 10; i++) {
			lv.move(Direction.DOWN);
			BlockState lv2 = world.getBlockState(lv);
			if (!lv2.getFluidState().isEmpty()) {
				return;
			}

			if (isTip(lv2, Direction.UP) && canGrow(lv2, world, lv)) {
				tryGrow(world, lv, Direction.UP);
				return;
			}

			if (canPlaceAtWithDirection(world, lv, Direction.UP) && !world.isWater(lv.down())) {
				tryGrow(world, lv.down(), Direction.UP);
				return;
			}

			if (!canDripThrough(world, lv, lv2)) {
				return;
			}
		}
	}

	private static void tryGrow(ServerWorld world, BlockPos pos, Direction direction) {
		BlockPos lv = pos.offset(direction);
		BlockState lv2 = world.getBlockState(lv);
		if (isTip(lv2, direction.getOpposite())) {
			growMerged(lv2, world, lv);
		} else if (lv2.isAir() || lv2.isOf(Blocks.WATER)) {
			place(world, lv, direction, Thickness.TIP);
		}
	}

	private static void place(WorldAccess world, BlockPos pos, Direction direction, Thickness thickness) {
		BlockState lv = Blocks.POINTED_DRIPSTONE
			.getDefaultState()
			.with(VERTICAL_DIRECTION, direction)
			.with(THICKNESS, thickness)
			.with(WATERLOGGED, Boolean.valueOf(world.getFluidState(pos).getFluid() == Fluids.WATER));
		world.setBlockState(pos, lv, 3);
	}

	private static void growMerged(BlockState state, WorldAccess world, BlockPos pos) {
		BlockPos lv2;
		BlockPos lv;
		if (state.get(VERTICAL_DIRECTION) == Direction.UP) {
			lv = pos;
			lv2 = pos.up();
		} else {
			lv2 = pos;
			lv = pos.down();
		}

		place(world, lv2, Direction.DOWN, Thickness.TIP_MERGE);
		place(world, lv, Direction.UP, Thickness.TIP_MERGE);
	}

	public static void createParticle(World world, BlockPos pos, BlockState state) {
		getFluid(world, pos, state).ifPresent(fluid -> createParticle(world, pos, state, fluid.fluid));
	}

	private static void createParticle(World world, BlockPos pos, BlockState state, Fluid fluid) {
		Vec3d lv = state.getModelOffset(pos);
		double d = 0.0625;
		double e = (double)pos.getX() + 0.5 + lv.x;
		double f = (double)pos.getY() + field_31203 - 0.0625;
		double g = (double)pos.getZ() + 0.5 + lv.z;
		Fluid lv2 = getDripFluid(world, fluid);
		ParticleEffect lv3 = lv2.isIn(FluidTags.LAVA) ? ParticleTypes.DRIPPING_DRIPSTONE_LAVA : ParticleTypes.DRIPPING_DRIPSTONE_WATER;
		world.addParticleClient(lv3, e, f, g, 0.0, 0.0, 0.0);
	}

	@Nullable
	private static BlockPos getTipPos(BlockState state, WorldAccess world, BlockPos pos, int range, boolean allowMerged) {
		if (isTip(state, allowMerged)) {
			return pos;
		} else {
			Direction lv = state.get(VERTICAL_DIRECTION);
			BiPredicate<BlockPos, BlockState> biPredicate = (posx, statex) -> statex.isOf(Blocks.POINTED_DRIPSTONE) && statex.get(VERTICAL_DIRECTION) == lv;
			return (BlockPos)searchInDirection(world, pos, lv.getDirection(), biPredicate, statex -> isTip(statex, allowMerged), range).orElse(null);
		}
	}

	@Nullable
	private static Direction getDirectionToPlaceAt(WorldView world, BlockPos pos, Direction direction) {
		Direction lv;
		if (canPlaceAtWithDirection(world, pos, direction)) {
			lv = direction;
		} else {
			if (!canPlaceAtWithDirection(world, pos, direction.getOpposite())) {
				return null;
			}

			lv = direction.getOpposite();
		}

		return lv;
	}

	private static Thickness getThickness(WorldView world, BlockPos pos, Direction direction, boolean tryMerge) {
		Direction lv = direction.getOpposite();
		BlockState lv2 = world.getBlockState(pos.offset(direction));
		if (isPointedDripstoneFacingDirection(lv2, lv)) {
			return !tryMerge && lv2.get(THICKNESS) != Thickness.TIP_MERGE ? Thickness.TIP : Thickness.TIP_MERGE;
		} else if (!isPointedDripstoneFacingDirection(lv2, direction)) {
			return Thickness.TIP;
		} else {
			Thickness lv3 = lv2.get(THICKNESS);
			if (lv3 != Thickness.TIP && lv3 != Thickness.TIP_MERGE) {
				BlockState lv4 = world.getBlockState(pos.offset(lv));
				return !isPointedDripstoneFacingDirection(lv4, direction) ? Thickness.BASE : Thickness.MIDDLE;
			} else {
				return Thickness.FRUSTUM;
			}
		}
	}

	public static boolean canDrip(BlockState state) {
		return isPointingDown(state) && state.get(THICKNESS) == Thickness.TIP && !(Boolean)state.get(WATERLOGGED);
	}

	private static boolean canGrow(BlockState state, ServerWorld world, BlockPos pos) {
		Direction lv = state.get(VERTICAL_DIRECTION);
		BlockPos lv2 = pos.offset(lv);
		BlockState lv3 = world.getBlockState(lv2);
		if (!lv3.getFluidState().isEmpty()) {
			return false;
		} else {
			return lv3.isAir() ? true : isTip(lv3, lv.getOpposite());
		}
	}

	private static Optional<BlockPos> getSupportingPos(World world, BlockPos pos, BlockState state, int range) {
		Direction lv = state.get(VERTICAL_DIRECTION);
		BiPredicate<BlockPos, BlockState> biPredicate = (posx, statex) -> statex.isOf(Blocks.POINTED_DRIPSTONE) && statex.get(VERTICAL_DIRECTION) == lv;
		return searchInDirection(world, pos, lv.getOpposite().getDirection(), biPredicate, statex -> !statex.isOf(Blocks.POINTED_DRIPSTONE), range);
	}

	private static boolean canPlaceAtWithDirection(WorldView world, BlockPos pos, Direction direction) {
		BlockPos lv = pos.offset(direction.getOpposite());
		BlockState lv2 = world.getBlockState(lv);
		return lv2.isSideSolidFullSquare(world, lv, direction) || isPointedDripstoneFacingDirection(lv2, direction);
	}

	private static boolean isTip(BlockState state, boolean allowMerged) {
		if (!state.isOf(Blocks.POINTED_DRIPSTONE)) {
			return false;
		} else {
			Thickness lv = state.get(THICKNESS);
			return lv == Thickness.TIP || allowMerged && lv == Thickness.TIP_MERGE;
		}
	}

	private static boolean isTip(BlockState state, Direction direction) {
		return isTip(state, false) && state.get(VERTICAL_DIRECTION) == direction;
	}

	private static boolean isPointingDown(BlockState state) {
		return isPointedDripstoneFacingDirection(state, Direction.DOWN);
	}

	private static boolean isPointingUp(BlockState state) {
		return isPointedDripstoneFacingDirection(state, Direction.UP);
	}

	private static boolean isHeldByPointedDripstone(BlockState state, WorldView world, BlockPos pos) {
		return isPointingDown(state) && !world.getBlockState(pos.up()).isOf(Blocks.POINTED_DRIPSTONE);
	}

	@Override
	protected boolean canPathfindThrough(BlockState state, NavigationType type) {
		return false;
	}

	private static boolean isPointedDripstoneFacingDirection(BlockState state, Direction direction) {
		return state.isOf(Blocks.POINTED_DRIPSTONE) && state.get(VERTICAL_DIRECTION) == direction;
	}

	@Nullable
	private static BlockPos getCauldronPos(World world, BlockPos pos, Fluid fluid) {
		Predicate<BlockState> predicate = state -> state.getBlock() instanceof AbstractCauldronBlock
				&& ((AbstractCauldronBlock)state.getBlock()).canBeFilledByDripstone(fluid);
		BiPredicate<BlockPos, BlockState> biPredicate = (posx, state) -> canDripThrough(world, posx, state);
		return (BlockPos)searchInDirection(world, pos, Direction.DOWN.getDirection(), biPredicate, predicate, 11).orElse(null);
	}

	@Nullable
	public static BlockPos getDripPos(World world, BlockPos pos) {
		BiPredicate<BlockPos, BlockState> biPredicate = (posx, state) -> canDripThrough(world, posx, state);
		return (BlockPos)searchInDirection(world, pos, Direction.UP.getDirection(), biPredicate, PointedDripstoneBlock::canDrip, 11).orElse(null);
	}

	public static Fluid getDripFluid(ServerWorld world, BlockPos pos) {
		return (Fluid)getFluid(world, pos, world.getBlockState(pos)).map(fluid -> fluid.fluid).filter(PointedDripstoneBlock::isFluidLiquid).orElse(Fluids.EMPTY);
	}

	private static Optional<PointedDripstoneBlock.DrippingFluid> getFluid(World world, BlockPos pos, BlockState state) {
		return !isPointingDown(state) ? Optional.empty() : getSupportingPos(world, pos, state, 11).map(posx -> {
			BlockPos lv = posx.up();
			BlockState lv2 = world.getBlockState(lv);
			Fluid lv3;
			if (lv2.isOf(Blocks.MUD) && !world.getDimension().ultrawarm()) {
				lv3 = Fluids.WATER;
			} else {
				lv3 = world.getFluidState(lv).getFluid();
			}

			return new PointedDripstoneBlock.DrippingFluid(lv, lv3, lv2);
		});
	}

	private static boolean isFluidLiquid(Fluid fluid) {
		return fluid == Fluids.LAVA || fluid == Fluids.WATER;
	}

	private static boolean canGrow(BlockState dripstoneBlockState, BlockState waterState) {
		return dripstoneBlockState.isOf(Blocks.DRIPSTONE_BLOCK) && waterState.isOf(Blocks.WATER) && waterState.getFluidState().isStill();
	}

	private static Fluid getDripFluid(World world, Fluid fluid) {
		if (fluid.matchesType(Fluids.EMPTY)) {
			return world.getDimension().ultrawarm() ? Fluids.LAVA : Fluids.WATER;
		} else {
			return fluid;
		}
	}

	private static Optional<BlockPos> searchInDirection(
		WorldAccess world, BlockPos pos, AxisDirection direction, BiPredicate<BlockPos, BlockState> continuePredicate, Predicate<BlockState> stopPredicate, int range
	) {
		Direction lv = Direction.get(direction, Axis.Y);
		Mutable lv2 = pos.mutableCopy();

		for (int j = 1; j < range; j++) {
			lv2.move(lv);
			BlockState lv3 = world.getBlockState(lv2);
			if (stopPredicate.test(lv3)) {
				return Optional.of(lv2.toImmutable());
			}

			if (world.isOutOfHeightLimit(lv2.getY()) || !continuePredicate.test(lv2, lv3)) {
				return Optional.empty();
			}
		}

		return Optional.empty();
	}

	private static boolean canDripThrough(BlockView world, BlockPos pos, BlockState state) {
		if (state.isAir()) {
			return true;
		} else if (state.isOpaqueFullCube()) {
			return false;
		} else if (!state.getFluidState().isEmpty()) {
			return false;
		} else {
			VoxelShape lv = state.getCollisionShape(world, pos);
			return !VoxelShapes.matchesAnywhere(DRIP_COLLISION_SHAPE, lv, BooleanBiFunction.AND);
		}
	}

	static record DrippingFluid(BlockPos pos, Fluid fluid, BlockState sourceState) {
	}
}
