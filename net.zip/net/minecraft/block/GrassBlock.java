package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import java.util.List;
import java.util.Optional;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.Fertilizable.FertilizableType;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntry.Reference;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.PlacedFeature;
import net.minecraft.world.gen.feature.RandomPatchFeatureConfig;
import net.minecraft.world.gen.feature.VegetationPlacedFeatures;

public class GrassBlock extends SpreadableBlock implements Fertilizable {
	public static final MapCodec<GrassBlock> CODEC = createCodec(GrassBlock::new);

	@Override
	public MapCodec<GrassBlock> getCodec() {
		return CODEC;
	}

	public GrassBlock(Settings settings) {
		super(settings);
	}

	@Override
	public boolean isFertilizable(WorldView world, BlockPos pos, BlockState state) {
		return world.getBlockState(pos.up()).isAir();
	}

	@Override
	public boolean canGrow(World world, Random random, BlockPos pos, BlockState state) {
		return true;
	}

	@Override
	public void grow(ServerWorld world, Random random, BlockPos pos, BlockState state) {
		BlockPos lv = pos.up();
		BlockState lv2 = Blocks.SHORT_GRASS.getDefaultState();
		Optional<Reference<PlacedFeature>> optional = world.getRegistryManager()
			.getOrThrow(RegistryKeys.PLACED_FEATURE)
			.getOptional(VegetationPlacedFeatures.GRASS_BONEMEAL);

		label51:
		for (int i = 0; i < 128; i++) {
			BlockPos lv3 = lv;

			for (int j = 0; j < i / 16; j++) {
				lv3 = lv3.add(random.nextInt(3) - 1, (random.nextInt(3) - 1) * random.nextInt(3) / 2, random.nextInt(3) - 1);
				if (!world.getBlockState(lv3.down()).isOf(this) || world.getBlockState(lv3).isFullCube(world, lv3)) {
					continue label51;
				}
			}

			BlockState lv4 = world.getBlockState(lv3);
			if (lv4.isOf(lv2.getBlock()) && random.nextInt(10) == 0) {
				Fertilizable lv5 = (Fertilizable)lv2.getBlock();
				if (lv5.isFertilizable(world, lv3, lv4)) {
					lv5.grow(world, random, lv3, lv4);
				}
			}

			if (lv4.isAir()) {
				RegistryEntry<PlacedFeature> lv6;
				if (random.nextInt(8) == 0) {
					List<ConfiguredFeature<?, ?>> list = world.getBiome(lv3).value().getGenerationSettings().getFlowerFeatures();
					if (list.isEmpty()) {
						continue;
					}

					lv6 = ((RandomPatchFeatureConfig)((ConfiguredFeature)list.get(0)).config()).feature();
				} else {
					if (!optional.isPresent()) {
						continue;
					}

					lv6 = (RegistryEntry<PlacedFeature>)optional.get();
				}

				lv6.value().generateUnregistered(world, world.getChunkManager().getChunkGenerator(), random, lv3);
			}
		}
	}

	@Override
	public FertilizableType getFertilizableType() {
		return FertilizableType.NEIGHBOR_SPREADER;
	}
}
