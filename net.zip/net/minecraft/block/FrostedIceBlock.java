package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.minecraft.world.block.WireOrientation;

public class FrostedIceBlock extends IceBlock {
	public static final MapCodec<FrostedIceBlock> CODEC = createCodec(FrostedIceBlock::new);
	public static final int MAX_AGE = 3;
	public static final IntProperty AGE = Properties.AGE_3;
	private static final int NEIGHBORS_CHECKED_ON_SCHEDULED_TICK = 4;
	private static final int NEIGHBORS_CHECKED_ON_NEIGHBOR_UPDATE = 2;

	@Override
	public MapCodec<FrostedIceBlock> getCodec() {
		return CODEC;
	}

	public FrostedIceBlock(Settings settings) {
		super(settings);
		this.setDefaultState(this.stateManager.getDefaultState().with(AGE, Integer.valueOf(0)));
	}

	@Override
	public void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
		world.scheduleBlockTick(pos, this, MathHelper.nextInt(world.getRandom(), 60, 120));
	}

	@Override
	protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		if ((random.nextInt(3) == 0 || this.canMelt(world, pos, 4))
			&& world.getLightLevel(pos) > 11 - (Integer)state.get(AGE) - state.getOpacity()
			&& this.increaseAge(state, world, pos)) {
			Mutable lv = new Mutable();

			for (Direction lv2 : Direction.values()) {
				lv.set(pos, lv2);
				BlockState lv3 = world.getBlockState(lv);
				if (lv3.isOf(this) && !this.increaseAge(lv3, world, lv)) {
					world.scheduleBlockTick(lv, this, MathHelper.nextInt(random, 20, 40));
				}
			}
		} else {
			world.scheduleBlockTick(pos, this, MathHelper.nextInt(random, 20, 40));
		}
	}

	private boolean increaseAge(BlockState state, World world, BlockPos pos) {
		int i = (Integer)state.get(AGE);
		if (i < 3) {
			world.setBlockState(pos, state.with(AGE, Integer.valueOf(i + 1)), 2);
			return false;
		} else {
			this.melt(state, world, pos);
			return true;
		}
	}

	@Override
	protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock, @Nullable WireOrientation wireOrientation, boolean notify) {
		if (sourceBlock.getDefaultState().isOf(this) && this.canMelt(world, pos, 2)) {
			this.melt(state, world, pos);
		}

		super.neighborUpdate(state, world, pos, sourceBlock, wireOrientation, notify);
	}

	private boolean canMelt(BlockView world, BlockPos pos, int maxNeighbors) {
		int j = 0;
		Mutable lv = new Mutable();

		for (Direction lv2 : Direction.values()) {
			lv.set(pos, lv2);
			if (world.getBlockState(lv).isOf(this)) {
				if (++j >= maxNeighbors) {
					return false;
				}
			}
		}

		return true;
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(AGE);
	}

	@Override
	protected ItemStack getPickStack(WorldView world, BlockPos pos, BlockState state, boolean includeData) {
		return ItemStack.EMPTY;
	}
}
