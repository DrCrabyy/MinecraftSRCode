package net.minecraft.block;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import it.unimi.dsi.fastutil.objects.Reference2ObjectArrayMap;
import net.minecraft.block.AbstractBlock.AbstractBlockState;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;

public class BlockState extends AbstractBlockState {
	public static final Codec<BlockState> CODEC = createCodec(Registries.BLOCK.getCodec(), Block::getDefaultState).stable();

	public BlockState(Block block, Reference2ObjectArrayMap<Property<?>, Comparable<?>> propertyMap, MapCodec<BlockState> codec) {
		super(block, propertyMap, codec);
	}

	@Override
	protected BlockState asBlockState() {
		return this;
	}
}
