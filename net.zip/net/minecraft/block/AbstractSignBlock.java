package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import java.util.Arrays;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.block.entity.SignText;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SignChangingItem;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.sound.SoundCategory;
import net.minecraft.stat.Stats;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.text.PlainTextContent;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Util;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.event.GameEvent.Emitter;
import net.minecraft.world.tick.ScheduledTickView;

public abstract class AbstractSignBlock extends BlockWithEntity implements Waterloggable {
	public static final BooleanProperty WATERLOGGED = Properties.WATERLOGGED;
	private static final VoxelShape SHAPE = Block.method_66404(8.0, 0.0, 16.0);
	private final WoodType type;

	protected AbstractSignBlock(WoodType type, Settings settings) {
		super(settings);
		this.type = type;
	}

	@Override
	protected abstract MapCodec<? extends AbstractSignBlock> getCodec();

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		if ((Boolean)state.get(WATERLOGGED)) {
			tickView.scheduleFluidTick(pos, Fluids.WATER, Fluids.WATER.getTickRate(world));
		}

		return super.getStateForNeighborUpdate(state, world, tickView, pos, direction, neighborPos, neighborState, random);
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return SHAPE;
	}

	@Override
	public boolean canMobSpawnInside(BlockState state) {
		return true;
	}

	@Override
	public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
		return new SignBlockEntity(pos, state);
	}

	@Override
	protected ActionResult onUseWithItem(ItemStack stack, BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
		if (world.getBlockEntity(pos) instanceof SignBlockEntity lv) {
			SignChangingItem lv3 = stack.getItem() instanceof SignChangingItem lv2 ? lv2 : null;
			boolean bl = lv3 != null && player.canModifyBlocks();
			if (!world.isClient) {
				if (bl && !lv.isWaxed() && !this.isOtherPlayerEditing(player, lv)) {
					boolean bl2 = lv.isPlayerFacingFront(player);
					if (lv3.canUseOnSignText(lv.getText(bl2), player) && lv3.useOnSign(world, lv, bl2, player)) {
						lv.runCommandClickEvent(player, world, pos, bl2);
						player.incrementStat(Stats.USED.getOrCreateStat(stack.getItem()));
						world.emitGameEvent(GameEvent.BLOCK_CHANGE, lv.getPos(), Emitter.of(player, lv.getCachedState()));
						stack.decrementUnlessCreative(1, player);
						return ActionResult.SUCCESS;
					} else {
						return ActionResult.PASS_TO_DEFAULT_BLOCK_ACTION;
					}
				} else {
					return ActionResult.PASS_TO_DEFAULT_BLOCK_ACTION;
				}
			} else {
				return !bl && !lv.isWaxed() ? ActionResult.CONSUME : ActionResult.SUCCESS;
			}
		} else {
			return ActionResult.PASS;
		}
	}

	@Override
	protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
		if (world.getBlockEntity(pos) instanceof SignBlockEntity lv) {
			if (world.isClient) {
				Util.getFatalOrPause(new IllegalStateException("Expected to only call this on server"));
			}

			boolean bl = lv.isPlayerFacingFront(player);
			boolean bl2 = lv.runCommandClickEvent(player, world, pos, bl);
			if (lv.isWaxed()) {
				world.playSound(null, lv.getPos(), lv.getInteractionFailSound(), SoundCategory.BLOCKS);
				return ActionResult.SUCCESS_SERVER;
			} else if (bl2) {
				return ActionResult.SUCCESS_SERVER;
			} else if (!this.isOtherPlayerEditing(player, lv) && player.canModifyBlocks() && this.isTextLiteralOrEmpty(player, lv, bl)) {
				this.openEditScreen(player, lv, bl);
				return ActionResult.SUCCESS_SERVER;
			} else {
				return ActionResult.PASS;
			}
		} else {
			return ActionResult.PASS;
		}
	}

	private boolean isTextLiteralOrEmpty(PlayerEntity player, SignBlockEntity blockEntity, boolean front) {
		SignText lv = blockEntity.getText(front);
		return Arrays.stream(lv.getMessages(player.shouldFilterText()))
			.allMatch(message -> message.equals(ScreenTexts.EMPTY) || message.getContent() instanceof PlainTextContent);
	}

	public abstract float getRotationDegrees(BlockState state);

	public Vec3d getCenter(BlockState state) {
		return new Vec3d(0.5, 0.5, 0.5);
	}

	@Override
	protected FluidState getFluidState(BlockState state) {
		return state.get(WATERLOGGED) ? Fluids.WATER.getStill(false) : super.getFluidState(state);
	}

	public WoodType getWoodType() {
		return this.type;
	}

	public static WoodType getWoodType(Block block) {
		WoodType lv;
		if (block instanceof AbstractSignBlock) {
			lv = ((AbstractSignBlock)block).getWoodType();
		} else {
			lv = WoodType.OAK;
		}

		return lv;
	}

	public void openEditScreen(PlayerEntity player, SignBlockEntity blockEntity, boolean front) {
		blockEntity.setEditor(player.getUuid());
		player.openEditSignScreen(blockEntity, front);
	}

	private boolean isOtherPlayerEditing(PlayerEntity player, SignBlockEntity blockEntity) {
		UUID uUID = blockEntity.getEditor();
		return uUID != null && !uUID.equals(player.getUuid());
	}

	@Nullable
	@Override
	public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state, BlockEntityType<T> type) {
		return validateTicker(type, BlockEntityType.SIGN, SignBlockEntity::tick);
	}
}
