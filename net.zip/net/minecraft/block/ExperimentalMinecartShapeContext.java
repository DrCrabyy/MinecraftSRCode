package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.enums.RailShape;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.CollisionView;

public class ExperimentalMinecartShapeContext extends EntityShapeContext {
	@Nullable
	private BlockPos belowPos;
	@Nullable
	private BlockPos ascendingPos;

	protected ExperimentalMinecartShapeContext(AbstractMinecartEntity minecart, boolean collidesWithFluid) {
		super(minecart, collidesWithFluid);
		this.setIgnoredPositions(minecart);
	}

	// $VF: Unable to simplify switch on enum
	// Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
	private void setIgnoredPositions(AbstractMinecartEntity minecart) {
		BlockPos lv = minecart.getRailOrMinecartPos();
		BlockState lv2 = minecart.getWorld().getBlockState(lv);
		boolean bl = AbstractRailBlock.isRail(lv2);
		if (bl) {
			this.belowPos = lv.down();
			RailShape lv3 = lv2.get(((AbstractRailBlock)lv2.getBlock()).getShapeProperty());
			if (lv3.isAscending()) {
				this.ascendingPos = switch (lv3) {
					case ASCENDING_EAST -> lv.east();
					case ASCENDING_WEST -> lv.west();
					case ASCENDING_NORTH -> lv.north();
					case ASCENDING_SOUTH -> lv.south();
					default -> null;
				};
			}
		}
	}

	@Override
	public VoxelShape getCollisionShape(BlockState state, CollisionView world, BlockPos pos) {
		return !pos.equals(this.belowPos) && !pos.equals(this.ascendingPos) ? super.getCollisionShape(state, world, pos) : VoxelShapes.empty();
	}
}
