package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Type;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.minecraft.world.tick.ScheduledTickView;

public class ChorusFlowerBlock extends Block {
	public static final MapCodec<ChorusFlowerBlock> CODEC = RecordCodecBuilder.mapCodec(
		instance -> instance.group(Registries.BLOCK.getCodec().fieldOf("plant").forGetter(block -> block.plantBlock), createSettingsCodec())
				.apply(instance, ChorusFlowerBlock::new)
	);
	public static final int MAX_AGE = 5;
	public static final IntProperty AGE = Properties.AGE_5;
	private static final VoxelShape SHAPE = Block.method_66404(14.0, 0.0, 15.0);
	private final Block plantBlock;

	@Override
	public MapCodec<ChorusFlowerBlock> getCodec() {
		return CODEC;
	}

	protected ChorusFlowerBlock(Block plantBlock, Settings settings) {
		super(settings);
		this.plantBlock = plantBlock;
		this.setDefaultState(this.stateManager.getDefaultState().with(AGE, Integer.valueOf(0)));
	}

	@Override
	protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		if (!state.canPlaceAt(world, pos)) {
			world.breakBlock(pos, true);
		}
	}

	@Override
	protected boolean hasRandomTicks(BlockState state) {
		return (Integer)state.get(AGE) < 5;
	}

	@Override
	public VoxelShape getSidesShape(BlockState state, BlockView world, BlockPos pos) {
		return SHAPE;
	}

	@Override
	protected void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		BlockPos lv = pos.up();
		if (world.isAir(lv) && lv.getY() <= world.getTopYInclusive()) {
			int i = (Integer)state.get(AGE);
			if (i < 5) {
				boolean bl = false;
				boolean bl2 = false;
				BlockState lv2 = world.getBlockState(pos.down());
				if (lv2.isOf(Blocks.END_STONE)) {
					bl = true;
				} else if (lv2.isOf(this.plantBlock)) {
					int j = 1;

					for (int k = 0; k < 4; k++) {
						BlockState lv3 = world.getBlockState(pos.down(j + 1));
						if (!lv3.isOf(this.plantBlock)) {
							if (lv3.isOf(Blocks.END_STONE)) {
								bl2 = true;
							}
							break;
						}

						j++;
					}

					if (j < 2 || j <= random.nextInt(bl2 ? 5 : 4)) {
						bl = true;
					}
				} else if (lv2.isAir()) {
					bl = true;
				}

				if (bl && isSurroundedByAir(world, lv, null) && world.isAir(pos.up(2))) {
					world.setBlockState(pos, ChorusPlantBlock.withConnectionProperties(world, pos, this.plantBlock.getDefaultState()), 2);
					this.grow(world, lv, i);
				} else if (i < 4) {
					int j = random.nextInt(4);
					if (bl2) {
						j++;
					}

					boolean bl3 = false;

					for (int l = 0; l < j; l++) {
						Direction lv4 = Type.HORIZONTAL.random(random);
						BlockPos lv5 = pos.offset(lv4);
						if (world.isAir(lv5) && world.isAir(lv5.down()) && isSurroundedByAir(world, lv5, lv4.getOpposite())) {
							this.grow(world, lv5, i + 1);
							bl3 = true;
						}
					}

					if (bl3) {
						world.setBlockState(pos, ChorusPlantBlock.withConnectionProperties(world, pos, this.plantBlock.getDefaultState()), 2);
					} else {
						this.die(world, pos);
					}
				} else {
					this.die(world, pos);
				}
			}
		}
	}

	private void grow(World world, BlockPos pos, int age) {
		world.setBlockState(pos, this.getDefaultState().with(AGE, Integer.valueOf(age)), 2);
		world.syncWorldEvent(1033, pos, 0);
	}

	private void die(World world, BlockPos pos) {
		world.setBlockState(pos, this.getDefaultState().with(AGE, Integer.valueOf(5)), 2);
		world.syncWorldEvent(1034, pos, 0);
	}

	private static boolean isSurroundedByAir(WorldView world, BlockPos pos, @Nullable Direction exceptDirection) {
		for (Direction lv : Type.HORIZONTAL) {
			if (lv != exceptDirection && !world.isAir(pos.offset(lv))) {
				return false;
			}
		}

		return true;
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		if (direction != Direction.UP && !state.canPlaceAt(world, pos)) {
			tickView.scheduleBlockTick(pos, this, 1);
		}

		return super.getStateForNeighborUpdate(state, world, tickView, pos, direction, neighborPos, neighborState, random);
	}

	@Override
	protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
		BlockState lv = world.getBlockState(pos.down());
		if (!lv.isOf(this.plantBlock) && !lv.isOf(Blocks.END_STONE)) {
			if (!lv.isAir()) {
				return false;
			} else {
				boolean bl = false;

				for (Direction lv2 : Type.HORIZONTAL) {
					BlockState lv3 = world.getBlockState(pos.offset(lv2));
					if (lv3.isOf(this.plantBlock)) {
						if (bl) {
							return false;
						}

						bl = true;
					} else if (!lv3.isAir()) {
						return false;
					}
				}

				return bl;
			}
		} else {
			return true;
		}
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(AGE);
	}

	public static void generate(WorldAccess world, BlockPos pos, Random random, int size) {
		world.setBlockState(pos, ChorusPlantBlock.withConnectionProperties(world, pos, Blocks.CHORUS_PLANT.getDefaultState()), 2);
		generate(world, pos, random, pos, size, 0);
	}

	private static void generate(WorldAccess world, BlockPos pos, Random random, BlockPos rootPos, int size, int layer) {
		Block lv = Blocks.CHORUS_PLANT;
		int k = random.nextInt(4) + 1;
		if (layer == 0) {
			k++;
		}

		for (int l = 0; l < k; l++) {
			BlockPos lv2 = pos.up(l + 1);
			if (!isSurroundedByAir(world, lv2, null)) {
				return;
			}

			world.setBlockState(lv2, ChorusPlantBlock.withConnectionProperties(world, lv2, lv.getDefaultState()), 2);
			world.setBlockState(lv2.down(), ChorusPlantBlock.withConnectionProperties(world, lv2.down(), lv.getDefaultState()), 2);
		}

		boolean bl = false;
		if (layer < 4) {
			int m = random.nextInt(4);
			if (layer == 0) {
				m++;
			}

			for (int n = 0; n < m; n++) {
				Direction lv3 = Type.HORIZONTAL.random(random);
				BlockPos lv4 = pos.up(k).offset(lv3);
				if (Math.abs(lv4.getX() - rootPos.getX()) < size
					&& Math.abs(lv4.getZ() - rootPos.getZ()) < size
					&& world.isAir(lv4)
					&& world.isAir(lv4.down())
					&& isSurroundedByAir(world, lv4, lv3.getOpposite())) {
					bl = true;
					world.setBlockState(lv4, ChorusPlantBlock.withConnectionProperties(world, lv4, lv.getDefaultState()), 2);
					world.setBlockState(
						lv4.offset(lv3.getOpposite()), ChorusPlantBlock.withConnectionProperties(world, lv4.offset(lv3.getOpposite()), lv.getDefaultState()), 2
					);
					generate(world, lv4, random, rootPos, size, layer + 1);
				}
			}
		}

		if (!bl) {
			world.setBlockState(pos.up(k), Blocks.CHORUS_FLOWER.getDefaultState().with(AGE, Integer.valueOf(5)), 2);
		}
	}

	@Override
	protected void onProjectileHit(World world, BlockState state, BlockHitResult hit, ProjectileEntity projectile) {
		BlockPos lv = hit.getBlockPos();
		if (world instanceof ServerWorld lv2 && projectile.canModifyAt(lv2, lv) && projectile.canBreakBlocks(lv2)) {
			world.breakBlock(lv, true, projectile);
		}
	}
}
