package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.Property;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldView;
import net.minecraft.world.tick.ScheduledTickView;

public class PaneBlock extends HorizontalConnectingBlock {
	public static final MapCodec<PaneBlock> CODEC = createCodec(PaneBlock::new);

	@Override
	public MapCodec<? extends PaneBlock> getCodec() {
		return CODEC;
	}

	protected PaneBlock(Settings settings) {
		super(2.0F, 16.0F, 2.0F, 16.0F, 16.0F, settings);
		this.setDefaultState(
			this.stateManager
				.getDefaultState()
				.with(NORTH, Boolean.valueOf(false))
				.with(EAST, Boolean.valueOf(false))
				.with(SOUTH, Boolean.valueOf(false))
				.with(WEST, Boolean.valueOf(false))
				.with(WATERLOGGED, Boolean.valueOf(false))
		);
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		BlockView lv = ctx.getWorld();
		BlockPos lv2 = ctx.getBlockPos();
		FluidState lv3 = ctx.getWorld().getFluidState(ctx.getBlockPos());
		BlockPos lv4 = lv2.north();
		BlockPos lv5 = lv2.south();
		BlockPos lv6 = lv2.west();
		BlockPos lv7 = lv2.east();
		BlockState lv8 = lv.getBlockState(lv4);
		BlockState lv9 = lv.getBlockState(lv5);
		BlockState lv10 = lv.getBlockState(lv6);
		BlockState lv11 = lv.getBlockState(lv7);
		return this.getDefaultState()
			.with(NORTH, Boolean.valueOf(this.connectsTo(lv8, lv8.isSideSolidFullSquare(lv, lv4, Direction.SOUTH))))
			.with(SOUTH, Boolean.valueOf(this.connectsTo(lv9, lv9.isSideSolidFullSquare(lv, lv5, Direction.NORTH))))
			.with(WEST, Boolean.valueOf(this.connectsTo(lv10, lv10.isSideSolidFullSquare(lv, lv6, Direction.EAST))))
			.with(EAST, Boolean.valueOf(this.connectsTo(lv11, lv11.isSideSolidFullSquare(lv, lv7, Direction.WEST))))
			.with(WATERLOGGED, Boolean.valueOf(lv3.getFluid() == Fluids.WATER));
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		if ((Boolean)state.get(WATERLOGGED)) {
			tickView.scheduleFluidTick(pos, Fluids.WATER, Fluids.WATER.getTickRate(world));
		}

		return direction.getAxis().isHorizontal()
			? state.with(
				(Property)FACING_PROPERTIES.get(direction),
				Boolean.valueOf(this.connectsTo(neighborState, neighborState.isSideSolidFullSquare(world, neighborPos, direction.getOpposite())))
			)
			: super.getStateForNeighborUpdate(state, world, tickView, pos, direction, neighborPos, neighborState, random);
	}

	@Override
	protected VoxelShape getCameraCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return VoxelShapes.empty();
	}

	@Override
	protected boolean isSideInvisible(BlockState state, BlockState stateFrom, Direction direction) {
		if (stateFrom.isOf(this)) {
			if (!direction.getAxis().isHorizontal()) {
				return true;
			}

			if ((Boolean)state.get((Property)FACING_PROPERTIES.get(direction)) && (Boolean)stateFrom.get((Property)FACING_PROPERTIES.get(direction.getOpposite()))) {
				return true;
			}
		}

		return super.isSideInvisible(state, stateFrom, direction);
	}

	public final boolean connectsTo(BlockState state, boolean sideSolidFullSquare) {
		return !cannotConnect(state) && sideSolidFullSquare || state.getBlock() instanceof PaneBlock || state.isIn(BlockTags.WALLS);
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(NORTH, EAST, WEST, SOUTH, WATERLOGGED);
	}
}
