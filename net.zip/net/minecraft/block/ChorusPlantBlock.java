package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.Property;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Type;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldView;
import net.minecraft.world.tick.ScheduledTickView;

public class ChorusPlantBlock extends ConnectingBlock {
	public static final MapCodec<ChorusPlantBlock> CODEC = createCodec(ChorusPlantBlock::new);

	@Override
	public MapCodec<ChorusPlantBlock> getCodec() {
		return CODEC;
	}

	protected ChorusPlantBlock(Settings settings) {
		super(10.0F, settings);
		this.setDefaultState(
			this.stateManager
				.getDefaultState()
				.with(NORTH, Boolean.valueOf(false))
				.with(EAST, Boolean.valueOf(false))
				.with(SOUTH, Boolean.valueOf(false))
				.with(WEST, Boolean.valueOf(false))
				.with(UP, Boolean.valueOf(false))
				.with(DOWN, Boolean.valueOf(false))
		);
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		return withConnectionProperties(ctx.getWorld(), ctx.getBlockPos(), this.getDefaultState());
	}

	public static BlockState withConnectionProperties(BlockView world, BlockPos pos, BlockState state) {
		BlockState lv = world.getBlockState(pos.down());
		BlockState lv2 = world.getBlockState(pos.up());
		BlockState lv3 = world.getBlockState(pos.north());
		BlockState lv4 = world.getBlockState(pos.east());
		BlockState lv5 = world.getBlockState(pos.south());
		BlockState lv6 = world.getBlockState(pos.west());
		Block lv7 = state.getBlock();
		return state.withIfExists(DOWN, Boolean.valueOf(lv.isOf(lv7) || lv.isOf(Blocks.CHORUS_FLOWER) || lv.isOf(Blocks.END_STONE)))
			.withIfExists(UP, Boolean.valueOf(lv2.isOf(lv7) || lv2.isOf(Blocks.CHORUS_FLOWER)))
			.withIfExists(NORTH, Boolean.valueOf(lv3.isOf(lv7) || lv3.isOf(Blocks.CHORUS_FLOWER)))
			.withIfExists(EAST, Boolean.valueOf(lv4.isOf(lv7) || lv4.isOf(Blocks.CHORUS_FLOWER)))
			.withIfExists(SOUTH, Boolean.valueOf(lv5.isOf(lv7) || lv5.isOf(Blocks.CHORUS_FLOWER)))
			.withIfExists(WEST, Boolean.valueOf(lv6.isOf(lv7) || lv6.isOf(Blocks.CHORUS_FLOWER)));
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		if (!state.canPlaceAt(world, pos)) {
			tickView.scheduleBlockTick(pos, this, 1);
			return super.getStateForNeighborUpdate(state, world, tickView, pos, direction, neighborPos, neighborState, random);
		} else {
			boolean bl = neighborState.isOf(this) || neighborState.isOf(Blocks.CHORUS_FLOWER) || direction == Direction.DOWN && neighborState.isOf(Blocks.END_STONE);
			return state.with((Property)FACING_PROPERTIES.get(direction), Boolean.valueOf(bl));
		}
	}

	@Override
	protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		if (!state.canPlaceAt(world, pos)) {
			world.breakBlock(pos, true);
		}
	}

	@Override
	protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
		BlockState lv = world.getBlockState(pos.down());
		boolean bl = !world.getBlockState(pos.up()).isAir() && !lv.isAir();

		for (Direction lv2 : Type.HORIZONTAL) {
			BlockPos lv3 = pos.offset(lv2);
			BlockState lv4 = world.getBlockState(lv3);
			if (lv4.isOf(this)) {
				if (bl) {
					return false;
				}

				BlockState lv5 = world.getBlockState(lv3.down());
				if (lv5.isOf(this) || lv5.isOf(Blocks.END_STONE)) {
					return true;
				}
			}
		}

		return lv.isOf(this) || lv.isOf(Blocks.END_STONE);
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(NORTH, EAST, SOUTH, WEST, UP, DOWN);
	}

	@Override
	protected boolean canPathfindThrough(BlockState state, NavigationType type) {
		return false;
	}
}
