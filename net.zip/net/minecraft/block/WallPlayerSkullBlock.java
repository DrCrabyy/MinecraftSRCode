package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.SkullBlock.Type;

public class WallPlayerSkullBlock extends WallSkullBlock {
	public static final MapCodec<WallPlayerSkullBlock> CODEC = createCodec(WallPlayerSkullBlock::new);

	@Override
	public MapCodec<WallPlayerSkullBlock> getCodec() {
		return CODEC;
	}

	protected WallPlayerSkullBlock(Settings settings) {
		super(Type.PLAYER, settings);
	}
}
