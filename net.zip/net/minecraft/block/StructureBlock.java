package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.StructureBlockBlockEntity;
import net.minecraft.block.enums.StructureBlockMode;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.block.WireOrientation;

public class StructureBlock extends BlockWithEntity implements OperatorBlock {
	public static final MapCodec<StructureBlock> CODEC = createCodec(StructureBlock::new);
	public static final EnumProperty<StructureBlockMode> MODE = Properties.STRUCTURE_BLOCK_MODE;

	@Override
	public MapCodec<StructureBlock> getCodec() {
		return CODEC;
	}

	protected StructureBlock(Settings settings) {
		super(settings);
		this.setDefaultState(this.stateManager.getDefaultState().with(MODE, StructureBlockMode.LOAD));
	}

	@Override
	public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
		return new StructureBlockBlockEntity(pos, state);
	}

	@Override
	protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
		BlockEntity lv = world.getBlockEntity(pos);
		if (lv instanceof StructureBlockBlockEntity) {
			return (ActionResult)(((StructureBlockBlockEntity)lv).openScreen(player) ? ActionResult.SUCCESS : ActionResult.PASS);
		} else {
			return ActionResult.PASS;
		}
	}

	@Override
	public void onPlaced(World world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack itemStack) {
		if (!world.isClient) {
			if (placer != null) {
				BlockEntity lv = world.getBlockEntity(pos);
				if (lv instanceof StructureBlockBlockEntity) {
					((StructureBlockBlockEntity)lv).setAuthor(placer);
				}
			}
		}
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(MODE);
	}

	@Override
	protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock, @Nullable WireOrientation wireOrientation, boolean notify) {
		if (world instanceof ServerWorld) {
			if (world.getBlockEntity(pos) instanceof StructureBlockBlockEntity lv2) {
				boolean bl2 = world.isReceivingRedstonePower(pos);
				boolean bl3 = lv2.isPowered();
				if (bl2 && !bl3) {
					lv2.setPowered(true);
					this.doAction((ServerWorld)world, lv2);
				} else if (!bl2 && bl3) {
					lv2.setPowered(false);
				}
			}
		}
	}

	private void doAction(ServerWorld world, StructureBlockBlockEntity blockEntity) {
		switch (blockEntity.getMode()) {
			case SAVE:
				blockEntity.saveStructure(false);
				break;
			case LOAD:
				blockEntity.loadAndPlaceStructure(world);
				break;
			case CORNER:
				blockEntity.unloadStructure();
			case DATA:
		}
	}
}
