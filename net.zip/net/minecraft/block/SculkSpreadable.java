package net.minecraft.block;

import java.util.Collection;
import javax.annotation.Nullable;
import net.minecraft.block.entity.SculkSpreadManager;
import net.minecraft.block.entity.SculkSpreadManager.Cursor;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.WorldAccess;

public interface SculkSpreadable {
	SculkSpreadable VEIN_ONLY_SPREADER = new SculkSpreadable$1();

	default byte getUpdate() {
		return 1;
	}

	default void spreadAtSamePosition(WorldAccess world, BlockState state, BlockPos pos, Random random) {
	}

	default boolean method_41470(WorldAccess world, BlockPos pos, Random random) {
		return false;
	}

	default boolean spread(WorldAccess world, BlockPos pos, BlockState state, @Nullable Collection<Direction> directions, boolean markForPostProcessing) {
		// $VF: Couldn't be decompiled
		// Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
		//
		// Bytecode:
		// 00: getstatic net/minecraft/block/Blocks.SCULK_VEIN Lnet/minecraft/block/Block;
		// 03: checkcast net/minecraft/block/MultifaceGrowthBlock
		// 06: invokevirtual net/minecraft/block/MultifaceGrowthBlock.getGrower ()Lnet/minecraft/block/MultifaceGrower;
		// 09: aload 3
		// 0a: aload 1
		// 0b: aload 2
		// 0c: iload 5
		// 0e: invokevirtual net/minecraft/block/MultifaceGrower.grow (Lnet/minecraft/block/BlockState;Lnet/minecraft/world/WorldAccess;Lnet/minecraft/util/math/BlockPos;Z)J
		// 11: lconst_0
		// 12: lcmp
		// 13: ifle 1a
		// 16: bipush 1
		// 17: goto 1b
		// 1a: bipush 0
		// 1b: ireturn
	}

	default boolean shouldConvertToSpreadable() {
		return true;
	}

	default int getDecay(int oldDecay) {
		return 1;
	}

	int spread(Cursor cursor, WorldAccess world, BlockPos catalystPos, Random random, SculkSpreadManager spreadManager, boolean shouldConvertToBlock);
}
