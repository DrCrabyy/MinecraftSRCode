package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.RavagerEntity;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;

public class CropBlock extends PlantBlock implements Fertilizable {
	public static final MapCodec<CropBlock> CODEC = createCodec(CropBlock::new);
	public static final int MAX_AGE = 7;
	public static final IntProperty AGE = Properties.AGE_7;
	private static final VoxelShape[] AGE_TO_SHAPE = Block.method_66397(7, i -> Block.method_66404(16.0, 0.0, (double)(2 + i * 2)));

	@Override
	public MapCodec<? extends CropBlock> getCodec() {
		return CODEC;
	}

	protected CropBlock(Settings settings) {
		super(settings);
		this.setDefaultState(this.stateManager.getDefaultState().with(this.getAgeProperty(), Integer.valueOf(0)));
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return AGE_TO_SHAPE[this.getAge(state)];
	}

	@Override
	protected boolean canPlantOnTop(BlockState floor, BlockView world, BlockPos pos) {
		return floor.isOf(Blocks.FARMLAND);
	}

	protected IntProperty getAgeProperty() {
		return AGE;
	}

	public int getMaxAge() {
		return 7;
	}

	public int getAge(BlockState state) {
		return (Integer)state.get(this.getAgeProperty());
	}

	public BlockState withAge(int age) {
		return this.getDefaultState().with(this.getAgeProperty(), Integer.valueOf(age));
	}

	public final boolean isMature(BlockState state) {
		return this.getAge(state) >= this.getMaxAge();
	}

	@Override
	protected boolean hasRandomTicks(BlockState state) {
		return !this.isMature(state);
	}

	@Override
	protected void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		if (world.getBaseLightLevel(pos, 0) >= 9) {
			int i = this.getAge(state);
			if (i < this.getMaxAge()) {
				float f = getAvailableMoisture(this, world, pos);
				if (random.nextInt((int)(25.0F / f) + 1) == 0) {
					world.setBlockState(pos, this.withAge(i + 1), 2);
				}
			}
		}
	}

	public void applyGrowth(World world, BlockPos pos, BlockState state) {
		int i = Math.min(this.getMaxAge(), this.getAge(state) + this.getGrowthAmount(world));
		world.setBlockState(pos, this.withAge(i), 2);
	}

	protected int getGrowthAmount(World world) {
		return MathHelper.nextInt(world.random, 2, 5);
	}

	protected static float getAvailableMoisture(Block block, BlockView world, BlockPos pos) {
		float f = 1.0F;
		BlockPos lv = pos.down();

		for (int i = -1; i <= 1; i++) {
			for (int j = -1; j <= 1; j++) {
				float g = 0.0F;
				BlockState lv2 = world.getBlockState(lv.add(i, 0, j));
				if (lv2.isOf(Blocks.FARMLAND)) {
					g = 1.0F;
					if ((Integer)lv2.get(FarmlandBlock.MOISTURE) > 0) {
						g = 3.0F;
					}
				}

				if (i != 0 || j != 0) {
					g /= 4.0F;
				}

				f += g;
			}
		}

		BlockPos lv3 = pos.north();
		BlockPos lv4 = pos.south();
		BlockPos lv5 = pos.west();
		BlockPos lv6 = pos.east();
		boolean bl = world.getBlockState(lv5).isOf(block) || world.getBlockState(lv6).isOf(block);
		boolean bl2 = world.getBlockState(lv3).isOf(block) || world.getBlockState(lv4).isOf(block);
		if (bl && bl2) {
			f /= 2.0F;
		} else {
			boolean bl3 = world.getBlockState(lv5.north()).isOf(block)
				|| world.getBlockState(lv6.north()).isOf(block)
				|| world.getBlockState(lv6.south()).isOf(block)
				|| world.getBlockState(lv5.south()).isOf(block);
			if (bl3) {
				f /= 2.0F;
			}
		}

		return f;
	}

	@Override
	protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
		return hasEnoughLightAt(world, pos) && super.canPlaceAt(state, world, pos);
	}

	protected static boolean hasEnoughLightAt(WorldView world, BlockPos pos) {
		return world.getBaseLightLevel(pos, 0) >= 8;
	}

	@Override
	protected void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
		if (world instanceof ServerWorld lv && entity instanceof RavagerEntity && lv.getGameRules().getBoolean(GameRules.DO_MOB_GRIEFING)) {
			lv.breakBlock(pos, true, entity);
		}

		super.onEntityCollision(state, world, pos, entity);
	}

	protected ItemConvertible getSeedsItem() {
		return Items.WHEAT_SEEDS;
	}

	@Override
	protected ItemStack getPickStack(WorldView world, BlockPos pos, BlockState state, boolean includeData) {
		return new ItemStack(this.getSeedsItem());
	}

	@Override
	public boolean isFertilizable(WorldView world, BlockPos pos, BlockState state) {
		return !this.isMature(state);
	}

	@Override
	public boolean canGrow(World world, Random random, BlockPos pos, BlockState state) {
		return true;
	}

	@Override
	public void grow(ServerWorld world, Random random, BlockPos pos, BlockState state) {
		this.applyGrowth(world, pos, state);
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(AGE);
	}
}
