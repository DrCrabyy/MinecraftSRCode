package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.RedstoneView;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.minecraft.world.block.OrientationHelper;
import net.minecraft.world.block.WireOrientation;
import net.minecraft.world.tick.TickPriority;

public abstract class AbstractRedstoneGateBlock extends HorizontalFacingBlock {
	public static final BooleanProperty POWERED = Properties.POWERED;
	private static final VoxelShape SHAPE = Block.method_66404(16.0, 0.0, 2.0);

	protected AbstractRedstoneGateBlock(Settings settings) {
		super(settings);
	}

	@Override
	protected abstract MapCodec<? extends AbstractRedstoneGateBlock> getCodec();

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return SHAPE;
	}

	@Override
	protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
		BlockPos lv = pos.down();
		return this.canPlaceAbove(world, lv, world.getBlockState(lv));
	}

	protected boolean canPlaceAbove(WorldView world, BlockPos pos, BlockState state) {
		return state.isSideSolid(world, pos, Direction.UP, SideShapeType.RIGID);
	}

	@Override
	protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		if (!this.isLocked(world, pos, state)) {
			boolean bl = (Boolean)state.get(POWERED);
			boolean bl2 = this.hasPower(world, pos, state);
			if (bl && !bl2) {
				world.setBlockState(pos, state.with(POWERED, Boolean.valueOf(false)), 2);
			} else if (!bl) {
				world.setBlockState(pos, state.with(POWERED, Boolean.valueOf(true)), 2);
				if (!bl2) {
					world.scheduleBlockTick(pos, this, this.getUpdateDelayInternal(state), TickPriority.VERY_HIGH);
				}
			}
		}
	}

	@Override
	protected int getStrongRedstonePower(BlockState state, BlockView world, BlockPos pos, Direction direction) {
		return state.getWeakRedstonePower(world, pos, direction);
	}

	@Override
	protected int getWeakRedstonePower(BlockState state, BlockView world, BlockPos pos, Direction direction) {
		if (!(Boolean)state.get(POWERED)) {
			return 0;
		} else {
			return state.get(FACING) == direction ? this.getOutputLevel(world, pos, state) : 0;
		}
	}

	@Override
	protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock, @Nullable WireOrientation wireOrientation, boolean notify) {
		if (state.canPlaceAt(world, pos)) {
			this.updatePowered(world, pos, state);
		} else {
			BlockEntity lv = state.hasBlockEntity() ? world.getBlockEntity(pos) : null;
			dropStacks(state, world, pos, lv);
			world.removeBlock(pos, false);

			for (Direction lv2 : Direction.values()) {
				world.updateNeighbors(pos.offset(lv2), this);
			}
		}
	}

	protected void updatePowered(World world, BlockPos pos, BlockState state) {
		if (!this.isLocked(world, pos, state)) {
			boolean bl = (Boolean)state.get(POWERED);
			boolean bl2 = this.hasPower(world, pos, state);
			if (bl != bl2 && !world.getBlockTickScheduler().isTicking(pos, this)) {
				TickPriority lv = TickPriority.HIGH;
				if (this.isTargetNotAligned(world, pos, state)) {
					lv = TickPriority.EXTREMELY_HIGH;
				} else if (bl) {
					lv = TickPriority.VERY_HIGH;
				}

				world.scheduleBlockTick(pos, this, this.getUpdateDelayInternal(state), lv);
			}
		}
	}

	public boolean isLocked(WorldView world, BlockPos pos, BlockState state) {
		return false;
	}

	protected boolean hasPower(World world, BlockPos pos, BlockState state) {
		return this.getPower(world, pos, state) > 0;
	}

	protected int getPower(World world, BlockPos pos, BlockState state) {
		Direction lv = state.get(FACING);
		BlockPos lv2 = pos.offset(lv);
		int i = world.getEmittedRedstonePower(lv2, lv);
		if (i >= 15) {
			return i;
		} else {
			BlockState lv3 = world.getBlockState(lv2);
			return Math.max(i, lv3.isOf(Blocks.REDSTONE_WIRE) ? (Integer)lv3.get(RedstoneWireBlock.POWER) : 0);
		}
	}

	protected int getMaxInputLevelSides(RedstoneView world, BlockPos pos, BlockState state) {
		Direction lv = state.get(FACING);
		Direction lv2 = lv.rotateYClockwise();
		Direction lv3 = lv.rotateYCounterclockwise();
		boolean bl = this.getSideInputFromGatesOnly();
		return Math.max(world.getEmittedRedstonePower(pos.offset(lv2), lv2, bl), world.getEmittedRedstonePower(pos.offset(lv3), lv3, bl));
	}

	@Override
	protected boolean emitsRedstonePower(BlockState state) {
		return true;
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		return this.getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite());
	}

	@Override
	public void onPlaced(World world, BlockPos pos, BlockState state, LivingEntity placer, ItemStack itemStack) {
		if (this.hasPower(world, pos, state)) {
			world.scheduleBlockTick(pos, this, 1);
		}
	}

	@Override
	protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
		this.updateTarget(world, pos, state);
	}

	@Override
	protected void onStateReplaced(BlockState state, ServerWorld world, BlockPos pos, boolean moved) {
		if (!moved) {
			this.updateTarget(world, pos, state);
		}
	}

	protected void updateTarget(World world, BlockPos pos, BlockState state) {
		Direction lv = state.get(FACING);
		BlockPos lv2 = pos.offset(lv.getOpposite());
		WireOrientation lv3 = OrientationHelper.getEmissionOrientation(world, lv.getOpposite(), Direction.UP);
		world.updateNeighbor(lv2, this, lv3);
		world.updateNeighborsExcept(lv2, this, lv, lv3);
	}

	protected boolean getSideInputFromGatesOnly() {
		return false;
	}

	protected int getOutputLevel(BlockView world, BlockPos pos, BlockState state) {
		return 15;
	}

	public static boolean isRedstoneGate(BlockState state) {
		return state.getBlock() instanceof AbstractRedstoneGateBlock;
	}

	public boolean isTargetNotAligned(BlockView world, BlockPos pos, BlockState state) {
		Direction lv = ((Direction)state.get(FACING)).getOpposite();
		BlockState lv2 = world.getBlockState(pos.offset(lv));
		return isRedstoneGate(lv2) && lv2.get(FACING) != lv;
	}

	protected abstract int getUpdateDelayInternal(BlockState state);
}
