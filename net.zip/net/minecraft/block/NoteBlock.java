package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.block.enums.NoteBlockInstrument;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.stat.Stats;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.minecraft.world.block.WireOrientation;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.tick.ScheduledTickView;

public class NoteBlock extends Block {
	public static final MapCodec<NoteBlock> CODEC = createCodec(NoteBlock::new);
	public static final EnumProperty<NoteBlockInstrument> INSTRUMENT = Properties.INSTRUMENT;
	public static final BooleanProperty POWERED = Properties.POWERED;
	public static final IntProperty NOTE = Properties.NOTE;
	public static final int field_41678 = 3;

	@Override
	public MapCodec<NoteBlock> getCodec() {
		return CODEC;
	}

	public NoteBlock(Settings settings) {
		super(settings);
		this.setDefaultState(
			this.stateManager.getDefaultState().with(INSTRUMENT, NoteBlockInstrument.HARP).with(NOTE, Integer.valueOf(0)).with(POWERED, Boolean.valueOf(false))
		);
	}

	private BlockState getStateWithInstrument(WorldView world, BlockPos pos, BlockState state) {
		NoteBlockInstrument lv = world.getBlockState(pos.up()).getInstrument();
		if (lv.isNotBaseBlock()) {
			return state.with(INSTRUMENT, lv);
		} else {
			NoteBlockInstrument lv2 = world.getBlockState(pos.down()).getInstrument();
			NoteBlockInstrument lv3 = lv2.isNotBaseBlock() ? NoteBlockInstrument.HARP : lv2;
			return state.with(INSTRUMENT, lv3);
		}
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		return this.getStateWithInstrument(ctx.getWorld(), ctx.getBlockPos(), this.getDefaultState());
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		boolean bl = direction.getAxis() == Axis.Y;
		return bl
			? this.getStateWithInstrument(world, pos, state)
			: super.getStateForNeighborUpdate(state, world, tickView, pos, direction, neighborPos, neighborState, random);
	}

	@Override
	protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock, @Nullable WireOrientation wireOrientation, boolean notify) {
		boolean bl2 = world.isReceivingRedstonePower(pos);
		if (bl2 != (Boolean)state.get(POWERED)) {
			if (bl2) {
				this.playNote(null, state, world, pos);
			}

			world.setBlockState(pos, state.with(POWERED, Boolean.valueOf(bl2)), 3);
		}
	}

	private void playNote(@Nullable Entity entity, BlockState state, World world, BlockPos pos) {
		if (((NoteBlockInstrument)state.get(INSTRUMENT)).isNotBaseBlock() || world.getBlockState(pos.up()).isAir()) {
			world.addSyncedBlockEvent(pos, this, 0, 0);
			world.emitGameEvent(entity, GameEvent.NOTE_BLOCK_PLAY, pos);
		}
	}

	@Override
	protected ActionResult onUseWithItem(ItemStack stack, BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
		return (ActionResult)(stack.isIn(ItemTags.NOTEBLOCK_TOP_INSTRUMENTS) && hit.getSide() == Direction.UP
			? ActionResult.PASS
			: super.onUseWithItem(stack, state, world, pos, player, hand, hit));
	}

	@Override
	protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
		if (!world.isClient) {
			state = state.cycle(NOTE);
			world.setBlockState(pos, state, 3);
			this.playNote(player, state, world, pos);
			player.incrementStat(Stats.TUNE_NOTEBLOCK);
		}

		return ActionResult.SUCCESS;
	}

	@Override
	protected void onBlockBreakStart(BlockState state, World world, BlockPos pos, PlayerEntity player) {
		if (!world.isClient) {
			this.playNote(player, state, world, pos);
			player.incrementStat(Stats.PLAY_NOTEBLOCK);
		}
	}

	public static float getNotePitch(int note) {
		return (float)Math.pow(2.0, (double)(note - 12) / 12.0);
	}

	@Override
	protected boolean onSyncedBlockEvent(BlockState state, World world, BlockPos pos, int type, int data) {
		NoteBlockInstrument lv = state.get(INSTRUMENT);
		float f;
		if (lv.canBePitched()) {
			int k = (Integer)state.get(NOTE);
			f = getNotePitch(k);
			world.addParticleClient(ParticleTypes.NOTE, (double)pos.getX() + 0.5, (double)pos.getY() + 1.2, (double)pos.getZ() + 0.5, (double)k / 24.0, 0.0, 0.0);
		} else {
			f = 1.0F;
		}

		RegistryEntry<SoundEvent> lv3;
		if (lv.hasCustomSound()) {
			Identifier lv2 = this.getCustomSound(world, pos);
			if (lv2 == null) {
				return false;
			}

			lv3 = RegistryEntry.of(SoundEvent.of(lv2));
		} else {
			lv3 = lv.getSound();
		}

		world.playSound(
			null, (double)pos.getX() + 0.5, (double)pos.getY() + 0.5, (double)pos.getZ() + 0.5, lv3, SoundCategory.RECORDS, 3.0F, f, world.random.nextLong()
		);
		return true;
	}

	@Nullable
	private Identifier getCustomSound(World world, BlockPos pos) {
		return world.getBlockEntity(pos.up()) instanceof SkullBlockEntity lv ? lv.getNoteBlockSound() : null;
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(INSTRUMENT, POWERED, NOTE);
	}
}
