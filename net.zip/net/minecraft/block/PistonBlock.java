package net.minecraft.block;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.PistonBlockEntity;
import net.minecraft.block.enums.PistonType;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.block.piston.PistonHandler;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.RedstoneView;
import net.minecraft.world.World;
import net.minecraft.world.block.OrientationHelper;
import net.minecraft.world.block.WireOrientation;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.event.GameEvent.Emitter;

public class PistonBlock extends FacingBlock {
	public static final MapCodec<PistonBlock> CODEC = RecordCodecBuilder.mapCodec(
		instance -> instance.group(Codec.BOOL.fieldOf("sticky").forGetter(block -> block.sticky), createSettingsCodec()).apply(instance, PistonBlock::new)
	);
	public static final BooleanProperty EXTENDED = Properties.EXTENDED;
	public static final int field_31373 = 0;
	public static final int field_31374 = 1;
	public static final int field_31375 = 2;
	public static final int field_31376 = 4;
	private static final Map<Direction, VoxelShape> field_55824 = VoxelShapes.method_66504(Block.method_66408(16.0, 4.0, 16.0));
	private final boolean sticky;

	@Override
	public MapCodec<PistonBlock> getCodec() {
		return CODEC;
	}

	public PistonBlock(boolean sticky, Settings settings) {
		super(settings);
		this.setDefaultState(this.stateManager.getDefaultState().with(FACING, Direction.NORTH).with(EXTENDED, Boolean.valueOf(false)));
		this.sticky = sticky;
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return state.get(EXTENDED) ? (VoxelShape)field_55824.get(state.get(FACING)) : VoxelShapes.fullCube();
	}

	@Override
	public void onPlaced(World world, BlockPos pos, BlockState state, LivingEntity placer, ItemStack itemStack) {
		if (!world.isClient) {
			this.tryMove(world, pos, state);
		}
	}

	@Override
	protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock, @Nullable WireOrientation wireOrientation, boolean notify) {
		if (!world.isClient) {
			this.tryMove(world, pos, state);
		}
	}

	@Override
	protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
		if (!oldState.isOf(state.getBlock())) {
			if (!world.isClient && world.getBlockEntity(pos) == null) {
				this.tryMove(world, pos, state);
			}
		}
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		return this.getDefaultState().with(FACING, ctx.getPlayerLookDirection().getOpposite()).with(EXTENDED, Boolean.valueOf(false));
	}

	private void tryMove(World world, BlockPos pos, BlockState state) {
		Direction lv = state.get(FACING);
		boolean bl = this.shouldExtend(world, pos, lv);
		if (bl && !(Boolean)state.get(EXTENDED)) {
			if (new PistonHandler(world, pos, lv, true).calculatePush()) {
				world.addSyncedBlockEvent(pos, this, 0, lv.getId());
			}
		} else if (!bl && (Boolean)state.get(EXTENDED)) {
			BlockPos lv2 = pos.offset(lv, 2);
			BlockState lv3 = world.getBlockState(lv2);
			int i = 1;
			if (lv3.isOf(Blocks.MOVING_PISTON)
				&& lv3.get(FACING) == lv
				&& world.getBlockEntity(lv2) instanceof PistonBlockEntity lv5
				&& lv5.isExtending()
				&& (lv5.getProgress(0.0F) < 0.5F || world.getTime() == lv5.getSavedWorldTime() || ((ServerWorld)world).isInBlockTick())) {
				i = 2;
			}

			world.addSyncedBlockEvent(pos, this, i, lv.getId());
		}
	}

	private boolean shouldExtend(RedstoneView world, BlockPos pos, Direction pistonFace) {
		for (Direction lv : Direction.values()) {
			if (lv != pistonFace && world.isEmittingRedstonePower(pos.offset(lv), lv)) {
				return true;
			}
		}

		if (world.isEmittingRedstonePower(pos, Direction.DOWN)) {
			return true;
		} else {
			BlockPos lv2 = pos.up();

			for (Direction lv3 : Direction.values()) {
				if (lv3 != Direction.DOWN && world.isEmittingRedstonePower(lv2.offset(lv3), lv3)) {
					return true;
				}
			}

			return false;
		}
	}

	@Override
	protected boolean onSyncedBlockEvent(BlockState state, World world, BlockPos pos, int type, int data) {
		Direction lv = state.get(FACING);
		BlockState lv2 = state.with(EXTENDED, Boolean.valueOf(true));
		if (!world.isClient) {
			boolean bl = this.shouldExtend(world, pos, lv);
			if (bl && (type == 1 || type == 2)) {
				world.setBlockState(pos, lv2, 2);
				return false;
			}

			if (!bl && type == 0) {
				return false;
			}
		}

		if (type == 0) {
			if (!this.move(world, pos, lv, true)) {
				return false;
			}

			world.setBlockState(pos, lv2, 67);
			world.playSound(null, pos, SoundEvents.BLOCK_PISTON_EXTEND, SoundCategory.BLOCKS, 0.5F, world.random.nextFloat() * 0.25F + 0.6F);
			world.emitGameEvent(GameEvent.BLOCK_ACTIVATE, pos, Emitter.of(lv2));
		} else if (type == 1 || type == 2) {
			BlockEntity lv3 = world.getBlockEntity(pos.offset(lv));
			if (lv3 instanceof PistonBlockEntity) {
				((PistonBlockEntity)lv3).finish();
			}

			BlockState lv4 = Blocks.MOVING_PISTON
				.getDefaultState()
				.with(PistonExtensionBlock.FACING, lv)
				.with(PistonExtensionBlock.TYPE, this.sticky ? PistonType.STICKY : PistonType.DEFAULT);
			world.setBlockState(pos, lv4, 276);
			world.addBlockEntity(PistonExtensionBlock.createBlockEntityPiston(pos, lv4, this.getDefaultState().with(FACING, Direction.byId(data & 7)), lv, false, true));
			world.updateNeighbors(pos, lv4.getBlock());
			lv4.updateNeighbors(world, pos, 2);
			if (this.sticky) {
				BlockPos lv5 = pos.add(lv.getOffsetX() * 2, lv.getOffsetY() * 2, lv.getOffsetZ() * 2);
				BlockState lv6 = world.getBlockState(lv5);
				boolean bl2 = false;
				if (lv6.isOf(Blocks.MOVING_PISTON) && world.getBlockEntity(lv5) instanceof PistonBlockEntity lv8 && lv8.getFacing() == lv && lv8.isExtending()) {
					lv8.finish();
					bl2 = true;
				}

				if (!bl2) {
					if (type != 1
						|| lv6.isAir()
						|| !isMovable(lv6, world, lv5, lv.getOpposite(), false, lv)
						|| lv6.getPistonBehavior() != PistonBehavior.NORMAL && !lv6.isOf(Blocks.PISTON) && !lv6.isOf(Blocks.STICKY_PISTON)) {
						world.removeBlock(pos.offset(lv), false);
					} else {
						this.move(world, pos, lv, false);
					}
				}
			} else {
				world.removeBlock(pos.offset(lv), false);
			}

			world.playSound(null, pos, SoundEvents.BLOCK_PISTON_CONTRACT, SoundCategory.BLOCKS, 0.5F, world.random.nextFloat() * 0.15F + 0.6F);
			world.emitGameEvent(GameEvent.BLOCK_DEACTIVATE, pos, Emitter.of(lv4));
		}

		return true;
	}

	public static boolean isMovable(BlockState state, World world, BlockPos pos, Direction direction, boolean canBreak, Direction pistonDir) {
		if (pos.getY() < world.getBottomY() || pos.getY() > world.getTopYInclusive() || !world.getWorldBorder().contains(pos)) {
			return false;
		} else if (state.isAir()) {
			return true;
		} else if (state.isOf(Blocks.OBSIDIAN) || state.isOf(Blocks.CRYING_OBSIDIAN) || state.isOf(Blocks.RESPAWN_ANCHOR) || state.isOf(Blocks.REINFORCED_DEEPSLATE)) {
			return false;
		} else if (direction == Direction.DOWN && pos.getY() == world.getBottomY()) {
			return false;
		} else if (direction == Direction.UP && pos.getY() == world.getTopYInclusive()) {
			return false;
		} else {
			if (!state.isOf(Blocks.PISTON) && !state.isOf(Blocks.STICKY_PISTON)) {
				if (state.getHardness(world, pos) == -1.0F) {
					return false;
				}

				switch (state.getPistonBehavior()) {
					case BLOCK:
						return false;
					case DESTROY:
						return canBreak;
					case PUSH_ONLY:
						return direction == pistonDir;
				}
			} else if ((Boolean)state.get(EXTENDED)) {
				return false;
			}

			return !state.hasBlockEntity();
		}
	}

	private boolean move(World world, BlockPos pos, Direction dir, boolean extend) {
		BlockPos lv = pos.offset(dir);
		if (!extend && world.getBlockState(lv).isOf(Blocks.PISTON_HEAD)) {
			world.setBlockState(lv, Blocks.AIR.getDefaultState(), 276);
		}

		PistonHandler lv2 = new PistonHandler(world, pos, dir, extend);
		if (!lv2.calculatePush()) {
			return false;
		} else {
			Map<BlockPos, BlockState> map = Maps.newHashMap();
			List<BlockPos> list = lv2.getMovedBlocks();
			List<BlockState> list2 = Lists.newArrayList();

			for (BlockPos lv3 : list) {
				BlockState lv4 = world.getBlockState(lv3);
				list2.add(lv4);
				map.put(lv3, lv4);
			}

			List<BlockPos> list3 = lv2.getBrokenBlocks();
			BlockState[] lvs = new BlockState[list.size() + list3.size()];
			Direction lv5 = extend ? dir : dir.getOpposite();
			int i = 0;

			for (int j = list3.size() - 1; j >= 0; j--) {
				BlockPos lv6 = (BlockPos)list3.get(j);
				BlockState lv7 = world.getBlockState(lv6);
				BlockEntity lv8 = lv7.hasBlockEntity() ? world.getBlockEntity(lv6) : null;
				dropStacks(lv7, world, lv6, lv8);
				world.setBlockState(lv6, Blocks.AIR.getDefaultState(), 18);
				world.emitGameEvent(GameEvent.BLOCK_DESTROY, lv6, Emitter.of(lv7));
				if (!lv7.isIn(BlockTags.FIRE)) {
					world.addBlockBreakParticles(lv6, lv7);
				}

				lvs[i++] = lv7;
			}

			for (int j = list.size() - 1; j >= 0; j--) {
				BlockPos lv6 = (BlockPos)list.get(j);
				BlockState lv7 = world.getBlockState(lv6);
				lv6 = lv6.offset(lv5);
				map.remove(lv6);
				BlockState lv9 = Blocks.MOVING_PISTON.getDefaultState().with(FACING, dir);
				world.setBlockState(lv6, lv9, 324);
				world.addBlockEntity(PistonExtensionBlock.createBlockEntityPiston(lv6, lv9, (BlockState)list2.get(j), dir, extend, false));
				lvs[i++] = lv7;
			}

			if (extend) {
				PistonType lv10 = this.sticky ? PistonType.STICKY : PistonType.DEFAULT;
				BlockState lv11 = Blocks.PISTON_HEAD.getDefaultState().with(PistonHeadBlock.FACING, dir).with(PistonHeadBlock.TYPE, lv10);
				BlockState lv7 = Blocks.MOVING_PISTON
					.getDefaultState()
					.with(PistonExtensionBlock.FACING, dir)
					.with(PistonExtensionBlock.TYPE, this.sticky ? PistonType.STICKY : PistonType.DEFAULT);
				map.remove(lv);
				world.setBlockState(lv, lv7, 324);
				world.addBlockEntity(PistonExtensionBlock.createBlockEntityPiston(lv, lv7, lv11, dir, true, true));
			}

			BlockState lv12 = Blocks.AIR.getDefaultState();

			for (BlockPos lv13 : map.keySet()) {
				world.setBlockState(lv13, lv12, 82);
			}

			for (Entry<BlockPos, BlockState> entry : map.entrySet()) {
				BlockPos lv14 = (BlockPos)entry.getKey();
				BlockState lv15 = (BlockState)entry.getValue();
				lv15.prepare(world, lv14, 2);
				lv12.updateNeighbors(world, lv14, 2);
				lv12.prepare(world, lv14, 2);
			}

			WireOrientation lv16 = OrientationHelper.getEmissionOrientation(world, lv2.getMotionDirection(), null);
			i = 0;

			for (int k = list3.size() - 1; k >= 0; k--) {
				BlockState lv9 = lvs[i++];
				BlockPos lv17 = (BlockPos)list3.get(k);
				lv9.prepare(world, lv17, 2);
				world.updateNeighborsAlways(lv17, lv9.getBlock(), lv16);
			}

			for (int k = list.size() - 1; k >= 0; k--) {
				world.updateNeighborsAlways((BlockPos)list.get(k), lvs[i++].getBlock(), lv16);
			}

			if (extend) {
				world.updateNeighborsAlways(lv, Blocks.PISTON_HEAD, lv16);
			}

			return true;
		}
	}

	@Override
	protected BlockState rotate(BlockState state, BlockRotation rotation) {
		return state.with(FACING, rotation.rotate(state.get(FACING)));
	}

	@Override
	protected BlockState mirror(BlockState state, BlockMirror mirror) {
		return state.rotate(mirror.getRotation(state.get(FACING)));
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(FACING, EXTENDED);
	}

	@Override
	protected boolean hasSidedTransparency(BlockState state) {
		return (Boolean)state.get(EXTENDED);
	}

	@Override
	protected boolean canPathfindThrough(BlockState state, NavigationType type) {
		return false;
	}
}
