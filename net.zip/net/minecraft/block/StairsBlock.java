package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Map;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.enums.BlockHalf;
import net.minecraft.block.enums.StairShape;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.DirectionTransformation;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldView;
import net.minecraft.world.tick.ScheduledTickView;

public class StairsBlock extends Block implements Waterloggable {
	public static final MapCodec<StairsBlock> CODEC = RecordCodecBuilder.mapCodec(
		instance -> instance.group(BlockState.CODEC.fieldOf("base_state").forGetter(block -> block.baseBlockState), createSettingsCodec())
				.apply(instance, StairsBlock::new)
	);
	public static final EnumProperty<Direction> FACING = HorizontalFacingBlock.FACING;
	public static final EnumProperty<BlockHalf> HALF = Properties.BLOCK_HALF;
	public static final EnumProperty<StairShape> SHAPE = Properties.STAIR_SHAPE;
	public static final BooleanProperty WATERLOGGED = Properties.WATERLOGGED;
	private static final VoxelShape field_55801 = VoxelShapes.union(Block.method_66404(16.0, 0.0, 8.0), Block.createCuboidShape(0.0, 8.0, 0.0, 8.0, 16.0, 8.0));
	private static final VoxelShape field_55802 = VoxelShapes.union(
		field_55801, VoxelShapes.method_66496(field_55801, DirectionTransformation.method_66543(0, 90))
	);
	private static final VoxelShape field_55803 = VoxelShapes.union(
		field_55802, VoxelShapes.method_66496(field_55802, DirectionTransformation.method_66543(0, 90))
	);
	private static final Map<Direction, VoxelShape> field_55795 = VoxelShapes.method_66501(field_55801);
	private static final Map<Direction, VoxelShape> field_55796 = VoxelShapes.method_66501(field_55802);
	private static final Map<Direction, VoxelShape> field_55797 = VoxelShapes.method_66501(field_55803);
	private static final Map<Direction, VoxelShape> field_55798 = VoxelShapes.method_66501(VoxelShapes.method_66496(field_55801, DirectionTransformation.INVERT_Y));
	private static final Map<Direction, VoxelShape> field_55799 = VoxelShapes.method_66501(VoxelShapes.method_66496(field_55802, DirectionTransformation.INVERT_Y));
	private static final Map<Direction, VoxelShape> field_55800 = VoxelShapes.method_66501(VoxelShapes.method_66496(field_55803, DirectionTransformation.INVERT_Y));
	private final Block baseBlock;
	protected final BlockState baseBlockState;

	@Override
	public MapCodec<? extends StairsBlock> getCodec() {
		return CODEC;
	}

	protected StairsBlock(BlockState baseBlockState, Settings settings) {
		super(settings);
		this.setDefaultState(
			this.stateManager
				.getDefaultState()
				.with(FACING, Direction.NORTH)
				.with(HALF, BlockHalf.BOTTOM)
				.with(SHAPE, StairShape.STRAIGHT)
				.with(WATERLOGGED, Boolean.valueOf(false))
		);
		this.baseBlock = baseBlockState.getBlock();
		this.baseBlockState = baseBlockState;
	}

	@Override
	protected boolean hasSidedTransparency(BlockState state) {
		return true;
	}

	// $VF: Unable to simplify switch on enum
	// Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		boolean bl = state.get(HALF) == BlockHalf.BOTTOM;
		Direction lv = state.get(FACING);

		Map var10000 = switch ((StairShape)state.get(SHAPE)) {
			case STRAIGHT -> bl ? field_55796 : field_55799;
			case OUTER_LEFT, OUTER_RIGHT -> bl ? field_55795 : field_55798;
			case INNER_RIGHT, INNER_LEFT -> bl ? field_55797 : field_55800;
			default -> throw new MatchException(null, null);
		};

		return (VoxelShape)var10000.get(switch ((StairShape)state.get(SHAPE)) {
			case STRAIGHT, OUTER_LEFT, INNER_RIGHT -> lv;
			case INNER_LEFT -> lv.rotateYCounterclockwise();
			case OUTER_RIGHT -> lv.rotateYClockwise();
			default -> throw new MatchException(null, null);
		});
	}

	@Override
	public float getBlastResistance() {
		return this.baseBlock.getBlastResistance();
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		Direction lv = ctx.getSide();
		BlockPos lv2 = ctx.getBlockPos();
		FluidState lv3 = ctx.getWorld().getFluidState(lv2);
		BlockState lv4 = this.getDefaultState()
			.with(FACING, ctx.getHorizontalPlayerFacing())
			.with(HALF, lv != Direction.DOWN && (lv == Direction.UP || !(ctx.getHitPos().y - (double)lv2.getY() > 0.5)) ? BlockHalf.BOTTOM : BlockHalf.TOP)
			.with(WATERLOGGED, Boolean.valueOf(lv3.getFluid() == Fluids.WATER));
		return lv4.with(SHAPE, getStairShape(lv4, ctx.getWorld(), lv2));
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		if ((Boolean)state.get(WATERLOGGED)) {
			tickView.scheduleFluidTick(pos, Fluids.WATER, Fluids.WATER.getTickRate(world));
		}

		return direction.getAxis().isHorizontal()
			? state.with(SHAPE, getStairShape(state, world, pos))
			: super.getStateForNeighborUpdate(state, world, tickView, pos, direction, neighborPos, neighborState, random);
	}

	private static StairShape getStairShape(BlockState state, BlockView world, BlockPos pos) {
		Direction lv = state.get(FACING);
		BlockState lv2 = world.getBlockState(pos.offset(lv));
		if (isStairs(lv2) && state.get(HALF) == lv2.get(HALF)) {
			Direction lv3 = lv2.get(FACING);
			if (lv3.getAxis() != ((Direction)state.get(FACING)).getAxis() && isDifferentOrientation(state, world, pos, lv3.getOpposite())) {
				if (lv3 == lv.rotateYCounterclockwise()) {
					return StairShape.OUTER_LEFT;
				}

				return StairShape.OUTER_RIGHT;
			}
		}

		BlockState lv4 = world.getBlockState(pos.offset(lv.getOpposite()));
		if (isStairs(lv4) && state.get(HALF) == lv4.get(HALF)) {
			Direction lv5 = lv4.get(FACING);
			if (lv5.getAxis() != ((Direction)state.get(FACING)).getAxis() && isDifferentOrientation(state, world, pos, lv5)) {
				if (lv5 == lv.rotateYCounterclockwise()) {
					return StairShape.INNER_LEFT;
				}

				return StairShape.INNER_RIGHT;
			}
		}

		return StairShape.STRAIGHT;
	}

	private static boolean isDifferentOrientation(BlockState state, BlockView world, BlockPos pos, Direction dir) {
		BlockState lv = world.getBlockState(pos.offset(dir));
		return !isStairs(lv) || lv.get(FACING) != state.get(FACING) || lv.get(HALF) != state.get(HALF);
	}

	public static boolean isStairs(BlockState state) {
		return state.getBlock() instanceof StairsBlock;
	}

	@Override
	protected BlockState rotate(BlockState state, BlockRotation rotation) {
		return state.with(FACING, rotation.rotate(state.get(FACING)));
	}

	@Override
	protected BlockState mirror(BlockState state, BlockMirror mirror) {
		Direction lv = state.get(FACING);
		StairShape lv2 = state.get(SHAPE);
		switch (mirror) {
			case LEFT_RIGHT:
				if (lv.getAxis() == Axis.Z) {
					switch (lv2) {
						case OUTER_LEFT:
							return state.rotate(BlockRotation.CLOCKWISE_180).with(SHAPE, StairShape.OUTER_RIGHT);
						case INNER_RIGHT:
							return state.rotate(BlockRotation.CLOCKWISE_180).with(SHAPE, StairShape.INNER_LEFT);
						case INNER_LEFT:
							return state.rotate(BlockRotation.CLOCKWISE_180).with(SHAPE, StairShape.INNER_RIGHT);
						case OUTER_RIGHT:
							return state.rotate(BlockRotation.CLOCKWISE_180).with(SHAPE, StairShape.OUTER_LEFT);
						default:
							return state.rotate(BlockRotation.CLOCKWISE_180);
					}
				}
				break;
			case FRONT_BACK:
				if (lv.getAxis() == Axis.X) {
					switch (lv2) {
						case STRAIGHT:
							return state.rotate(BlockRotation.CLOCKWISE_180);
						case OUTER_LEFT:
							return state.rotate(BlockRotation.CLOCKWISE_180).with(SHAPE, StairShape.OUTER_RIGHT);
						case INNER_RIGHT:
							return state.rotate(BlockRotation.CLOCKWISE_180).with(SHAPE, StairShape.INNER_RIGHT);
						case INNER_LEFT:
							return state.rotate(BlockRotation.CLOCKWISE_180).with(SHAPE, StairShape.INNER_LEFT);
						case OUTER_RIGHT:
							return state.rotate(BlockRotation.CLOCKWISE_180).with(SHAPE, StairShape.OUTER_LEFT);
					}
				}
		}

		return super.mirror(state, mirror);
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(FACING, HALF, SHAPE, WATERLOGGED);
	}

	@Override
	protected FluidState getFluidState(BlockState state) {
		return state.get(WATERLOGGED) ? Fluids.WATER.getStill(false) : super.getFluidState(state);
	}

	@Override
	protected boolean canPathfindThrough(BlockState state, NavigationType type) {
		return false;
	}
}
