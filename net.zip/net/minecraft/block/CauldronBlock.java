package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.cauldron.CauldronBehavior;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.Fluids;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome.Precipitation;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.event.GameEvent.Emitter;

public class CauldronBlock extends AbstractCauldronBlock {
	public static final MapCodec<CauldronBlock> CODEC = createCodec(CauldronBlock::new);
	private static final float FILL_WITH_RAIN_CHANCE = 0.05F;
	private static final float FILL_WITH_SNOW_CHANCE = 0.1F;

	@Override
	public MapCodec<CauldronBlock> getCodec() {
		return CODEC;
	}

	public CauldronBlock(Settings settings) {
		super(settings, CauldronBehavior.EMPTY_CAULDRON_BEHAVIOR);
	}

	@Override
	public boolean isFull(BlockState state) {
		return false;
	}

	protected static boolean canFillWithPrecipitation(World world, Precipitation precipitation) {
		if (precipitation == Precipitation.RAIN) {
			return world.getRandom().nextFloat() < 0.05F;
		} else {
			return precipitation == Precipitation.SNOW ? world.getRandom().nextFloat() < 0.1F : false;
		}
	}

	@Override
	public void precipitationTick(BlockState state, World world, BlockPos pos, Precipitation precipitation) {
		if (canFillWithPrecipitation(world, precipitation)) {
			if (precipitation == Precipitation.RAIN) {
				world.setBlockState(pos, Blocks.WATER_CAULDRON.getDefaultState());
				world.emitGameEvent(null, GameEvent.BLOCK_CHANGE, pos);
			} else if (precipitation == Precipitation.SNOW) {
				world.setBlockState(pos, Blocks.POWDER_SNOW_CAULDRON.getDefaultState());
				world.emitGameEvent(null, GameEvent.BLOCK_CHANGE, pos);
			}
		}
	}

	@Override
	protected boolean canBeFilledByDripstone(Fluid fluid) {
		return true;
	}

	@Override
	protected void fillFromDripstone(BlockState state, World world, BlockPos pos, Fluid fluid) {
		if (fluid == Fluids.WATER) {
			BlockState lv = Blocks.WATER_CAULDRON.getDefaultState();
			world.setBlockState(pos, lv);
			world.emitGameEvent(GameEvent.BLOCK_CHANGE, pos, Emitter.of(lv));
			world.syncWorldEvent(1047, pos, 0);
		} else if (fluid == Fluids.LAVA) {
			BlockState lv = Blocks.LAVA_CAULDRON.getDefaultState();
			world.setBlockState(pos, lv);
			world.emitGameEvent(GameEvent.BLOCK_CHANGE, pos, Emitter.of(lv));
			world.syncWorldEvent(1046, pos, 0);
		}
	}
}
