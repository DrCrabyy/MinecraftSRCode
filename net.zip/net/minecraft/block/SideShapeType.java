package net.minecraft.block;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;

public enum SideShapeType {
	FULL,
	CENTER,
	RIGID;

	public abstract boolean matches(BlockState state, BlockView world, BlockPos pos, Direction direction);
}
