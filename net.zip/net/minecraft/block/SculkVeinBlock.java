package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import java.util.Collection;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.MultifaceGrower.GrowType;
import net.minecraft.block.MultifaceGrower.LichenGrowChecker;
import net.minecraft.block.entity.SculkSpreadManager;
import net.minecraft.block.entity.SculkSpreadManager.Cursor;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldAccess;

public class SculkVeinBlock extends MultifaceGrowthBlock implements SculkSpreadable {
	public static final MapCodec<SculkVeinBlock> CODEC = createCodec(SculkVeinBlock::new);
	private final MultifaceGrower allGrowTypeGrower = new MultifaceGrower(new SculkVeinBlock.SculkVeinGrowChecker(this, MultifaceGrower.GROW_TYPES));
	private final MultifaceGrower samePositionOnlyGrower = new MultifaceGrower(new SculkVeinBlock.SculkVeinGrowChecker(this, GrowType.SAME_POSITION));

	@Override
	public MapCodec<SculkVeinBlock> getCodec() {
		return CODEC;
	}

	public SculkVeinBlock(Settings settings) {
		super(settings);
	}

	@Override
	public MultifaceGrower getGrower() {
		return this.allGrowTypeGrower;
	}

	public MultifaceGrower getSamePositionOnlyGrower() {
		return this.samePositionOnlyGrower;
	}

	public static boolean place(WorldAccess world, BlockPos pos, BlockState state, Collection<Direction> directions) {
		boolean bl = false;
		BlockState lv = Blocks.SCULK_VEIN.getDefaultState();

		for (Direction lv2 : directions) {
			if (canGrowOn(world, pos, lv2)) {
				lv = lv.with(getProperty(lv2), Boolean.valueOf(true));
				bl = true;
			}
		}

		if (!bl) {
			return false;
		} else {
			if (!state.getFluidState().isEmpty()) {
				lv = lv.with(MultifaceBlock.WATERLOGGED, Boolean.valueOf(true));
			}

			world.setBlockState(pos, lv, 3);
			return true;
		}
	}

	@Override
	public void spreadAtSamePosition(WorldAccess world, BlockState state, BlockPos pos, Random random) {
		if (state.isOf(this)) {
			for (Direction lv : DIRECTIONS) {
				BooleanProperty lv2 = getProperty(lv);
				if ((Boolean)state.get(lv2) && world.getBlockState(pos.offset(lv)).isOf(Blocks.SCULK)) {
					state = state.with(lv2, Boolean.valueOf(false));
				}
			}

			if (!hasAnyDirection(state)) {
				FluidState lv3 = world.getFluidState(pos);
				state = (lv3.isEmpty() ? Blocks.AIR : Blocks.WATER).getDefaultState();
			}

			world.setBlockState(pos, state, 3);
			SculkSpreadable.super.spreadAtSamePosition(world, state, pos, random);
		}
	}

	@Override
	public int spread(Cursor cursor, WorldAccess world, BlockPos catalystPos, Random random, SculkSpreadManager spreadManager, boolean shouldConvertToBlock) {
		if (shouldConvertToBlock && this.convertToBlock(spreadManager, world, cursor.getPos(), random)) {
			return cursor.getCharge() - 1;
		} else {
			return random.nextInt(spreadManager.getSpreadChance()) == 0 ? MathHelper.floor((float)cursor.getCharge() * 0.5F) : cursor.getCharge();
		}
	}

	private boolean convertToBlock(SculkSpreadManager spreadManager, WorldAccess world, BlockPos pos, Random random) {
		BlockState lv = world.getBlockState(pos);
		TagKey<Block> lv2 = spreadManager.getReplaceableTag();

		for (Direction lv3 : Direction.shuffle(random)) {
			if (hasDirection(lv, lv3)) {
				BlockPos lv4 = pos.offset(lv3);
				BlockState lv5 = world.getBlockState(lv4);
				if (lv5.isIn(lv2)) {
					BlockState lv6 = Blocks.SCULK.getDefaultState();
					world.setBlockState(lv4, lv6, 3);
					Block.pushEntitiesUpBeforeBlockChange(lv5, lv6, world, lv4);
					world.playSound(null, lv4, SoundEvents.BLOCK_SCULK_SPREAD, SoundCategory.BLOCKS, 1.0F, 1.0F);
					this.allGrowTypeGrower.grow(lv6, world, lv4, spreadManager.isWorldGen());
					Direction lv7 = lv3.getOpposite();

					for (Direction lv8 : DIRECTIONS) {
						if (lv8 != lv7) {
							BlockPos lv9 = lv4.offset(lv8);
							BlockState lv10 = world.getBlockState(lv9);
							if (lv10.isOf(this)) {
								this.spreadAtSamePosition(world, lv10, lv9, random);
							}
						}
					}

					return true;
				}
			}
		}

		return false;
	}

	public static boolean veinCoversSculkReplaceable(WorldAccess world, BlockState state, BlockPos pos) {
		if (!state.isOf(Blocks.SCULK_VEIN)) {
			return false;
		} else {
			for (Direction lv : DIRECTIONS) {
				if (hasDirection(state, lv) && world.getBlockState(pos.offset(lv)).isIn(BlockTags.SCULK_REPLACEABLE)) {
					return true;
				}
			}

			return false;
		}
	}

	class SculkVeinGrowChecker extends LichenGrowChecker {
		private final GrowType[] growTypes;

		public SculkVeinGrowChecker(final SculkVeinBlock block, final GrowType... growTypes) {
			super(block);
			this.growTypes = growTypes;
		}

		@Override
		public boolean canGrow(BlockView world, BlockPos pos, BlockPos growPos, Direction direction, BlockState state) {
			BlockState lv = world.getBlockState(growPos.offset(direction));
			if (!lv.isOf(Blocks.SCULK) && !lv.isOf(Blocks.SCULK_CATALYST) && !lv.isOf(Blocks.MOVING_PISTON)) {
				if (pos.getManhattanDistance(growPos) == 2) {
					BlockPos lv2 = pos.offset(direction.getOpposite());
					if (world.getBlockState(lv2).isSideSolidFullSquare(world, lv2, direction)) {
						return false;
					}
				}

				FluidState lv3 = state.getFluidState();
				if (!lv3.isEmpty() && !lv3.isOf(Fluids.WATER)) {
					return false;
				} else {
					return state.isIn(BlockTags.FIRE) ? false : state.isReplaceable() || super.canGrow(world, pos, growPos, direction, state);
				}
			} else {
				return false;
			}
		}

		@Override
		public GrowType[] getGrowTypes() {
			return this.growTypes;
		}

		@Override
		public boolean canGrow(BlockState state) {
			return !state.isOf(Blocks.SCULK_VEIN);
		}
	}
}
