package net.minecraft.block.piston;

public enum PistonBehavior {
	NORMAL,
	DESTROY,
	BLOCK,
	IGNORE,
	PUSH_ONLY;
}
