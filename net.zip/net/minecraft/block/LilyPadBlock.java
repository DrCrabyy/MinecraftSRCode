package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.AbstractBoatEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

public class LilyPadBlock extends PlantBlock {
	public static final MapCodec<LilyPadBlock> CODEC = createCodec(LilyPadBlock::new);
	private static final VoxelShape SHAPE = Block.method_66404(14.0, 0.0, 1.5);

	@Override
	public MapCodec<LilyPadBlock> getCodec() {
		return CODEC;
	}

	protected LilyPadBlock(Settings settings) {
		super(settings);
	}

	@Override
	protected void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
		super.onEntityCollision(state, world, pos, entity);
		if (world instanceof ServerWorld && entity instanceof AbstractBoatEntity) {
			world.breakBlock(new BlockPos(pos), true, entity);
		}
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return SHAPE;
	}

	@Override
	protected boolean canPlantOnTop(BlockState floor, BlockView world, BlockPos pos) {
		FluidState lv = world.getFluidState(pos);
		FluidState lv2 = world.getFluidState(pos.up());
		return (lv.getFluid() == Fluids.WATER || floor.getBlock() instanceof IceBlock) && lv2.getFluid() == Fluids.EMPTY;
	}
}
