package net.minecraft.block.entity;

import javax.annotation.Nullable;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity.ComponentsAccess;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.ComponentMap.Builder;
import net.minecraft.component.type.ContainerLootComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.LootableInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.LootTable;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryKey;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.util.math.BlockPos;

public abstract class LootableContainerBlockEntity extends LockableContainerBlockEntity implements LootableInventory {
	@Nullable
	protected RegistryKey<LootTable> lootTable;
	protected long lootTableSeed = 0L;

	protected LootableContainerBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
		super(type, pos, state);
	}

	@Nullable
	@Override
	public RegistryKey<LootTable> getLootTable() {
		return this.lootTable;
	}

	@Override
	public void setLootTable(@Nullable RegistryKey<LootTable> lootTable) {
		this.lootTable = lootTable;
	}

	@Override
	public long getLootTableSeed() {
		return this.lootTableSeed;
	}

	@Override
	public void setLootTableSeed(long lootTableSeed) {
		this.lootTableSeed = lootTableSeed;
	}

	@Override
	public boolean isEmpty() {
		this.generateLoot(null);
		return super.isEmpty();
	}

	@Override
	public ItemStack getStack(int slot) {
		this.generateLoot(null);
		return super.getStack(slot);
	}

	@Override
	public ItemStack removeStack(int slot, int amount) {
		this.generateLoot(null);
		return super.removeStack(slot, amount);
	}

	@Override
	public ItemStack removeStack(int slot) {
		this.generateLoot(null);
		return super.removeStack(slot);
	}

	@Override
	public void setStack(int slot, ItemStack stack) {
		this.generateLoot(null);
		super.setStack(slot, stack);
	}

	@Override
	public boolean checkUnlocked(PlayerEntity player) {
		return super.checkUnlocked(player) && (this.lootTable == null || !player.isSpectator());
	}

	@Nullable
	@Override
	public ScreenHandler createMenu(int syncId, PlayerInventory playerInventory, PlayerEntity player) {
		if (this.checkUnlocked(player)) {
			this.generateLoot(playerInventory.player);
			return this.createScreenHandler(syncId, playerInventory);
		} else {
			return null;
		}
	}

	@Override
	protected void readComponents(ComponentsAccess components) {
		super.readComponents(components);
		ContainerLootComponent lv = components.get(DataComponentTypes.CONTAINER_LOOT);
		if (lv != null) {
			this.lootTable = lv.lootTable();
			this.lootTableSeed = lv.seed();
		}
	}

	@Override
	protected void addComponents(Builder builder) {
		super.addComponents(builder);
		if (this.lootTable != null) {
			builder.add(DataComponentTypes.CONTAINER_LOOT, new ContainerLootComponent(this.lootTable, this.lootTableSeed));
		}
	}

	@Override
	public void removeFromCopiedStackNbt(NbtCompound nbt) {
		super.removeFromCopiedStackNbt(nbt);
		nbt.remove("LootTable");
		nbt.remove("LootTableSeed");
	}
}
