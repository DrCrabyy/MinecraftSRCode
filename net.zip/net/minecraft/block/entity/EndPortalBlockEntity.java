package net.minecraft.block.entity;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;

public class EndPortalBlockEntity extends BlockEntity {
	protected EndPortalBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
		super(type, pos, state);
	}

	public EndPortalBlockEntity(BlockPos pos, BlockState state) {
		this(BlockEntityType.END_PORTAL, pos, state);
	}

	public boolean shouldDrawSide(Direction direction) {
		return direction.getAxis() == Axis.Y;
	}
}
