package net.minecraft.block.entity;

import com.mojang.logging.LogUtils;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.OptionalInt;
import javax.annotation.Nullable;
import net.minecraft.block.BlockState;
import net.minecraft.block.SculkShriekerBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LargeEntitySpawnHelper;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.LargeEntitySpawnHelper.Requirements;
import net.minecraft.entity.mob.WardenEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtOps;
import net.minecraft.registry.RegistryOps;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.GameEventTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Difficulty;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import net.minecraft.world.event.BlockPositionSource;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.event.PositionSource;
import net.minecraft.world.event.Vibrations;
import net.minecraft.world.event.GameEvent.Emitter;
import net.minecraft.world.event.Vibrations.Callback;
import net.minecraft.world.event.Vibrations.ListenerData;
import net.minecraft.world.event.Vibrations.VibrationListener;
import net.minecraft.world.event.listener.GameEventListener.Holder;
import org.slf4j.Logger;

public class SculkShriekerBlockEntity extends BlockEntity implements Holder<VibrationListener>, Vibrations {
	private static final Logger LOGGER = LogUtils.getLogger();
	private static final int field_38750 = 10;
	private static final int WARDEN_SPAWN_TRIES = 20;
	private static final int WARDEN_SPAWN_HORIZONTAL_RANGE = 5;
	private static final int WARDEN_SPAWN_VERTICAL_RANGE = 6;
	private static final int DARKNESS_RANGE = 40;
	private static final int SHRIEK_DELAY = 90;
	private static final Int2ObjectMap<SoundEvent> WARNING_SOUNDS = Util.make(new Int2ObjectOpenHashMap(), warningSounds -> {
		warningSounds.put(1, SoundEvents.ENTITY_WARDEN_NEARBY_CLOSE);
		warningSounds.put(2, SoundEvents.ENTITY_WARDEN_NEARBY_CLOSER);
		warningSounds.put(3, SoundEvents.ENTITY_WARDEN_NEARBY_CLOSEST);
		warningSounds.put(4, SoundEvents.ENTITY_WARDEN_LISTENING_ANGRY);
	});
	private int warningLevel;
	private final Callback vibrationCallback = new SculkShriekerBlockEntity.VibrationCallback();
	private ListenerData vibrationListenerData = new ListenerData();
	private final VibrationListener vibrationListener = new VibrationListener(this);

	public SculkShriekerBlockEntity(BlockPos pos, BlockState state) {
		super(BlockEntityType.SCULK_SHRIEKER, pos, state);
	}

	@Override
	public ListenerData getVibrationListenerData() {
		return this.vibrationListenerData;
	}

	@Override
	public Callback getVibrationCallback() {
		return this.vibrationCallback;
	}

	@Override
	protected void readNbt(NbtCompound nbt, WrapperLookup registries) {
		super.readNbt(nbt, registries);
		if (nbt.contains("warning_level", 99)) {
			this.warningLevel = nbt.getInt("warning_level");
		}

		RegistryOps<NbtElement> lv = registries.getOps(NbtOps.INSTANCE);
		if (nbt.contains("listener", 10)) {
			ListenerData.CODEC
				.parse(lv, nbt.getCompound("listener"))
				.resultOrPartial(string -> LOGGER.error("Failed to parse vibration listener for Sculk Shrieker: '{}'", string))
				.ifPresent(vibrationListener -> this.vibrationListenerData = vibrationListener);
		}
	}

	@Override
	protected void writeNbt(NbtCompound nbt, WrapperLookup registries) {
		super.writeNbt(nbt, registries);
		nbt.putInt("warning_level", this.warningLevel);
		RegistryOps<NbtElement> lv = registries.getOps(NbtOps.INSTANCE);
		ListenerData.CODEC
			.encodeStart(lv, this.vibrationListenerData)
			.resultOrPartial(string -> LOGGER.error("Failed to encode vibration listener for Sculk Shrieker: '{}'", string))
			.ifPresent(arg2 -> nbt.put("listener", arg2));
	}

	@Nullable
	public static ServerPlayerEntity findResponsiblePlayerFromEntity(@Nullable Entity entity) {
		// $VF: Couldn't be decompiled
		// Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
		//
		// Bytecode:
		// 00: aload 0
		// 01: instanceof net/minecraft/server/network/ServerPlayerEntity
		// 04: ifeq 0e
		// 07: aload 0
		// 08: checkcast net/minecraft/server/network/ServerPlayerEntity
		// 0b: astore 1
		// 0c: aload 1
		// 0d: areturn
		// 0e: aload 0
		// 0f: ifnull 25
		// 12: aload 0
		// 13: invokevirtual net/minecraft/entity/Entity.getControllingPassenger ()Lnet/minecraft/entity/LivingEntity;
		// 16: astore 2
		// 17: aload 2
		// 18: instanceof net/minecraft/server/network/ServerPlayerEntity
		// 1b: ifeq 25
		// 1e: aload 2
		// 1f: checkcast net/minecraft/server/network/ServerPlayerEntity
		// 22: astore 1
		// 23: aload 1
		// 24: areturn
		// 25: aload 0
		// 26: instanceof net/minecraft/entity/projectile/ProjectileEntity
		// 29: ifeq 44
		// 2c: aload 0
		// 2d: checkcast net/minecraft/entity/projectile/ProjectileEntity
		// 30: astore 1
		// 31: aload 1
		// 32: invokevirtual net/minecraft/entity/projectile/ProjectileEntity.getOwner ()Lnet/minecraft/entity/Entity;
		// 35: astore 3
		// 36: aload 3
		// 37: instanceof net/minecraft/server/network/ServerPlayerEntity
		// 3a: ifeq 44
		// 3d: aload 3
		// 3e: checkcast net/minecraft/server/network/ServerPlayerEntity
		// 41: astore 2
		// 42: aload 2
		// 43: areturn
		// 44: aload 0
		// 45: instanceof net/minecraft/entity/ItemEntity
		// 48: ifeq 63
		// 4b: aload 0
		// 4c: checkcast net/minecraft/entity/ItemEntity
		// 4f: astore 1
		// 50: aload 1
		// 51: invokevirtual net/minecraft/entity/ItemEntity.getOwner ()Lnet/minecraft/entity/Entity;
		// 54: astore 3
		// 55: aload 3
		// 56: instanceof net/minecraft/server/network/ServerPlayerEntity
		// 59: ifeq 63
		// 5c: aload 3
		// 5d: checkcast net/minecraft/server/network/ServerPlayerEntity
		// 60: astore 2
		// 61: aload 2
		// 62: areturn
		// 63: aconst_null
		// 64: areturn
	}

	public void shriek(ServerWorld world, @Nullable ServerPlayerEntity player) {
		if (player != null) {
			BlockState lv = this.getCachedState();
			if (!(Boolean)lv.get(SculkShriekerBlock.SHRIEKING)) {
				this.warningLevel = 0;
				if (!this.canWarn(world) || this.trySyncWarningLevel(world, player)) {
					this.shriek(world, (Entity)player);
				}
			}
		}
	}

	private boolean trySyncWarningLevel(ServerWorld world, ServerPlayerEntity player) {
		OptionalInt optionalInt = SculkShriekerWarningManager.warnNearbyPlayers(world, this.getPos(), player);
		optionalInt.ifPresent(warningLevel -> this.warningLevel = warningLevel);
		return optionalInt.isPresent();
	}

	private void shriek(ServerWorld world, @Nullable Entity entity) {
		BlockPos lv = this.getPos();
		BlockState lv2 = this.getCachedState();
		world.setBlockState(lv, lv2.with(SculkShriekerBlock.SHRIEKING, Boolean.valueOf(true)), 2);
		world.scheduleBlockTick(lv, lv2.getBlock(), 90);
		world.syncWorldEvent(3007, lv, 0);
		world.emitGameEvent(GameEvent.SHRIEK, lv, Emitter.of(entity));
	}

	private boolean canWarn(ServerWorld world) {
		return (Boolean)this.getCachedState().get(SculkShriekerBlock.CAN_SUMMON)
			&& world.getDifficulty() != Difficulty.PEACEFUL
			&& world.getGameRules().getBoolean(GameRules.DO_WARDEN_SPAWNING);
	}

	@Override
	public void onStateReplaced(BlockPos pos, BlockState oldState, boolean moved) {
		if ((Boolean)oldState.get(SculkShriekerBlock.SHRIEKING) && this.world instanceof ServerWorld lv) {
			this.warn(lv);
		}
	}

	public void warn(ServerWorld world) {
		if (this.canWarn(world) && this.warningLevel > 0) {
			if (!this.trySpawnWarden(world)) {
				this.playWarningSound(world);
			}

			WardenEntity.addDarknessToClosePlayers(world, Vec3d.ofCenter(this.getPos()), null, 40);
		}
	}

	private void playWarningSound(World world) {
		SoundEvent lv = (SoundEvent)WARNING_SOUNDS.get(this.warningLevel);
		if (lv != null) {
			BlockPos lv2 = this.getPos();
			int i = lv2.getX() + MathHelper.nextBetween(world.random, -10, 10);
			int j = lv2.getY() + MathHelper.nextBetween(world.random, -10, 10);
			int k = lv2.getZ() + MathHelper.nextBetween(world.random, -10, 10);
			world.playSound(null, (double)i, (double)j, (double)k, lv, SoundCategory.HOSTILE, 5.0F, 1.0F);
		}
	}

	private boolean trySpawnWarden(ServerWorld world) {
		return this.warningLevel < 4
			? false
			: LargeEntitySpawnHelper.trySpawnAt(EntityType.WARDEN, SpawnReason.TRIGGERED, world, this.getPos(), 20, 5, 6, Requirements.WARDEN, false).isPresent();
	}

	public VibrationListener getEventListener() {
		return this.vibrationListener;
	}

	class VibrationCallback implements Callback {
		private static final int RANGE = 8;
		private final PositionSource positionSource = new BlockPositionSource(SculkShriekerBlockEntity.this.pos);

		public VibrationCallback() {
		}

		@Override
		public int getRange() {
			return 8;
		}

		@Override
		public PositionSource getPositionSource() {
			return this.positionSource;
		}

		@Override
		public TagKey<GameEvent> getTag() {
			return GameEventTags.SHRIEKER_CAN_LISTEN;
		}

		@Override
		public boolean accepts(ServerWorld world, BlockPos pos, RegistryEntry<GameEvent> event, Emitter emitter) {
			return !(Boolean)SculkShriekerBlockEntity.this.getCachedState().get(SculkShriekerBlock.SHRIEKING)
				&& SculkShriekerBlockEntity.findResponsiblePlayerFromEntity(emitter.sourceEntity()) != null;
		}

		@Override
		public void accept(ServerWorld world, BlockPos pos, RegistryEntry<GameEvent> event, @Nullable Entity sourceEntity, @Nullable Entity entity, float distance) {
			SculkShriekerBlockEntity.this.shriek(world, SculkShriekerBlockEntity.findResponsiblePlayerFromEntity(entity != null ? entity : sourceEntity));
		}

		@Override
		public void onListen() {
			SculkShriekerBlockEntity.this.markDirty();
		}

		@Override
		public boolean requiresTickingChunksAround() {
			return true;
		}
	}
}
