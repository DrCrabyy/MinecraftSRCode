package net.minecraft.block.entity;

import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.block.BlockState;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.entity.BlockEntity.ComponentsAccess;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.ComponentMap.Builder;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.inventory.Inventories;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.recipe.CampfireCookingRecipe;
import net.minecraft.recipe.RecipeEntry;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.ServerRecipeManager.MatchGetter;
import net.minecraft.recipe.input.SingleStackRecipeInput;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Clearable;
import net.minecraft.util.ItemScatterer;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.event.GameEvent.Emitter;

public class CampfireBlockEntity extends BlockEntity implements Clearable {
	private static final int field_31330 = 2;
	private static final int field_31331 = 4;
	private final DefaultedList<ItemStack> itemsBeingCooked = DefaultedList.ofSize(4, ItemStack.EMPTY);
	private final int[] cookingTimes = new int[4];
	private final int[] cookingTotalTimes = new int[4];

	public CampfireBlockEntity(BlockPos pos, BlockState state) {
		super(BlockEntityType.CAMPFIRE, pos, state);
	}

	public static void litServerTick(
		ServerWorld world,
		BlockPos pos,
		BlockState state,
		CampfireBlockEntity blockEntity,
		MatchGetter<SingleStackRecipeInput, CampfireCookingRecipe> recipeMatchGetter
	) {
		boolean bl = false;

		for (int i = 0; i < blockEntity.itemsBeingCooked.size(); i++) {
			ItemStack lv = blockEntity.itemsBeingCooked.get(i);
			if (!lv.isEmpty()) {
				bl = true;
				blockEntity.cookingTimes[i]++;
				if (blockEntity.cookingTimes[i] >= blockEntity.cookingTotalTimes[i]) {
					SingleStackRecipeInput lv2 = new SingleStackRecipeInput(lv);
					ItemStack lv3 = (ItemStack)recipeMatchGetter.getFirstMatch(lv2, world)
						.map(recipe -> ((CampfireCookingRecipe)recipe.value()).craft(lv2, world.getRegistryManager()))
						.orElse(lv);
					if (lv3.isItemEnabled(world.getEnabledFeatures())) {
						ItemScatterer.spawn(world, (double)pos.getX(), (double)pos.getY(), (double)pos.getZ(), lv3);
						blockEntity.itemsBeingCooked.set(i, ItemStack.EMPTY);
						world.updateListeners(pos, state, state, 3);
						world.emitGameEvent(GameEvent.BLOCK_CHANGE, pos, Emitter.of(state));
					}
				}
			}
		}

		if (bl) {
			markDirty(world, pos, state);
		}
	}

	public static void unlitServerTick(World world, BlockPos pos, BlockState state, CampfireBlockEntity campfire) {
		boolean bl = false;

		for (int i = 0; i < campfire.itemsBeingCooked.size(); i++) {
			if (campfire.cookingTimes[i] > 0) {
				bl = true;
				campfire.cookingTimes[i] = MathHelper.clamp(campfire.cookingTimes[i] - 2, 0, campfire.cookingTotalTimes[i]);
			}
		}

		if (bl) {
			markDirty(world, pos, state);
		}
	}

	public static void clientTick(World world, BlockPos pos, BlockState state, CampfireBlockEntity campfire) {
		Random lv = world.random;
		if (lv.nextFloat() < 0.11F) {
			for (int i = 0; i < lv.nextInt(2) + 2; i++) {
				CampfireBlock.spawnSmokeParticle(world, pos, (Boolean)state.get(CampfireBlock.SIGNAL_FIRE), false);
			}
		}

		int i = ((Direction)state.get(CampfireBlock.FACING)).getHorizontalQuarterTurns();

		for (int j = 0; j < campfire.itemsBeingCooked.size(); j++) {
			if (!campfire.itemsBeingCooked.get(j).isEmpty() && lv.nextFloat() < 0.2F) {
				Direction lv2 = Direction.fromHorizontalQuarterTurns(Math.floorMod(j + i, 4));
				float f = 0.3125F;
				double d = (double)pos.getX() + 0.5 - (double)((float)lv2.getOffsetX() * 0.3125F) + (double)((float)lv2.rotateYClockwise().getOffsetX() * 0.3125F);
				double e = (double)pos.getY() + 0.5;
				double g = (double)pos.getZ() + 0.5 - (double)((float)lv2.getOffsetZ() * 0.3125F) + (double)((float)lv2.rotateYClockwise().getOffsetZ() * 0.3125F);

				for (int k = 0; k < 4; k++) {
					world.addParticleClient(ParticleTypes.SMOKE, d, e, g, 0.0, 5.0E-4, 0.0);
				}
			}
		}
	}

	public DefaultedList<ItemStack> getItemsBeingCooked() {
		return this.itemsBeingCooked;
	}

	@Override
	protected void readNbt(NbtCompound nbt, WrapperLookup registries) {
		super.readNbt(nbt, registries);
		this.itemsBeingCooked.clear();
		Inventories.readNbt(nbt, this.itemsBeingCooked, registries);
		if (nbt.contains("CookingTimes", 11)) {
			int[] is = nbt.getIntArray("CookingTimes");
			System.arraycopy(is, 0, this.cookingTimes, 0, Math.min(this.cookingTotalTimes.length, is.length));
		}

		if (nbt.contains("CookingTotalTimes", 11)) {
			int[] is = nbt.getIntArray("CookingTotalTimes");
			System.arraycopy(is, 0, this.cookingTotalTimes, 0, Math.min(this.cookingTotalTimes.length, is.length));
		}
	}

	@Override
	protected void writeNbt(NbtCompound nbt, WrapperLookup registries) {
		super.writeNbt(nbt, registries);
		Inventories.writeNbt(nbt, this.itemsBeingCooked, true, registries);
		nbt.putIntArray("CookingTimes", this.cookingTimes);
		nbt.putIntArray("CookingTotalTimes", this.cookingTotalTimes);
	}

	public BlockEntityUpdateS2CPacket toUpdatePacket() {
		return BlockEntityUpdateS2CPacket.create(this);
	}

	@Override
	public NbtCompound toInitialChunkDataNbt(WrapperLookup registries) {
		NbtCompound lv = new NbtCompound();
		Inventories.writeNbt(lv, this.itemsBeingCooked, true, registries);
		return lv;
	}

	public boolean addItem(ServerWorld world, @Nullable LivingEntity entity, ItemStack stack) {
		for (int i = 0; i < this.itemsBeingCooked.size(); i++) {
			ItemStack lv = this.itemsBeingCooked.get(i);
			if (lv.isEmpty()) {
				Optional<RecipeEntry<CampfireCookingRecipe>> optional = world.getRecipeManager()
					.getFirstMatch(RecipeType.CAMPFIRE_COOKING, new SingleStackRecipeInput(stack), world);
				if (optional.isEmpty()) {
					return false;
				}

				this.cookingTotalTimes[i] = ((CampfireCookingRecipe)((RecipeEntry)optional.get()).value()).getCookingTime();
				this.cookingTimes[i] = 0;
				this.itemsBeingCooked.set(i, stack.splitUnlessCreative(1, entity));
				world.emitGameEvent(GameEvent.BLOCK_CHANGE, this.getPos(), Emitter.of(entity, this.getCachedState()));
				this.updateListeners();
				return true;
			}
		}

		return false;
	}

	private void updateListeners() {
		this.markDirty();
		this.getWorld().updateListeners(this.getPos(), this.getCachedState(), this.getCachedState(), 3);
	}

	@Override
	public void clear() {
		this.itemsBeingCooked.clear();
	}

	@Override
	public void onStateReplaced(BlockPos pos, BlockState oldState, boolean moved) {
		if (this.world != null) {
			ItemScatterer.spawn(this.world, pos, this.getItemsBeingCooked());
		}
	}

	public void spawnItemsBeingCooked() {
		if (this.world != null) {
			this.updateListeners();
		}
	}

	@Override
	protected void readComponents(ComponentsAccess components) {
		super.readComponents(components);
		components.getOrDefault(DataComponentTypes.CONTAINER, ContainerComponent.DEFAULT).copyTo(this.getItemsBeingCooked());
	}

	@Override
	protected void addComponents(Builder builder) {
		super.addComponents(builder);
		builder.add(DataComponentTypes.CONTAINER, ContainerComponent.fromStacks(this.getItemsBeingCooked()));
	}

	@Override
	public void removeFromCopiedStackNbt(NbtCompound nbt) {
		nbt.remove("Items");
	}
}
