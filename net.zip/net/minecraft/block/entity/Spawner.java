package net.minecraft.block.entity;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.EntityType;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

public interface Spawner {
	void setEntityType(EntityType<?> type, Random random);

	static void appendSpawnDataToTooltip(ItemStack stack, List<Text> tooltip, String spawnDataKey) {
		Text lv = getSpawnedEntityText(stack, spawnDataKey);
		if (lv != null) {
			tooltip.add(lv);
		} else {
			tooltip.add(ScreenTexts.EMPTY);
			tooltip.add(Text.translatable("block.minecraft.spawner.desc1").formatted(Formatting.GRAY));
			tooltip.add(ScreenTexts.space().append(Text.translatable("block.minecraft.spawner.desc2").formatted(Formatting.BLUE)));
		}
	}

	@Nullable
	static Text getSpawnedEntityText(ItemStack stack, String spawnDataKey) {
		NbtCompound lv = stack.getOrDefault(DataComponentTypes.BLOCK_ENTITY_DATA, NbtComponent.DEFAULT).getNbt();
		Identifier lv2 = getSpawnedEntityId(lv, spawnDataKey);
		return lv2 != null
			? (Text)Registries.ENTITY_TYPE
				.getOptionalValue(lv2)
				.map(entityType -> Text.translatable(entityType.getTranslationKey()).formatted(Formatting.GRAY))
				.orElse(null)
			: null;
	}

	@Nullable
	private static Identifier getSpawnedEntityId(NbtCompound nbt, String spawnDataKey) {
		if (nbt.contains(spawnDataKey, 10)) {
			String string2 = nbt.getCompound(spawnDataKey).getCompound("entity").getString("id");
			return Identifier.tryParse(string2);
		} else {
			return null;
		}
	}
}
