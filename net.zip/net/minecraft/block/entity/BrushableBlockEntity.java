package net.minecraft.block.entity;

import com.mojang.logging.LogUtils;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.BrushableBlock;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.loot.context.LootWorldContext;
import net.minecraft.loot.context.LootWorldContext.Builder;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.slf4j.Logger;

public class BrushableBlockEntity extends BlockEntity {
	private static final Logger LOGGER = LogUtils.getLogger();
	private static final String LOOT_TABLE_NBT_KEY = "LootTable";
	private static final String LOOT_TABLE_SEED_NBT_KEY = "LootTableSeed";
	private static final String HIT_DIRECTION_NBT_KEY = "hit_direction";
	private static final String ITEM_NBT_KEY = "item";
	private static final int field_42806 = 10;
	private static final int field_42807 = 40;
	private static final int field_42808 = 10;
	private int brushesCount;
	private long nextDustTime;
	private long nextBrushTime;
	private ItemStack item = ItemStack.EMPTY;
	@Nullable
	private Direction hitDirection;
	@Nullable
	private RegistryKey<LootTable> lootTable;
	private long lootTableSeed;

	public BrushableBlockEntity(BlockPos pos, BlockState state) {
		super(BlockEntityType.BRUSHABLE_BLOCK, pos, state);
	}

	public boolean brush(long worldTime, ServerWorld world, LivingEntity brusher, Direction hitDirection, ItemStack brush) {
		if (this.hitDirection == null) {
			this.hitDirection = hitDirection;
		}

		this.nextDustTime = worldTime + 40L;
		if (worldTime < this.nextBrushTime) {
			return false;
		} else {
			this.nextBrushTime = worldTime + 10L;
			this.generateItem(world, brusher, brush);
			int i = this.getDustedLevel();
			if (++this.brushesCount >= 10) {
				this.finishBrushing(world, brusher, brush);
				return true;
			} else {
				world.scheduleBlockTick(this.getPos(), this.getCachedState().getBlock(), 2);
				int j = this.getDustedLevel();
				if (i != j) {
					BlockState lv = this.getCachedState();
					BlockState lv2 = lv.with(Properties.DUSTED, Integer.valueOf(j));
					world.setBlockState(this.getPos(), lv2, 3);
				}

				return false;
			}
		}
	}

	private void generateItem(ServerWorld world, LivingEntity brusher, ItemStack brush) {
		if (this.lootTable != null) {
			LootTable lv = world.getServer().getReloadableRegistries().getLootTable(this.lootTable);
			if (brusher instanceof ServerPlayerEntity lv2) {
				Criteria.PLAYER_GENERATES_CONTAINER_LOOT.trigger(lv2, this.lootTable);
			}

			LootWorldContext lv3 = new Builder(world)
				.add(LootContextParameters.ORIGIN, Vec3d.ofCenter(this.pos))
				.luck(brusher.getLuck())
				.add(LootContextParameters.THIS_ENTITY, brusher)
				.add(LootContextParameters.TOOL, brush)
				.build(LootContextTypes.ARCHAEOLOGY);
			ObjectArrayList<ItemStack> objectArrayList = lv.generateLoot(lv3, this.lootTableSeed);

			this.item = switch (objectArrayList.size()) {
				case 0 -> ItemStack.EMPTY;
				case 1 -> (ItemStack)objectArrayList.getFirst();
				default -> {
					LOGGER.warn("Expected max 1 loot from loot table {}, but got {}", this.lootTable.getValue(), objectArrayList.size());
					yield (ItemStack)objectArrayList.getFirst();
				}
			};
			this.lootTable = null;
			this.markDirty();
		}
	}

	private void finishBrushing(ServerWorld world, LivingEntity brusher, ItemStack brush) {
		this.spawnItem(world, brusher, brush);
		BlockState lv = this.getCachedState();
		world.syncWorldEvent(3008, this.getPos(), Block.getRawIdFromState(lv));
		Block lv4;
		if (this.getCachedState().getBlock() instanceof BrushableBlock lv3) {
			lv4 = lv3.getBaseBlock();
		} else {
			lv4 = Blocks.AIR;
		}

		world.setBlockState(this.pos, lv4.getDefaultState(), 3);
	}

	private void spawnItem(ServerWorld world, LivingEntity brusher, ItemStack brush) {
		this.generateItem(world, brusher, brush);
		if (!this.item.isEmpty()) {
			double d = (double)EntityType.ITEM.getWidth();
			double e = 1.0 - d;
			double f = d / 2.0;
			Direction lv = (Direction)Objects.requireNonNullElse(this.hitDirection, Direction.UP);
			BlockPos lv2 = this.pos.offset(lv, 1);
			double g = (double)lv2.getX() + 0.5 * e + f;
			double h = (double)lv2.getY() + 0.5 + (double)(EntityType.ITEM.getHeight() / 2.0F);
			double i = (double)lv2.getZ() + 0.5 * e + f;
			ItemEntity lv3 = new ItemEntity(world, g, h, i, this.item.split(world.random.nextInt(21) + 10));
			lv3.setVelocity(Vec3d.ZERO);
			world.spawnEntity(lv3);
			this.item = ItemStack.EMPTY;
		}
	}

	public void scheduledTick(ServerWorld world) {
		if (this.brushesCount != 0 && world.getTime() >= this.nextDustTime) {
			int i = this.getDustedLevel();
			this.brushesCount = Math.max(0, this.brushesCount - 2);
			int j = this.getDustedLevel();
			if (i != j) {
				world.setBlockState(this.getPos(), this.getCachedState().with(Properties.DUSTED, Integer.valueOf(j)), 3);
			}

			int k = 4;
			this.nextDustTime = world.getTime() + 4L;
		}

		if (this.brushesCount == 0) {
			this.hitDirection = null;
			this.nextDustTime = 0L;
			this.nextBrushTime = 0L;
		} else {
			world.scheduleBlockTick(this.getPos(), this.getCachedState().getBlock(), 2);
		}
	}

	private boolean readLootTableFromNbt(NbtCompound nbt) {
		if (nbt.contains("LootTable", 8)) {
			this.lootTable = RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of(nbt.getString("LootTable")));
			this.lootTableSeed = nbt.getLong("LootTableSeed");
			return true;
		} else {
			return false;
		}
	}

	private boolean writeLootTableToNbt(NbtCompound nbt) {
		if (this.lootTable == null) {
			return false;
		} else {
			nbt.putString("LootTable", this.lootTable.getValue().toString());
			if (this.lootTableSeed != 0L) {
				nbt.putLong("LootTableSeed", this.lootTableSeed);
			}

			return true;
		}
	}

	@Override
	public NbtCompound toInitialChunkDataNbt(WrapperLookup registries) {
		NbtCompound lv = super.toInitialChunkDataNbt(registries);
		if (this.hitDirection != null) {
			lv.putInt("hit_direction", this.hitDirection.ordinal());
		}

		if (!this.item.isEmpty()) {
			lv.put("item", this.item.toNbt(registries));
		}

		return lv;
	}

	public BlockEntityUpdateS2CPacket toUpdatePacket() {
		return BlockEntityUpdateS2CPacket.create(this);
	}

	@Override
	protected void readNbt(NbtCompound nbt, WrapperLookup registries) {
		super.readNbt(nbt, registries);
		if (!this.readLootTableFromNbt(nbt) && nbt.contains("item")) {
			this.item = (ItemStack)ItemStack.fromNbt(registries, nbt.getCompound("item")).orElse(ItemStack.EMPTY);
		} else {
			this.item = ItemStack.EMPTY;
		}

		if (nbt.contains("hit_direction")) {
			this.hitDirection = Direction.values()[nbt.getInt("hit_direction")];
		}
	}

	@Override
	protected void writeNbt(NbtCompound nbt, WrapperLookup registries) {
		super.writeNbt(nbt, registries);
		if (!this.writeLootTableToNbt(nbt) && !this.item.isEmpty()) {
			nbt.put("item", this.item.toNbt(registries));
		}
	}

	public void setLootTable(RegistryKey<LootTable> lootTable, long seed) {
		this.lootTable = lootTable;
		this.lootTableSeed = seed;
	}

	private int getDustedLevel() {
		if (this.brushesCount == 0) {
			return 0;
		} else if (this.brushesCount < 3) {
			return 1;
		} else {
			return this.brushesCount < 6 ? 2 : 3;
		}
	}

	@Nullable
	public Direction getHitDirection() {
		return this.hitDirection;
	}

	public ItemStack getItem() {
		return this.item;
	}
}
