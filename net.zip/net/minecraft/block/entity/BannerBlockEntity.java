package net.minecraft.block.entity;

import com.mojang.logging.LogUtils;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBannerBlock;
import net.minecraft.block.BannerBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity.ComponentsAccess;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.ComponentMap.Builder;
import net.minecraft.component.type.BannerPatternsComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtOps;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.registry.RegistryOps;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.text.Text;
import net.minecraft.text.TextCodecs;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Nameable;
import net.minecraft.util.math.BlockPos;
import org.slf4j.Logger;

public class BannerBlockEntity extends BlockEntity implements Nameable {
	private static final Logger LOGGER = LogUtils.getLogger();
	public static final int MAX_PATTERN_COUNT = 6;
	private static final String PATTERNS_KEY = "patterns";
	@Nullable
	private Text customName;
	private final DyeColor baseColor;
	private BannerPatternsComponent patterns = BannerPatternsComponent.DEFAULT;

	public BannerBlockEntity(BlockPos pos, BlockState state) {
		this(pos, state, ((AbstractBannerBlock)state.getBlock()).getColor());
	}

	public BannerBlockEntity(BlockPos pos, BlockState state, DyeColor baseColor) {
		super(BlockEntityType.BANNER, pos, state);
		this.baseColor = baseColor;
	}

	@Override
	public Text getName() {
		return (Text)(this.customName != null ? this.customName : Text.translatable("block.minecraft.banner"));
	}

	@Nullable
	@Override
	public Text getCustomName() {
		return this.customName;
	}

	@Override
	protected void writeNbt(NbtCompound nbt, WrapperLookup registries) {
		super.writeNbt(nbt, registries);
		RegistryOps<NbtElement> lv = registries.getOps(NbtOps.INSTANCE);
		if (!this.patterns.equals(BannerPatternsComponent.DEFAULT)) {
			nbt.put("patterns", (NbtElement)BannerPatternsComponent.CODEC.encodeStart(lv, this.patterns).getOrThrow());
		}

		if (this.customName != null) {
			nbt.put("CustomName", (NbtElement)TextCodecs.CODEC.encodeStart(lv, this.customName).getOrThrow());
		}
	}

	@Override
	protected void readNbt(NbtCompound nbt, WrapperLookup registries) {
		super.readNbt(nbt, registries);
		if (nbt.contains("CustomName")) {
			this.customName = tryParseCustomName(nbt.get("CustomName"), registries);
		}

		if (nbt.contains("patterns")) {
			BannerPatternsComponent.CODEC
				.parse(registries.getOps(NbtOps.INSTANCE), nbt.get("patterns"))
				.resultOrPartial(patterns -> LOGGER.error("Failed to parse banner patterns: '{}'", patterns))
				.ifPresent(patterns -> this.patterns = patterns);
		}
	}

	public BlockEntityUpdateS2CPacket toUpdatePacket() {
		return BlockEntityUpdateS2CPacket.create(this);
	}

	@Override
	public NbtCompound toInitialChunkDataNbt(WrapperLookup registries) {
		return this.createNbt(registries);
	}

	public BannerPatternsComponent getPatterns() {
		return this.patterns;
	}

	public ItemStack getPickStack() {
		ItemStack lv = new ItemStack(BannerBlock.getForColor(this.baseColor));
		lv.applyComponentsFrom(this.createComponentMap());
		return lv;
	}

	public DyeColor getColorForState() {
		return this.baseColor;
	}

	@Override
	protected void readComponents(ComponentsAccess components) {
		super.readComponents(components);
		this.patterns = components.getOrDefault(DataComponentTypes.BANNER_PATTERNS, BannerPatternsComponent.DEFAULT);
		this.customName = components.get(DataComponentTypes.CUSTOM_NAME);
	}

	@Override
	protected void addComponents(Builder builder) {
		super.addComponents(builder);
		builder.add(DataComponentTypes.BANNER_PATTERNS, this.patterns);
		builder.add(DataComponentTypes.CUSTOM_NAME, this.customName);
	}

	@Override
	public void removeFromCopiedStackNbt(NbtCompound nbt) {
		nbt.remove("patterns");
		nbt.remove("CustomName");
	}
}
