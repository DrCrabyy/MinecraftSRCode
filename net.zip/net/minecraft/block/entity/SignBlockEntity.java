package net.minecraft.block.entity;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.DynamicOps;
import java.util.List;
import java.util.UUID;
import java.util.function.UnaryOperator;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractSignBlock;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtOps;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.server.command.CommandOutput;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.filter.FilteredMessage;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.Texts;
import net.minecraft.text.ClickEvent.RunCommand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.slf4j.Logger;

public class SignBlockEntity extends BlockEntity {
	private static final Logger LOGGER = LogUtils.getLogger();
	private static final int MAX_TEXT_WIDTH = 90;
	private static final int TEXT_LINE_HEIGHT = 10;
	@Nullable
	private UUID editor;
	private SignText frontText = this.createText();
	private SignText backText = this.createText();
	private boolean waxed;

	public SignBlockEntity(BlockPos pos, BlockState state) {
		this(BlockEntityType.SIGN, pos, state);
	}

	public SignBlockEntity(BlockEntityType type, BlockPos pos, BlockState state) {
		super(type, pos, state);
	}

	protected SignText createText() {
		return new SignText();
	}

	public boolean isPlayerFacingFront(PlayerEntity player) {
		if (this.getCachedState().getBlock() instanceof AbstractSignBlock lv) {
			Vec3d lv2 = lv.getCenter(this.getCachedState());
			double d = player.getX() - ((double)this.getPos().getX() + lv2.x);
			double e = player.getZ() - ((double)this.getPos().getZ() + lv2.z);
			float f = lv.getRotationDegrees(this.getCachedState());
			float g = (float)(MathHelper.atan2(e, d) * 180.0F / (float)Math.PI) - 90.0F;
			return MathHelper.angleBetween(f, g) <= 90.0F;
		} else {
			return false;
		}
	}

	public SignText getText(boolean front) {
		return front ? this.frontText : this.backText;
	}

	public SignText getFrontText() {
		return this.frontText;
	}

	public SignText getBackText() {
		return this.backText;
	}

	public int getTextLineHeight() {
		return 10;
	}

	public int getMaxTextWidth() {
		return 90;
	}

	@Override
	protected void writeNbt(NbtCompound nbt, WrapperLookup registries) {
		super.writeNbt(nbt, registries);
		DynamicOps<NbtElement> dynamicOps = registries.getOps(NbtOps.INSTANCE);
		SignText.CODEC.encodeStart(dynamicOps, this.frontText).resultOrPartial(LOGGER::error).ifPresent(frontText -> nbt.put("front_text", frontText));
		SignText.CODEC.encodeStart(dynamicOps, this.backText).resultOrPartial(LOGGER::error).ifPresent(backText -> nbt.put("back_text", backText));
		nbt.putBoolean("is_waxed", this.waxed);
	}

	@Override
	protected void readNbt(NbtCompound nbt, WrapperLookup registries) {
		super.readNbt(nbt, registries);
		DynamicOps<NbtElement> dynamicOps = registries.getOps(NbtOps.INSTANCE);
		if (nbt.contains("front_text")) {
			SignText.CODEC
				.parse(dynamicOps, nbt.getCompound("front_text"))
				.resultOrPartial(LOGGER::error)
				.ifPresent(signText -> this.frontText = this.parseLines(signText));
		}

		if (nbt.contains("back_text")) {
			SignText.CODEC
				.parse(dynamicOps, nbt.getCompound("back_text"))
				.resultOrPartial(LOGGER::error)
				.ifPresent(signText -> this.backText = this.parseLines(signText));
		}

		this.waxed = nbt.getBoolean("is_waxed");
	}

	private SignText parseLines(SignText signText) {
		for (int i = 0; i < 4; i++) {
			Text lv = this.parseLine(signText.getMessage(i, false));
			Text lv2 = this.parseLine(signText.getMessage(i, true));
			signText = signText.withMessage(i, lv, lv2);
		}

		return signText;
	}

	private Text parseLine(Text text) {
		if (this.world instanceof ServerWorld lv) {
			try {
				return Texts.parse(createCommandSource(null, lv, this.pos), text, null, 0);
			} catch (CommandSyntaxException var4) {
			}
		}

		return text;
	}

	public void tryChangeText(PlayerEntity player, boolean front, List<FilteredMessage> messages) {
		if (!this.isWaxed() && player.getUuid().equals(this.getEditor()) && this.world != null) {
			this.changeText(text -> this.getTextWithMessages(player, messages, text), front);
			this.setEditor(null);
			this.world.updateListeners(this.getPos(), this.getCachedState(), this.getCachedState(), 3);
		} else {
			LOGGER.warn("Player {} just tried to change non-editable sign", player.getName().getString());
		}
	}

	public boolean changeText(UnaryOperator<SignText> textChanger, boolean front) {
		SignText lv = this.getText(front);
		return this.setText((SignText)textChanger.apply(lv), front);
	}

	private SignText getTextWithMessages(PlayerEntity player, List<FilteredMessage> messages, SignText text) {
		for (int i = 0; i < messages.size(); i++) {
			FilteredMessage lv = (FilteredMessage)messages.get(i);
			Style lv2 = text.getMessage(i, player.shouldFilterText()).getStyle();
			if (player.shouldFilterText()) {
				text = text.withMessage(i, Text.literal(lv.getString()).setStyle(lv2));
			} else {
				text = text.withMessage(i, Text.literal(lv.raw()).setStyle(lv2), Text.literal(lv.getString()).setStyle(lv2));
			}
		}

		return text;
	}

	public boolean setText(SignText text, boolean front) {
		return front ? this.setFrontText(text) : this.setBackText(text);
	}

	private boolean setBackText(SignText backText) {
		if (backText != this.backText) {
			this.backText = backText;
			this.updateListeners();
			return true;
		} else {
			return false;
		}
	}

	private boolean setFrontText(SignText frontText) {
		if (frontText != this.frontText) {
			this.frontText = frontText;
			this.updateListeners();
			return true;
		} else {
			return false;
		}
	}

	public boolean canRunCommandClickEvent(boolean front, PlayerEntity player) {
		return this.isWaxed() && this.getText(front).hasRunCommandClickEvent(player);
	}

	public boolean runCommandClickEvent(PlayerEntity player, World world, BlockPos pos, boolean front) {
		boolean bl2 = false;

		for (Text lv : this.getText(front).getMessages(player.shouldFilterText())) {
			Style lv2 = lv.getStyle();
			ClickEvent lv3 = lv2.getClickEvent();
			if (lv3 instanceof RunCommand) {
				RunCommand var12 = (RunCommand)lv3;
				RunCommand var10000 = var12;

				try {
					var16 = var10000.command();
				} catch (Throwable var15) {
					throw new MatchException(var15.toString(), var15);
				}

				String var14 = var16;
				player.getServer().getCommandManager().executeWithPrefix(createCommandSource(player, world, pos), var14);
				bl2 = true;
			}
		}

		return bl2;
	}

	private static ServerCommandSource createCommandSource(@Nullable PlayerEntity player, World world, BlockPos pos) {
		String string = player == null ? "Sign" : player.getName().getString();
		Text lv = (Text)(player == null ? Text.literal("Sign") : player.getDisplayName());
		return new ServerCommandSource(CommandOutput.DUMMY, Vec3d.ofCenter(pos), Vec2f.ZERO, (ServerWorld)world, 2, string, lv, world.getServer(), player);
	}

	public BlockEntityUpdateS2CPacket toUpdatePacket() {
		return BlockEntityUpdateS2CPacket.create(this);
	}

	@Override
	public NbtCompound toInitialChunkDataNbt(WrapperLookup registries) {
		return this.createComponentlessNbt(registries);
	}

	public void setEditor(@Nullable UUID editor) {
		this.editor = editor;
	}

	@Nullable
	public UUID getEditor() {
		return this.editor;
	}

	private void updateListeners() {
		this.markDirty();
		this.world.updateListeners(this.getPos(), this.getCachedState(), this.getCachedState(), 3);
	}

	public boolean isWaxed() {
		return this.waxed;
	}

	public boolean setWaxed(boolean waxed) {
		if (this.waxed != waxed) {
			this.waxed = waxed;
			this.updateListeners();
			return true;
		} else {
			return false;
		}
	}

	public boolean isPlayerTooFarToEdit(UUID uuid) {
		PlayerEntity lv = this.world.getPlayerByUuid(uuid);
		return lv == null || !lv.canInteractWithBlockAt(this.getPos(), 4.0);
	}

	public static void tick(World world, BlockPos pos, BlockState state, SignBlockEntity blockEntity) {
		UUID uUID = blockEntity.getEditor();
		if (uUID != null) {
			blockEntity.tryClearInvalidEditor(blockEntity, world, uUID);
		}
	}

	private void tryClearInvalidEditor(SignBlockEntity blockEntity, World world, UUID uuid) {
		if (blockEntity.isPlayerTooFarToEdit(uuid)) {
			blockEntity.setEditor(null);
		}
	}

	public SoundEvent getInteractionFailSound() {
		return SoundEvents.BLOCK_SIGN_WAXED_INTERACT_FAIL;
	}
}
