package net.minecraft.block.entity;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.Dynamic;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.MultifaceBlock;
import net.minecraft.block.SculkSpreadable;
import net.minecraft.block.SculkVeinBlock;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtOps;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.Direction.AxisDirection;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.WorldAccess;
import org.slf4j.Logger;

public class SculkSpreadManager {
	public static final int field_37609 = 24;
	public static final int MAX_CHARGE = 1000;
	public static final float field_37611 = 0.5F;
	private static final int MAX_CURSORS = 32;
	public static final int field_37612 = 11;
	public static final int MAX_CURSOR_DISTANCE = 1024;
	final boolean worldGen;
	private final TagKey<Block> replaceableTag;
	private final int extraBlockChance;
	private final int maxDistance;
	private final int spreadChance;
	private final int decayChance;
	private List<SculkSpreadManager.Cursor> cursors = new ArrayList();
	private static final Logger LOGGER = LogUtils.getLogger();

	public SculkSpreadManager(boolean worldGen, TagKey<Block> replaceableTag, int extraBlockChance, int maxDistance, int spreadChance, int decayChance) {
		this.worldGen = worldGen;
		this.replaceableTag = replaceableTag;
		this.extraBlockChance = extraBlockChance;
		this.maxDistance = maxDistance;
		this.spreadChance = spreadChance;
		this.decayChance = decayChance;
	}

	public static SculkSpreadManager create() {
		return new SculkSpreadManager(false, BlockTags.SCULK_REPLACEABLE, 10, 4, 10, 5);
	}

	public static SculkSpreadManager createWorldGen() {
		return new SculkSpreadManager(true, BlockTags.SCULK_REPLACEABLE_WORLD_GEN, 50, 1, 5, 10);
	}

	public TagKey<Block> getReplaceableTag() {
		return this.replaceableTag;
	}

	public int getExtraBlockChance() {
		return this.extraBlockChance;
	}

	public int getMaxDistance() {
		return this.maxDistance;
	}

	public int getSpreadChance() {
		return this.spreadChance;
	}

	public int getDecayChance() {
		return this.decayChance;
	}

	public boolean isWorldGen() {
		return this.worldGen;
	}

	@VisibleForTesting
	public List<SculkSpreadManager.Cursor> getCursors() {
		return this.cursors;
	}

	public void clearCursors() {
		this.cursors.clear();
	}

	public void readNbt(NbtCompound nbt) {
		if (nbt.contains("cursors", 9)) {
			this.cursors.clear();
			List<SculkSpreadManager.Cursor> list = (List<SculkSpreadManager.Cursor>)SculkSpreadManager.Cursor.CODEC
				.listOf()
				.parse(new Dynamic(NbtOps.INSTANCE, nbt.getList("cursors", 10)))
				.resultOrPartial(LOGGER::error)
				.orElseGet(ArrayList::new);
			int i = Math.min(list.size(), 32);

			for (int j = 0; j < i; j++) {
				this.addCursor((SculkSpreadManager.Cursor)list.get(j));
			}
		}
	}

	public void writeNbt(NbtCompound nbt) {
		SculkSpreadManager.Cursor.CODEC
			.listOf()
			.encodeStart(NbtOps.INSTANCE, this.cursors)
			.resultOrPartial(LOGGER::error)
			.ifPresent(cursorsNbt -> nbt.put("cursors", cursorsNbt));
	}

	public void spread(BlockPos pos, int charge) {
		while (charge > 0) {
			int j = Math.min(charge, 1000);
			this.addCursor(new SculkSpreadManager.Cursor(pos, j));
			charge -= j;
		}
	}

	private void addCursor(SculkSpreadManager.Cursor cursor) {
		if (this.cursors.size() < 32) {
			this.cursors.add(cursor);
		}
	}

	public void tick(WorldAccess world, BlockPos pos, Random random, boolean shouldConvertToBlock) {
		if (!this.cursors.isEmpty()) {
			List<SculkSpreadManager.Cursor> list = new ArrayList();
			Map<BlockPos, SculkSpreadManager.Cursor> map = new HashMap();
			Object2IntMap<BlockPos> object2IntMap = new Object2IntOpenHashMap();

			for (SculkSpreadManager.Cursor lv : this.cursors) {
				if (!lv.isTooFarFrom(pos)) {
					lv.spread(world, pos, random, this, shouldConvertToBlock);
					if (lv.charge <= 0) {
						world.syncWorldEvent(3006, lv.getPos(), 0);
					} else {
						BlockPos lv2 = lv.getPos();
						object2IntMap.computeInt(lv2, (posx, charge) -> (charge == null ? 0 : charge) + lv.charge);
						SculkSpreadManager.Cursor lv3 = (SculkSpreadManager.Cursor)map.get(lv2);
						if (lv3 == null) {
							map.put(lv2, lv);
							list.add(lv);
						} else if (!this.isWorldGen() && lv.charge + lv3.charge <= 1000) {
							lv3.merge(lv);
						} else {
							list.add(lv);
							if (lv.charge < lv3.charge) {
								map.put(lv2, lv);
							}
						}
					}
				}
			}

			ObjectIterator var16 = object2IntMap.object2IntEntrySet().iterator();

			while (var16.hasNext()) {
				Entry<BlockPos> entry = (Entry<BlockPos>)var16.next();
				BlockPos lv2 = (BlockPos)entry.getKey();
				int i = entry.getIntValue();
				SculkSpreadManager.Cursor lv4 = (SculkSpreadManager.Cursor)map.get(lv2);
				Collection<Direction> collection = lv4 == null ? null : lv4.getFaces();
				if (i > 0 && collection != null) {
					int j = (int)(Math.log1p((double)i) / 2.3F) + 1;
					int k = (j << 6) + MultifaceBlock.directionsToFlag(collection);
					world.syncWorldEvent(3006, lv2, k);
				}
			}

			this.cursors = list;
		}
	}

	public static class Cursor {
		private static final ObjectArrayList<Vec3i> OFFSETS = Util.make(
			new ObjectArrayList(18),
			list -> BlockPos.stream(new BlockPos(-1, -1, -1), new BlockPos(1, 1, 1))
					.filter(pos -> (pos.getX() == 0 || pos.getY() == 0 || pos.getZ() == 0) && !pos.equals(BlockPos.ORIGIN))
					.map(BlockPos::toImmutable)
					.forEach(list::add)
		);
		public static final int field_37622 = 1;
		private BlockPos pos;
		int charge;
		private int update;
		private int decay;
		@Nullable
		private Set<Direction> faces;
		private static final Codec<Set<Direction>> DIRECTION_SET_CODEC = Direction.CODEC
			.listOf()
			.xmap(directions -> Sets.newEnumSet(directions, Direction.class), Lists::newArrayList);
		public static final Codec<SculkSpreadManager.Cursor> CODEC = RecordCodecBuilder.create(
			instance -> instance.group(
						BlockPos.CODEC.fieldOf("pos").forGetter(SculkSpreadManager.Cursor::getPos),
						Codec.intRange(0, 1000).fieldOf("charge").orElse(0).forGetter(SculkSpreadManager.Cursor::getCharge),
						Codec.intRange(0, 1).fieldOf("decay_delay").orElse(1).forGetter(SculkSpreadManager.Cursor::getDecay),
						Codec.intRange(0, Integer.MAX_VALUE).fieldOf("update_delay").orElse(0).forGetter(cursor -> cursor.update),
						DIRECTION_SET_CODEC.lenientOptionalFieldOf("facings").forGetter(cursor -> Optional.ofNullable(cursor.getFaces()))
					)
					.apply(instance, SculkSpreadManager.Cursor::new)
		);

		private Cursor(BlockPos pos, int charge, int decay, int update, Optional<Set<Direction>> faces) {
			this.pos = pos;
			this.charge = charge;
			this.decay = decay;
			this.update = update;
			this.faces = (Set<Direction>)faces.orElse(null);
		}

		public Cursor(BlockPos pos, int charge) {
			this(pos, charge, 1, 0, Optional.empty());
		}

		public BlockPos getPos() {
			return this.pos;
		}

		boolean isTooFarFrom(BlockPos pos) {
			return this.pos.getChebyshevDistance(pos) > 1024;
		}

		public int getCharge() {
			return this.charge;
		}

		public int getDecay() {
			return this.decay;
		}

		@Nullable
		public Set<Direction> getFaces() {
			return this.faces;
		}

		private boolean canSpread(WorldAccess world, BlockPos pos, boolean worldGen) {
			if (this.charge <= 0) {
				return false;
			} else if (worldGen) {
				return true;
			} else {
				return world instanceof ServerWorld lv ? lv.shouldTickBlockPos(pos) : false;
			}
		}

		public void spread(WorldAccess world, BlockPos pos, Random random, SculkSpreadManager spreadManager, boolean shouldConvertToBlock) {
			if (this.canSpread(world, pos, spreadManager.worldGen)) {
				if (this.update > 0) {
					this.update--;
				} else {
					BlockState lv = world.getBlockState(this.pos);
					SculkSpreadable lv2 = getSpreadable(lv);
					if (shouldConvertToBlock && lv2.spread(world, this.pos, lv, this.faces, spreadManager.isWorldGen())) {
						if (lv2.shouldConvertToSpreadable()) {
							lv = world.getBlockState(this.pos);
							lv2 = getSpreadable(lv);
						}

						world.playSound(null, this.pos, SoundEvents.BLOCK_SCULK_SPREAD, SoundCategory.BLOCKS, 1.0F, 1.0F);
					}

					this.charge = lv2.spread(this, world, pos, random, spreadManager, shouldConvertToBlock);
					if (this.charge <= 0) {
						lv2.spreadAtSamePosition(world, lv, this.pos, random);
					} else {
						BlockPos lv3 = getSpreadPos(world, this.pos, random);
						if (lv3 != null) {
							lv2.spreadAtSamePosition(world, lv, this.pos, random);
							this.pos = lv3.toImmutable();
							if (spreadManager.isWorldGen() && !this.pos.isWithinDistance(new Vec3i(pos.getX(), this.pos.getY(), pos.getZ()), 15.0)) {
								this.charge = 0;
								return;
							}

							lv = world.getBlockState(lv3);
						}

						if (lv.getBlock() instanceof SculkSpreadable) {
							this.faces = MultifaceBlock.collectDirections(lv);
						}

						this.decay = lv2.getDecay(this.decay);
						this.update = lv2.getUpdate();
					}
				}
			}
		}

		void merge(SculkSpreadManager.Cursor cursor) {
			this.charge = this.charge + cursor.charge;
			cursor.charge = 0;
			this.update = Math.min(this.update, cursor.update);
		}

		private static SculkSpreadable getSpreadable(BlockState state) {
			return state.getBlock() instanceof SculkSpreadable lv ? lv : SculkSpreadable.VEIN_ONLY_SPREADER;
		}

		private static List<Vec3i> shuffleOffsets(Random random) {
			return Util.copyShuffled(OFFSETS, random);
		}

		@Nullable
		private static BlockPos getSpreadPos(WorldAccess world, BlockPos pos, Random random) {
			Mutable lv = pos.mutableCopy();
			Mutable lv2 = pos.mutableCopy();

			for (Vec3i lv3 : shuffleOffsets(random)) {
				lv2.set(pos, lv3);
				BlockState lv4 = world.getBlockState(lv2);
				if (lv4.getBlock() instanceof SculkSpreadable && canSpread(world, pos, lv2)) {
					lv.set(lv2);
					if (SculkVeinBlock.veinCoversSculkReplaceable(world, lv4, lv2)) {
						break;
					}
				}
			}

			return lv.equals(pos) ? null : lv;
		}

		private static boolean canSpread(WorldAccess world, BlockPos sourcePos, BlockPos targetPos) {
			if (sourcePos.getManhattanDistance(targetPos) == 1) {
				return true;
			} else {
				BlockPos lv = targetPos.subtract(sourcePos);
				Direction lv2 = Direction.from(Axis.X, lv.getX() < 0 ? AxisDirection.NEGATIVE : AxisDirection.POSITIVE);
				Direction lv3 = Direction.from(Axis.Y, lv.getY() < 0 ? AxisDirection.NEGATIVE : AxisDirection.POSITIVE);
				Direction lv4 = Direction.from(Axis.Z, lv.getZ() < 0 ? AxisDirection.NEGATIVE : AxisDirection.POSITIVE);
				if (lv.getX() == 0) {
					return canSpread(world, sourcePos, lv3) || canSpread(world, sourcePos, lv4);
				} else {
					return lv.getY() == 0
						? canSpread(world, sourcePos, lv2) || canSpread(world, sourcePos, lv4)
						: canSpread(world, sourcePos, lv2) || canSpread(world, sourcePos, lv3);
				}
			}
		}

		private static boolean canSpread(WorldAccess world, BlockPos pos, Direction direction) {
			BlockPos lv = pos.offset(direction);
			return !world.getBlockState(lv).isSideSolidFullSquare(world, lv, direction.getOpposite());
		}
	}
}
