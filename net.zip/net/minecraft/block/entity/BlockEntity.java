package net.minecraft.block.entity;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import java.util.HashSet;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.block.BlockState;
import net.minecraft.component.ComponentChanges;
import net.minecraft.component.ComponentMap;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.MergedComponentMap;
import net.minecraft.component.ComponentMap.Builder;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtOps;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.text.Text;
import net.minecraft.text.TextCodecs;
import net.minecraft.util.Identifier;
import net.minecraft.util.ItemScatterer;
import net.minecraft.util.crash.CrashReportSection;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.slf4j.Logger;

public abstract class BlockEntity {
	private static final Logger LOGGER = LogUtils.getLogger();
	private final BlockEntityType<?> type;
	@Nullable
	protected World world;
	protected final BlockPos pos;
	protected boolean removed;
	private BlockState cachedState;
	private ComponentMap components = ComponentMap.EMPTY;

	public BlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
		this.type = type;
		this.pos = pos.toImmutable();
		this.validateSupports(state);
		this.cachedState = state;
	}

	private void validateSupports(BlockState state) {
		if (!this.supports(state)) {
			throw new IllegalStateException("Invalid block entity " + this.getNameForReport() + " state at " + this.pos + ", got " + state);
		}
	}

	public boolean supports(BlockState state) {
		return this.type.supports(state);
	}

	public static BlockPos posFromNbt(NbtCompound nbt) {
		return new BlockPos(nbt.getInt("x"), nbt.getInt("y"), nbt.getInt("z"));
	}

	@Nullable
	public World getWorld() {
		return this.world;
	}

	public void setWorld(World world) {
		this.world = world;
	}

	public boolean hasWorld() {
		return this.world != null;
	}

	protected void readNbt(NbtCompound nbt, WrapperLookup registries) {
	}

	public final void read(NbtCompound nbt, WrapperLookup registries) {
		this.readNbt(nbt, registries);
		BlockEntity.Components.CODEC
			.parse(registries.getOps(NbtOps.INSTANCE), nbt)
			.resultOrPartial(error -> LOGGER.warn("Failed to load components: {}", error))
			.ifPresent(components -> this.components = components);
	}

	public final void readComponentlessNbt(NbtCompound nbt, WrapperLookup registries) {
		this.readNbt(nbt, registries);
	}

	protected void writeNbt(NbtCompound nbt, WrapperLookup registries) {
	}

	public final NbtCompound createNbtWithIdentifyingData(WrapperLookup registries) {
		NbtCompound lv = this.createNbt(registries);
		this.writeIdentifyingData(lv);
		return lv;
	}

	public final NbtCompound createNbtWithId(WrapperLookup registries) {
		NbtCompound lv = this.createNbt(registries);
		this.writeIdToNbt(lv);
		return lv;
	}

	public final NbtCompound createNbt(WrapperLookup registries) {
		NbtCompound lv = new NbtCompound();
		this.writeNbt(lv, registries);
		BlockEntity.Components.CODEC
			.encodeStart(registries.getOps(NbtOps.INSTANCE), this.components)
			.resultOrPartial(snbt -> LOGGER.warn("Failed to save components: {}", snbt))
			.ifPresent(nbt -> lv.copyFrom((NbtCompound)nbt));
		return lv;
	}

	public final NbtCompound createComponentlessNbt(WrapperLookup registries) {
		NbtCompound lv = new NbtCompound();
		this.writeNbt(lv, registries);
		return lv;
	}

	public final NbtCompound createComponentlessNbtWithIdentifyingData(WrapperLookup registries) {
		NbtCompound lv = this.createComponentlessNbt(registries);
		this.writeIdentifyingData(lv);
		return lv;
	}

	private void writeIdToNbt(NbtCompound nbt) {
		Identifier lv = BlockEntityType.getId(this.getType());
		if (lv == null) {
			throw new RuntimeException(this.getClass() + " is missing a mapping! This is a bug!");
		} else {
			nbt.putString("id", lv.toString());
		}
	}

	public static void writeIdToNbt(NbtCompound nbt, BlockEntityType<?> type) {
		nbt.putString("id", BlockEntityType.getId(type).toString());
	}

	private void writeIdentifyingData(NbtCompound nbt) {
		this.writeIdToNbt(nbt);
		nbt.putInt("x", this.pos.getX());
		nbt.putInt("y", this.pos.getY());
		nbt.putInt("z", this.pos.getZ());
	}

	@Nullable
	public static BlockEntity createFromNbt(BlockPos pos, BlockState state, NbtCompound nbt, WrapperLookup registries) {
		String string = nbt.getString("id");
		Identifier lv = Identifier.tryParse(string);
		if (lv == null) {
			LOGGER.error("Block entity has invalid type: {}", string);
			return null;
		} else {
			return (BlockEntity)Registries.BLOCK_ENTITY_TYPE.getOptionalValue(lv).map(type -> {
				try {
					return type.instantiate(pos, state);
				} catch (Throwable var5x) {
					LOGGER.error("Failed to create block entity {}", string, var5x);
					return null;
				}
			}).map(blockEntity -> {
				try {
					blockEntity.read(nbt, registries);
					return blockEntity;
				} catch (Throwable var5x) {
					LOGGER.error("Failed to load data for block entity {}", string, var5x);
					return null;
				}
			}).orElseGet(() -> {
				LOGGER.warn("Skipping BlockEntity with id {}", string);
				return null;
			});
		}
	}

	public void markDirty() {
		if (this.world != null) {
			markDirty(this.world, this.pos, this.cachedState);
		}
	}

	protected static void markDirty(World world, BlockPos pos, BlockState state) {
		world.markDirty(pos);
		if (!state.isAir()) {
			world.updateComparators(pos, state.getBlock());
		}
	}

	public BlockPos getPos() {
		return this.pos;
	}

	public BlockState getCachedState() {
		return this.cachedState;
	}

	@Nullable
	public Packet<ClientPlayPacketListener> toUpdatePacket() {
		return null;
	}

	public NbtCompound toInitialChunkDataNbt(WrapperLookup registries) {
		return new NbtCompound();
	}

	public boolean isRemoved() {
		return this.removed;
	}

	public void markRemoved() {
		this.removed = true;
	}

	public void cancelRemoval() {
		this.removed = false;
	}

	public void onStateReplaced(BlockPos pos, BlockState oldState, boolean moved) {
		if (this instanceof Inventory lv && this.world != null) {
			ItemScatterer.spawn(this.world, pos, lv);
		}
	}

	public boolean onSyncedBlockEvent(int type, int data) {
		return false;
	}

	public void populateCrashReport(CrashReportSection crashReportSection) {
		crashReportSection.add("Name", this::getNameForReport);
		if (this.world != null) {
			CrashReportSection.addBlockInfo(crashReportSection, this.world, this.pos, this.getCachedState());
			CrashReportSection.addBlockInfo(crashReportSection, this.world, this.pos, this.world.getBlockState(this.pos));
		}
	}

	private String getNameForReport() {
		return Registries.BLOCK_ENTITY_TYPE.getId(this.getType()) + " // " + this.getClass().getCanonicalName();
	}

	public BlockEntityType<?> getType() {
		return this.type;
	}

	@Deprecated
	public void setCachedState(BlockState state) {
		this.validateSupports(state);
		this.cachedState = state;
	}

	protected void readComponents(BlockEntity.ComponentsAccess components) {
	}

	public final void readComponents(ItemStack stack) {
		this.readComponents(stack.getDefaultComponents(), stack.getComponentChanges());
	}

	public final void readComponents(ComponentMap defaultComponents, ComponentChanges components) {
		final Set<ComponentType<?>> set = new HashSet();
		set.add(DataComponentTypes.BLOCK_ENTITY_DATA);
		set.add(DataComponentTypes.BLOCK_STATE);
		final ComponentMap lv = MergedComponentMap.create(defaultComponents, components);
		this.readComponents(new BlockEntity.ComponentsAccess() {
			@Nullable
			@Override
			public <T> T get(ComponentType<T> type) {
				set.add(type);
				return lv.get(type);
			}

			@Override
			public <T> T getOrDefault(ComponentType<? extends T> type, T fallback) {
				set.add(type);
				return lv.getOrDefault(type, fallback);
			}
		});
		ComponentChanges lv2 = components.withRemovedIf(set::contains);
		this.components = lv2.toAddedRemovedPair().added();
	}

	protected void addComponents(Builder builder) {
	}

	@Deprecated
	public void removeFromCopiedStackNbt(NbtCompound nbt) {
	}

	public final ComponentMap createComponentMap() {
		Builder lv = ComponentMap.builder();
		lv.addAll(this.components);
		this.addComponents(lv);
		return lv.build();
	}

	public ComponentMap getComponents() {
		return this.components;
	}

	public void setComponents(ComponentMap components) {
		this.components = components;
	}

	@Nullable
	public static Text tryParseCustomName(@Nullable NbtElement nbt, WrapperLookup registries) {
		return nbt == null
			? null
			: (Text)TextCodecs.CODEC
				.parse(registries.getOps(NbtOps.INSTANCE), nbt)
				.resultOrPartial(error -> LOGGER.warn("Failed to parse custom name, discarding: {}", error))
				.orElse(null);
	}

	static class Components {
		public static final Codec<ComponentMap> CODEC = ComponentMap.CODEC.optionalFieldOf("components", ComponentMap.EMPTY).codec();

		private Components() {
		}
	}

	protected interface ComponentsAccess {
		@Nullable
		<T> T get(ComponentType<T> type);

		<T> T getOrDefault(ComponentType<? extends T> type, T fallback);
	}
}
