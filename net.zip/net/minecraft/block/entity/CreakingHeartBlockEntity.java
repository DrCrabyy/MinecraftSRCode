package net.minecraft.block.entity;

import com.mojang.datafixers.util.Either;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CreakingHeartBlock;
import net.minecraft.block.MultifaceBlock;
import net.minecraft.block.enums.CreakingHeartState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LargeEntitySpawnHelper;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.LargeEntitySpawnHelper.Requirements;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.CreakingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.particle.TrailParticleEffect;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.IterationState;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Difficulty;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.event.GameEvent.Emitter;
import org.apache.commons.lang3.mutable.Mutable;
import org.apache.commons.lang3.mutable.MutableObject;

public class CreakingHeartBlockEntity extends BlockEntity {
	private static final int field_54776 = 32;
	public static final int field_54775 = 32;
	private static final int field_54777 = 34;
	private static final int field_54778 = 16;
	private static final int field_54779 = 8;
	private static final int field_54780 = 5;
	private static final int field_54781 = 20;
	private static final int field_55498 = 5;
	private static final int field_54782 = 100;
	private static final int field_54783 = 10;
	private static final int field_54784 = 10;
	private static final int field_54785 = 50;
	private static final int field_55085 = 2;
	private static final int field_55086 = 64;
	private static final int field_55499 = 30;
	private static final Optional<CreakingEntity> DEFAULT_CREAKING_PUPPET = Optional.empty();
	@Nullable
	private Either<CreakingEntity, UUID> creakingPuppet;
	private long ticks;
	private int creakingUpdateTimer;
	private int trailParticlesSpawnTimer;
	@Nullable
	private Vec3d lastCreakingPuppetPos;
	private int comparatorOutput;

	public CreakingHeartBlockEntity(BlockPos pos, BlockState state) {
		super(BlockEntityType.CREAKING_HEART, pos, state);
	}

	public static void tick(World world, BlockPos pos, BlockState state, CreakingHeartBlockEntity blockEntity) {
		blockEntity.ticks++;
		if (world instanceof ServerWorld lv) {
			int i = blockEntity.calcComparatorOutput();
			if (blockEntity.comparatorOutput != i) {
				blockEntity.comparatorOutput = i;
				world.updateComparators(pos, Blocks.CREAKING_HEART);
			}

			if (blockEntity.trailParticlesSpawnTimer > 0) {
				if (blockEntity.trailParticlesSpawnTimer > 50) {
					blockEntity.spawnTrailParticles(lv, 1, true);
					blockEntity.spawnTrailParticles(lv, 1, false);
				}

				if (blockEntity.trailParticlesSpawnTimer % 10 == 0 && blockEntity.lastCreakingPuppetPos != null) {
					blockEntity.getCreakingPuppet().ifPresent(creaking -> blockEntity.lastCreakingPuppetPos = creaking.getBoundingBox().getCenter());
					Vec3d lv2 = Vec3d.ofCenter(pos);
					float f = 0.2F + 0.8F * (float)(100 - blockEntity.trailParticlesSpawnTimer) / 100.0F;
					Vec3d lv3 = lv2.subtract(blockEntity.lastCreakingPuppetPos).multiply((double)f).add(blockEntity.lastCreakingPuppetPos);
					BlockPos lv4 = BlockPos.ofFloored(lv3);
					float g = (float)blockEntity.trailParticlesSpawnTimer / 2.0F / 100.0F + 0.5F;
					lv.playSound(null, lv4, SoundEvents.BLOCK_CREAKING_HEART_HURT, SoundCategory.BLOCKS, g, 1.0F);
				}

				blockEntity.trailParticlesSpawnTimer--;
			}

			if (blockEntity.creakingUpdateTimer-- < 0) {
				blockEntity.creakingUpdateTimer = blockEntity.world == null ? 20 : blockEntity.world.random.nextInt(5) + 20;
				BlockState lv5 = getBlockState(world, state, pos, blockEntity);
				if (lv5 != state) {
					world.setBlockState(pos, lv5, 3);
					if (lv5.get(CreakingHeartBlock.ACTIVE) == CreakingHeartState.UPROOTED) {
						return;
					}
				}

				if (blockEntity.creakingPuppet == null) {
					if (lv5.get(CreakingHeartBlock.ACTIVE) == CreakingHeartState.AWAKE) {
						if (world.getDifficulty() != Difficulty.PEACEFUL) {
							if (lv.getGameRules().getBoolean(GameRules.DO_MOB_SPAWNING)) {
								PlayerEntity lv7 = world.getClosestPlayer((double)pos.getX(), (double)pos.getY(), (double)pos.getZ(), 32.0, false);
								if (lv7 != null) {
									CreakingEntity lv6 = spawnCreakingPuppet(lv, blockEntity);
									if (lv6 != null) {
										blockEntity.setCreakingPuppet(lv6);
										lv6.playSound(SoundEvents.ENTITY_CREAKING_SPAWN);
										world.playSound(null, blockEntity.getPos(), SoundEvents.BLOCK_CREAKING_HEART_SPAWN, SoundCategory.BLOCKS, 1.0F, 1.0F);
									}
								}
							}
						}
					}
				} else {
					Optional<CreakingEntity> optional = blockEntity.getCreakingPuppet();
					if (optional.isPresent()) {
						CreakingEntity lv6 = (CreakingEntity)optional.get();
						if (!CreakingHeartBlock.isNightAndNatural(world) && !lv6.isPersistent() || blockEntity.getDistanceToPuppet() > 34.0 || lv6.isStuckWithPlayer()) {
							blockEntity.killPuppet(null);
						}
					}
				}
			}
		}
	}

	private static BlockState getBlockState(World world, BlockState state, BlockPos pos, CreakingHeartBlockEntity creakingHeart) {
		if (!CreakingHeartBlock.shouldBeEnabled(state, world, pos) && creakingHeart.creakingPuppet == null) {
			return state.with(CreakingHeartBlock.ACTIVE, CreakingHeartState.UPROOTED);
		} else {
			boolean bl = CreakingHeartBlock.isNightAndNatural(world);
			return state.with(CreakingHeartBlock.ACTIVE, bl ? CreakingHeartState.AWAKE : CreakingHeartState.DORMANT);
		}
	}

	private double getDistanceToPuppet() {
		return (Double)this.getCreakingPuppet().map(creaking -> Math.sqrt(creaking.squaredDistanceTo(Vec3d.ofBottomCenter(this.getPos())))).orElse(0.0);
	}

	private void clearCreakingPuppet() {
		this.creakingPuppet = null;
		this.markDirty();
	}

	public void setCreakingPuppet(CreakingEntity creakingPuppet) {
		this.creakingPuppet = Either.left(creakingPuppet);
		this.markDirty();
	}

	public void setCreakingPuppetFromUuid(UUID creakingPuppetUuid) {
		this.creakingPuppet = Either.right(creakingPuppetUuid);
		this.ticks = 0L;
		this.markDirty();
	}

	private Optional<CreakingEntity> getCreakingPuppet() {
		if (this.creakingPuppet == null) {
			return DEFAULT_CREAKING_PUPPET;
		} else {
			if (this.creakingPuppet.left().isPresent()) {
				CreakingEntity lv = (CreakingEntity)this.creakingPuppet.left().get();
				if (!lv.isRemoved()) {
					return Optional.of(lv);
				}

				this.setCreakingPuppetFromUuid(lv.getUuid());
			}

			if (this.world instanceof ServerWorld lv2 && this.creakingPuppet.right().isPresent()) {
				UUID uUID = (UUID)this.creakingPuppet.right().get();
				if (lv2.getEntity(uUID) instanceof CreakingEntity lv4) {
					this.setCreakingPuppet(lv4);
					return Optional.of(lv4);
				}

				if (this.ticks >= 30L) {
					this.clearCreakingPuppet();
				}

				return DEFAULT_CREAKING_PUPPET;
			}

			return DEFAULT_CREAKING_PUPPET;
		}
	}

	@Nullable
	private static CreakingEntity spawnCreakingPuppet(ServerWorld world, CreakingHeartBlockEntity blockEntity) {
		BlockPos lv = blockEntity.getPos();
		Optional<CreakingEntity> optional = LargeEntitySpawnHelper.trySpawnAt(
			EntityType.CREAKING, SpawnReason.SPAWNER, world, lv, 5, 16, 8, Requirements.CREAKING, true
		);
		if (optional.isEmpty()) {
			return null;
		} else {
			CreakingEntity lv2 = (CreakingEntity)optional.get();
			world.emitGameEvent(lv2, GameEvent.ENTITY_PLACE, lv2.getPos());
			world.sendEntityStatus(lv2, (byte)60);
			lv2.initHomePos(lv);
			return lv2;
		}
	}

	public BlockEntityUpdateS2CPacket toUpdatePacket() {
		return BlockEntityUpdateS2CPacket.create(this);
	}

	@Override
	public NbtCompound toInitialChunkDataNbt(WrapperLookup registries) {
		return this.createComponentlessNbt(registries);
	}

	public void onPuppetDamage() {
		if (this.getCreakingPuppet().orElse(null) instanceof CreakingEntity lv) {
			if (this.world instanceof ServerWorld lv2) {
				if (this.trailParticlesSpawnTimer <= 0) {
					this.spawnTrailParticles(lv2, 20, false);
					if (this.getCachedState().get(CreakingHeartBlock.ACTIVE) == CreakingHeartState.AWAKE) {
						int i = this.world.getRandom().nextBetween(2, 3);

						for (int j = 0; j < i; j++) {
							this.findResinGenerationPos().ifPresent(pos -> {
								this.world.playSound(null, pos, SoundEvents.BLOCK_RESIN_PLACE, SoundCategory.BLOCKS, 1.0F, 1.0F);
								this.world.emitGameEvent(GameEvent.BLOCK_PLACE, pos, Emitter.of(this.getCachedState()));
							});
						}
					}

					this.trailParticlesSpawnTimer = 100;
					this.lastCreakingPuppetPos = lv.getBoundingBox().getCenter();
				}
			}
		}
	}

	private Optional<BlockPos> findResinGenerationPos() {
		Mutable<BlockPos> mutable = new MutableObject(null);
		BlockPos.iterateRecursively(this.pos, 2, 64, (pos, consumer) -> {
			for (Direction lv : Util.copyShuffled(Direction.values(), this.world.random)) {
				BlockPos lv2 = pos.offset(lv);
				if (this.world.getBlockState(lv2).isIn(BlockTags.PALE_OAK_LOGS)) {
					consumer.accept(lv2);
				}
			}
		}, pos -> {
			if (!this.world.getBlockState(pos).isIn(BlockTags.PALE_OAK_LOGS)) {
				return IterationState.ACCEPT;
			} else {
				for (Direction lv : Util.copyShuffled(Direction.values(), this.world.random)) {
					BlockPos lv2 = pos.offset(lv);
					BlockState lv3 = this.world.getBlockState(lv2);
					Direction lv4 = lv.getOpposite();
					if (lv3.isAir()) {
						lv3 = Blocks.RESIN_CLUMP.getDefaultState();
					} else if (lv3.isOf(Blocks.WATER) && lv3.getFluidState().isStill()) {
						lv3 = Blocks.RESIN_CLUMP.getDefaultState().with(MultifaceBlock.WATERLOGGED, Boolean.valueOf(true));
					}

					if (lv3.isOf(Blocks.RESIN_CLUMP) && !MultifaceBlock.hasDirection(lv3, lv4)) {
						this.world.setBlockState(lv2, lv3.with(MultifaceBlock.getProperty(lv4), Boolean.valueOf(true)), 3);
						mutable.setValue(lv2);
						return IterationState.STOP;
					}
				}

				return IterationState.ACCEPT;
			}
		});
		return Optional.ofNullable((BlockPos)mutable.getValue());
	}

	private void spawnTrailParticles(ServerWorld world, int count, boolean towardsPuppet) {
		if (this.getCreakingPuppet().orElse(null) instanceof CreakingEntity lv) {
			int j = towardsPuppet ? 16545810 : 6250335;
			Random lv2 = world.random;

			for (double d = 0.0; d < (double)count; d++) {
				Box lv3 = lv.getBoundingBox();
				Vec3d lv4 = lv3.getMinPos().add(lv2.nextDouble() * lv3.getLengthX(), lv2.nextDouble() * lv3.getLengthY(), lv2.nextDouble() * lv3.getLengthZ());
				Vec3d lv5 = Vec3d.of(this.getPos()).add(lv2.nextDouble(), lv2.nextDouble(), lv2.nextDouble());
				if (towardsPuppet) {
					Vec3d lv6 = lv4;
					lv4 = lv5;
					lv5 = lv6;
				}

				TrailParticleEffect lv7 = new TrailParticleEffect(lv5, j, lv2.nextInt(40) + 10);
				world.spawnParticles(lv7, true, true, lv4.x, lv4.y, lv4.z, 1, 0.0, 0.0, 0.0, 0.0);
			}
		}
	}

	@Override
	public void onStateReplaced(BlockPos pos, BlockState oldState, boolean moved) {
		this.killPuppet(null);
	}

	public void killPuppet(@Nullable DamageSource damageSource) {
		if (this.getCreakingPuppet().orElse(null) instanceof CreakingEntity lv) {
			if (damageSource == null) {
				lv.finishCrumbling();
			} else {
				lv.killFromHeart(damageSource);
				lv.setCrumbling();
				lv.setHealth(0.0F);
			}

			this.clearCreakingPuppet();
		}
	}

	public boolean isPuppet(CreakingEntity creaking) {
		return (Boolean)this.getCreakingPuppet().map(puppet -> puppet == creaking).orElse(false);
	}

	public int getComparatorOutput() {
		return this.comparatorOutput;
	}

	public int calcComparatorOutput() {
		if (this.creakingPuppet != null && !this.getCreakingPuppet().isEmpty()) {
			double d = this.getDistanceToPuppet();
			double e = Math.clamp(d, 0.0, 32.0) / 32.0;
			return 15 - (int)Math.floor(e * 15.0);
		} else {
			return 0;
		}
	}

	@Override
	protected void readNbt(NbtCompound nbt, WrapperLookup registries) {
		super.readNbt(nbt, registries);
		if (nbt.contains("creaking")) {
			this.setCreakingPuppetFromUuid(nbt.getUuid("creaking"));
		} else {
			this.clearCreakingPuppet();
		}
	}

	@Override
	protected void writeNbt(NbtCompound nbt, WrapperLookup registries) {
		super.writeNbt(nbt, registries);
		if (this.creakingPuppet != null) {
			nbt.putUuid("creaking", (UUID)this.creakingPuppet.map(Entity::getUuid, uuid -> uuid));
		}
	}
}
