package net.minecraft.block.entity;

import javax.annotation.Nullable;
import net.minecraft.block.BlockState;
import net.minecraft.block.LecternBlock;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.WritableBookContentComponent;
import net.minecraft.component.type.WrittenBookContentComponent;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.screen.LecternScreenHandler;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.screen.PropertyDelegate;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.command.CommandOutput;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Clearable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;

public class LecternBlockEntity extends BlockEntity implements Clearable, NamedScreenHandlerFactory {
	public static final int field_31348 = 0;
	public static final int field_31349 = 1;
	public static final int field_31350 = 0;
	public static final int field_31351 = 1;
	private final Inventory inventory = new LecternBlockEntity$1(this);
	private final PropertyDelegate propertyDelegate = new LecternBlockEntity$2(this);
	ItemStack book = ItemStack.EMPTY;
	int currentPage;
	private int pageCount;

	public LecternBlockEntity(BlockPos pos, BlockState state) {
		super(BlockEntityType.LECTERN, pos, state);
	}

	public ItemStack getBook() {
		return this.book;
	}

	public boolean hasBook() {
		return this.book.contains(DataComponentTypes.WRITABLE_BOOK_CONTENT) || this.book.contains(DataComponentTypes.WRITTEN_BOOK_CONTENT);
	}

	public void setBook(ItemStack book) {
		this.setBook(book, null);
	}

	void onBookRemoved() {
		this.currentPage = 0;
		this.pageCount = 0;
		LecternBlock.setHasBook(null, this.getWorld(), this.getPos(), this.getCachedState(), false);
	}

	public void setBook(ItemStack book, @Nullable PlayerEntity player) {
		this.book = this.resolveBook(book, player);
		this.currentPage = 0;
		this.pageCount = getPageCount(this.book);
		this.markDirty();
	}

	void setCurrentPage(int currentPage) {
		int j = MathHelper.clamp(currentPage, 0, this.pageCount - 1);
		if (j != this.currentPage) {
			this.currentPage = j;
			this.markDirty();
			LecternBlock.setPowered(this.getWorld(), this.getPos(), this.getCachedState());
		}
	}

	public int getCurrentPage() {
		return this.currentPage;
	}

	public int getComparatorOutput() {
		float f = this.pageCount > 1 ? (float)this.getCurrentPage() / ((float)this.pageCount - 1.0F) : 1.0F;
		return MathHelper.floor(f * 14.0F) + (this.hasBook() ? 1 : 0);
	}

	private ItemStack resolveBook(ItemStack book, @Nullable PlayerEntity player) {
		if (this.world instanceof ServerWorld lv) {
			WrittenBookContentComponent.resolveInStack(book, this.getCommandSource(player, lv), player);
		}

		return book;
	}

	private ServerCommandSource getCommandSource(@Nullable PlayerEntity player, ServerWorld world) {
		String string;
		Text lv;
		if (player == null) {
			string = "Lectern";
			lv = Text.literal("Lectern");
		} else {
			string = player.getName().getString();
			lv = player.getDisplayName();
		}

		Vec3d lv2 = Vec3d.ofCenter(this.pos);
		return new ServerCommandSource(CommandOutput.DUMMY, lv2, Vec2f.ZERO, world, 2, string, lv, world.getServer(), player);
	}

	@Override
	protected void readNbt(NbtCompound nbt, WrapperLookup registries) {
		super.readNbt(nbt, registries);
		if (nbt.contains("Book", 10)) {
			this.book = this.resolveBook((ItemStack)ItemStack.fromNbt(registries, nbt.getCompound("Book")).orElse(ItemStack.EMPTY), null);
		} else {
			this.book = ItemStack.EMPTY;
		}

		this.pageCount = getPageCount(this.book);
		this.currentPage = MathHelper.clamp(nbt.getInt("Page"), 0, this.pageCount - 1);
	}

	@Override
	protected void writeNbt(NbtCompound nbt, WrapperLookup registries) {
		super.writeNbt(nbt, registries);
		if (!this.getBook().isEmpty()) {
			nbt.put("Book", this.getBook().toNbt(registries));
			nbt.putInt("Page", this.currentPage);
		}
	}

	@Override
	public void clear() {
		this.setBook(ItemStack.EMPTY);
	}

	@Override
	public void onStateReplaced(BlockPos pos, BlockState oldState, boolean moved) {
		// $VF: Couldn't be decompiled
		// Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
		//
		// Bytecode:
		// 00: aload 2
		// 01: getstatic net/minecraft/block/LecternBlock.HAS_BOOK Lnet/minecraft/state/property/BooleanProperty;
		// 04: invokevirtual net/minecraft/block/BlockState.get (Lnet/minecraft/state/property/Property;)Ljava/lang/Comparable;
		// 07: checkcast java/lang/Boolean
		// 0a: invokevirtual java/lang/Boolean.booleanValue ()Z
		// 0d: ifeq 83
		// 10: aload 0
		// 11: getfield net/minecraft/block/entity/LecternBlockEntity.world Lnet/minecraft/world/World;
		// 14: ifnull 83
		// 17: aload 2
		// 18: getstatic net/minecraft/block/LecternBlock.FACING Lnet/minecraft/state/property/EnumProperty;
		// 1b: invokevirtual net/minecraft/block/BlockState.get (Lnet/minecraft/state/property/Property;)Ljava/lang/Comparable;
		// 1e: checkcast net/minecraft/util/math/Direction
		// 21: astore 4
		// 23: aload 0
		// 24: invokevirtual net/minecraft/block/entity/LecternBlockEntity.getBook ()Lnet/minecraft/item/ItemStack;
		// 27: invokevirtual net/minecraft/item/ItemStack.copy ()Lnet/minecraft/item/ItemStack;
		// 2a: astore 5
		// 2c: ldc_w 0.25
		// 2f: aload 4
		// 31: invokevirtual net/minecraft/util/math/Direction.getOffsetX ()I
		// 34: i2f
		// 35: fmul
		// 36: fstore 6
		// 38: ldc_w 0.25
		// 3b: aload 4
		// 3d: invokevirtual net/minecraft/util/math/Direction.getOffsetZ ()I
		// 40: i2f
		// 41: fmul
		// 42: fstore 7
		// 44: new net/minecraft/entity/ItemEntity
		// 47: dup
		// 48: aload 0
		// 49: getfield net/minecraft/block/entity/LecternBlockEntity.world Lnet/minecraft/world/World;
		// 4c: aload 1
		// 4d: invokevirtual net/minecraft/util/math/BlockPos.getX ()I
		// 50: i2d
		// 51: ldc2_w 0.5
		// 54: dadd
		// 55: fload 6
		// 57: f2d
		// 58: dadd
		// 59: aload 1
		// 5a: invokevirtual net/minecraft/util/math/BlockPos.getY ()I
		// 5d: bipush 1
		// 5e: iadd
		// 5f: i2d
		// 60: aload 1
		// 61: invokevirtual net/minecraft/util/math/BlockPos.getZ ()I
		// 64: i2d
		// 65: ldc2_w 0.5
		// 68: dadd
		// 69: fload 7
		// 6b: f2d
		// 6c: dadd
		// 6d: aload 5
		// 6f: invokespecial net/minecraft/entity/ItemEntity.<init> (Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;)V
		// 72: astore 8
		// 74: aload 8
		// 76: invokevirtual net/minecraft/entity/ItemEntity.setToDefaultPickupDelay ()V
		// 79: aload 0
		// 7a: getfield net/minecraft/block/entity/LecternBlockEntity.world Lnet/minecraft/world/World;
		// 7d: aload 8
		// 7f: invokevirtual net/minecraft/world/World.spawnEntity (Lnet/minecraft/entity/Entity;)Z
		// 82: pop
		// 83: return
	}

	@Override
	public ScreenHandler createMenu(int syncId, PlayerInventory playerInventory, PlayerEntity player) {
		return new LecternScreenHandler(syncId, this.inventory, this.propertyDelegate);
	}

	@Override
	public Text getDisplayName() {
		return Text.translatable("container.lectern");
	}

	private static int getPageCount(ItemStack stack) {
		WrittenBookContentComponent lv = stack.get(DataComponentTypes.WRITTEN_BOOK_CONTENT);
		if (lv != null) {
			return lv.pages().size();
		} else {
			WritableBookContentComponent lv2 = stack.get(DataComponentTypes.WRITABLE_BOOK_CONTENT);
			return lv2 != null ? lv2.pages().size() : 0;
		}
	}
}
