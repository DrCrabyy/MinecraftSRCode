package net.minecraft.block.entity;

import javax.annotation.Nullable;
import net.minecraft.block.BlockState;
import net.minecraft.block.CalibratedSculkSensorBlock;
import net.minecraft.block.entity.SculkSensorBlockEntity.VibrationCallback;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.event.Vibrations;
import net.minecraft.world.event.GameEvent.Emitter;

public class CalibratedSculkSensorBlockEntity extends SculkSensorBlockEntity {
	public CalibratedSculkSensorBlockEntity(BlockPos pos, BlockState state) {
		super(BlockEntityType.CALIBRATED_SCULK_SENSOR, pos, state);
	}

	@Override
	public net.minecraft.world.event.Vibrations.Callback createCallback() {
		return new CalibratedSculkSensorBlockEntity.Callback(this.getPos());
	}

	protected class Callback extends VibrationCallback {
		public Callback(final BlockPos pos) {
			super(CalibratedSculkSensorBlockEntity.this, pos);
		}

		@Override
		public int getRange() {
			return 16;
		}

		@Override
		public boolean accepts(ServerWorld world, BlockPos pos, RegistryEntry<GameEvent> event, @Nullable Emitter emitter) {
			int i = this.getCalibrationFrequency(world, this.pos, CalibratedSculkSensorBlockEntity.this.getCachedState());
			return i != 0 && Vibrations.getFrequency(event) != i ? false : super.accepts(world, pos, event, emitter);
		}

		private int getCalibrationFrequency(World world, BlockPos pos, BlockState state) {
			Direction lv = ((Direction)state.get(CalibratedSculkSensorBlock.FACING)).getOpposite();
			return world.getEmittedRedstonePower(pos.offset(lv), lv);
		}
	}
}
