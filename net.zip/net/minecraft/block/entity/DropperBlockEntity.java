package net.minecraft.block.entity;

import net.minecraft.block.BlockState;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

public class DropperBlockEntity extends DispenserBlockEntity {
	public DropperBlockEntity(BlockPos pos, BlockState state) {
		super(BlockEntityType.DROPPER, pos, state);
	}

	@Override
	protected Text getContainerName() {
		return Text.translatable("container.dropper");
	}
}
