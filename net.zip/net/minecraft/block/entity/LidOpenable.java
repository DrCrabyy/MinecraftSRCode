package net.minecraft.block.entity;

public interface LidOpenable {
	float getAnimationProgress(float tickDelta);
}
