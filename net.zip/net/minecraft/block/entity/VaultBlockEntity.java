package net.minecraft.block.entity;

import com.google.common.annotations.VisibleForTesting;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DynamicOps;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.BlockState;
import net.minecraft.block.VaultBlock;
import net.minecraft.block.enums.VaultState;
import net.minecraft.block.vault.VaultClientData;
import net.minecraft.block.vault.VaultConfig;
import net.minecraft.block.vault.VaultServerData;
import net.minecraft.block.vault.VaultSharedData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.loot.context.LootWorldContext;
import net.minecraft.loot.context.LootWorldContext.Builder;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtOps;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import org.slf4j.Logger;

public class VaultBlockEntity extends BlockEntity {
	private static final Logger LOGGER = LogUtils.getLogger();
	private final VaultServerData serverData = new VaultServerData();
	private final VaultSharedData sharedData = new VaultSharedData();
	private final VaultClientData clientData = new VaultClientData();
	private VaultConfig config = VaultConfig.DEFAULT;

	public VaultBlockEntity(BlockPos pos, BlockState state) {
		super(BlockEntityType.VAULT, pos, state);
	}

	@Nullable
	@Override
	public Packet<ClientPlayPacketListener> toUpdatePacket() {
		return BlockEntityUpdateS2CPacket.create(this);
	}

	@Override
	public NbtCompound toInitialChunkDataNbt(WrapperLookup registries) {
		return Util.make(new NbtCompound(), nbt -> nbt.put("shared_data", encodeValue(VaultSharedData.codec, this.sharedData, registries)));
	}

	@Override
	protected void writeNbt(NbtCompound nbt, WrapperLookup registries) {
		super.writeNbt(nbt, registries);
		nbt.put("config", encodeValue(VaultConfig.codec, this.config, registries));
		nbt.put("shared_data", encodeValue(VaultSharedData.codec, this.sharedData, registries));
		nbt.put("server_data", encodeValue(VaultServerData.codec, this.serverData, registries));
	}

	private static <T> NbtElement encodeValue(Codec<T> codec, T value, WrapperLookup registries) {
		return (NbtElement)codec.encodeStart(registries.getOps(NbtOps.INSTANCE), value).getOrThrow();
	}

	@Override
	protected void readNbt(NbtCompound nbt, WrapperLookup registries) {
		super.readNbt(nbt, registries);
		DynamicOps<NbtElement> dynamicOps = registries.getOps(NbtOps.INSTANCE);
		if (nbt.contains("server_data")) {
			VaultServerData.codec.parse(dynamicOps, nbt.get("server_data")).resultOrPartial(LOGGER::error).ifPresent(this.serverData::copyFrom);
		}

		if (nbt.contains("config")) {
			VaultConfig.codec.parse(dynamicOps, nbt.get("config")).resultOrPartial(LOGGER::error).ifPresent(config -> this.config = config);
		}

		if (nbt.contains("shared_data")) {
			VaultSharedData.codec.parse(dynamicOps, nbt.get("shared_data")).resultOrPartial(LOGGER::error).ifPresent(this.sharedData::copyFrom);
		}
	}

	@Nullable
	public VaultServerData getServerData() {
		return this.world != null && !this.world.isClient ? this.serverData : null;
	}

	public VaultSharedData getSharedData() {
		return this.sharedData;
	}

	public VaultClientData getClientData() {
		return this.clientData;
	}

	public VaultConfig getConfig() {
		return this.config;
	}

	@VisibleForTesting
	public void setConfig(VaultConfig config) {
		this.config = config;
	}

	public static final class Client {
		private static final int field_48870 = 20;
		private static final float field_48871 = 0.5F;
		private static final float field_48872 = 0.02F;
		private static final int field_48873 = 20;
		private static final int field_48874 = 20;

		public static void tick(World world, BlockPos pos, BlockState state, VaultClientData clientData, VaultSharedData sharedData) {
			clientData.rotateDisplay();
			if (world.getTime() % 20L == 0L) {
				spawnConnectedParticles(world, pos, state, sharedData);
			}

			spawnAmbientParticles(world, pos, sharedData, state.get(VaultBlock.OMINOUS) ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.SMALL_FLAME);
			playAmbientSound(world, pos, sharedData);
		}

		public static void spawnActivateParticles(World world, BlockPos pos, BlockState state, VaultSharedData sharedData, ParticleEffect particle) {
			spawnConnectedParticles(world, pos, state, sharedData);
			Random lv = world.random;

			for (int i = 0; i < 20; i++) {
				Vec3d lv2 = getRegularParticlesPos(pos, lv);
				world.addParticleClient(ParticleTypes.SMOKE, lv2.getX(), lv2.getY(), lv2.getZ(), 0.0, 0.0, 0.0);
				world.addParticleClient(particle, lv2.getX(), lv2.getY(), lv2.getZ(), 0.0, 0.0, 0.0);
			}
		}

		public static void spawnDeactivateParticles(World world, BlockPos pos, ParticleEffect particle) {
			Random lv = world.random;

			for (int i = 0; i < 20; i++) {
				Vec3d lv2 = getDeactivateParticlesPos(pos, lv);
				Vec3d lv3 = new Vec3d(lv.nextGaussian() * 0.02, lv.nextGaussian() * 0.02, lv.nextGaussian() * 0.02);
				world.addParticleClient(particle, lv2.getX(), lv2.getY(), lv2.getZ(), lv3.getX(), lv3.getY(), lv3.getZ());
			}
		}

		private static void spawnAmbientParticles(World world, BlockPos pos, VaultSharedData sharedData, ParticleEffect particle) {
			Random lv = world.getRandom();
			if (lv.nextFloat() <= 0.5F) {
				Vec3d lv2 = getRegularParticlesPos(pos, lv);
				world.addParticleClient(ParticleTypes.SMOKE, lv2.getX(), lv2.getY(), lv2.getZ(), 0.0, 0.0, 0.0);
				if (hasDisplayItem(sharedData)) {
					world.addParticleClient(particle, lv2.getX(), lv2.getY(), lv2.getZ(), 0.0, 0.0, 0.0);
				}
			}
		}

		private static void spawnConnectedParticlesFor(World world, Vec3d pos, PlayerEntity player) {
			Random lv = world.random;
			Vec3d lv2 = pos.relativize(player.getPos().add(0.0, (double)(player.getHeight() / 2.0F), 0.0));
			int i = MathHelper.nextInt(lv, 2, 5);

			for (int j = 0; j < i; j++) {
				Vec3d lv3 = lv2.addRandom(lv, 1.0F);
				world.addParticleClient(ParticleTypes.VAULT_CONNECTION, pos.getX(), pos.getY(), pos.getZ(), lv3.getX(), lv3.getY(), lv3.getZ());
			}
		}

		private static void spawnConnectedParticles(World world, BlockPos pos, BlockState state, VaultSharedData sharedData) {
			Set<UUID> set = sharedData.getConnectedPlayers();
			if (!set.isEmpty()) {
				Vec3d lv = getConnectedParticlesOrigin(pos, state.get(VaultBlock.FACING));

				for (UUID uUID : set) {
					PlayerEntity lv2 = world.getPlayerByUuid(uUID);
					if (lv2 != null && isPlayerWithinConnectedParticlesRange(pos, sharedData, lv2)) {
						spawnConnectedParticlesFor(world, lv, lv2);
					}
				}
			}
		}

		private static boolean isPlayerWithinConnectedParticlesRange(BlockPos pos, VaultSharedData sharedData, PlayerEntity player) {
			return player.getBlockPos().getSquaredDistance(pos) <= MathHelper.square(sharedData.getConnectedParticlesRange());
		}

		private static void playAmbientSound(World world, BlockPos pos, VaultSharedData sharedData) {
			if (hasDisplayItem(sharedData)) {
				Random lv = world.getRandom();
				if (lv.nextFloat() <= 0.02F) {
					world.playSoundAtBlockCenterClient(
						pos, SoundEvents.BLOCK_VAULT_AMBIENT, SoundCategory.BLOCKS, lv.nextFloat() * 0.25F + 0.75F, lv.nextFloat() + 0.5F, false
					);
				}
			}
		}

		public static boolean hasDisplayItem(VaultSharedData sharedData) {
			return sharedData.hasDisplayItem();
		}

		private static Vec3d getDeactivateParticlesPos(BlockPos pos, Random random) {
			return Vec3d.of(pos).add(MathHelper.nextDouble(random, 0.4, 0.6), MathHelper.nextDouble(random, 0.4, 0.6), MathHelper.nextDouble(random, 0.4, 0.6));
		}

		private static Vec3d getRegularParticlesPos(BlockPos pos, Random random) {
			return Vec3d.of(pos).add(MathHelper.nextDouble(random, 0.1, 0.9), MathHelper.nextDouble(random, 0.25, 0.75), MathHelper.nextDouble(random, 0.1, 0.9));
		}

		private static Vec3d getConnectedParticlesOrigin(BlockPos pos, Direction direction) {
			return Vec3d.ofBottomCenter(pos).add((double)direction.getOffsetX() * 0.5, 1.75, (double)direction.getOffsetZ() * 0.5);
		}
	}

	public static final class Server {
		private static final int UNLOCK_TIME = 14;
		private static final int DISPLAY_UPDATE_INTERVAL = 20;
		private static final int FAILED_UNLOCK_COOLDOWN = 15;

		public static void tick(ServerWorld world, BlockPos pos, BlockState state, VaultConfig config, VaultServerData serverData, VaultSharedData sharedData) {
			VaultState lv = state.get(VaultBlock.VAULT_STATE);
			if (shouldUpdateDisplayItem(world.getTime(), lv)) {
				updateDisplayItem(world, lv, config, sharedData, pos);
			}

			BlockState lv2 = state;
			if (world.getTime() >= serverData.getStateUpdatingResumeTime()) {
				lv2 = state.with(VaultBlock.VAULT_STATE, lv.update(world, pos, config, serverData, sharedData));
				if (state != lv2) {
					changeVaultState(world, pos, state, lv2, config, sharedData);
				}
			}

			if (serverData.dirty || sharedData.dirty) {
				VaultBlockEntity.markDirty(world, pos, state);
				if (sharedData.dirty) {
					world.updateListeners(pos, state, lv2, 2);
				}

				serverData.dirty = false;
				sharedData.dirty = false;
			}
		}

		public static void tryUnlock(
			ServerWorld world,
			BlockPos pos,
			BlockState state,
			VaultConfig config,
			VaultServerData serverData,
			VaultSharedData sharedData,
			PlayerEntity player,
			ItemStack stack
		) {
			VaultState lv = state.get(VaultBlock.VAULT_STATE);
			if (canBeUnlocked(config, lv)) {
				if (!isValidKey(config, stack)) {
					playFailedUnlockSound(world, serverData, pos, SoundEvents.BLOCK_VAULT_INSERT_ITEM_FAIL);
				} else if (serverData.hasRewardedPlayer(player)) {
					playFailedUnlockSound(world, serverData, pos, SoundEvents.BLOCK_VAULT_REJECT_REWARDED_PLAYER);
				} else {
					List<ItemStack> list = generateLoot(world, config, pos, player, stack);
					if (!list.isEmpty()) {
						player.incrementStat(Stats.USED.getOrCreateStat(stack.getItem()));
						stack.decrementUnlessCreative(config.keyItem().getCount(), player);
						unlock(world, state, pos, config, serverData, sharedData, list);
						serverData.markPlayerAsRewarded(player);
						sharedData.updateConnectedPlayers(world, pos, serverData, config, config.deactivationRange());
					}
				}
			}
		}

		static void changeVaultState(ServerWorld world, BlockPos pos, BlockState oldState, BlockState newState, VaultConfig config, VaultSharedData sharedData) {
			VaultState lv = oldState.get(VaultBlock.VAULT_STATE);
			VaultState lv2 = newState.get(VaultBlock.VAULT_STATE);
			world.setBlockState(pos, newState, 3);
			lv.onStateChange(world, pos, lv2, config, sharedData, (Boolean)newState.get(VaultBlock.OMINOUS));
		}

		static void updateDisplayItem(ServerWorld world, VaultState state, VaultConfig config, VaultSharedData sharedData, BlockPos pos) {
			if (!canBeUnlocked(config, state)) {
				sharedData.setDisplayItem(ItemStack.EMPTY);
			} else {
				ItemStack lv = generateDisplayItem(world, pos, (RegistryKey<LootTable>)config.overrideLootTableToDisplay().orElse(config.lootTable()));
				sharedData.setDisplayItem(lv);
			}
		}

		private static ItemStack generateDisplayItem(ServerWorld world, BlockPos pos, RegistryKey<LootTable> lootTable) {
			LootTable lv = world.getServer().getReloadableRegistries().getLootTable(lootTable);
			LootWorldContext lv2 = new Builder(world).add(LootContextParameters.ORIGIN, Vec3d.ofCenter(pos)).build(LootContextTypes.VAULT);
			List<ItemStack> list = lv.generateLoot(lv2, world.getRandom());
			return list.isEmpty() ? ItemStack.EMPTY : Util.getRandom(list, world.getRandom());
		}

		private static void unlock(
			ServerWorld world, BlockState state, BlockPos pos, VaultConfig config, VaultServerData serverData, VaultSharedData sharedData, List<ItemStack> itemsToEject
		) {
			serverData.setItemsToEject(itemsToEject);
			sharedData.setDisplayItem(serverData.getItemToDisplay());
			serverData.setStateUpdatingResumeTime(world.getTime() + 14L);
			changeVaultState(world, pos, state, state.with(VaultBlock.VAULT_STATE, VaultState.UNLOCKING), config, sharedData);
		}

		private static List<ItemStack> generateLoot(ServerWorld world, VaultConfig config, BlockPos pos, PlayerEntity player, ItemStack key) {
			LootTable lv = world.getServer().getReloadableRegistries().getLootTable(config.lootTable());
			LootWorldContext lv2 = new Builder(world)
				.add(LootContextParameters.ORIGIN, Vec3d.ofCenter(pos))
				.luck(player.getLuck())
				.add(LootContextParameters.THIS_ENTITY, player)
				.add(LootContextParameters.TOOL, key)
				.build(LootContextTypes.VAULT);
			return lv.generateLoot(lv2);
		}

		private static boolean canBeUnlocked(VaultConfig config, VaultState state) {
			return !config.keyItem().isEmpty() && state != VaultState.INACTIVE;
		}

		private static boolean isValidKey(VaultConfig config, ItemStack stack) {
			return ItemStack.areItemsAndComponentsEqual(stack, config.keyItem()) && stack.getCount() >= config.keyItem().getCount();
		}

		private static boolean shouldUpdateDisplayItem(long time, VaultState state) {
			return time % 20L == 0L && state == VaultState.ACTIVE;
		}

		private static void playFailedUnlockSound(ServerWorld world, VaultServerData serverData, BlockPos pos, SoundEvent sound) {
			if (world.getTime() >= serverData.getLastFailedUnlockTime() + 15L) {
				world.playSound(null, pos, sound, SoundCategory.BLOCKS);
				serverData.setLastFailedUnlockTime(world.getTime());
			}
		}
	}
}
