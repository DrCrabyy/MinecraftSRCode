package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Map;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.SkullBlock.SkullType;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;

public class WallSkullBlock extends AbstractSkullBlock {
	public static final MapCodec<WallSkullBlock> CODEC = RecordCodecBuilder.mapCodec(
		instance -> instance.group(SkullType.CODEC.fieldOf("kind").forGetter(AbstractSkullBlock::getSkullType), createSettingsCodec())
				.apply(instance, WallSkullBlock::new)
	);
	public static final EnumProperty<Direction> FACING = HorizontalFacingBlock.FACING;
	private static final Map<Direction, VoxelShape> FACING_TO_SHAPE = VoxelShapes.method_66501(Block.method_66408(8.0, 8.0, 16.0));

	@Override
	public MapCodec<? extends WallSkullBlock> getCodec() {
		return CODEC;
	}

	protected WallSkullBlock(SkullType type, Settings settings) {
		super(type, settings);
		this.setDefaultState(this.getDefaultState().with(FACING, Direction.NORTH));
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return (VoxelShape)FACING_TO_SHAPE.get(state.get(FACING));
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		BlockState lv = super.getPlacementState(ctx);
		BlockView lv2 = ctx.getWorld();
		BlockPos lv3 = ctx.getBlockPos();
		Direction[] lvs = ctx.getPlacementDirections();

		for (Direction lv4 : lvs) {
			if (lv4.getAxis().isHorizontal()) {
				Direction lv5 = lv4.getOpposite();
				lv = lv.with(FACING, lv5);
				if (!lv2.getBlockState(lv3.offset(lv4)).canReplace(ctx)) {
					return lv;
				}
			}
		}

		return null;
	}

	@Override
	protected BlockState rotate(BlockState state, BlockRotation rotation) {
		return state.with(FACING, rotation.rotate(state.get(FACING)));
	}

	@Override
	protected BlockState mirror(BlockState state, BlockMirror mirror) {
		return state.rotate(mirror.getRotation(state.get(FACING)));
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		super.appendProperties(builder);
		builder.add(FACING);
	}
}
