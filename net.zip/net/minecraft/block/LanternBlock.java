package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldView;
import net.minecraft.world.tick.ScheduledTickView;

public class LanternBlock extends Block implements Waterloggable {
	public static final MapCodec<LanternBlock> CODEC = createCodec(LanternBlock::new);
	public static final BooleanProperty HANGING = Properties.HANGING;
	public static final BooleanProperty WATERLOGGED = Properties.WATERLOGGED;
	private static final VoxelShape STANDING_SHAPE = VoxelShapes.union(Block.method_66404(4.0, 7.0, 9.0), Block.method_66404(6.0, 0.0, 7.0));
	private static final VoxelShape HANGING_SHAPE = STANDING_SHAPE.offset(0.0, 0.0625, 0.0).simplify();

	@Override
	public MapCodec<LanternBlock> getCodec() {
		return CODEC;
	}

	public LanternBlock(Settings settings) {
		super(settings);
		this.setDefaultState(this.stateManager.getDefaultState().with(HANGING, Boolean.valueOf(false)).with(WATERLOGGED, Boolean.valueOf(false)));
	}

	@Nullable
	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		FluidState lv = ctx.getWorld().getFluidState(ctx.getBlockPos());

		for (Direction lv2 : ctx.getPlacementDirections()) {
			if (lv2.getAxis() == Axis.Y) {
				BlockState lv3 = this.getDefaultState().with(HANGING, Boolean.valueOf(lv2 == Direction.UP));
				if (lv3.canPlaceAt(ctx.getWorld(), ctx.getBlockPos())) {
					return lv3.with(WATERLOGGED, Boolean.valueOf(lv.getFluid() == Fluids.WATER));
				}
			}
		}

		return null;
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return state.get(HANGING) ? HANGING_SHAPE : STANDING_SHAPE;
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(HANGING, WATERLOGGED);
	}

	@Override
	protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
		Direction lv = attachedDirection(state).getOpposite();
		return Block.sideCoversSmallSquare(world, pos.offset(lv), lv.getOpposite());
	}

	protected static Direction attachedDirection(BlockState state) {
		return state.get(HANGING) ? Direction.DOWN : Direction.UP;
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		if ((Boolean)state.get(WATERLOGGED)) {
			tickView.scheduleFluidTick(pos, Fluids.WATER, Fluids.WATER.getTickRate(world));
		}

		return attachedDirection(state).getOpposite() == direction && !state.canPlaceAt(world, pos)
			? Blocks.AIR.getDefaultState()
			: super.getStateForNeighborUpdate(state, world, tickView, pos, direction, neighborPos, neighborState, random);
	}

	@Override
	protected FluidState getFluidState(BlockState state) {
		return state.get(WATERLOGGED) ? Fluids.WATER.getStill(false) : super.getFluidState(state);
	}

	@Override
	protected boolean canPathfindThrough(BlockState state, NavigationType type) {
		return false;
	}
}
