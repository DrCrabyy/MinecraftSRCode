package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.world.World;

public class PumpkinBlock extends Block {
	public static final MapCodec<PumpkinBlock> CODEC = createCodec(PumpkinBlock::new);

	@Override
	public MapCodec<PumpkinBlock> getCodec() {
		return CODEC;
	}

	protected PumpkinBlock(Settings settings) {
		super(settings);
	}

	@Override
	protected ActionResult onUseWithItem(ItemStack stack, BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
		// $VF: Couldn't be decompiled
		// Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
		//
		// Bytecode:
		// 000: aload 1
		// 001: getstatic net/minecraft/item/Items.SHEARS Lnet/minecraft/item/Item;
		// 004: invokevirtual net/minecraft/item/ItemStack.isOf (Lnet/minecraft/item/Item;)Z
		// 007: ifne 01a
		// 00a: aload 0
		// 00b: aload 1
		// 00c: aload 2
		// 00d: aload 3
		// 00e: aload 4
		// 010: aload 5
		// 012: aload 6
		// 014: aload 7
		// 016: invokespecial net/minecraft/block/Block.onUseWithItem (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/BlockState;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/util/Hand;Lnet/minecraft/util/hit/BlockHitResult;)Lnet/minecraft/util/ActionResult;
		// 019: areturn
		// 01a: aload 3
		// 01b: getfield net/minecraft/world/World.isClient Z
		// 01e: ifeq 025
		// 021: getstatic net/minecraft/util/ActionResult.SUCCESS Lnet/minecraft/util/ActionResult$Success;
		// 024: areturn
		// 025: aload 7
		// 027: invokevirtual net/minecraft/util/hit/BlockHitResult.getSide ()Lnet/minecraft/util/math/Direction;
		// 02a: astore 8
		// 02c: aload 8
		// 02e: invokevirtual net/minecraft/util/math/Direction.getAxis ()Lnet/minecraft/util/math/Direction$Axis;
		// 031: getstatic net/minecraft/util/math/Direction$Axis.Y Lnet/minecraft/util/math/Direction$Axis;
		// 034: if_acmpne 042
		// 037: aload 5
		// 039: invokevirtual net/minecraft/entity/player/PlayerEntity.getHorizontalFacing ()Lnet/minecraft/util/math/Direction;
		// 03c: invokevirtual net/minecraft/util/math/Direction.getOpposite ()Lnet/minecraft/util/math/Direction;
		// 03f: goto 044
		// 042: aload 8
		// 044: astore 9
		// 046: aload 3
		// 047: aconst_null
		// 048: aload 4
		// 04a: getstatic net/minecraft/sound/SoundEvents.BLOCK_PUMPKIN_CARVE Lnet/minecraft/sound/SoundEvent;
		// 04d: getstatic net/minecraft/sound/SoundCategory.BLOCKS Lnet/minecraft/sound/SoundCategory;
		// 050: fconst_1
		// 051: fconst_1
		// 052: invokevirtual net/minecraft/world/World.playSound (Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/sound/SoundEvent;Lnet/minecraft/sound/SoundCategory;FF)V
		// 055: aload 3
		// 056: aload 4
		// 058: getstatic net/minecraft/block/Blocks.CARVED_PUMPKIN Lnet/minecraft/block/Block;
		// 05b: invokevirtual net/minecraft/block/Block.getDefaultState ()Lnet/minecraft/block/BlockState;
		// 05e: getstatic net/minecraft/block/CarvedPumpkinBlock.FACING Lnet/minecraft/state/property/EnumProperty;
		// 061: aload 9
		// 063: invokevirtual net/minecraft/block/BlockState.with (Lnet/minecraft/state/property/Property;Ljava/lang/Comparable;)Ljava/lang/Object;
		// 066: checkcast net/minecraft/block/BlockState
		// 069: bipush 11
		// 06b: invokevirtual net/minecraft/world/World.setBlockState (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;I)Z
		// 06e: pop
		// 06f: new net/minecraft/entity/ItemEntity
		// 072: dup
		// 073: aload 3
		// 074: aload 4
		// 076: invokevirtual net/minecraft/util/math/BlockPos.getX ()I
		// 079: i2d
		// 07a: ldc2_w 0.5
		// 07d: dadd
		// 07e: aload 9
		// 080: invokevirtual net/minecraft/util/math/Direction.getOffsetX ()I
		// 083: i2d
		// 084: ldc2_w 0.65
		// 087: dmul
		// 088: dadd
		// 089: aload 4
		// 08b: invokevirtual net/minecraft/util/math/BlockPos.getY ()I
		// 08e: i2d
		// 08f: ldc2_w 0.1
		// 092: dadd
		// 093: aload 4
		// 095: invokevirtual net/minecraft/util/math/BlockPos.getZ ()I
		// 098: i2d
		// 099: ldc2_w 0.5
		// 09c: dadd
		// 09d: aload 9
		// 09f: invokevirtual net/minecraft/util/math/Direction.getOffsetZ ()I
		// 0a2: i2d
		// 0a3: ldc2_w 0.65
		// 0a6: dmul
		// 0a7: dadd
		// 0a8: new net/minecraft/item/ItemStack
		// 0ab: dup
		// 0ac: getstatic net/minecraft/item/Items.PUMPKIN_SEEDS Lnet/minecraft/item/Item;
		// 0af: bipush 4
		// 0b0: invokespecial net/minecraft/item/ItemStack.<init> (Lnet/minecraft/item/ItemConvertible;I)V
		// 0b3: invokespecial net/minecraft/entity/ItemEntity.<init> (Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;)V
		// 0b6: astore 10
		// 0b8: aload 10
		// 0ba: ldc2_w 0.05
		// 0bd: aload 9
		// 0bf: invokevirtual net/minecraft/util/math/Direction.getOffsetX ()I
		// 0c2: i2d
		// 0c3: dmul
		// 0c4: aload 3
		// 0c5: getfield net/minecraft/world/World.random Lnet/minecraft/util/math/random/Random;
		// 0c8: invokeinterface net/minecraft/util/math/random/Random.nextDouble ()D 1
		// 0cd: ldc2_w 0.02
		// 0d0: dmul
		// 0d1: dadd
		// 0d2: ldc2_w 0.05
		// 0d5: ldc2_w 0.05
		// 0d8: aload 9
		// 0da: invokevirtual net/minecraft/util/math/Direction.getOffsetZ ()I
		// 0dd: i2d
		// 0de: dmul
		// 0df: aload 3
		// 0e0: getfield net/minecraft/world/World.random Lnet/minecraft/util/math/random/Random;
		// 0e3: invokeinterface net/minecraft/util/math/random/Random.nextDouble ()D 1
		// 0e8: ldc2_w 0.02
		// 0eb: dmul
		// 0ec: dadd
		// 0ed: invokevirtual net/minecraft/entity/ItemEntity.setVelocity (DDD)V
		// 0f0: aload 3
		// 0f1: aload 10
		// 0f3: invokevirtual net/minecraft/world/World.spawnEntity (Lnet/minecraft/entity/Entity;)Z
		// 0f6: pop
		// 0f7: aload 1
		// 0f8: bipush 1
		// 0f9: aload 5
		// 0fb: aload 6
		// 0fd: invokestatic net/minecraft/entity/LivingEntity.getSlotForHand (Lnet/minecraft/util/Hand;)Lnet/minecraft/entity/EquipmentSlot;
		// 100: invokevirtual net/minecraft/item/ItemStack.damage (ILnet/minecraft/entity/LivingEntity;Lnet/minecraft/entity/EquipmentSlot;)V
		// 103: aload 3
		// 104: aload 5
		// 106: getstatic net/minecraft/world/event/GameEvent.SHEAR Lnet/minecraft/registry/entry/RegistryEntry$Reference;
		// 109: aload 4
		// 10b: invokevirtual net/minecraft/world/World.emitGameEvent (Lnet/minecraft/entity/Entity;Lnet/minecraft/registry/entry/RegistryEntry;Lnet/minecraft/util/math/BlockPos;)V
		// 10e: aload 5
		// 110: getstatic net/minecraft/stat/Stats.USED Lnet/minecraft/stat/StatType;
		// 113: getstatic net/minecraft/item/Items.SHEARS Lnet/minecraft/item/Item;
		// 116: invokevirtual net/minecraft/stat/StatType.getOrCreateStat (Ljava/lang/Object;)Lnet/minecraft/stat/Stat;
		// 119: invokevirtual net/minecraft/entity/player/PlayerEntity.incrementStat (Lnet/minecraft/stat/Stat;)V
		// 11c: getstatic net/minecraft/util/ActionResult.SUCCESS Lnet/minecraft/util/ActionResult$Success;
		// 11f: areturn
	}
}
