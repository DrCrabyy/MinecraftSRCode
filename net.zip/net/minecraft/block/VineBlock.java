package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Property;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.Direction.Type;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.GameRules;
import net.minecraft.world.WorldView;
import net.minecraft.world.tick.ScheduledTickView;

public class VineBlock extends Block {
	public static final MapCodec<VineBlock> CODEC = createCodec(VineBlock::new);
	public static final BooleanProperty UP = ConnectingBlock.UP;
	public static final BooleanProperty NORTH = ConnectingBlock.NORTH;
	public static final BooleanProperty EAST = ConnectingBlock.EAST;
	public static final BooleanProperty SOUTH = ConnectingBlock.SOUTH;
	public static final BooleanProperty WEST = ConnectingBlock.WEST;
	public static final Map<Direction, BooleanProperty> FACING_PROPERTIES = (Map<Direction, BooleanProperty>)ConnectingBlock.FACING_PROPERTIES
		.entrySet()
		.stream()
		.filter(entry -> entry.getKey() != Direction.DOWN)
		.collect(Util.toMap());
	private final Function<BlockState, VoxelShape> field_55811;

	@Override
	public MapCodec<VineBlock> getCodec() {
		return CODEC;
	}

	public VineBlock(Settings settings) {
		super(settings);
		this.setDefaultState(
			this.stateManager
				.getDefaultState()
				.with(UP, Boolean.valueOf(false))
				.with(NORTH, Boolean.valueOf(false))
				.with(EAST, Boolean.valueOf(false))
				.with(SOUTH, Boolean.valueOf(false))
				.with(WEST, Boolean.valueOf(false))
		);
		this.field_55811 = this.method_66471();
	}

	private Function<BlockState, VoxelShape> method_66471() {
		Map<Direction, VoxelShape> map = VoxelShapes.method_66504(Block.method_66408(16.0, 0.0, 1.0));
		return this.getShapesForStates(arg -> {
			VoxelShape lv = VoxelShapes.empty();

			for (Entry<Direction, BooleanProperty> entry : FACING_PROPERTIES.entrySet()) {
				if ((Boolean)arg.get((Property)entry.getValue())) {
					lv = VoxelShapes.union(lv, (VoxelShape)map.get(entry.getKey()));
				}
			}

			return lv.isEmpty() ? VoxelShapes.fullCube() : lv;
		});
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return (VoxelShape)this.field_55811.apply(state);
	}

	@Override
	protected boolean isTransparent(BlockState state) {
		return true;
	}

	@Override
	protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
		return this.hasAdjacentBlocks(this.getPlacementShape(state, world, pos));
	}

	private boolean hasAdjacentBlocks(BlockState state) {
		return this.getAdjacentBlockCount(state) > 0;
	}

	private int getAdjacentBlockCount(BlockState state) {
		int i = 0;

		for (BooleanProperty lv : FACING_PROPERTIES.values()) {
			if ((Boolean)state.get(lv)) {
				i++;
			}
		}

		return i;
	}

	private boolean shouldHaveSide(BlockView world, BlockPos pos, Direction side) {
		if (side == Direction.DOWN) {
			return false;
		} else {
			BlockPos lv = pos.offset(side);
			if (shouldConnectTo(world, lv, side)) {
				return true;
			} else if (side.getAxis() == Axis.Y) {
				return false;
			} else {
				BooleanProperty lv2 = (BooleanProperty)FACING_PROPERTIES.get(side);
				BlockState lv3 = world.getBlockState(pos.up());
				return lv3.isOf(this) && (Boolean)lv3.get(lv2);
			}
		}
	}

	public static boolean shouldConnectTo(BlockView world, BlockPos pos, Direction direction) {
		return MultifaceBlock.canGrowOn(world, direction, pos, world.getBlockState(pos));
	}

	private BlockState getPlacementShape(BlockState state, BlockView world, BlockPos pos) {
		BlockPos lv = pos.up();
		if ((Boolean)state.get(UP)) {
			state = state.with(UP, Boolean.valueOf(shouldConnectTo(world, lv, Direction.DOWN)));
		}

		BlockState lv2 = null;

		for (Direction lv3 : Type.HORIZONTAL) {
			BooleanProperty lv4 = getFacingProperty(lv3);
			if ((Boolean)state.get(lv4)) {
				boolean bl = this.shouldHaveSide(world, pos, lv3);
				if (!bl) {
					if (lv2 == null) {
						lv2 = world.getBlockState(lv);
					}

					bl = lv2.isOf(this) && (Boolean)lv2.get(lv4);
				}

				state = state.with(lv4, Boolean.valueOf(bl));
			}
		}

		return state;
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		if (direction == Direction.DOWN) {
			return super.getStateForNeighborUpdate(state, world, tickView, pos, direction, neighborPos, neighborState, random);
		} else {
			BlockState lv = this.getPlacementShape(state, world, pos);
			return !this.hasAdjacentBlocks(lv) ? Blocks.AIR.getDefaultState() : lv;
		}
	}

	@Override
	protected void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		if (world.getGameRules().getBoolean(GameRules.DO_VINES_SPREAD)) {
			if (random.nextInt(4) == 0) {
				Direction lv = Direction.random(random);
				BlockPos lv2 = pos.up();
				if (lv.getAxis().isHorizontal() && !(Boolean)state.get(getFacingProperty(lv))) {
					if (this.canGrowAt(world, pos)) {
						BlockPos lv3 = pos.offset(lv);
						BlockState lv4 = world.getBlockState(lv3);
						if (lv4.isAir()) {
							Direction lv5 = lv.rotateYClockwise();
							Direction lv6 = lv.rotateYCounterclockwise();
							boolean bl = (Boolean)state.get(getFacingProperty(lv5));
							boolean bl2 = (Boolean)state.get(getFacingProperty(lv6));
							BlockPos lv7 = lv3.offset(lv5);
							BlockPos lv8 = lv3.offset(lv6);
							if (bl && shouldConnectTo(world, lv7, lv5)) {
								world.setBlockState(lv3, this.getDefaultState().with(getFacingProperty(lv5), Boolean.valueOf(true)), 2);
							} else if (bl2 && shouldConnectTo(world, lv8, lv6)) {
								world.setBlockState(lv3, this.getDefaultState().with(getFacingProperty(lv6), Boolean.valueOf(true)), 2);
							} else {
								Direction lv9 = lv.getOpposite();
								if (bl && world.isAir(lv7) && shouldConnectTo(world, pos.offset(lv5), lv9)) {
									world.setBlockState(lv7, this.getDefaultState().with(getFacingProperty(lv9), Boolean.valueOf(true)), 2);
								} else if (bl2 && world.isAir(lv8) && shouldConnectTo(world, pos.offset(lv6), lv9)) {
									world.setBlockState(lv8, this.getDefaultState().with(getFacingProperty(lv9), Boolean.valueOf(true)), 2);
								} else if ((double)random.nextFloat() < 0.05 && shouldConnectTo(world, lv3.up(), Direction.UP)) {
									world.setBlockState(lv3, this.getDefaultState().with(UP, Boolean.valueOf(true)), 2);
								}
							}
						} else if (shouldConnectTo(world, lv3, lv)) {
							world.setBlockState(pos, state.with(getFacingProperty(lv), Boolean.valueOf(true)), 2);
						}
					}
				} else {
					if (lv == Direction.UP && pos.getY() < world.getTopYInclusive()) {
						if (this.shouldHaveSide(world, pos, lv)) {
							world.setBlockState(pos, state.with(UP, Boolean.valueOf(true)), 2);
							return;
						}

						if (world.isAir(lv2)) {
							if (!this.canGrowAt(world, pos)) {
								return;
							}

							BlockState lv10 = state;

							for (Direction lv5 : Type.HORIZONTAL) {
								if (random.nextBoolean() || !shouldConnectTo(world, lv2.offset(lv5), lv5)) {
									lv10 = lv10.with(getFacingProperty(lv5), Boolean.valueOf(false));
								}
							}

							if (this.hasHorizontalSide(lv10)) {
								world.setBlockState(lv2, lv10, 2);
							}

							return;
						}
					}

					if (pos.getY() > world.getBottomY()) {
						BlockPos lv3 = pos.down();
						BlockState lv4 = world.getBlockState(lv3);
						if (lv4.isAir() || lv4.isOf(this)) {
							BlockState lv11 = lv4.isAir() ? this.getDefaultState() : lv4;
							BlockState lv12 = this.getGrownState(state, lv11, random);
							if (lv11 != lv12 && this.hasHorizontalSide(lv12)) {
								world.setBlockState(lv3, lv12, 2);
							}
						}
					}
				}
			}
		}
	}

	private BlockState getGrownState(BlockState above, BlockState state, Random random) {
		for (Direction lv : Type.HORIZONTAL) {
			if (random.nextBoolean()) {
				BooleanProperty lv2 = getFacingProperty(lv);
				if ((Boolean)above.get(lv2)) {
					state = state.with(lv2, Boolean.valueOf(true));
				}
			}
		}

		return state;
	}

	private boolean hasHorizontalSide(BlockState state) {
		return (Boolean)state.get(NORTH) || (Boolean)state.get(EAST) || (Boolean)state.get(SOUTH) || (Boolean)state.get(WEST);
	}

	private boolean canGrowAt(BlockView world, BlockPos pos) {
		int i = 4;
		Iterable<BlockPos> iterable = BlockPos.iterate(pos.getX() - 4, pos.getY() - 1, pos.getZ() - 4, pos.getX() + 4, pos.getY() + 1, pos.getZ() + 4);
		int j = 5;

		for (BlockPos lv : iterable) {
			if (world.getBlockState(lv).isOf(this)) {
				if (--j <= 0) {
					return false;
				}
			}
		}

		return true;
	}

	@Override
	protected boolean canReplace(BlockState state, ItemPlacementContext context) {
		BlockState lv = context.getWorld().getBlockState(context.getBlockPos());
		return lv.isOf(this) ? this.getAdjacentBlockCount(lv) < FACING_PROPERTIES.size() : super.canReplace(state, context);
	}

	@Nullable
	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		BlockState lv = ctx.getWorld().getBlockState(ctx.getBlockPos());
		boolean bl = lv.isOf(this);
		BlockState lv2 = bl ? lv : this.getDefaultState();

		for (Direction lv3 : ctx.getPlacementDirections()) {
			if (lv3 != Direction.DOWN) {
				BooleanProperty lv4 = getFacingProperty(lv3);
				boolean bl2 = bl && (Boolean)lv.get(lv4);
				if (!bl2 && this.shouldHaveSide(ctx.getWorld(), ctx.getBlockPos(), lv3)) {
					return lv2.with(lv4, Boolean.valueOf(true));
				}
			}
		}

		return bl ? lv2 : null;
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(UP, NORTH, EAST, SOUTH, WEST);
	}

	@Override
	protected BlockState rotate(BlockState state, BlockRotation rotation) {
		switch (rotation) {
			case CLOCKWISE_180:
				return state.with(NORTH, (Boolean)state.get(SOUTH))
					.with(EAST, (Boolean)state.get(WEST))
					.with(SOUTH, (Boolean)state.get(NORTH))
					.with(WEST, (Boolean)state.get(EAST));
			case COUNTERCLOCKWISE_90:
				return state.with(NORTH, (Boolean)state.get(EAST))
					.with(EAST, (Boolean)state.get(SOUTH))
					.with(SOUTH, (Boolean)state.get(WEST))
					.with(WEST, (Boolean)state.get(NORTH));
			case CLOCKWISE_90:
				return state.with(NORTH, (Boolean)state.get(WEST))
					.with(EAST, (Boolean)state.get(NORTH))
					.with(SOUTH, (Boolean)state.get(EAST))
					.with(WEST, (Boolean)state.get(SOUTH));
			default:
				return state;
		}
	}

	@Override
	protected BlockState mirror(BlockState state, BlockMirror mirror) {
		switch (mirror) {
			case LEFT_RIGHT:
				return state.with(NORTH, (Boolean)state.get(SOUTH)).with(SOUTH, (Boolean)state.get(NORTH));
			case FRONT_BACK:
				return state.with(EAST, (Boolean)state.get(WEST)).with(WEST, (Boolean)state.get(EAST));
			default:
				return super.mirror(state, mirror);
		}
	}

	public static BooleanProperty getFacingProperty(Direction direction) {
		return (BooleanProperty)FACING_PROPERTIES.get(direction);
	}
}
