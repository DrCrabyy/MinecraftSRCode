package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.BlockPos.IterationState;
import net.minecraft.world.World;
import net.minecraft.world.block.WireOrientation;

public class SpongeBlock extends Block {
	public static final MapCodec<SpongeBlock> CODEC = createCodec(SpongeBlock::new);
	public static final int ABSORB_RADIUS = 6;
	public static final int ABSORB_LIMIT = 64;
	private static final Direction[] DIRECTIONS = Direction.values();

	@Override
	public MapCodec<SpongeBlock> getCodec() {
		return CODEC;
	}

	protected SpongeBlock(Settings settings) {
		super(settings);
	}

	@Override
	protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
		if (!oldState.isOf(state.getBlock())) {
			this.update(world, pos);
		}
	}

	@Override
	protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock, @Nullable WireOrientation wireOrientation, boolean notify) {
		this.update(world, pos);
		super.neighborUpdate(state, world, pos, sourceBlock, wireOrientation, notify);
	}

	protected void update(World world, BlockPos pos) {
		if (this.absorbWater(world, pos)) {
			world.setBlockState(pos, Blocks.WET_SPONGE.getDefaultState(), 2);
			world.playSound(null, pos, SoundEvents.BLOCK_SPONGE_ABSORB, SoundCategory.BLOCKS, 1.0F, 1.0F);
		}
	}

	private boolean absorbWater(World world, BlockPos pos) {
		return BlockPos.iterateRecursively(pos, 6, 65, (currentPos, queuer) -> {
			for (Direction lv : DIRECTIONS) {
				queuer.accept(currentPos.offset(lv));
			}
		}, currentPos -> {
			if (currentPos.equals(pos)) {
				return IterationState.ACCEPT;
			} else {
				BlockState lv = world.getBlockState(currentPos);
				FluidState lv2 = world.getFluidState(currentPos);
				if (!lv2.isIn(FluidTags.WATER)) {
					return IterationState.SKIP;
				} else {
					if (lv.getBlock() instanceof FluidDrainable lv4 && !lv4.tryDrainFluid(null, world, currentPos, lv).isEmpty()) {
						return IterationState.ACCEPT;
					}

					if (lv.getBlock() instanceof FluidBlock) {
						world.setBlockState(currentPos, Blocks.AIR.getDefaultState(), 3);
					} else {
						if (!lv.isOf(Blocks.KELP) && !lv.isOf(Blocks.KELP_PLANT) && !lv.isOf(Blocks.SEAGRASS) && !lv.isOf(Blocks.TALL_SEAGRASS)) {
							return IterationState.SKIP;
						}

						BlockEntity lv5 = lv.hasBlockEntity() ? world.getBlockEntity(currentPos) : null;
						dropStacks(lv, world, currentPos, lv5);
						world.setBlockState(currentPos, Blocks.AIR.getDefaultState(), 3);
					}

					return IterationState.ACCEPT;
				}
			}
		}) > 1;
	}
}
