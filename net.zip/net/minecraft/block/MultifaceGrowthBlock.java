package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.AbstractBlock.Settings;

public abstract class MultifaceGrowthBlock extends MultifaceBlock {
	public MultifaceGrowthBlock(Settings settings) {
		super(settings);
	}

	@Override
	public abstract MapCodec<? extends MultifaceGrowthBlock> getCodec();

	public abstract MultifaceGrower getGrower();
}
