package net.minecraft.block;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.MapCodec;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.Portal.Effect;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.PositionFlag;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockLocating;
import net.minecraft.world.BlockView;
import net.minecraft.world.GameRules;
import net.minecraft.world.TeleportTarget;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.minecraft.world.BlockLocating.Rectangle;
import net.minecraft.world.TeleportTarget.PostDimensionTransition;
import net.minecraft.world.border.WorldBorder;
import net.minecraft.world.dimension.DimensionType;
import net.minecraft.world.dimension.NetherPortal;
import net.minecraft.world.tick.ScheduledTickView;
import org.slf4j.Logger;

public class NetherPortalBlock extends Block implements Portal {
	private static final Logger LOGGER = LogUtils.getLogger();
	public static final MapCodec<NetherPortalBlock> CODEC = createCodec(NetherPortalBlock::new);
	public static final EnumProperty<Axis> AXIS = Properties.HORIZONTAL_AXIS;
	private static final Map<Axis, VoxelShape> field_55781 = VoxelShapes.method_66494(Block.method_66395(4.0, 16.0, 0.0, 16.0));

	@Override
	public MapCodec<NetherPortalBlock> getCodec() {
		return CODEC;
	}

	public NetherPortalBlock(Settings settings) {
		super(settings);
		this.setDefaultState(this.stateManager.getDefaultState().with(AXIS, Axis.X));
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return (VoxelShape)field_55781.get(state.get(AXIS));
	}

	@Override
	protected void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		if (world.getDimension().natural() && world.getGameRules().getBoolean(GameRules.DO_MOB_SPAWNING) && random.nextInt(2000) < world.getDifficulty().getId()) {
			while (world.getBlockState(pos).isOf(this)) {
				pos = pos.down();
			}

			if (world.getBlockState(pos).allowsSpawning(world, pos, EntityType.ZOMBIFIED_PIGLIN)) {
				Entity lv = EntityType.ZOMBIFIED_PIGLIN.spawn(world, pos.up(), SpawnReason.STRUCTURE);
				if (lv != null) {
					lv.resetPortalCooldown();
					Entity lv2 = lv.getVehicle();
					if (lv2 != null) {
						lv2.resetPortalCooldown();
					}
				}
			}
		}
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		Axis lv = direction.getAxis();
		Axis lv2 = state.get(AXIS);
		boolean bl = lv2 != lv && lv.isHorizontal();
		return !bl && !neighborState.isOf(this) && !NetherPortal.getOnAxis(world, pos, lv2).wasAlreadyValid()
			? Blocks.AIR.getDefaultState()
			: super.getStateForNeighborUpdate(state, world, tickView, pos, direction, neighborPos, neighborState, random);
	}

	@Override
	protected void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
		if (entity.canUsePortals(false)) {
			entity.tryUsePortal(this, pos);
		}
	}

	@Override
	public int getPortalDelay(ServerWorld world, Entity entity) {
		return entity instanceof PlayerEntity lv
			? Math.max(
				0,
				world.getGameRules()
					.getInt(lv.getAbilities().invulnerable ? GameRules.PLAYERS_NETHER_PORTAL_CREATIVE_DELAY : GameRules.PLAYERS_NETHER_PORTAL_DEFAULT_DELAY)
			)
			: 0;
	}

	@Nullable
	@Override
	public TeleportTarget createTeleportTarget(ServerWorld world, Entity entity, BlockPos pos) {
		RegistryKey<World> lv = world.getRegistryKey() == World.NETHER ? World.OVERWORLD : World.NETHER;
		ServerWorld lv2 = world.getServer().getWorld(lv);
		if (lv2 == null) {
			return null;
		} else {
			boolean bl = lv2.getRegistryKey() == World.NETHER;
			WorldBorder lv3 = lv2.getWorldBorder();
			double d = DimensionType.getCoordinateScaleFactor(world.getDimension(), lv2.getDimension());
			BlockPos lv4 = lv3.clampFloored(entity.getX() * d, entity.getY(), entity.getZ() * d);
			return this.getOrCreateExitPortalTarget(lv2, entity, pos, lv4, bl, lv3);
		}
	}

	@Nullable
	private TeleportTarget getOrCreateExitPortalTarget(
		ServerWorld world, Entity entity, BlockPos pos, BlockPos scaledPos, boolean inNether, WorldBorder worldBorder
	) {
		Optional<BlockPos> optional = world.getPortalForcer().getPortalPos(scaledPos, inNether, worldBorder);
		Rectangle lv3;
		PostDimensionTransition lv4;
		if (optional.isPresent()) {
			BlockPos lv = (BlockPos)optional.get();
			BlockState lv2 = world.getBlockState(lv);
			lv3 = BlockLocating.getLargestRectangle(lv, lv2.get(Properties.HORIZONTAL_AXIS), 21, Axis.Y, 21, posx -> world.getBlockState(posx) == lv2);
			lv4 = TeleportTarget.SEND_TRAVEL_THROUGH_PORTAL_PACKET.then(entityx -> entityx.addPortalChunkTicketAt(lv));
		} else {
			Axis lv5 = (Axis)entity.getWorld().getBlockState(pos).getOrEmpty(AXIS).orElse(Axis.X);
			Optional<Rectangle> optional2 = world.getPortalForcer().createPortal(scaledPos, lv5);
			if (optional2.isEmpty()) {
				LOGGER.error("Unable to create a portal, likely target out of worldborder");
				return null;
			}

			lv3 = (Rectangle)optional2.get();
			lv4 = TeleportTarget.SEND_TRAVEL_THROUGH_PORTAL_PACKET.then(TeleportTarget.ADD_PORTAL_CHUNK_TICKET);
		}

		return getExitPortalTarget(entity, pos, lv3, world, lv4);
	}

	private static TeleportTarget getExitPortalTarget(
		Entity entity, BlockPos pos, Rectangle exitPortalRectangle, ServerWorld world, PostDimensionTransition postDimensionTransition
	) {
		BlockState lv = entity.getWorld().getBlockState(pos);
		Axis lv2;
		Vec3d lv4;
		if (lv.contains(Properties.HORIZONTAL_AXIS)) {
			lv2 = lv.get(Properties.HORIZONTAL_AXIS);
			Rectangle lv3 = BlockLocating.getLargestRectangle(pos, lv2, 21, Axis.Y, 21, posx -> entity.getWorld().getBlockState(posx) == lv);
			lv4 = entity.positionInPortal(lv2, lv3);
		} else {
			lv2 = Axis.X;
			lv4 = new Vec3d(0.5, 0.0, 0.0);
		}

		return getExitPortalTarget(world, exitPortalRectangle, lv2, lv4, entity, postDimensionTransition);
	}

	private static TeleportTarget getExitPortalTarget(
		ServerWorld world, Rectangle exitPortalRectangle, Axis axis, Vec3d positionInPortal, Entity entity, PostDimensionTransition postDimensionTransition
	) {
		BlockPos lv = exitPortalRectangle.lowerLeft;
		BlockState lv2 = world.getBlockState(lv);
		Axis lv3 = (Axis)lv2.getOrEmpty(Properties.HORIZONTAL_AXIS).orElse(Axis.X);
		double d = (double)exitPortalRectangle.width;
		double e = (double)exitPortalRectangle.height;
		EntityDimensions lv4 = entity.getDimensions(entity.getPose());
		int i = axis == lv3 ? 0 : 90;
		double f = (double)lv4.width() / 2.0 + (d - (double)lv4.width()) * positionInPortal.getX();
		double g = (e - (double)lv4.height()) * positionInPortal.getY();
		double h = 0.5 + positionInPortal.getZ();
		boolean bl = lv3 == Axis.X;
		Vec3d lv5 = new Vec3d((double)lv.getX() + (bl ? f : h), (double)lv.getY() + g, (double)lv.getZ() + (bl ? h : f));
		Vec3d lv6 = NetherPortal.findOpenPosition(lv5, world, entity, lv4);
		return new TeleportTarget(world, lv6, Vec3d.ZERO, (float)i, 0.0F, PositionFlag.combine(PositionFlag.DELTA, PositionFlag.ROT), postDimensionTransition);
	}

	@Override
	public Effect getPortalEffect() {
		return Effect.CONFUSION;
	}

	@Override
	public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
		if (random.nextInt(100) == 0) {
			world.playSoundClient(
				(double)pos.getX() + 0.5,
				(double)pos.getY() + 0.5,
				(double)pos.getZ() + 0.5,
				SoundEvents.BLOCK_PORTAL_AMBIENT,
				SoundCategory.BLOCKS,
				0.5F,
				random.nextFloat() * 0.4F + 0.8F,
				false
			);
		}

		for (int i = 0; i < 4; i++) {
			double d = (double)pos.getX() + random.nextDouble();
			double e = (double)pos.getY() + random.nextDouble();
			double f = (double)pos.getZ() + random.nextDouble();
			double g = ((double)random.nextFloat() - 0.5) * 0.5;
			double h = ((double)random.nextFloat() - 0.5) * 0.5;
			double j = ((double)random.nextFloat() - 0.5) * 0.5;
			int k = random.nextInt(2) * 2 - 1;
			if (!world.getBlockState(pos.west()).isOf(this) && !world.getBlockState(pos.east()).isOf(this)) {
				d = (double)pos.getX() + 0.5 + 0.25 * (double)k;
				g = (double)(random.nextFloat() * 2.0F * (float)k);
			} else {
				f = (double)pos.getZ() + 0.5 + 0.25 * (double)k;
				j = (double)(random.nextFloat() * 2.0F * (float)k);
			}

			world.addParticleClient(ParticleTypes.PORTAL, d, e, f, g, h, j);
		}
	}

	@Override
	protected ItemStack getPickStack(WorldView world, BlockPos pos, BlockState state, boolean includeData) {
		return ItemStack.EMPTY;
	}

	@Override
	protected BlockState rotate(BlockState state, BlockRotation rotation) {
		switch (rotation) {
			case COUNTERCLOCKWISE_90:
			case CLOCKWISE_90:
				switch ((Axis)state.get(AXIS)) {
					case X:
						return state.with(AXIS, Axis.Z);
					case Z:
						return state.with(AXIS, Axis.X);
					default:
						return state;
				}
			default:
				return state;
		}
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(AXIS);
	}
}
