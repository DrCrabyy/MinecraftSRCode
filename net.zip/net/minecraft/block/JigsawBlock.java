package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.JigsawBlockEntity;
import net.minecraft.block.entity.JigsawBlockEntity.Joint;
import net.minecraft.block.enums.Orientation;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.structure.StructureTemplate.JigsawBlockInfo;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.world.World;

public class JigsawBlock extends Block implements BlockEntityProvider, OperatorBlock {
	public static final MapCodec<JigsawBlock> CODEC = createCodec(JigsawBlock::new);
	public static final EnumProperty<Orientation> ORIENTATION = Properties.ORIENTATION;

	@Override
	public MapCodec<JigsawBlock> getCodec() {
		return CODEC;
	}

	protected JigsawBlock(Settings settings) {
		super(settings);
		this.setDefaultState(this.stateManager.getDefaultState().with(ORIENTATION, Orientation.NORTH_UP));
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(ORIENTATION);
	}

	@Override
	protected BlockState rotate(BlockState state, BlockRotation rotation) {
		return state.with(ORIENTATION, rotation.getDirectionTransformation().mapJigsawOrientation(state.get(ORIENTATION)));
	}

	@Override
	protected BlockState mirror(BlockState state, BlockMirror mirror) {
		return state.with(ORIENTATION, mirror.getDirectionTransformation().mapJigsawOrientation(state.get(ORIENTATION)));
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		Direction lv = ctx.getSide();
		Direction lv2;
		if (lv.getAxis() == Axis.Y) {
			lv2 = ctx.getHorizontalPlayerFacing().getOpposite();
		} else {
			lv2 = Direction.UP;
		}

		return this.getDefaultState().with(ORIENTATION, Orientation.byDirections(lv, lv2));
	}

	@Override
	public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
		return new JigsawBlockEntity(pos, state);
	}

	@Override
	protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
		BlockEntity lv = world.getBlockEntity(pos);
		if (lv instanceof JigsawBlockEntity && player.isCreativeLevelTwoOp()) {
			player.openJigsawScreen((JigsawBlockEntity)lv);
			return ActionResult.SUCCESS;
		} else {
			return ActionResult.PASS;
		}
	}

	public static boolean attachmentMatches(JigsawBlockInfo info1, JigsawBlockInfo info2) {
		Direction lv = getFacing(info1.info().state());
		Direction lv2 = getFacing(info2.info().state());
		Direction lv3 = getRotation(info1.info().state());
		Direction lv4 = getRotation(info2.info().state());
		Joint lv5 = info1.jointType();
		boolean bl = lv5 == Joint.ROLLABLE;
		return lv == lv2.getOpposite() && (bl || lv3 == lv4) && info1.target().equals(info2.name());
	}

	public static Direction getFacing(BlockState state) {
		return ((Orientation)state.get(ORIENTATION)).getFacing();
	}

	public static Direction getRotation(BlockState state) {
		return ((Orientation)state.get(ORIENTATION)).getRotation();
	}
}
