package net.minecraft.block;

import java.lang.runtime.SwitchBootstraps;
import java.util.Objects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.CollisionView;

public interface ShapeContext {
	static ShapeContext absent() {
		return EntityShapeContext.ABSENT;
	}

	static ShapeContext of(Entity entity) {
		Objects.requireNonNull(entity);
		byte var2 = 0;

		return (ShapeContext)(switch (SwitchBootstraps.typeSwitch<"typeSwitch",AbstractMinecartEntity>(entity, var2)) {
			case 0 -> {
				AbstractMinecartEntity lv = (AbstractMinecartEntity)entity;
				yield AbstractMinecartEntity.areMinecartImprovementsEnabled(lv.getWorld())
					? new ExperimentalMinecartShapeContext(lv, false)
					: new EntityShapeContext(entity, false);
			}
			default -> new EntityShapeContext(entity, false);
		});
	}

	static ShapeContext of(Entity entity, boolean collidesWithFluid) {
		return new EntityShapeContext(entity, collidesWithFluid);
	}

	boolean isDescending();

	boolean isAbove(VoxelShape shape, BlockPos pos, boolean defaultValue);

	boolean isHolding(Item item);

	boolean canWalkOnFluid(FluidState stateAbove, FluidState state);

	VoxelShape getCollisionShape(BlockState state, CollisionView world, BlockPos pos);
}
