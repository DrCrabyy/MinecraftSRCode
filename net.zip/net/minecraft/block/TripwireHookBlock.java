package net.minecraft.block;

import com.google.common.base.MoreObjects;
import com.mojang.serialization.MapCodec;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.minecraft.world.block.OrientationHelper;
import net.minecraft.world.block.WireOrientation;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.tick.ScheduledTickView;

public class TripwireHookBlock extends Block {
	public static final MapCodec<TripwireHookBlock> CODEC = createCodec(TripwireHookBlock::new);
	public static final EnumProperty<Direction> FACING = HorizontalFacingBlock.FACING;
	public static final BooleanProperty POWERED = Properties.POWERED;
	public static final BooleanProperty ATTACHED = Properties.ATTACHED;
	protected static final int field_31268 = 1;
	protected static final int field_31269 = 42;
	private static final int SCHEDULED_TICK_DELAY = 10;
	private static final Map<Direction, VoxelShape> field_55808 = VoxelShapes.method_66501(Block.method_66396(6.0, 0.0, 10.0, 10.0, 16.0));

	@Override
	public MapCodec<TripwireHookBlock> getCodec() {
		return CODEC;
	}

	public TripwireHookBlock(Settings settings) {
		super(settings);
		this.setDefaultState(
			this.stateManager.getDefaultState().with(FACING, Direction.NORTH).with(POWERED, Boolean.valueOf(false)).with(ATTACHED, Boolean.valueOf(false))
		);
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return (VoxelShape)field_55808.get(state.get(FACING));
	}

	@Override
	protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
		Direction lv = state.get(FACING);
		BlockPos lv2 = pos.offset(lv.getOpposite());
		BlockState lv3 = world.getBlockState(lv2);
		return lv.getAxis().isHorizontal() && lv3.isSideSolidFullSquare(world, lv2, lv);
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		return direction.getOpposite() == state.get(FACING) && !state.canPlaceAt(world, pos)
			? Blocks.AIR.getDefaultState()
			: super.getStateForNeighborUpdate(state, world, tickView, pos, direction, neighborPos, neighborState, random);
	}

	@Nullable
	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		BlockState lv = this.getDefaultState().with(POWERED, Boolean.valueOf(false)).with(ATTACHED, Boolean.valueOf(false));
		WorldView lv2 = ctx.getWorld();
		BlockPos lv3 = ctx.getBlockPos();
		Direction[] lvs = ctx.getPlacementDirections();

		for (Direction lv4 : lvs) {
			if (lv4.getAxis().isHorizontal()) {
				Direction lv5 = lv4.getOpposite();
				lv = lv.with(FACING, lv5);
				if (lv.canPlaceAt(lv2, lv3)) {
					return lv;
				}
			}
		}

		return null;
	}

	@Override
	public void onPlaced(World world, BlockPos pos, BlockState state, LivingEntity placer, ItemStack itemStack) {
		update(world, pos, state, false, false, -1, null);
	}

	public static void update(World world, BlockPos pos, BlockState state, boolean bl, boolean bl2, int i, @Nullable BlockState arg4) {
		Optional<Direction> optional = state.getOrEmpty(FACING);
		if (optional.isPresent()) {
			Direction lv = (Direction)optional.get();
			boolean bl3 = (Boolean)state.getOrEmpty(ATTACHED).orElse(false);
			boolean bl4 = (Boolean)state.getOrEmpty(POWERED).orElse(false);
			Block lv2 = state.getBlock();
			boolean bl5 = !bl;
			boolean bl6 = false;
			int j = 0;
			BlockState[] lvs = new BlockState[42];

			for (int k = 1; k < 42; k++) {
				BlockPos lv3 = pos.offset(lv, k);
				BlockState lv4 = world.getBlockState(lv3);
				if (lv4.isOf(Blocks.TRIPWIRE_HOOK)) {
					if (lv4.get(FACING) == lv.getOpposite()) {
						j = k;
					}
					break;
				}

				if (!lv4.isOf(Blocks.TRIPWIRE) && k != i) {
					lvs[k] = null;
					bl5 = false;
				} else {
					if (k == i) {
						lv4 = (BlockState)MoreObjects.firstNonNull(arg4, lv4);
					}

					boolean bl7 = !(Boolean)lv4.get(TripwireBlock.DISARMED);
					boolean bl8 = (Boolean)lv4.get(TripwireBlock.POWERED);
					bl6 |= bl7 && bl8;
					lvs[k] = lv4;
					if (k == i) {
						world.scheduleBlockTick(pos, lv2, 10);
						bl5 &= bl7;
					}
				}
			}

			bl5 &= j > 1;
			bl6 &= bl5;
			BlockState lv5 = lv2.getDefaultState().withIfExists(ATTACHED, Boolean.valueOf(bl5)).withIfExists(POWERED, Boolean.valueOf(bl6));
			if (j > 0) {
				BlockPos lv3x = pos.offset(lv, j);
				Direction lv6 = lv.getOpposite();
				world.setBlockState(lv3x, lv5.with(FACING, lv6), 3);
				updateNeighborsOnAxis(lv2, world, lv3x, lv6);
				playSound(world, lv3x, bl5, bl6, bl3, bl4);
			}

			playSound(world, pos, bl5, bl6, bl3, bl4);
			if (!bl) {
				world.setBlockState(pos, lv5.with(FACING, lv), 3);
				if (bl2) {
					updateNeighborsOnAxis(lv2, world, pos, lv);
				}
			}

			if (bl3 != bl5) {
				for (int l = 1; l < j; l++) {
					BlockPos lv7 = pos.offset(lv, l);
					BlockState lv8 = lvs[l];
					if (lv8 != null) {
						BlockState lv9 = world.getBlockState(lv7);
						if (lv9.isOf(Blocks.TRIPWIRE) || lv9.isOf(Blocks.TRIPWIRE_HOOK)) {
							world.setBlockState(lv7, lv8.withIfExists(ATTACHED, Boolean.valueOf(bl5)), 3);
						}
					}
				}
			}
		}
	}

	@Override
	protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		update(world, pos, state, false, true, -1, null);
	}

	private static void playSound(World world, BlockPos pos, boolean attached, boolean on, boolean detached, boolean off) {
		if (on && !off) {
			world.playSound(null, pos, SoundEvents.BLOCK_TRIPWIRE_CLICK_ON, SoundCategory.BLOCKS, 0.4F, 0.6F);
			world.emitGameEvent(null, GameEvent.BLOCK_ACTIVATE, pos);
		} else if (!on && off) {
			world.playSound(null, pos, SoundEvents.BLOCK_TRIPWIRE_CLICK_OFF, SoundCategory.BLOCKS, 0.4F, 0.5F);
			world.emitGameEvent(null, GameEvent.BLOCK_DEACTIVATE, pos);
		} else if (attached && !detached) {
			world.playSound(null, pos, SoundEvents.BLOCK_TRIPWIRE_ATTACH, SoundCategory.BLOCKS, 0.4F, 0.7F);
			world.emitGameEvent(null, GameEvent.BLOCK_ATTACH, pos);
		} else if (!attached && detached) {
			world.playSound(null, pos, SoundEvents.BLOCK_TRIPWIRE_DETACH, SoundCategory.BLOCKS, 0.4F, 1.2F / (world.random.nextFloat() * 0.2F + 0.9F));
			world.emitGameEvent(null, GameEvent.BLOCK_DETACH, pos);
		}
	}

	private static void updateNeighborsOnAxis(Block block, World world, BlockPos pos, Direction direction) {
		Direction lv = direction.getOpposite();
		WireOrientation lv2 = OrientationHelper.getEmissionOrientation(world, lv, Direction.UP);
		world.updateNeighborsAlways(pos, block, lv2);
		world.updateNeighborsAlways(pos.offset(lv), block, lv2);
	}

	@Override
	protected void onStateReplaced(BlockState state, ServerWorld world, BlockPos pos, boolean moved) {
		if (!moved) {
			boolean bl2 = (Boolean)state.get(ATTACHED);
			boolean bl3 = (Boolean)state.get(POWERED);
			if (bl2 || bl3) {
				update(world, pos, state, true, false, -1, null);
			}

			if (bl3) {
				updateNeighborsOnAxis(this, world, pos, state.get(FACING));
			}
		}
	}

	@Override
	protected int getWeakRedstonePower(BlockState state, BlockView world, BlockPos pos, Direction direction) {
		return state.get(POWERED) ? 15 : 0;
	}

	@Override
	protected int getStrongRedstonePower(BlockState state, BlockView world, BlockPos pos, Direction direction) {
		if (!(Boolean)state.get(POWERED)) {
			return 0;
		} else {
			return state.get(FACING) == direction ? 15 : 0;
		}
	}

	@Override
	protected boolean emitsRedstonePower(BlockState state) {
		return true;
	}

	@Override
	protected BlockState rotate(BlockState state, BlockRotation rotation) {
		return state.with(FACING, rotation.rotate(state.get(FACING)));
	}

	@Override
	protected BlockState mirror(BlockState state, BlockMirror mirror) {
		return state.rotate(mirror.getRotation(state.get(FACING)));
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(FACING, POWERED, ATTACHED);
	}
}
