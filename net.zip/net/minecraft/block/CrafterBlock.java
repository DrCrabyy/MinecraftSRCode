package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.dispenser.ItemDispenserBehavior;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.entity.CrafterBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.enums.Orientation;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.CraftingRecipe;
import net.minecraft.recipe.RecipeCache;
import net.minecraft.recipe.RecipeEntry;
import net.minecraft.recipe.input.CraftingRecipeInput;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.ItemScatterer;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.block.WireOrientation;

public class CrafterBlock extends BlockWithEntity {
	public static final MapCodec<CrafterBlock> CODEC = createCodec(CrafterBlock::new);
	public static final BooleanProperty CRAFTING = Properties.CRAFTING;
	public static final BooleanProperty TRIGGERED = Properties.TRIGGERED;
	private static final EnumProperty<Orientation> ORIENTATION = Properties.ORIENTATION;
	private static final int field_46802 = 6;
	private static final int TRIGGER_DELAY = 4;
	private static final RecipeCache recipeCache = new RecipeCache(10);
	private static final int field_50015 = 17;

	public CrafterBlock(Settings settings) {
		super(settings);
		this.setDefaultState(
			this.stateManager.getDefaultState().with(ORIENTATION, Orientation.NORTH_UP).with(TRIGGERED, Boolean.valueOf(false)).with(CRAFTING, Boolean.valueOf(false))
		);
	}

	@Override
	protected MapCodec<CrafterBlock> getCodec() {
		return CODEC;
	}

	@Override
	protected boolean hasComparatorOutput(BlockState state) {
		return true;
	}

	@Override
	protected int getComparatorOutput(BlockState state, World world, BlockPos pos) {
		return world.getBlockEntity(pos) instanceof CrafterBlockEntity lv2 ? lv2.getComparatorOutput() : 0;
	}

	@Override
	protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock, @Nullable WireOrientation wireOrientation, boolean notify) {
		boolean bl2 = world.isReceivingRedstonePower(pos);
		boolean bl3 = (Boolean)state.get(TRIGGERED);
		BlockEntity lv = world.getBlockEntity(pos);
		if (bl2 && !bl3) {
			world.scheduleBlockTick(pos, this, 4);
			world.setBlockState(pos, state.with(TRIGGERED, Boolean.valueOf(true)), 2);
			this.setTriggered(lv, true);
		} else if (!bl2 && bl3) {
			world.setBlockState(pos, state.with(TRIGGERED, Boolean.valueOf(false)).with(CRAFTING, Boolean.valueOf(false)), 2);
			this.setTriggered(lv, false);
		}
	}

	@Override
	protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		this.craft(state, world, pos);
	}

	@Nullable
	@Override
	public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state, BlockEntityType<T> type) {
		return world.isClient ? null : validateTicker(type, BlockEntityType.CRAFTER, CrafterBlockEntity::tickCrafting);
	}

	private void setTriggered(@Nullable BlockEntity blockEntity, boolean triggered) {
		if (blockEntity instanceof CrafterBlockEntity lv) {
			lv.setTriggered(triggered);
		}
	}

	@Override
	public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
		CrafterBlockEntity lv = new CrafterBlockEntity(pos, state);
		lv.setTriggered(state.contains(TRIGGERED) && (Boolean)state.get(TRIGGERED));
		return lv;
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		Direction lv = ctx.getPlayerLookDirection().getOpposite();

		Direction lv2 = switch (lv) {
			case DOWN -> ctx.getHorizontalPlayerFacing().getOpposite();
			case UP -> ctx.getHorizontalPlayerFacing();
			case NORTH, SOUTH, WEST, EAST -> Direction.UP;
			default -> throw new MatchException(null, null);
		};
		return this.getDefaultState()
			.with(ORIENTATION, Orientation.byDirections(lv, lv2))
			.with(TRIGGERED, Boolean.valueOf(ctx.getWorld().isReceivingRedstonePower(ctx.getBlockPos())));
	}

	@Override
	public void onPlaced(World world, BlockPos pos, BlockState state, LivingEntity placer, ItemStack itemStack) {
		if ((Boolean)state.get(TRIGGERED)) {
			world.scheduleBlockTick(pos, this, 4);
		}
	}

	@Override
	protected void onStateReplaced(BlockState state, ServerWorld world, BlockPos pos, boolean moved) {
		ItemScatterer.onStateReplaced(state, world, pos);
	}

	@Override
	protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
		if (!world.isClient && world.getBlockEntity(pos) instanceof CrafterBlockEntity lv) {
			player.openHandledScreen(lv);
		}

		return ActionResult.SUCCESS;
	}

	protected void craft(BlockState state, ServerWorld world, BlockPos pos) {
		if (world.getBlockEntity(pos) instanceof CrafterBlockEntity lv) {
			CraftingRecipeInput var11 = lv.createRecipeInput();
			Optional<RecipeEntry<CraftingRecipe>> optional = getCraftingRecipe(world, var11);
			if (optional.isEmpty()) {
				world.syncWorldEvent(1050, pos, 0);
			} else {
				RecipeEntry<CraftingRecipe> lv3 = (RecipeEntry<CraftingRecipe>)optional.get();
				ItemStack lv4 = lv3.value().craft(var11, world.getRegistryManager());
				if (lv4.isEmpty()) {
					world.syncWorldEvent(1050, pos, 0);
				} else {
					lv.setCraftingTicksRemaining(6);
					world.setBlockState(pos, state.with(CRAFTING, Boolean.valueOf(true)), 2);
					lv4.onCraftByCrafter(world);
					this.transferOrSpawnStack(world, pos, lv, lv4, state, lv3);

					for (ItemStack lv5 : lv3.value().getRecipeRemainders(var11)) {
						if (!lv5.isEmpty()) {
							this.transferOrSpawnStack(world, pos, lv, lv5, state, lv3);
						}
					}

					lv.getHeldStacks().forEach(stack -> {
						if (!stack.isEmpty()) {
							stack.decrement(1);
						}
					});
					lv.markDirty();
				}
			}
		}
	}

	public static Optional<RecipeEntry<CraftingRecipe>> getCraftingRecipe(ServerWorld world, CraftingRecipeInput input) {
		return recipeCache.getRecipe(world, input);
	}

	private void transferOrSpawnStack(ServerWorld world, BlockPos pos, CrafterBlockEntity blockEntity, ItemStack stack, BlockState state, RecipeEntry<?> recipe) {
		Direction lv = ((Orientation)state.get(ORIENTATION)).getFacing();
		Inventory lv2 = HopperBlockEntity.getInventoryAt(world, pos.offset(lv));
		ItemStack lv3 = stack.copy();
		if (lv2 != null && (lv2 instanceof CrafterBlockEntity || stack.getCount() > lv2.getMaxCount(stack))) {
			while (!lv3.isEmpty()) {
				ItemStack lv4 = lv3.copyWithCount(1);
				ItemStack lv5 = HopperBlockEntity.transfer(blockEntity, lv2, lv4, lv.getOpposite());
				if (!lv5.isEmpty()) {
					break;
				}

				lv3.decrement(1);
			}
		} else if (lv2 != null) {
			while (!lv3.isEmpty()) {
				int i = lv3.getCount();
				lv3 = HopperBlockEntity.transfer(blockEntity, lv2, lv3, lv.getOpposite());
				if (i == lv3.getCount()) {
					break;
				}
			}
		}

		if (!lv3.isEmpty()) {
			Vec3d lv6 = Vec3d.ofCenter(pos);
			Vec3d lv7 = lv6.offset(lv, 0.7);
			ItemDispenserBehavior.spawnItem(world, lv3, 6, lv, lv7);

			for (ServerPlayerEntity lv8 : world.getNonSpectatingEntities(ServerPlayerEntity.class, Box.of(lv6, 17.0, 17.0, 17.0))) {
				Criteria.CRAFTER_RECIPE_CRAFTED.trigger(lv8, recipe.id(), blockEntity.getHeldStacks());
			}

			world.syncWorldEvent(1049, pos, 0);
			world.syncWorldEvent(2010, pos, lv.getId());
		}
	}

	@Override
	protected BlockState rotate(BlockState state, BlockRotation rotation) {
		return state.with(ORIENTATION, rotation.getDirectionTransformation().mapJigsawOrientation(state.get(ORIENTATION)));
	}

	@Override
	protected BlockState mirror(BlockState state, BlockMirror mirror) {
		return state.with(ORIENTATION, mirror.getDirectionTransformation().mapJigsawOrientation(state.get(ORIENTATION)));
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(ORIENTATION, TRIGGERED, CRAFTING);
	}
}
