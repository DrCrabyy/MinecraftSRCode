package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.Oxidizable.OxidationLevel;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;

public class OxidizableStairsBlock extends StairsBlock implements Oxidizable {
	public static final MapCodec<OxidizableStairsBlock> CODEC = RecordCodecBuilder.mapCodec(
		instance -> instance.group(
					OxidationLevel.CODEC.fieldOf("weathering_state").forGetter(Degradable::getDegradationLevel),
					BlockState.CODEC.fieldOf("base_state").forGetter(arg -> arg.baseBlockState),
					createSettingsCodec()
				)
				.apply(instance, OxidizableStairsBlock::new)
	);
	private final OxidationLevel oxidationLevel;

	@Override
	public MapCodec<OxidizableStairsBlock> getCodec() {
		return CODEC;
	}

	public OxidizableStairsBlock(OxidationLevel oxidationLevel, BlockState baseBlockState, Settings settings) {
		super(baseBlockState, settings);
		this.oxidationLevel = oxidationLevel;
	}

	@Override
	protected void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		this.tickDegradation(state, world, pos, random);
	}

	@Override
	protected boolean hasRandomTicks(BlockState state) {
		return Oxidizable.getIncreasedOxidationBlock(state.getBlock()).isPresent();
	}

	public OxidationLevel getDegradationLevel() {
		return this.oxidationLevel;
	}
}
