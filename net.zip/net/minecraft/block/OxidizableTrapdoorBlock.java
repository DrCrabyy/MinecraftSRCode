package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.Oxidizable.OxidationLevel;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;

public class OxidizableTrapdoorBlock extends TrapdoorBlock implements Oxidizable {
	public static final MapCodec<OxidizableTrapdoorBlock> CODEC = RecordCodecBuilder.mapCodec(
		instance -> instance.group(
					BlockSetType.CODEC.fieldOf("block_set_type").forGetter(TrapdoorBlock::getBlockSetType),
					OxidationLevel.CODEC.fieldOf("weathering_state").forGetter(OxidizableTrapdoorBlock::getDegradationLevel),
					createSettingsCodec()
				)
				.apply(instance, OxidizableTrapdoorBlock::new)
	);
	private final OxidationLevel oxidationLevel;

	@Override
	public MapCodec<OxidizableTrapdoorBlock> getCodec() {
		return CODEC;
	}

	protected OxidizableTrapdoorBlock(BlockSetType type, OxidationLevel oxidationLevel, Settings settings) {
		super(type, settings);
		this.oxidationLevel = oxidationLevel;
	}

	@Override
	protected void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		this.tickDegradation(state, world, pos, random);
	}

	@Override
	protected boolean hasRandomTicks(BlockState state) {
		return Oxidizable.getIncreasedOxidationBlock(state.getBlock()).isPresent();
	}

	public OxidationLevel getDegradationLevel() {
		return this.oxidationLevel;
	}
}
