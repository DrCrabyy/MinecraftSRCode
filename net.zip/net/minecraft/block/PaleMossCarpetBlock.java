package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.mojang.serialization.MapCodec;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.BooleanSupplier;
import java.util.function.Function;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.enums.WallShape;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Type;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.minecraft.world.tick.ScheduledTickView;

public class PaleMossCarpetBlock extends Block implements Fertilizable {
	public static final MapCodec<PaleMossCarpetBlock> CODEC = createCodec(PaleMossCarpetBlock::new);
	public static final BooleanProperty BOTTOM = Properties.BOTTOM;
	public static final EnumProperty<WallShape> NORTH = Properties.NORTH_WALL_SHAPE;
	public static final EnumProperty<WallShape> EAST = Properties.EAST_WALL_SHAPE;
	public static final EnumProperty<WallShape> SOUTH = Properties.SOUTH_WALL_SHAPE;
	public static final EnumProperty<WallShape> WEST = Properties.WEST_WALL_SHAPE;
	public static final Map<Direction, EnumProperty<WallShape>> field_55778 = ImmutableMap.copyOf(
		Maps.newEnumMap(Map.of(Direction.NORTH, NORTH, Direction.EAST, EAST, Direction.SOUTH, SOUTH, Direction.WEST, WEST))
	);
	private final Function<BlockState, VoxelShape> field_55779;

	@Override
	public MapCodec<PaleMossCarpetBlock> getCodec() {
		return CODEC;
	}

	public PaleMossCarpetBlock(Settings settings) {
		super(settings);
		this.setDefaultState(
			this.stateManager
				.getDefaultState()
				.with(BOTTOM, Boolean.valueOf(true))
				.with(NORTH, WallShape.NONE)
				.with(EAST, WallShape.NONE)
				.with(SOUTH, WallShape.NONE)
				.with(WEST, WallShape.NONE)
		);
		this.field_55779 = this.method_66453();
	}

	@Override
	protected VoxelShape getCullingShape(BlockState state) {
		return VoxelShapes.empty();
	}

	public Function<BlockState, VoxelShape> method_66453() {
		Map<Direction, VoxelShape> map = VoxelShapes.method_66501(Block.method_66396(16.0, 0.0, 10.0, 0.0, 1.0));
		Map<Direction, VoxelShape> map2 = VoxelShapes.method_66504(Block.method_66408(16.0, 0.0, 1.0));
		return this.getShapesForStates(arg -> {
			VoxelShape lv = arg.get(BOTTOM) ? (VoxelShape)map2.get(Direction.DOWN) : VoxelShapes.empty();

			for (Entry<Direction, EnumProperty<WallShape>> entry : field_55778.entrySet()) {
				switch ((WallShape)arg.get((Property)entry.getValue())) {
					case NONE:
					default:
						break;
					case LOW:
						lv = VoxelShapes.union(lv, (VoxelShape)map.get(entry.getKey()));
						break;
					case TALL:
						lv = VoxelShapes.union(lv, (VoxelShape)map2.get(entry.getKey()));
				}
			}

			return lv.isEmpty() ? VoxelShapes.fullCube() : lv;
		});
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return (VoxelShape)this.field_55779.apply(state);
	}

	@Override
	protected VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return state.get(BOTTOM) ? (VoxelShape)this.field_55779.apply(this.getDefaultState()) : VoxelShapes.empty();
	}

	@Override
	protected boolean isTransparent(BlockState state) {
		return true;
	}

	@Override
	protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
		BlockState lv = world.getBlockState(pos.down());
		return state.get(BOTTOM) ? !lv.isAir() : lv.isOf(this) && (Boolean)lv.get(BOTTOM);
	}

	private static boolean hasAnyShape(BlockState state) {
		if ((Boolean)state.get(BOTTOM)) {
			return true;
		} else {
			for (EnumProperty<WallShape> lv : field_55778.values()) {
				if (state.get(lv) != WallShape.NONE) {
					return true;
				}
			}

			return false;
		}
	}

	private static boolean canGrowOnFace(BlockView world, BlockPos pos, Direction direction) {
		return direction == Direction.UP ? false : MultifaceBlock.canGrowOn(world, pos, direction);
	}

	private static BlockState updateState(BlockState state, BlockView world, BlockPos pos, boolean bl) {
		BlockState lv = null;
		BlockState lv2 = null;
		bl |= state.get(BOTTOM);

		for (Direction lv3 : Type.HORIZONTAL) {
			EnumProperty<WallShape> lv4 = getWallShape(lv3);
			WallShape lv5 = canGrowOnFace(world, pos, lv3) ? (bl ? WallShape.LOW : state.get(lv4)) : WallShape.NONE;
			if (lv5 == WallShape.LOW) {
				if (lv == null) {
					lv = world.getBlockState(pos.up());
				}

				if (lv.isOf(Blocks.PALE_MOSS_CARPET) && lv.get(lv4) != WallShape.NONE && !(Boolean)lv.get(BOTTOM)) {
					lv5 = WallShape.TALL;
				}

				if (!(Boolean)state.get(BOTTOM)) {
					if (lv2 == null) {
						lv2 = world.getBlockState(pos.down());
					}

					if (lv2.isOf(Blocks.PALE_MOSS_CARPET) && lv2.get(lv4) == WallShape.NONE) {
						lv5 = WallShape.NONE;
					}
				}
			}

			state = state.with(lv4, lv5);
		}

		return state;
	}

	@Nullable
	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		return updateState(this.getDefaultState(), ctx.getWorld(), ctx.getBlockPos(), true);
	}

	public static void placeAt(WorldAccess world, BlockPos pos, Random random, int flags) {
		BlockState lv = Blocks.PALE_MOSS_CARPET.getDefaultState();
		BlockState lv2 = updateState(lv, world, pos, true);
		world.setBlockState(pos, lv2, flags);
		BlockState lv3 = createUpperState(world, pos, random::nextBoolean);
		if (!lv3.isAir()) {
			world.setBlockState(pos.up(), lv3, flags);
			BlockState lv4 = updateState(lv2, world, pos, true);
			world.setBlockState(pos, lv4, flags);
		}
	}

	@Override
	public void onPlaced(World world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack itemStack) {
		if (!world.isClient) {
			Random lv = world.getRandom();
			BlockState lv2 = createUpperState(world, pos, lv::nextBoolean);
			if (!lv2.isAir()) {
				world.setBlockState(pos.up(), lv2, 3);
			}
		}
	}

	private static BlockState createUpperState(BlockView world, BlockPos pos, BooleanSupplier booleanSupplier) {
		BlockPos lv = pos.up();
		BlockState lv2 = world.getBlockState(lv);
		boolean bl = lv2.isOf(Blocks.PALE_MOSS_CARPET);
		if ((!bl || !(Boolean)lv2.get(BOTTOM)) && (bl || lv2.isReplaceable())) {
			BlockState lv3 = Blocks.PALE_MOSS_CARPET.getDefaultState().with(BOTTOM, Boolean.valueOf(false));
			BlockState lv4 = updateState(lv3, world, pos.up(), true);

			for (Direction lv5 : Type.HORIZONTAL) {
				EnumProperty<WallShape> lv6 = getWallShape(lv5);
				if (lv4.get(lv6) != WallShape.NONE && !booleanSupplier.getAsBoolean()) {
					lv4 = lv4.with(lv6, WallShape.NONE);
				}
			}

			return hasAnyShape(lv4) && lv4 != lv2 ? lv4 : Blocks.AIR.getDefaultState();
		} else {
			return Blocks.AIR.getDefaultState();
		}
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		if (!state.canPlaceAt(world, pos)) {
			return Blocks.AIR.getDefaultState();
		} else {
			BlockState lv = updateState(state, world, pos, false);
			return !hasAnyShape(lv) ? Blocks.AIR.getDefaultState() : lv;
		}
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(BOTTOM, NORTH, EAST, SOUTH, WEST);
	}

	@Override
	protected BlockState rotate(BlockState state, BlockRotation rotation) {
		return switch (rotation) {
			case CLOCKWISE_180 -> (BlockState)state.with(NORTH, (WallShape)state.get(SOUTH))
			.with(EAST, (WallShape)state.get(WEST))
			.with(SOUTH, (WallShape)state.get(NORTH))
			.with(WEST, (WallShape)state.get(EAST));
			case COUNTERCLOCKWISE_90 -> (BlockState)state.with(NORTH, (WallShape)state.get(EAST))
			.with(EAST, (WallShape)state.get(SOUTH))
			.with(SOUTH, (WallShape)state.get(WEST))
			.with(WEST, (WallShape)state.get(NORTH));
			case CLOCKWISE_90 -> (BlockState)state.with(NORTH, (WallShape)state.get(WEST))
			.with(EAST, (WallShape)state.get(NORTH))
			.with(SOUTH, (WallShape)state.get(EAST))
			.with(WEST, (WallShape)state.get(SOUTH));
			default -> state;
		};
	}

	@Override
	protected BlockState mirror(BlockState state, BlockMirror mirror) {
		return switch (mirror) {
			case LEFT_RIGHT -> (BlockState)state.with(NORTH, (WallShape)state.get(SOUTH)).with(SOUTH, (WallShape)state.get(NORTH));
			case FRONT_BACK -> (BlockState)state.with(EAST, (WallShape)state.get(WEST)).with(WEST, (WallShape)state.get(EAST));
			default -> super.mirror(state, mirror);
		};
	}

	@Nullable
	public static EnumProperty<WallShape> getWallShape(Direction face) {
		return (EnumProperty<WallShape>)field_55778.get(face);
	}

	@Override
	public boolean isFertilizable(WorldView world, BlockPos pos, BlockState state) {
		return (Boolean)state.get(BOTTOM) && !createUpperState(world, pos, () -> true).isAir();
	}

	@Override
	public boolean canGrow(World world, Random random, BlockPos pos, BlockState state) {
		return true;
	}

	@Override
	public void grow(ServerWorld world, Random random, BlockPos pos, BlockState state) {
		BlockState lv = createUpperState(world, pos, () -> true);
		if (!lv.isAir()) {
			world.setBlockState(pos.up(), lv, 3);
		}
	}
}
