package net.minecraft.block;

import com.google.common.annotations.VisibleForTesting;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldAccess;

public class MultifaceGrower {
	public static final MultifaceGrower.GrowType[] GROW_TYPES = new MultifaceGrower.GrowType[]{
		MultifaceGrower.GrowType.SAME_POSITION, MultifaceGrower.GrowType.SAME_PLANE, MultifaceGrower.GrowType.WRAP_AROUND
	};
	private final MultifaceGrower.GrowChecker growChecker;

	public MultifaceGrower(MultifaceBlock lichen) {
		this(new MultifaceGrower.LichenGrowChecker(lichen));
	}

	public MultifaceGrower(MultifaceGrower.GrowChecker growChecker) {
		this.growChecker = growChecker;
	}

	public boolean canGrow(BlockState state, BlockView world, BlockPos pos, Direction direction) {
		return Direction.stream().anyMatch(direction2 -> this.getGrowPos(state, world, pos, direction, direction2, this.growChecker::canGrow).isPresent());
	}

	public Optional<MultifaceGrower.GrowPos> grow(BlockState state, WorldAccess world, BlockPos pos, Random random) {
		return (Optional<MultifaceGrower.GrowPos>)Direction.shuffle(random)
			.stream()
			.filter(direction -> this.growChecker.canGrow(state, direction))
			.map(direction -> this.grow(state, world, pos, direction, random, false))
			.filter(Optional::isPresent)
			.findFirst()
			.orElse(Optional.empty());
	}

	public long grow(BlockState state, WorldAccess world, BlockPos pos, boolean markForPostProcessing) {
		return (Long)Direction.stream()
			.filter(direction -> this.growChecker.canGrow(state, direction))
			.map(direction -> this.grow(state, world, pos, direction, markForPostProcessing))
			.reduce(0L, Long::sum);
	}

	public Optional<MultifaceGrower.GrowPos> grow(
		BlockState state, WorldAccess world, BlockPos pos, Direction direction, Random random, boolean markForPostProcessing
	) {
		return (Optional<MultifaceGrower.GrowPos>)Direction.shuffle(random)
			.stream()
			.map(direction2 -> this.grow(state, world, pos, direction, direction2, markForPostProcessing))
			.filter(Optional::isPresent)
			.findFirst()
			.orElse(Optional.empty());
	}

	private long grow(BlockState state, WorldAccess world, BlockPos pos, Direction direction, boolean markForPostProcessing) {
		return Direction.stream().map(direction2 -> this.grow(state, world, pos, direction, direction2, markForPostProcessing)).filter(Optional::isPresent).count();
	}

	@VisibleForTesting
	public Optional<MultifaceGrower.GrowPos> grow(
		BlockState state, WorldAccess world, BlockPos pos, Direction oldDirection, Direction newDirection, boolean markForPostProcessing
	) {
		return this.getGrowPos(state, world, pos, oldDirection, newDirection, this.growChecker::canGrow)
			.flatMap(growPos -> this.place(world, growPos, markForPostProcessing));
	}

	public Optional<MultifaceGrower.GrowPos> getGrowPos(
		BlockState state, BlockView world, BlockPos pos, Direction oldDirection, Direction newDirection, MultifaceGrower.GrowPosPredicate predicate
	) {
		if (newDirection.getAxis() == oldDirection.getAxis()) {
			return Optional.empty();
		} else if (this.growChecker.canGrow(state) || this.growChecker.hasDirection(state, oldDirection) && !this.growChecker.hasDirection(state, newDirection)) {
			for (MultifaceGrower.GrowType lv : this.growChecker.getGrowTypes()) {
				MultifaceGrower.GrowPos lv2 = lv.getGrowPos(pos, newDirection, oldDirection);
				if (predicate.test(world, pos, lv2)) {
					return Optional.of(lv2);
				}
			}

			return Optional.empty();
		} else {
			return Optional.empty();
		}
	}

	public Optional<MultifaceGrower.GrowPos> place(WorldAccess world, MultifaceGrower.GrowPos pos, boolean markForPostProcessing) {
		BlockState lv = world.getBlockState(pos.pos());
		return this.growChecker.place(world, pos, lv, markForPostProcessing) ? Optional.of(pos) : Optional.empty();
	}

	public interface GrowChecker {
		@Nullable
		BlockState getStateWithDirection(BlockState state, BlockView world, BlockPos pos, Direction direction);

		boolean canGrow(BlockView world, BlockPos pos, MultifaceGrower.GrowPos growPos);

		default MultifaceGrower.GrowType[] getGrowTypes() {
			return MultifaceGrower.GROW_TYPES;
		}

		default boolean hasDirection(BlockState state, Direction direction) {
			return MultifaceBlock.hasDirection(state, direction);
		}

		default boolean canGrow(BlockState state) {
			return false;
		}

		default boolean canGrow(BlockState state, Direction direction) {
			return this.canGrow(state) || this.hasDirection(state, direction);
		}

		default boolean place(WorldAccess world, MultifaceGrower.GrowPos growPos, BlockState state, boolean markForPostProcessing) {
			BlockState lv = this.getStateWithDirection(state, world, growPos.pos(), growPos.face());
			if (lv != null) {
				if (markForPostProcessing) {
					world.getChunk(growPos.pos()).markBlockForPostProcessing(growPos.pos());
				}

				return world.setBlockState(growPos.pos(), lv, 2);
			} else {
				return false;
			}
		}
	}

	public static record GrowPos(BlockPos pos, Direction face) {
	}

	@FunctionalInterface
	public interface GrowPosPredicate {
		boolean test(BlockView world, BlockPos pos, MultifaceGrower.GrowPos growPos);
	}

	public static enum GrowType {
		SAME_POSITION,
		SAME_PLANE,
		WRAP_AROUND;

		public abstract MultifaceGrower.GrowPos getGrowPos(BlockPos pos, Direction newDirection, Direction oldDirection);
	}

	public static class LichenGrowChecker implements MultifaceGrower.GrowChecker {
		protected MultifaceBlock lichen;

		public LichenGrowChecker(MultifaceBlock lichen) {
			this.lichen = lichen;
		}

		@Nullable
		@Override
		public BlockState getStateWithDirection(BlockState state, BlockView world, BlockPos pos, Direction direction) {
			return this.lichen.withDirection(state, world, pos, direction);
		}

		protected boolean canGrow(BlockView world, BlockPos pos, BlockPos growPos, Direction direction, BlockState state) {
			return state.isAir() || state.isOf(this.lichen) || state.isOf(Blocks.WATER) && state.getFluidState().isStill();
		}

		@Override
		public boolean canGrow(BlockView world, BlockPos pos, MultifaceGrower.GrowPos growPos) {
			BlockState lv = world.getBlockState(growPos.pos());
			return this.canGrow(world, pos, growPos.pos(), growPos.face(), lv) && this.lichen.canGrowWithDirection(world, lv, growPos.pos(), growPos.face());
		}
	}
}
