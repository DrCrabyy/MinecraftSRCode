package net.minecraft.block;

import net.minecraft.util.DyeColor;

public interface Stainable {
	DyeColor getColor();
}
