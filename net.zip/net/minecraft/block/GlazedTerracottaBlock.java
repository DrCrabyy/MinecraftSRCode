package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager.Builder;

public class GlazedTerracottaBlock extends HorizontalFacingBlock {
	public static final MapCodec<GlazedTerracottaBlock> CODEC = createCodec(GlazedTerracottaBlock::new);

	@Override
	public MapCodec<GlazedTerracottaBlock> getCodec() {
		return CODEC;
	}

	public GlazedTerracottaBlock(Settings settings) {
		super(settings);
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		return this.getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite());
	}
}
