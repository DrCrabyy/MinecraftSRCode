package net.minecraft.block;

public interface OperatorBlock {
}
