package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.OptionalInt;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.particle.ParticleUtil;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.dynamic.Codecs;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.minecraft.world.tick.ScheduledTickView;

public class LeavesBlock extends Block implements Waterloggable {
	public static final MapCodec<LeavesBlock> CODEC = RecordCodecBuilder.mapCodec(
		instance -> instance.group(
					Codecs.POSITIVE_INT.fieldOf("leaf_particle_chance").forGetter(block -> block.leafParticleChance),
					ParticleTypes.TYPE_CODEC.fieldOf("leaf_particle").forGetter(block -> block.leafParticle),
					createSettingsCodec()
				)
				.apply(instance, LeavesBlock::new)
	);
	public static final int MAX_DISTANCE = 7;
	public static final IntProperty DISTANCE = Properties.DISTANCE_1_7;
	public static final BooleanProperty PERSISTENT = Properties.PERSISTENT;
	public static final BooleanProperty WATERLOGGED = Properties.WATERLOGGED;
	protected final ParticleEffect leafParticle;
	protected final int leafParticleChance;
	private static final int field_31112 = 1;

	@Override
	public MapCodec<? extends LeavesBlock> getCodec() {
		return CODEC;
	}

	public LeavesBlock(int leafParticleChance, ParticleEffect leafParticle, Settings settings) {
		super(settings);
		this.leafParticleChance = leafParticleChance;
		this.leafParticle = leafParticle;
		this.setDefaultState(
			this.stateManager.getDefaultState().with(DISTANCE, Integer.valueOf(7)).with(PERSISTENT, Boolean.valueOf(false)).with(WATERLOGGED, Boolean.valueOf(false))
		);
	}

	@Override
	protected VoxelShape getSidesShape(BlockState state, BlockView world, BlockPos pos) {
		return VoxelShapes.empty();
	}

	@Override
	protected boolean hasRandomTicks(BlockState state) {
		return (Integer)state.get(DISTANCE) == 7 && !(Boolean)state.get(PERSISTENT);
	}

	@Override
	protected void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		if (this.shouldDecay(state)) {
			dropStacks(state, world, pos);
			world.removeBlock(pos, false);
		}
	}

	protected boolean shouldDecay(BlockState state) {
		return !(Boolean)state.get(PERSISTENT) && (Integer)state.get(DISTANCE) == 7;
	}

	@Override
	protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		world.setBlockState(pos, updateDistanceFromLogs(state, world, pos), 3);
	}

	@Override
	protected int getOpacity(BlockState state) {
		return 1;
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		if ((Boolean)state.get(WATERLOGGED)) {
			tickView.scheduleFluidTick(pos, Fluids.WATER, Fluids.WATER.getTickRate(world));
		}

		int i = getDistanceFromLog(neighborState) + 1;
		if (i != 1 || (Integer)state.get(DISTANCE) != i) {
			tickView.scheduleBlockTick(pos, this, 1);
		}

		return state;
	}

	private static BlockState updateDistanceFromLogs(BlockState state, WorldAccess world, BlockPos pos) {
		int i = 7;
		Mutable lv = new Mutable();

		for (Direction lv2 : Direction.values()) {
			lv.set(pos, lv2);
			i = Math.min(i, getDistanceFromLog(world.getBlockState(lv)) + 1);
			if (i == 1) {
				break;
			}
		}

		return state.with(DISTANCE, Integer.valueOf(i));
	}

	private static int getDistanceFromLog(BlockState state) {
		return getOptionalDistanceFromLog(state).orElse(7);
	}

	public static OptionalInt getOptionalDistanceFromLog(BlockState state) {
		if (state.isIn(BlockTags.LOGS)) {
			return OptionalInt.of(0);
		} else {
			return state.contains(DISTANCE) ? OptionalInt.of((Integer)state.get(DISTANCE)) : OptionalInt.empty();
		}
	}

	@Override
	protected FluidState getFluidState(BlockState state) {
		return state.get(WATERLOGGED) ? Fluids.WATER.getStill(false) : super.getFluidState(state);
	}

	@Override
	public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
		super.randomDisplayTick(state, world, pos, random);
		BlockPos lv = pos.down();
		BlockState lv2 = world.getBlockState(lv);
		spawnWaterParticle(world, pos, random, lv2, lv);
		this.spawnLeafParticle(world, pos, random, lv2, lv);
	}

	private static void spawnWaterParticle(World world, BlockPos pos, Random random, BlockState state, BlockPos posBelow) {
		if (world.hasRain(pos.up())) {
			if (random.nextInt(15) == 1) {
				if (!state.isOpaque() || !state.isSideSolidFullSquare(world, posBelow, Direction.UP)) {
					ParticleUtil.spawnParticle(world, pos, random, ParticleTypes.DRIPPING_WATER);
				}
			}
		}
	}

	private void spawnLeafParticle(World world, BlockPos pos, Random random, BlockState state, BlockPos posBelow) {
		if (random.nextInt(this.leafParticleChance) == 0) {
			if (!isFaceFullSquare(state.getCollisionShape(world, posBelow), Direction.UP)) {
				ParticleUtil.spawnParticle(world, pos, random, this.leafParticle);
			}
		}
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(DISTANCE, PERSISTENT, WATERLOGGED);
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		FluidState lv = ctx.getWorld().getFluidState(ctx.getBlockPos());
		BlockState lv2 = this.getDefaultState().with(PERSISTENT, Boolean.valueOf(true)).with(WATERLOGGED, Boolean.valueOf(lv.getFluid() == Fluids.WATER));
		return updateDistanceFromLogs(lv2, ctx.getWorld(), ctx.getBlockPos());
	}
}
