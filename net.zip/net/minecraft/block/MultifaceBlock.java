package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import java.util.Arrays;
import java.util.Collection;
import java.util.EnumSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.Direction.Type;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.minecraft.world.tick.ScheduledTickView;

public class MultifaceBlock extends Block implements Waterloggable {
	public static final MapCodec<MultifaceBlock> CODEC = createCodec(MultifaceBlock::new);
	public static final BooleanProperty WATERLOGGED = Properties.WATERLOGGED;
	private static final Map<Direction, BooleanProperty> FACING_PROPERTIES = ConnectingBlock.FACING_PROPERTIES;
	protected static final Direction[] DIRECTIONS = Direction.values();
	private final Function<BlockState, VoxelShape> field_55780;
	private final boolean hasAllHorizontalDirections;
	private final boolean canMirrorX;
	private final boolean canMirrorZ;

	@Override
	protected MapCodec<? extends MultifaceBlock> getCodec() {
		return CODEC;
	}

	public MultifaceBlock(Settings settings) {
		super(settings);
		this.setDefaultState(withAllDirections(this.stateManager));
		this.field_55780 = this.method_66455();
		this.hasAllHorizontalDirections = Type.HORIZONTAL.stream().allMatch(this::canHaveDirection);
		this.canMirrorX = Type.HORIZONTAL.stream().filter(Axis.X).filter(this::canHaveDirection).count() % 2L == 0L;
		this.canMirrorZ = Type.HORIZONTAL.stream().filter(Axis.Z).filter(this::canHaveDirection).count() % 2L == 0L;
	}

	private Function<BlockState, VoxelShape> method_66455() {
		Map<Direction, VoxelShape> map = VoxelShapes.method_66504(Block.method_66408(16.0, 0.0, 1.0));
		return this.method_66403(arg -> {
			VoxelShape lv = VoxelShapes.empty();

			for (Direction lv2 : DIRECTIONS) {
				if (hasDirection(arg, lv2)) {
					lv = VoxelShapes.union(lv, (VoxelShape)map.get(lv2));
				}
			}

			return lv.isEmpty() ? VoxelShapes.fullCube() : lv;
		}, new Property[]{WATERLOGGED});
	}

	public static Set<Direction> collectDirections(BlockState state) {
		if (!(state.getBlock() instanceof MultifaceBlock)) {
			return Set.of();
		} else {
			Set<Direction> set = EnumSet.noneOf(Direction.class);

			for (Direction lv : Direction.values()) {
				if (hasDirection(state, lv)) {
					set.add(lv);
				}
			}

			return set;
		}
	}

	public static Set<Direction> flagToDirections(byte flag) {
		Set<Direction> set = EnumSet.noneOf(Direction.class);

		for (Direction lv : Direction.values()) {
			if ((flag & (byte)(1 << lv.ordinal())) > 0) {
				set.add(lv);
			}
		}

		return set;
	}

	public static byte directionsToFlag(Collection<Direction> directions) {
		byte b = 0;

		for (Direction lv : directions) {
			b = (byte)(b | 1 << lv.ordinal());
		}

		return b;
	}

	protected boolean canHaveDirection(Direction direction) {
		return true;
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		for (Direction lv : DIRECTIONS) {
			if (this.canHaveDirection(lv)) {
				builder.add(getProperty(lv));
			}
		}

		builder.add(WATERLOGGED);
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		if ((Boolean)state.get(WATERLOGGED)) {
			tickView.scheduleFluidTick(pos, Fluids.WATER, Fluids.WATER.getTickRate(world));
		}

		if (!hasAnyDirection(state)) {
			return Blocks.AIR.getDefaultState();
		} else {
			return hasDirection(state, direction) && !canGrowOn(world, direction, neighborPos, neighborState) ? disableDirection(state, getProperty(direction)) : state;
		}
	}

	@Override
	protected FluidState getFluidState(BlockState state) {
		return state.get(WATERLOGGED) ? Fluids.WATER.getStill(false) : super.getFluidState(state);
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return (VoxelShape)this.field_55780.apply(state);
	}

	@Override
	protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
		boolean bl = false;

		for (Direction lv : DIRECTIONS) {
			if (hasDirection(state, lv)) {
				if (!canGrowOn(world, pos, lv)) {
					return false;
				}

				bl = true;
			}
		}

		return bl;
	}

	@Override
	protected boolean canReplace(BlockState state, ItemPlacementContext context) {
		return !context.getStack().isOf(this.asItem()) || isNotFullBlock(state);
	}

	@Nullable
	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		World lv = ctx.getWorld();
		BlockPos lv2 = ctx.getBlockPos();
		BlockState lv3 = lv.getBlockState(lv2);
		return (BlockState)Arrays.stream(ctx.getPlacementDirections())
			.map(direction -> this.withDirection(lv3, lv, lv2, direction))
			.filter(Objects::nonNull)
			.findFirst()
			.orElse(null);
	}

	public boolean canGrowWithDirection(BlockView world, BlockState state, BlockPos pos, Direction direction) {
		if (this.canHaveDirection(direction) && (!state.isOf(this) || !hasDirection(state, direction))) {
			BlockPos lv = pos.offset(direction);
			return canGrowOn(world, direction, lv, world.getBlockState(lv));
		} else {
			return false;
		}
	}

	@Nullable
	public BlockState withDirection(BlockState state, BlockView world, BlockPos pos, Direction direction) {
		if (!this.canGrowWithDirection(world, state, pos, direction)) {
			return null;
		} else {
			BlockState lv;
			if (state.isOf(this)) {
				lv = state;
			} else if (state.getFluidState().isEqualAndStill(Fluids.WATER)) {
				lv = this.getDefaultState().with(Properties.WATERLOGGED, Boolean.valueOf(true));
			} else {
				lv = this.getDefaultState();
			}

			return lv.with(getProperty(direction), Boolean.valueOf(true));
		}
	}

	@Override
	protected BlockState rotate(BlockState state, BlockRotation rotation) {
		return !this.hasAllHorizontalDirections ? state : this.mirror(state, rotation::rotate);
	}

	@Override
	protected BlockState mirror(BlockState state, BlockMirror mirror) {
		if (mirror == BlockMirror.FRONT_BACK && !this.canMirrorX) {
			return state;
		} else {
			return mirror == BlockMirror.LEFT_RIGHT && !this.canMirrorZ ? state : this.mirror(state, mirror::apply);
		}
	}

	private BlockState mirror(BlockState state, Function<Direction, Direction> mirror) {
		BlockState lv = state;

		for (Direction lv2 : DIRECTIONS) {
			if (this.canHaveDirection(lv2)) {
				lv = lv.with(getProperty((Direction)mirror.apply(lv2)), (Boolean)state.get(getProperty(lv2)));
			}
		}

		return lv;
	}

	public static boolean hasDirection(BlockState state, Direction direction) {
		BooleanProperty lv = getProperty(direction);
		return (Boolean)state.get(lv, Boolean.valueOf(false));
	}

	public static boolean canGrowOn(BlockView world, BlockPos pos, Direction direction) {
		BlockPos lv = pos.offset(direction);
		BlockState lv2 = world.getBlockState(lv);
		return canGrowOn(world, direction, lv, lv2);
	}

	public static boolean canGrowOn(BlockView world, Direction direction, BlockPos pos, BlockState state) {
		return Block.isFaceFullSquare(state.getSidesShape(world, pos), direction.getOpposite())
			|| Block.isFaceFullSquare(state.getCollisionShape(world, pos), direction.getOpposite());
	}

	private static BlockState disableDirection(BlockState state, BooleanProperty direction) {
		BlockState lv = state.with(direction, Boolean.valueOf(false));
		return hasAnyDirection(lv) ? lv : Blocks.AIR.getDefaultState();
	}

	public static BooleanProperty getProperty(Direction direction) {
		return (BooleanProperty)FACING_PROPERTIES.get(direction);
	}

	private static BlockState withAllDirections(StateManager<Block, BlockState> stateManager) {
		BlockState lv = stateManager.getDefaultState().with(WATERLOGGED, Boolean.valueOf(false));

		for (BooleanProperty lv2 : FACING_PROPERTIES.values()) {
			lv = lv.withIfExists(lv2, Boolean.valueOf(false));
		}

		return lv;
	}

	protected static boolean hasAnyDirection(BlockState state) {
		for (Direction lv : DIRECTIONS) {
			if (hasDirection(state, lv)) {
				return true;
			}
		}

		return false;
	}

	private static boolean isNotFullBlock(BlockState state) {
		for (Direction lv : DIRECTIONS) {
			if (!hasDirection(state, lv)) {
				return true;
			}
		}

		return false;
	}
}
