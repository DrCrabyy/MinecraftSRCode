package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.enums.SlabType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.minecraft.world.tick.ScheduledTickView;

public class SlabBlock extends Block implements Waterloggable {
	public static final MapCodec<SlabBlock> CODEC = createCodec(SlabBlock::new);
	public static final EnumProperty<SlabType> TYPE = Properties.SLAB_TYPE;
	public static final BooleanProperty WATERLOGGED = Properties.WATERLOGGED;
	private static final VoxelShape BOTTOM_SHAPE = Block.method_66404(16.0, 0.0, 8.0);
	private static final VoxelShape TOP_SHAPE = Block.method_66404(16.0, 8.0, 16.0);

	@Override
	public MapCodec<? extends SlabBlock> getCodec() {
		return CODEC;
	}

	public SlabBlock(Settings settings) {
		super(settings);
		this.setDefaultState(this.getDefaultState().with(TYPE, SlabType.BOTTOM).with(WATERLOGGED, Boolean.valueOf(false)));
	}

	@Override
	protected boolean hasSidedTransparency(BlockState state) {
		return state.get(TYPE) != SlabType.DOUBLE;
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(TYPE, WATERLOGGED);
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return switch ((SlabType)state.get(TYPE)) {
			case TOP -> TOP_SHAPE;
			case BOTTOM -> BOTTOM_SHAPE;
			case DOUBLE -> VoxelShapes.fullCube();
			default -> throw new MatchException(null, null);
		};
	}

	@Nullable
	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		BlockPos lv = ctx.getBlockPos();
		BlockState lv2 = ctx.getWorld().getBlockState(lv);
		if (lv2.isOf(this)) {
			return lv2.with(TYPE, SlabType.DOUBLE).with(WATERLOGGED, Boolean.valueOf(false));
		} else {
			FluidState lv3 = ctx.getWorld().getFluidState(lv);
			BlockState lv4 = this.getDefaultState().with(TYPE, SlabType.BOTTOM).with(WATERLOGGED, Boolean.valueOf(lv3.getFluid() == Fluids.WATER));
			Direction lv5 = ctx.getSide();
			return lv5 != Direction.DOWN && (lv5 == Direction.UP || !(ctx.getHitPos().y - (double)lv.getY() > 0.5)) ? lv4 : lv4.with(TYPE, SlabType.TOP);
		}
	}

	@Override
	protected boolean canReplace(BlockState state, ItemPlacementContext context) {
		// $VF: Couldn't be decompiled
		// Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
		//
		// Bytecode:
		// 00: aload 2
		// 01: invokevirtual net/minecraft/item/ItemPlacementContext.getStack ()Lnet/minecraft/item/ItemStack;
		// 04: astore 3
		// 05: aload 1
		// 06: getstatic net/minecraft/block/SlabBlock.TYPE Lnet/minecraft/state/property/EnumProperty;
		// 09: invokevirtual net/minecraft/block/BlockState.get (Lnet/minecraft/state/property/Property;)Ljava/lang/Comparable;
		// 0c: checkcast net/minecraft/block/enums/SlabType
		// 0f: astore 4
		// 11: aload 4
		// 13: getstatic net/minecraft/block/enums/SlabType.DOUBLE Lnet/minecraft/block/enums/SlabType;
		// 16: if_acmpeq 24
		// 19: aload 3
		// 1a: aload 0
		// 1b: invokevirtual net/minecraft/block/SlabBlock.asItem ()Lnet/minecraft/item/Item;
		// 1e: invokevirtual net/minecraft/item/ItemStack.isOf (Lnet/minecraft/item/Item;)Z
		// 21: ifne 26
		// 24: bipush 0
		// 25: ireturn
		// 26: aload 2
		// 27: invokevirtual net/minecraft/item/ItemPlacementContext.canReplaceExisting ()Z
		// 2a: ifeq 95
		// 2d: aload 2
		// 2e: invokevirtual net/minecraft/item/ItemPlacementContext.getHitPos ()Lnet/minecraft/util/math/Vec3d;
		// 31: getfield net/minecraft/util/math/Vec3d.y D
		// 34: aload 2
		// 35: invokevirtual net/minecraft/item/ItemPlacementContext.getBlockPos ()Lnet/minecraft/util/math/BlockPos;
		// 38: invokevirtual net/minecraft/util/math/BlockPos.getY ()I
		// 3b: i2d
		// 3c: dsub
		// 3d: ldc2_w 0.5
		// 40: dcmpl
		// 41: ifle 48
		// 44: bipush 1
		// 45: goto 49
		// 48: bipush 0
		// 49: istore 5
		// 4b: aload 2
		// 4c: invokevirtual net/minecraft/item/ItemPlacementContext.getSide ()Lnet/minecraft/util/math/Direction;
		// 4f: astore 6
		// 51: aload 4
		// 53: getstatic net/minecraft/block/enums/SlabType.BOTTOM Lnet/minecraft/block/enums/SlabType;
		// 56: if_acmpne 77
		// 59: aload 6
		// 5b: getstatic net/minecraft/util/math/Direction.UP Lnet/minecraft/util/math/Direction;
		// 5e: if_acmpeq 71
		// 61: iload 5
		// 63: ifeq 75
		// 66: aload 6
		// 68: invokevirtual net/minecraft/util/math/Direction.getAxis ()Lnet/minecraft/util/math/Direction$Axis;
		// 6b: invokevirtual net/minecraft/util/math/Direction$Axis.isHorizontal ()Z
		// 6e: ifeq 75
		// 71: bipush 1
		// 72: goto 76
		// 75: bipush 0
		// 76: ireturn
		// 77: aload 6
		// 79: getstatic net/minecraft/util/math/Direction.DOWN Lnet/minecraft/util/math/Direction;
		// 7c: if_acmpeq 8f
		// 7f: iload 5
		// 81: ifne 93
		// 84: aload 6
		// 86: invokevirtual net/minecraft/util/math/Direction.getAxis ()Lnet/minecraft/util/math/Direction$Axis;
		// 89: invokevirtual net/minecraft/util/math/Direction$Axis.isHorizontal ()Z
		// 8c: ifeq 93
		// 8f: bipush 1
		// 90: goto 94
		// 93: bipush 0
		// 94: ireturn
		// 95: bipush 1
		// 96: ireturn
	}

	@Override
	protected FluidState getFluidState(BlockState state) {
		return state.get(WATERLOGGED) ? Fluids.WATER.getStill(false) : super.getFluidState(state);
	}

	@Override
	public boolean tryFillWithFluid(WorldAccess world, BlockPos pos, BlockState state, FluidState fluidState) {
		return state.get(TYPE) != SlabType.DOUBLE ? Waterloggable.super.tryFillWithFluid(world, pos, state, fluidState) : false;
	}

	@Override
	public boolean canFillWithFluid(@Nullable LivingEntity filler, BlockView world, BlockPos pos, BlockState state, Fluid fluid) {
		return state.get(TYPE) != SlabType.DOUBLE ? Waterloggable.super.canFillWithFluid(filler, world, pos, state, fluid) : false;
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		if ((Boolean)state.get(WATERLOGGED)) {
			tickView.scheduleFluidTick(pos, Fluids.WATER, Fluids.WATER.getTickRate(world));
		}

		return super.getStateForNeighborUpdate(state, world, tickView, pos, direction, neighborPos, neighborState, random);
	}

	@Override
	protected boolean canPathfindThrough(BlockState state, NavigationType type) {
		switch (type) {
			case LAND:
				return false;
			case WATER:
				return state.getFluidState().isIn(FluidTags.WATER);
			case AIR:
				return false;
			default:
				return false;
		}
	}
}
