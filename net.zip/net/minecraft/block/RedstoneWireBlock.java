package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.mojang.serialization.MapCodec;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.enums.WireConnection;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.resource.featuretoggle.FeatureFlags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Util;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Direction.Type;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.DefaultRedstoneController;
import net.minecraft.world.ExperimentalRedstoneController;
import net.minecraft.world.RedstoneController;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.minecraft.world.block.OrientationHelper;
import net.minecraft.world.block.WireOrientation;
import net.minecraft.world.tick.ScheduledTickView;

public class RedstoneWireBlock extends Block {
	public static final MapCodec<RedstoneWireBlock> CODEC = createCodec(RedstoneWireBlock::new);
	public static final EnumProperty<WireConnection> WIRE_CONNECTION_NORTH = Properties.NORTH_WIRE_CONNECTION;
	public static final EnumProperty<WireConnection> WIRE_CONNECTION_EAST = Properties.EAST_WIRE_CONNECTION;
	public static final EnumProperty<WireConnection> WIRE_CONNECTION_SOUTH = Properties.SOUTH_WIRE_CONNECTION;
	public static final EnumProperty<WireConnection> WIRE_CONNECTION_WEST = Properties.WEST_WIRE_CONNECTION;
	public static final IntProperty POWER = Properties.POWER;
	public static final Map<Direction, EnumProperty<WireConnection>> DIRECTION_TO_WIRE_CONNECTION_PROPERTY = ImmutableMap.copyOf(
		Maps.newEnumMap(
			Map.of(
				Direction.NORTH, WIRE_CONNECTION_NORTH, Direction.EAST, WIRE_CONNECTION_EAST, Direction.SOUTH, WIRE_CONNECTION_SOUTH, Direction.WEST, WIRE_CONNECTION_WEST
			)
		)
	);
	private static final int[] COLORS = Util.make(new int[16], colors -> {
		for (int i = 0; i <= 15; i++) {
			float f = (float)i / 15.0F;
			float g = f * 0.6F + (f > 0.0F ? 0.4F : 0.3F);
			float h = MathHelper.clamp(f * f * 0.7F - 0.5F, 0.0F, 1.0F);
			float j = MathHelper.clamp(f * f * 0.6F - 0.7F, 0.0F, 1.0F);
			colors[i] = ColorHelper.fromFloats(1.0F, g, h, j);
		}
	});
	private static final float field_31221 = 0.2F;
	private final Function<BlockState, VoxelShape> field_55787;
	private final BlockState dotState;
	private final RedstoneController redstoneController = new DefaultRedstoneController(this);
	private boolean wiresGivePower = true;

	@Override
	public MapCodec<RedstoneWireBlock> getCodec() {
		return CODEC;
	}

	public RedstoneWireBlock(Settings settings) {
		super(settings);
		this.setDefaultState(
			this.stateManager
				.getDefaultState()
				.with(WIRE_CONNECTION_NORTH, WireConnection.NONE)
				.with(WIRE_CONNECTION_EAST, WireConnection.NONE)
				.with(WIRE_CONNECTION_SOUTH, WireConnection.NONE)
				.with(WIRE_CONNECTION_WEST, WireConnection.NONE)
				.with(POWER, Integer.valueOf(0))
		);
		this.field_55787 = this.method_66462();
		this.dotState = this.getDefaultState()
			.with(WIRE_CONNECTION_NORTH, WireConnection.SIDE)
			.with(WIRE_CONNECTION_EAST, WireConnection.SIDE)
			.with(WIRE_CONNECTION_SOUTH, WireConnection.SIDE)
			.with(WIRE_CONNECTION_WEST, WireConnection.SIDE);
	}

	private Function<BlockState, VoxelShape> method_66462() {
		int i = 1;
		int j = 10;
		VoxelShape lv = Block.method_66404(10.0, 0.0, 1.0);
		Map<Direction, VoxelShape> map = VoxelShapes.method_66501(Block.method_66396(10.0, 0.0, 1.0, 0.0, 8.0));
		Map<Direction, VoxelShape> map2 = VoxelShapes.method_66501(Block.method_66405(10.0, 16.0, 0.0, 1.0));
		return this.method_66403(arg2 -> {
			VoxelShape lvx = lv;

			for (Entry<Direction, EnumProperty<WireConnection>> entry : DIRECTION_TO_WIRE_CONNECTION_PROPERTY.entrySet()) {
				lvx = switch ((WireConnection)arg2.get((Property)entry.getValue())) {
					case UP -> VoxelShapes.union(lvx, (VoxelShape)map.get(entry.getKey()), (VoxelShape)map2.get(entry.getKey()));
					case SIDE -> VoxelShapes.union(lvx, (VoxelShape)map.get(entry.getKey()));
					case NONE -> lvx;
					default -> throw new MatchException(null, null);
				};
			}

			return lvx;
		}, new Property[]{POWER});
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return (VoxelShape)this.field_55787.apply(state);
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		return this.getPlacementState(ctx.getWorld(), this.dotState, ctx.getBlockPos());
	}

	private BlockState getPlacementState(BlockView world, BlockState state, BlockPos pos) {
		boolean bl = isNotConnected(state);
		state = this.getDefaultWireState(world, this.getDefaultState().with(POWER, (Integer)state.get(POWER)), pos);
		if (bl && isNotConnected(state)) {
			return state;
		} else {
			boolean bl2 = ((WireConnection)state.get(WIRE_CONNECTION_NORTH)).isConnected();
			boolean bl3 = ((WireConnection)state.get(WIRE_CONNECTION_SOUTH)).isConnected();
			boolean bl4 = ((WireConnection)state.get(WIRE_CONNECTION_EAST)).isConnected();
			boolean bl5 = ((WireConnection)state.get(WIRE_CONNECTION_WEST)).isConnected();
			boolean bl6 = !bl2 && !bl3;
			boolean bl7 = !bl4 && !bl5;
			if (!bl5 && bl6) {
				state = state.with(WIRE_CONNECTION_WEST, WireConnection.SIDE);
			}

			if (!bl4 && bl6) {
				state = state.with(WIRE_CONNECTION_EAST, WireConnection.SIDE);
			}

			if (!bl2 && bl7) {
				state = state.with(WIRE_CONNECTION_NORTH, WireConnection.SIDE);
			}

			if (!bl3 && bl7) {
				state = state.with(WIRE_CONNECTION_SOUTH, WireConnection.SIDE);
			}

			return state;
		}
	}

	private BlockState getDefaultWireState(BlockView world, BlockState state, BlockPos pos) {
		boolean bl = !world.getBlockState(pos.up()).isSolidBlock(world, pos);

		for (Direction lv : Type.HORIZONTAL) {
			if (!((WireConnection)state.get((Property)DIRECTION_TO_WIRE_CONNECTION_PROPERTY.get(lv))).isConnected()) {
				WireConnection lv2 = this.getRenderConnectionType(world, pos, lv, bl);
				state = state.with((Property)DIRECTION_TO_WIRE_CONNECTION_PROPERTY.get(lv), lv2);
			}
		}

		return state;
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		if (direction == Direction.DOWN) {
			return !this.canRunOnTop(world, neighborPos, neighborState) ? Blocks.AIR.getDefaultState() : state;
		} else if (direction == Direction.UP) {
			return this.getPlacementState(world, state, pos);
		} else {
			WireConnection lv = this.getRenderConnectionType(world, pos, direction);
			return lv.isConnected() == ((WireConnection)state.get((Property)DIRECTION_TO_WIRE_CONNECTION_PROPERTY.get(direction))).isConnected()
					&& !isFullyConnected(state)
				? state.with((Property)DIRECTION_TO_WIRE_CONNECTION_PROPERTY.get(direction), lv)
				: this.getPlacementState(
					world, this.dotState.with(POWER, (Integer)state.get(POWER)).with((Property)DIRECTION_TO_WIRE_CONNECTION_PROPERTY.get(direction), lv), pos
				);
		}
	}

	private static boolean isFullyConnected(BlockState state) {
		return ((WireConnection)state.get(WIRE_CONNECTION_NORTH)).isConnected()
			&& ((WireConnection)state.get(WIRE_CONNECTION_SOUTH)).isConnected()
			&& ((WireConnection)state.get(WIRE_CONNECTION_EAST)).isConnected()
			&& ((WireConnection)state.get(WIRE_CONNECTION_WEST)).isConnected();
	}

	private static boolean isNotConnected(BlockState state) {
		return !((WireConnection)state.get(WIRE_CONNECTION_NORTH)).isConnected()
			&& !((WireConnection)state.get(WIRE_CONNECTION_SOUTH)).isConnected()
			&& !((WireConnection)state.get(WIRE_CONNECTION_EAST)).isConnected()
			&& !((WireConnection)state.get(WIRE_CONNECTION_WEST)).isConnected();
	}

	@Override
	protected void prepare(BlockState state, WorldAccess world, BlockPos pos, int flags, int maxUpdateDepth) {
		Mutable lv = new Mutable();

		for (Direction lv2 : Type.HORIZONTAL) {
			WireConnection lv3 = state.get((Property<WireConnection>)DIRECTION_TO_WIRE_CONNECTION_PROPERTY.get(lv2));
			if (lv3 != WireConnection.NONE && !world.getBlockState(lv.set(pos, lv2)).isOf(this)) {
				lv.move(Direction.DOWN);
				BlockState lv4 = world.getBlockState(lv);
				if (lv4.isOf(this)) {
					BlockPos lv5 = lv.offset(lv2.getOpposite());
					world.replaceWithStateForNeighborUpdate(lv2.getOpposite(), lv, lv5, world.getBlockState(lv5), flags, maxUpdateDepth);
				}

				lv.set(pos, lv2).move(Direction.UP);
				BlockState lv6 = world.getBlockState(lv);
				if (lv6.isOf(this)) {
					BlockPos lv7 = lv.offset(lv2.getOpposite());
					world.replaceWithStateForNeighborUpdate(lv2.getOpposite(), lv, lv7, world.getBlockState(lv7), flags, maxUpdateDepth);
				}
			}
		}
	}

	private WireConnection getRenderConnectionType(BlockView world, BlockPos pos, Direction direction) {
		return this.getRenderConnectionType(world, pos, direction, !world.getBlockState(pos.up()).isSolidBlock(world, pos));
	}

	private WireConnection getRenderConnectionType(BlockView world, BlockPos pos, Direction direction, boolean bl) {
		BlockPos lv = pos.offset(direction);
		BlockState lv2 = world.getBlockState(lv);
		if (bl) {
			boolean bl2 = lv2.getBlock() instanceof TrapdoorBlock || this.canRunOnTop(world, lv, lv2);
			if (bl2 && connectsTo(world.getBlockState(lv.up()))) {
				if (lv2.isSideSolidFullSquare(world, lv, direction.getOpposite())) {
					return WireConnection.UP;
				}

				return WireConnection.SIDE;
			}
		}

		return !connectsTo(lv2, direction) && (lv2.isSolidBlock(world, lv) || !connectsTo(world.getBlockState(lv.down())))
			? WireConnection.NONE
			: WireConnection.SIDE;
	}

	@Override
	protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
		BlockPos lv = pos.down();
		BlockState lv2 = world.getBlockState(lv);
		return this.canRunOnTop(world, lv, lv2);
	}

	private boolean canRunOnTop(BlockView world, BlockPos pos, BlockState floor) {
		return floor.isSideSolidFullSquare(world, pos, Direction.UP) || floor.isOf(Blocks.HOPPER);
	}

	private void update(World world, BlockPos pos, BlockState state, @Nullable WireOrientation orientation, boolean blockAdded) {
		if (areRedstoneExperimentsEnabled(world)) {
			new ExperimentalRedstoneController(this).update(world, pos, state, orientation, blockAdded);
		} else {
			this.redstoneController.update(world, pos, state, orientation, blockAdded);
		}
	}

	public int getStrongPower(World world, BlockPos pos) {
		this.wiresGivePower = false;
		int i = world.getReceivedRedstonePower(pos);
		this.wiresGivePower = true;
		return i;
	}

	private void updateNeighbors(World world, BlockPos pos) {
		if (world.getBlockState(pos).isOf(this)) {
			world.updateNeighbors(pos, this);

			for (Direction lv : Direction.values()) {
				world.updateNeighbors(pos.offset(lv), this);
			}
		}
	}

	@Override
	protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
		if (!oldState.isOf(state.getBlock()) && !world.isClient) {
			this.update(world, pos, state, null, true);

			for (Direction lv : Type.VERTICAL) {
				world.updateNeighbors(pos.offset(lv), this);
			}

			this.updateOffsetNeighbors(world, pos);
		}
	}

	@Override
	protected void onStateReplaced(BlockState state, ServerWorld world, BlockPos pos, boolean moved) {
		if (!moved) {
			for (Direction lv : Direction.values()) {
				world.updateNeighbors(pos.offset(lv), this);
			}

			this.update(world, pos, state, null, false);
			this.updateOffsetNeighbors(world, pos);
		}
	}

	private void updateOffsetNeighbors(World world, BlockPos pos) {
		for (Direction lv : Type.HORIZONTAL) {
			this.updateNeighbors(world, pos.offset(lv));
		}

		for (Direction lv : Type.HORIZONTAL) {
			BlockPos lv2 = pos.offset(lv);
			if (world.getBlockState(lv2).isSolidBlock(world, lv2)) {
				this.updateNeighbors(world, lv2.up());
			} else {
				this.updateNeighbors(world, lv2.down());
			}
		}
	}

	@Override
	protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock, @Nullable WireOrientation wireOrientation, boolean notify) {
		if (!world.isClient) {
			if (sourceBlock != this || !areRedstoneExperimentsEnabled(world)) {
				if (state.canPlaceAt(world, pos)) {
					this.update(world, pos, state, wireOrientation, false);
				} else {
					dropStacks(state, world, pos);
					world.removeBlock(pos, false);
				}
			}
		}
	}

	private static boolean areRedstoneExperimentsEnabled(World world) {
		return world.getEnabledFeatures().contains(FeatureFlags.REDSTONE_EXPERIMENTS);
	}

	@Override
	protected int getStrongRedstonePower(BlockState state, BlockView world, BlockPos pos, Direction direction) {
		return !this.wiresGivePower ? 0 : state.getWeakRedstonePower(world, pos, direction);
	}

	@Override
	protected int getWeakRedstonePower(BlockState state, BlockView world, BlockPos pos, Direction direction) {
		if (this.wiresGivePower && direction != Direction.DOWN) {
			int i = (Integer)state.get(POWER);
			if (i == 0) {
				return 0;
			} else {
				return direction != Direction.UP
						&& !((WireConnection)this.getPlacementState(world, state, pos).get((Property)DIRECTION_TO_WIRE_CONNECTION_PROPERTY.get(direction.getOpposite())))
							.isConnected()
					? 0
					: i;
			}
		} else {
			return 0;
		}
	}

	protected static boolean connectsTo(BlockState state) {
		return connectsTo(state, null);
	}

	protected static boolean connectsTo(BlockState state, @Nullable Direction dir) {
		if (state.isOf(Blocks.REDSTONE_WIRE)) {
			return true;
		} else if (state.isOf(Blocks.REPEATER)) {
			Direction lv = state.get(RepeaterBlock.FACING);
			return lv == dir || lv.getOpposite() == dir;
		} else {
			return state.isOf(Blocks.OBSERVER) ? dir == state.get(ObserverBlock.FACING) : state.emitsRedstonePower() && dir != null;
		}
	}

	@Override
	protected boolean emitsRedstonePower(BlockState state) {
		return this.wiresGivePower;
	}

	public static int getWireColor(int powerLevel) {
		return COLORS[powerLevel];
	}

	private static void addPoweredParticles(
		World world, Random random, BlockPos pos, int color, Direction perpendicular, Direction direction, float minOffset, float maxOffset
	) {
		float h = maxOffset - minOffset;
		if (!(random.nextFloat() >= 0.2F * h)) {
			float j = 0.4375F;
			float k = minOffset + h * random.nextFloat();
			double d = 0.5 + (double)(0.4375F * (float)perpendicular.getOffsetX()) + (double)(k * (float)direction.getOffsetX());
			double e = 0.5 + (double)(0.4375F * (float)perpendicular.getOffsetY()) + (double)(k * (float)direction.getOffsetY());
			double l = 0.5 + (double)(0.4375F * (float)perpendicular.getOffsetZ()) + (double)(k * (float)direction.getOffsetZ());
			world.addParticleClient(new DustParticleEffect(color, 1.0F), (double)pos.getX() + d, (double)pos.getY() + e, (double)pos.getZ() + l, 0.0, 0.0, 0.0);
		}
	}

	@Override
	public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
		int i = (Integer)state.get(POWER);
		if (i != 0) {
			for (Direction lv : Type.HORIZONTAL) {
				WireConnection lv2 = state.get((Property<WireConnection>)DIRECTION_TO_WIRE_CONNECTION_PROPERTY.get(lv));
				switch (lv2) {
					case UP:
						addPoweredParticles(world, random, pos, COLORS[i], lv, Direction.UP, -0.5F, 0.5F);
					case SIDE:
						addPoweredParticles(world, random, pos, COLORS[i], Direction.DOWN, lv, 0.0F, 0.5F);
						break;
					case NONE:
					default:
						addPoweredParticles(world, random, pos, COLORS[i], Direction.DOWN, lv, 0.0F, 0.3F);
				}
			}
		}
	}

	@Override
	protected BlockState rotate(BlockState state, BlockRotation rotation) {
		switch (rotation) {
			case CLOCKWISE_180:
				return state.with(WIRE_CONNECTION_NORTH, (WireConnection)state.get(WIRE_CONNECTION_SOUTH))
					.with(WIRE_CONNECTION_EAST, (WireConnection)state.get(WIRE_CONNECTION_WEST))
					.with(WIRE_CONNECTION_SOUTH, (WireConnection)state.get(WIRE_CONNECTION_NORTH))
					.with(WIRE_CONNECTION_WEST, (WireConnection)state.get(WIRE_CONNECTION_EAST));
			case COUNTERCLOCKWISE_90:
				return state.with(WIRE_CONNECTION_NORTH, (WireConnection)state.get(WIRE_CONNECTION_EAST))
					.with(WIRE_CONNECTION_EAST, (WireConnection)state.get(WIRE_CONNECTION_SOUTH))
					.with(WIRE_CONNECTION_SOUTH, (WireConnection)state.get(WIRE_CONNECTION_WEST))
					.with(WIRE_CONNECTION_WEST, (WireConnection)state.get(WIRE_CONNECTION_NORTH));
			case CLOCKWISE_90:
				return state.with(WIRE_CONNECTION_NORTH, (WireConnection)state.get(WIRE_CONNECTION_WEST))
					.with(WIRE_CONNECTION_EAST, (WireConnection)state.get(WIRE_CONNECTION_NORTH))
					.with(WIRE_CONNECTION_SOUTH, (WireConnection)state.get(WIRE_CONNECTION_EAST))
					.with(WIRE_CONNECTION_WEST, (WireConnection)state.get(WIRE_CONNECTION_SOUTH));
			default:
				return state;
		}
	}

	@Override
	protected BlockState mirror(BlockState state, BlockMirror mirror) {
		switch (mirror) {
			case LEFT_RIGHT:
				return state.with(WIRE_CONNECTION_NORTH, (WireConnection)state.get(WIRE_CONNECTION_SOUTH))
					.with(WIRE_CONNECTION_SOUTH, (WireConnection)state.get(WIRE_CONNECTION_NORTH));
			case FRONT_BACK:
				return state.with(WIRE_CONNECTION_EAST, (WireConnection)state.get(WIRE_CONNECTION_WEST))
					.with(WIRE_CONNECTION_WEST, (WireConnection)state.get(WIRE_CONNECTION_EAST));
			default:
				return super.mirror(state, mirror);
		}
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(WIRE_CONNECTION_NORTH, WIRE_CONNECTION_EAST, WIRE_CONNECTION_SOUTH, WIRE_CONNECTION_WEST, POWER);
	}

	@Override
	protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
		if (!player.getAbilities().allowModifyWorld) {
			return ActionResult.PASS;
		} else {
			if (isFullyConnected(state) || isNotConnected(state)) {
				BlockState lv = isFullyConnected(state) ? this.getDefaultState() : this.dotState;
				lv = lv.with(POWER, (Integer)state.get(POWER));
				lv = this.getPlacementState(world, lv, pos);
				if (lv != state) {
					world.setBlockState(pos, lv, 3);
					this.updateForNewState(world, pos, state, lv);
					return ActionResult.SUCCESS;
				}
			}

			return ActionResult.PASS;
		}
	}

	private void updateForNewState(World world, BlockPos pos, BlockState oldState, BlockState newState) {
		WireOrientation lv = OrientationHelper.getEmissionOrientation(world, null, Direction.UP);

		for (Direction lv2 : Type.HORIZONTAL) {
			BlockPos lv3 = pos.offset(lv2);
			if (((WireConnection)oldState.get((Property)DIRECTION_TO_WIRE_CONNECTION_PROPERTY.get(lv2))).isConnected()
					!= ((WireConnection)newState.get((Property)DIRECTION_TO_WIRE_CONNECTION_PROPERTY.get(lv2))).isConnected()
				&& world.getBlockState(lv3).isSolidBlock(world, lv3)) {
				world.updateNeighborsExcept(lv3, newState.getBlock(), lv2.getOpposite(), OrientationHelper.withFrontNullable(lv, lv2));
			}
		}
	}
}
