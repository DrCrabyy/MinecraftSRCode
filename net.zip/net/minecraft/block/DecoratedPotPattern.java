package net.minecraft.block;

import net.minecraft.util.Identifier;

public record DecoratedPotPattern(Identifier assetId) {
}
