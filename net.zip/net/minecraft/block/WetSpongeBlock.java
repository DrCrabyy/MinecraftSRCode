package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

public class WetSpongeBlock extends Block {
	public static final MapCodec<WetSpongeBlock> CODEC = createCodec(WetSpongeBlock::new);

	@Override
	public MapCodec<WetSpongeBlock> getCodec() {
		return CODEC;
	}

	protected WetSpongeBlock(Settings settings) {
		super(settings);
	}

	@Override
	protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
		if (world.getDimension().ultrawarm()) {
			world.setBlockState(pos, Blocks.SPONGE.getDefaultState(), 3);
			world.syncWorldEvent(2009, pos, 0);
			world.playSound(null, pos, SoundEvents.BLOCK_WET_SPONGE_DRIES, SoundCategory.BLOCKS, 1.0F, (1.0F + world.getRandom().nextFloat() * 0.2F) * 0.7F);
		}
	}

	@Override
	public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
		Direction lv = Direction.random(random);
		if (lv != Direction.UP) {
			BlockPos lv2 = pos.offset(lv);
			BlockState lv3 = world.getBlockState(lv2);
			if (!state.isOpaque() || !lv3.isSideSolidFullSquare(world, lv2, lv.getOpposite())) {
				double d = (double)pos.getX();
				double e = (double)pos.getY();
				double f = (double)pos.getZ();
				if (lv == Direction.DOWN) {
					e -= 0.05;
					d += random.nextDouble();
					f += random.nextDouble();
				} else {
					e += random.nextDouble() * 0.8;
					if (lv.getAxis() == Axis.X) {
						f += random.nextDouble();
						if (lv == Direction.EAST) {
							d++;
						} else {
							d += 0.05;
						}
					} else {
						d += random.nextDouble();
						if (lv == Direction.SOUTH) {
							f++;
						} else {
							f += 0.05;
						}
					}
				}

				world.addParticleClient(ParticleTypes.DRIPPING_WATER, d, e, f, 0.0, 0.0, 0.0);
			}
		}
	}
}
