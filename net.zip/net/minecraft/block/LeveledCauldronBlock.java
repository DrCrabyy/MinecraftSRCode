package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.cauldron.CauldronBehavior;
import net.minecraft.block.cauldron.CauldronBehavior.CauldronBehaviorMap;
import net.minecraft.entity.Entity;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.Fluids;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome.Precipitation;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.event.GameEvent.Emitter;

public class LeveledCauldronBlock extends AbstractCauldronBlock {
	public static final MapCodec<LeveledCauldronBlock> CODEC = RecordCodecBuilder.mapCodec(
		instance -> instance.group(
					Precipitation.CODEC.fieldOf("precipitation").forGetter(block -> block.precipitation),
					CauldronBehavior.CODEC.fieldOf("interactions").forGetter(block -> block.behaviorMap),
					createSettingsCodec()
				)
				.apply(instance, LeveledCauldronBlock::new)
	);
	public static final int MIN_LEVEL = 1;
	public static final int MAX_LEVEL = 3;
	public static final IntProperty LEVEL = Properties.LEVEL_3;
	private static final int BASE_FLUID_HEIGHT = 6;
	private static final double FLUID_HEIGHT_PER_LEVEL = 3.0;
	private final Precipitation precipitation;

	@Override
	public MapCodec<LeveledCauldronBlock> getCodec() {
		return CODEC;
	}

	public LeveledCauldronBlock(Precipitation precipitation, CauldronBehaviorMap behaviorMap, Settings settings) {
		super(settings, behaviorMap);
		this.precipitation = precipitation;
		this.setDefaultState(this.stateManager.getDefaultState().with(LEVEL, Integer.valueOf(1)));
	}

	@Override
	public boolean isFull(BlockState state) {
		return (Integer)state.get(LEVEL) == 3;
	}

	@Override
	protected boolean canBeFilledByDripstone(Fluid fluid) {
		return fluid == Fluids.WATER && this.precipitation == Precipitation.RAIN;
	}

	@Override
	protected double getFluidHeight(BlockState state) {
		return (6.0 + (double)((Integer)state.get(LEVEL)).intValue() * 3.0) / 16.0;
	}

	@Override
	protected void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
		if (world instanceof ServerWorld lv && entity.isOnFire() && this.isEntityTouchingFluid(state, pos, entity)) {
			entity.extinguish();
			if (entity.canModifyAt(lv, pos)) {
				this.onFireCollision(state, world, pos);
			}
		}
	}

	private void onFireCollision(BlockState state, World world, BlockPos pos) {
		if (this.precipitation == Precipitation.SNOW) {
			decrementFluidLevel(Blocks.WATER_CAULDRON.getDefaultState().with(LEVEL, (Integer)state.get(LEVEL)), world, pos);
		} else {
			decrementFluidLevel(state, world, pos);
		}
	}

	public static void decrementFluidLevel(BlockState state, World world, BlockPos pos) {
		int i = (Integer)state.get(LEVEL) - 1;
		BlockState lv = i == 0 ? Blocks.CAULDRON.getDefaultState() : state.with(LEVEL, Integer.valueOf(i));
		world.setBlockState(pos, lv);
		world.emitGameEvent(GameEvent.BLOCK_CHANGE, pos, Emitter.of(lv));
	}

	@Override
	public void precipitationTick(BlockState state, World world, BlockPos pos, Precipitation precipitation) {
		if (CauldronBlock.canFillWithPrecipitation(world, precipitation) && (Integer)state.get(LEVEL) != 3 && precipitation == this.precipitation) {
			BlockState lv = state.cycle(LEVEL);
			world.setBlockState(pos, lv);
			world.emitGameEvent(GameEvent.BLOCK_CHANGE, pos, Emitter.of(lv));
		}
	}

	@Override
	protected int getComparatorOutput(BlockState state, World world, BlockPos pos) {
		return (Integer)state.get(LEVEL);
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(LEVEL);
	}

	@Override
	protected void fillFromDripstone(BlockState state, World world, BlockPos pos, Fluid fluid) {
		if (!this.isFull(state)) {
			BlockState lv = state.with(LEVEL, Integer.valueOf((Integer)state.get(LEVEL) + 1));
			world.setBlockState(pos, lv);
			world.emitGameEvent(GameEvent.BLOCK_CHANGE, pos, Emitter.of(lv));
			world.syncWorldEvent(1047, pos, 0);
		}
	}
}
