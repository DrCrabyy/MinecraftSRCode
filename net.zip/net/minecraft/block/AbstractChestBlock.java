package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import java.util.function.Supplier;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.DoubleBlockProperties.PropertySource;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public abstract class AbstractChestBlock<E extends BlockEntity> extends BlockWithEntity {
	protected final Supplier<BlockEntityType<? extends E>> entityTypeRetriever;

	protected AbstractChestBlock(Settings settings, Supplier<BlockEntityType<? extends E>> entityTypeRetriever) {
		super(settings);
		this.entityTypeRetriever = entityTypeRetriever;
	}

	@Override
	protected abstract MapCodec<? extends AbstractChestBlock<E>> getCodec();

	public abstract PropertySource<? extends ChestBlockEntity> getBlockEntitySource(BlockState state, World world, BlockPos pos, boolean ignoreBlocked);
}
