package net.minecraft.block.enums;

public enum CameraSubmersionType {
	LAVA,
	WATER,
	POWDER_SNOW,
	NONE;
}
