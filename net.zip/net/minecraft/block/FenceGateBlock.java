package net.minecraft.block;

import com.google.common.collect.Maps;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Map;
import java.util.function.BiConsumer;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Util;
import net.minecraft.util.function.BooleanBiFunction;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.minecraft.world.block.WireOrientation;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.event.GameEvent.Emitter;
import net.minecraft.world.explosion.Explosion;
import net.minecraft.world.tick.ScheduledTickView;

public class FenceGateBlock extends HorizontalFacingBlock {
	public static final MapCodec<FenceGateBlock> CODEC = RecordCodecBuilder.mapCodec(
		instance -> instance.group(WoodType.CODEC.fieldOf("wood_type").forGetter(block -> block.type), createSettingsCodec()).apply(instance, FenceGateBlock::new)
	);
	public static final BooleanProperty OPEN = Properties.OPEN;
	public static final BooleanProperty POWERED = Properties.POWERED;
	public static final BooleanProperty IN_WALL = Properties.IN_WALL;
	private static final Map<Axis, VoxelShape> field_55756 = VoxelShapes.method_66494(Block.method_66394(16.0, 16.0, 4.0));
	private static final Map<Axis, VoxelShape> field_55757 = Maps.newEnumMap(
		Util.transformMapValues(field_55756, arg -> VoxelShapes.combineAndSimplify(arg, Block.method_66404(16.0, 13.0, 16.0), BooleanBiFunction.ONLY_FIRST))
	);
	private static final Map<Axis, VoxelShape> field_55758 = VoxelShapes.method_66494(Block.method_66395(16.0, 4.0, 0.0, 24.0));
	private static final Map<Axis, VoxelShape> field_55759 = VoxelShapes.method_66494(Block.method_66395(16.0, 4.0, 5.0, 24.0));
	private static final Map<Axis, VoxelShape> field_55754 = VoxelShapes.method_66494(
		VoxelShapes.union(Block.createCuboidShape(0.0, 5.0, 7.0, 2.0, 16.0, 9.0), Block.createCuboidShape(14.0, 5.0, 7.0, 16.0, 16.0, 9.0))
	);
	private static final Map<Axis, VoxelShape> field_55755 = Maps.newEnumMap(Util.transformMapValues(field_55754, arg -> arg.offset(0.0, -0.1875, 0.0).simplify()));
	private final WoodType type;

	@Override
	public MapCodec<FenceGateBlock> getCodec() {
		return CODEC;
	}

	public FenceGateBlock(WoodType type, Settings settings) {
		super(settings.sounds(type.soundType()));
		this.type = type;
		this.setDefaultState(
			this.stateManager.getDefaultState().with(OPEN, Boolean.valueOf(false)).with(POWERED, Boolean.valueOf(false)).with(IN_WALL, Boolean.valueOf(false))
		);
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		Axis lv = ((Direction)state.get(FACING)).getAxis();
		return (VoxelShape)(state.get(IN_WALL) ? field_55757 : field_55756).get(lv);
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		Axis lv = direction.getAxis();
		if (((Direction)state.get(FACING)).rotateYClockwise().getAxis() != lv) {
			return super.getStateForNeighborUpdate(state, world, tickView, pos, direction, neighborPos, neighborState, random);
		} else {
			boolean bl = this.isWall(neighborState) || this.isWall(world.getBlockState(pos.offset(direction.getOpposite())));
			return state.with(IN_WALL, Boolean.valueOf(bl));
		}
	}

	@Override
	protected VoxelShape getSidesShape(BlockState state, BlockView world, BlockPos pos) {
		Axis lv = ((Direction)state.get(FACING)).getAxis();
		return state.get(OPEN) ? VoxelShapes.empty() : (VoxelShape)field_55759.get(lv);
	}

	@Override
	protected VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		Axis lv = ((Direction)state.get(FACING)).getAxis();
		return state.get(OPEN) ? VoxelShapes.empty() : (VoxelShape)field_55758.get(lv);
	}

	@Override
	protected VoxelShape getCullingShape(BlockState state) {
		Axis lv = ((Direction)state.get(FACING)).getAxis();
		return (VoxelShape)(state.get(IN_WALL) ? field_55755 : field_55754).get(lv);
	}

	@Override
	protected boolean canPathfindThrough(BlockState state, NavigationType type) {
		switch (type) {
			case LAND:
				return (Boolean)state.get(OPEN);
			case WATER:
				return false;
			case AIR:
				return (Boolean)state.get(OPEN);
			default:
				return false;
		}
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		World lv = ctx.getWorld();
		BlockPos lv2 = ctx.getBlockPos();
		boolean bl = lv.isReceivingRedstonePower(lv2);
		Direction lv3 = ctx.getHorizontalPlayerFacing();
		Axis lv4 = lv3.getAxis();
		boolean bl2 = lv4 == Axis.Z && (this.isWall(lv.getBlockState(lv2.west())) || this.isWall(lv.getBlockState(lv2.east())))
			|| lv4 == Axis.X && (this.isWall(lv.getBlockState(lv2.north())) || this.isWall(lv.getBlockState(lv2.south())));
		return this.getDefaultState().with(FACING, lv3).with(OPEN, Boolean.valueOf(bl)).with(POWERED, Boolean.valueOf(bl)).with(IN_WALL, Boolean.valueOf(bl2));
	}

	private boolean isWall(BlockState state) {
		return state.isIn(BlockTags.WALLS);
	}

	@Override
	protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
		// $VF: Couldn't be decompiled
		// Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
		//
		// Bytecode:
		// 00: aload 1
		// 01: getstatic net/minecraft/block/FenceGateBlock.OPEN Lnet/minecraft/state/property/BooleanProperty;
		// 04: invokevirtual net/minecraft/block/BlockState.get (Lnet/minecraft/state/property/Property;)Ljava/lang/Comparable;
		// 07: checkcast java/lang/Boolean
		// 0a: invokevirtual java/lang/Boolean.booleanValue ()Z
		// 0d: ifeq 2b
		// 10: aload 1
		// 11: getstatic net/minecraft/block/FenceGateBlock.OPEN Lnet/minecraft/state/property/BooleanProperty;
		// 14: bipush 0
		// 15: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
		// 18: invokevirtual net/minecraft/block/BlockState.with (Lnet/minecraft/state/property/Property;Ljava/lang/Comparable;)Ljava/lang/Object;
		// 1b: checkcast net/minecraft/block/BlockState
		// 1e: astore 1
		// 1f: aload 2
		// 20: aload 3
		// 21: aload 1
		// 22: bipush 10
		// 24: invokevirtual net/minecraft/world/World.setBlockState (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;I)Z
		// 27: pop
		// 28: goto 66
		// 2b: aload 4
		// 2d: invokevirtual net/minecraft/entity/player/PlayerEntity.getHorizontalFacing ()Lnet/minecraft/util/math/Direction;
		// 30: astore 6
		// 32: aload 1
		// 33: getstatic net/minecraft/block/FenceGateBlock.FACING Lnet/minecraft/state/property/EnumProperty;
		// 36: invokevirtual net/minecraft/block/BlockState.get (Lnet/minecraft/state/property/Property;)Ljava/lang/Comparable;
		// 39: aload 6
		// 3b: invokevirtual net/minecraft/util/math/Direction.getOpposite ()Lnet/minecraft/util/math/Direction;
		// 3e: if_acmpne 4e
		// 41: aload 1
		// 42: getstatic net/minecraft/block/FenceGateBlock.FACING Lnet/minecraft/state/property/EnumProperty;
		// 45: aload 6
		// 47: invokevirtual net/minecraft/block/BlockState.with (Lnet/minecraft/state/property/Property;Ljava/lang/Comparable;)Ljava/lang/Object;
		// 4a: checkcast net/minecraft/block/BlockState
		// 4d: astore 1
		// 4e: aload 1
		// 4f: getstatic net/minecraft/block/FenceGateBlock.OPEN Lnet/minecraft/state/property/BooleanProperty;
		// 52: bipush 1
		// 53: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
		// 56: invokevirtual net/minecraft/block/BlockState.with (Lnet/minecraft/state/property/Property;Ljava/lang/Comparable;)Ljava/lang/Object;
		// 59: checkcast net/minecraft/block/BlockState
		// 5c: astore 1
		// 5d: aload 2
		// 5e: aload 3
		// 5f: aload 1
		// 60: bipush 10
		// 62: invokevirtual net/minecraft/world/World.setBlockState (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;I)Z
		// 65: pop
		// 66: aload 1
		// 67: getstatic net/minecraft/block/FenceGateBlock.OPEN Lnet/minecraft/state/property/BooleanProperty;
		// 6a: invokevirtual net/minecraft/block/BlockState.get (Lnet/minecraft/state/property/Property;)Ljava/lang/Comparable;
		// 6d: checkcast java/lang/Boolean
		// 70: invokevirtual java/lang/Boolean.booleanValue ()Z
		// 73: istore 6
		// 75: aload 2
		// 76: aload 4
		// 78: aload 3
		// 79: iload 6
		// 7b: ifeq 88
		// 7e: aload 0
		// 7f: getfield net/minecraft/block/FenceGateBlock.type Lnet/minecraft/block/WoodType;
		// 82: invokevirtual net/minecraft/block/WoodType.fenceGateOpen ()Lnet/minecraft/sound/SoundEvent;
		// 85: goto 8f
		// 88: aload 0
		// 89: getfield net/minecraft/block/FenceGateBlock.type Lnet/minecraft/block/WoodType;
		// 8c: invokevirtual net/minecraft/block/WoodType.fenceGateClose ()Lnet/minecraft/sound/SoundEvent;
		// 8f: getstatic net/minecraft/sound/SoundCategory.BLOCKS Lnet/minecraft/sound/SoundCategory;
		// 92: fconst_1
		// 93: aload 2
		// 94: invokevirtual net/minecraft/world/World.getRandom ()Lnet/minecraft/util/math/random/Random;
		// 97: invokeinterface net/minecraft/util/math/random/Random.nextFloat ()F 1
		// 9c: ldc_w 0.1
		// 9f: fmul
		// a0: ldc_w 0.9
		// a3: fadd
		// a4: invokevirtual net/minecraft/world/World.playSound (Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/sound/SoundEvent;Lnet/minecraft/sound/SoundCategory;FF)V
		// a7: aload 2
		// a8: aload 4
		// aa: iload 6
		// ac: ifeq b5
		// af: getstatic net/minecraft/world/event/GameEvent.BLOCK_OPEN Lnet/minecraft/registry/entry/RegistryEntry$Reference;
		// b2: goto b8
		// b5: getstatic net/minecraft/world/event/GameEvent.BLOCK_CLOSE Lnet/minecraft/registry/entry/RegistryEntry$Reference;
		// b8: aload 3
		// b9: invokevirtual net/minecraft/world/World.emitGameEvent (Lnet/minecraft/entity/Entity;Lnet/minecraft/registry/entry/RegistryEntry;Lnet/minecraft/util/math/BlockPos;)V
		// bc: getstatic net/minecraft/util/ActionResult.SUCCESS Lnet/minecraft/util/ActionResult$Success;
		// bf: areturn
	}

	@Override
	protected void onExploded(BlockState state, ServerWorld world, BlockPos pos, Explosion explosion, BiConsumer<ItemStack, BlockPos> stackMerger) {
		if (explosion.canTriggerBlocks() && !(Boolean)state.get(POWERED)) {
			boolean bl = (Boolean)state.get(OPEN);
			world.setBlockState(pos, state.with(OPEN, Boolean.valueOf(!bl)));
			world.playSound(
				null, pos, bl ? this.type.fenceGateClose() : this.type.fenceGateOpen(), SoundCategory.BLOCKS, 1.0F, world.getRandom().nextFloat() * 0.1F + 0.9F
			);
			world.emitGameEvent(bl ? GameEvent.BLOCK_CLOSE : GameEvent.BLOCK_OPEN, pos, Emitter.of(state));
		}

		super.onExploded(state, world, pos, explosion, stackMerger);
	}

	@Override
	protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock, @Nullable WireOrientation wireOrientation, boolean notify) {
		if (!world.isClient) {
			boolean bl2 = world.isReceivingRedstonePower(pos);
			if ((Boolean)state.get(POWERED) != bl2) {
				world.setBlockState(pos, state.with(POWERED, Boolean.valueOf(bl2)).with(OPEN, Boolean.valueOf(bl2)), 2);
				if ((Boolean)state.get(OPEN) != bl2) {
					world.playSound(
						null, pos, bl2 ? this.type.fenceGateOpen() : this.type.fenceGateClose(), SoundCategory.BLOCKS, 1.0F, world.getRandom().nextFloat() * 0.1F + 0.9F
					);
					world.emitGameEvent(null, bl2 ? GameEvent.BLOCK_OPEN : GameEvent.BLOCK_CLOSE, pos);
				}
			}
		}
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(FACING, OPEN, POWERED, IN_WALL);
	}

	public static boolean canWallConnect(BlockState state, Direction side) {
		return ((Direction)state.get(FACING)).getAxis() == side.rotateYClockwise().getAxis();
	}
}
