package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity.AnimationStage;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.mob.PiglinBrain;
import net.minecraft.entity.mob.ShulkerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item.TooltipContext;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.stat.Stats;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.ItemScatterer;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

public class ShulkerBoxBlock extends BlockWithEntity {
	public static final MapCodec<ShulkerBoxBlock> CODEC = RecordCodecBuilder.mapCodec(
		instance -> instance.group(DyeColor.CODEC.optionalFieldOf("color").forGetter(block -> Optional.ofNullable(block.color)), createSettingsCodec())
				.apply(instance, (color, settings) -> new ShulkerBoxBlock((DyeColor)color.orElse(null), settings))
	);
	private static final Text UNKNOWN_CONTENTS_TEXT = Text.translatable("container.shulkerBox.unknownContents");
	public static final Map<Direction, VoxelShape> field_55792 = VoxelShapes.method_66504(Block.method_66408(16.0, 0.0, 1.0));
	public static final EnumProperty<Direction> FACING = FacingBlock.FACING;
	public static final Identifier CONTENTS_DYNAMIC_DROP_ID = Identifier.ofVanilla("contents");
	@Nullable
	private final DyeColor color;

	@Override
	public MapCodec<ShulkerBoxBlock> getCodec() {
		return CODEC;
	}

	public ShulkerBoxBlock(@Nullable DyeColor color, Settings settings) {
		super(settings);
		this.color = color;
		this.setDefaultState(this.stateManager.getDefaultState().with(FACING, Direction.UP));
	}

	@Override
	public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
		return new ShulkerBoxBlockEntity(this.color, pos, state);
	}

	@Nullable
	@Override
	public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state, BlockEntityType<T> type) {
		return validateTicker(type, BlockEntityType.SHULKER_BOX, ShulkerBoxBlockEntity::tick);
	}

	@Override
	protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
		if (world instanceof ServerWorld lv && world.getBlockEntity(pos) instanceof ShulkerBoxBlockEntity lv2 && canOpen(state, world, pos, lv2)) {
			player.openHandledScreen(lv2);
			player.incrementStat(Stats.OPEN_SHULKER_BOX);
			PiglinBrain.onGuardedBlockInteracted(lv, player, true);
		}

		return ActionResult.SUCCESS;
	}

	private static boolean canOpen(BlockState state, World world, BlockPos pos, ShulkerBoxBlockEntity entity) {
		if (entity.getAnimationStage() != AnimationStage.CLOSED) {
			return true;
		} else {
			Box lv = ShulkerEntity.calculateBoundingBox(1.0F, state.get(FACING), 0.0F, 0.5F, pos.toBottomCenterPos()).contract(1.0E-6);
			return world.isSpaceEmpty(lv);
		}
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		return this.getDefaultState().with(FACING, ctx.getSide());
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState onBreak(World world, BlockPos pos, BlockState state, PlayerEntity player) {
		BlockEntity lv = world.getBlockEntity(pos);
		if (lv instanceof ShulkerBoxBlockEntity lv2) {
			if (!world.isClient && player.shouldSkipBlockDrops() && !lv2.isEmpty()) {
				ItemStack lv3 = getItemStack(this.getColor());
				lv3.applyComponentsFrom(lv.createComponentMap());
				ItemEntity lv4 = new ItemEntity(world, (double)pos.getX() + 0.5, (double)pos.getY() + 0.5, (double)pos.getZ() + 0.5, lv3);
				lv4.setToDefaultPickupDelay();
				world.spawnEntity(lv4);
			} else {
				lv2.generateLoot(player);
			}
		}

		return super.onBreak(world, pos, state, player);
	}

	@Override
	protected List<ItemStack> getDroppedStacks(BlockState state, net.minecraft.loot.context.LootWorldContext.Builder builder) {
		BlockEntity lv = builder.getOptional(LootContextParameters.BLOCK_ENTITY);
		if (lv instanceof ShulkerBoxBlockEntity lv2) {
			builder = builder.addDynamicDrop(CONTENTS_DYNAMIC_DROP_ID, lootConsumer -> {
				for (int i = 0; i < lv2.size(); i++) {
					lootConsumer.accept(lv2.getStack(i));
				}
			});
		}

		return super.getDroppedStacks(state, builder);
	}

	@Override
	protected void onStateReplaced(BlockState state, ServerWorld world, BlockPos pos, boolean moved) {
		ItemScatterer.onStateReplaced(state, world, pos);
	}

	@Override
	public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType options) {
		super.appendTooltip(stack, context, tooltip, options);
		if (stack.contains(DataComponentTypes.CONTAINER_LOOT)) {
			tooltip.add(UNKNOWN_CONTENTS_TEXT);
		}

		int i = 0;
		int j = 0;

		for (ItemStack lv : stack.getOrDefault(DataComponentTypes.CONTAINER, ContainerComponent.DEFAULT).iterateNonEmpty()) {
			j++;
			if (i <= 4) {
				i++;
				tooltip.add(Text.translatable("container.shulkerBox.itemCount", lv.getName(), lv.getCount()));
			}
		}

		if (j - i > 0) {
			tooltip.add(Text.translatable("container.shulkerBox.more", j - i).formatted(Formatting.ITALIC));
		}
	}

	@Override
	protected VoxelShape getSidesShape(BlockState state, BlockView world, BlockPos pos) {
		if (world.getBlockEntity(pos) instanceof ShulkerBoxBlockEntity lv2 && !lv2.suffocates()) {
			return (VoxelShape)field_55792.get(((Direction)state.get(FACING)).getOpposite());
		}

		return VoxelShapes.fullCube();
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return world.getBlockEntity(pos) instanceof ShulkerBoxBlockEntity lv2 ? VoxelShapes.cuboid(lv2.getBoundingBox(state)) : VoxelShapes.fullCube();
	}

	@Override
	protected boolean isTransparent(BlockState state) {
		return false;
	}

	@Override
	protected boolean hasComparatorOutput(BlockState state) {
		return true;
	}

	@Override
	protected int getComparatorOutput(BlockState state, World world, BlockPos pos) {
		return ScreenHandler.calculateComparatorOutput(world.getBlockEntity(pos));
	}

	public static Block get(@Nullable DyeColor dyeColor) {
		if (dyeColor == null) {
			return Blocks.SHULKER_BOX;
		} else {
			return switch (dyeColor) {
				case WHITE -> Blocks.WHITE_SHULKER_BOX;
				case ORANGE -> Blocks.ORANGE_SHULKER_BOX;
				case MAGENTA -> Blocks.MAGENTA_SHULKER_BOX;
				case LIGHT_BLUE -> Blocks.LIGHT_BLUE_SHULKER_BOX;
				case YELLOW -> Blocks.YELLOW_SHULKER_BOX;
				case LIME -> Blocks.LIME_SHULKER_BOX;
				case PINK -> Blocks.PINK_SHULKER_BOX;
				case GRAY -> Blocks.GRAY_SHULKER_BOX;
				case LIGHT_GRAY -> Blocks.LIGHT_GRAY_SHULKER_BOX;
				case CYAN -> Blocks.CYAN_SHULKER_BOX;
				case BLUE -> Blocks.BLUE_SHULKER_BOX;
				case BROWN -> Blocks.BROWN_SHULKER_BOX;
				case GREEN -> Blocks.GREEN_SHULKER_BOX;
				case RED -> Blocks.RED_SHULKER_BOX;
				case BLACK -> Blocks.BLACK_SHULKER_BOX;
				case PURPLE -> Blocks.PURPLE_SHULKER_BOX;
				default -> throw new MatchException(null, null);
			};
		}
	}

	@Nullable
	public DyeColor getColor() {
		return this.color;
	}

	public static ItemStack getItemStack(@Nullable DyeColor color) {
		return new ItemStack(get(color));
	}

	@Override
	protected BlockState rotate(BlockState state, BlockRotation rotation) {
		return state.with(FACING, rotation.rotate(state.get(FACING)));
	}

	@Override
	protected BlockState mirror(BlockState state, BlockMirror mirror) {
		return state.rotate(mirror.getRotation(state.get(FACING)));
	}
}
