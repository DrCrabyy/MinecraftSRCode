package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.mojang.serialization.MapCodec;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.enums.WallShape;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.function.BooleanBiFunction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldView;
import net.minecraft.world.tick.ScheduledTickView;

public class WallBlock extends Block implements Waterloggable {
	public static final MapCodec<WallBlock> CODEC = createCodec(WallBlock::new);
	public static final BooleanProperty UP = Properties.UP;
	public static final EnumProperty<WallShape> field_55815 = Properties.EAST_WALL_SHAPE;
	public static final EnumProperty<WallShape> field_55816 = Properties.NORTH_WALL_SHAPE;
	public static final EnumProperty<WallShape> field_55817 = Properties.SOUTH_WALL_SHAPE;
	public static final EnumProperty<WallShape> field_55818 = Properties.WEST_WALL_SHAPE;
	public static final Map<Direction, EnumProperty<WallShape>> field_55819 = ImmutableMap.copyOf(
		Maps.newEnumMap(Map.of(Direction.NORTH, field_55816, Direction.EAST, field_55815, Direction.SOUTH, field_55817, Direction.WEST, field_55818))
	);
	public static final BooleanProperty WATERLOGGED = Properties.WATERLOGGED;
	private final Function<BlockState, VoxelShape> field_55820;
	private final Function<BlockState, VoxelShape> field_55812;
	private static final VoxelShape field_55813 = Block.method_66404(2.0, 0.0, 16.0);
	private static final Map<Direction, VoxelShape> field_55814 = VoxelShapes.method_66501(Block.method_66405(2.0, 16.0, 0.0, 9.0));

	@Override
	public MapCodec<WallBlock> getCodec() {
		return CODEC;
	}

	public WallBlock(Settings settings) {
		super(settings);
		this.setDefaultState(
			this.stateManager
				.getDefaultState()
				.with(UP, Boolean.valueOf(true))
				.with(field_55816, WallShape.NONE)
				.with(field_55815, WallShape.NONE)
				.with(field_55817, WallShape.NONE)
				.with(field_55818, WallShape.NONE)
				.with(WATERLOGGED, Boolean.valueOf(false))
		);
		this.field_55820 = this.getShapeMap(16.0F, 14.0F);
		this.field_55812 = this.getShapeMap(24.0F, 24.0F);
	}

	private Function<BlockState, VoxelShape> getShapeMap(float f, float g) {
		VoxelShape lv = Block.method_66404(8.0, 0.0, (double)f);
		int i = 6;
		Map<Direction, VoxelShape> map = VoxelShapes.method_66501(Block.method_66396(6.0, 0.0, (double)g, 0.0, 11.0));
		Map<Direction, VoxelShape> map2 = VoxelShapes.method_66501(Block.method_66396(6.0, 0.0, (double)f, 0.0, 11.0));
		return this.method_66403(arg2 -> {
			VoxelShape lvx = arg2.get(UP) ? lv : VoxelShapes.empty();

			for (Entry<Direction, EnumProperty<WallShape>> entry : field_55819.entrySet()) {
				lvx = VoxelShapes.union(lvx, switch ((WallShape)arg2.get((Property)entry.getValue())) {
					case NONE -> VoxelShapes.empty();
					case LOW -> (VoxelShape)map.get(entry.getKey());
					case TALL -> (VoxelShape)map2.get(entry.getKey());
					default -> throw new MatchException(null, null);
				});
			}

			return lvx;
		}, new Property[]{WATERLOGGED});
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return (VoxelShape)this.field_55820.apply(state);
	}

	@Override
	protected VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return (VoxelShape)this.field_55812.apply(state);
	}

	@Override
	protected boolean canPathfindThrough(BlockState state, NavigationType type) {
		return false;
	}

	private boolean shouldConnectTo(BlockState state, boolean faceFullSquare, Direction side) {
		Block lv = state.getBlock();
		boolean bl2 = lv instanceof FenceGateBlock && FenceGateBlock.canWallConnect(state, side);
		return state.isIn(BlockTags.WALLS) || !cannotConnect(state) && faceFullSquare || lv instanceof PaneBlock || bl2;
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		WorldView lv = ctx.getWorld();
		BlockPos lv2 = ctx.getBlockPos();
		FluidState lv3 = ctx.getWorld().getFluidState(ctx.getBlockPos());
		BlockPos lv4 = lv2.north();
		BlockPos lv5 = lv2.east();
		BlockPos lv6 = lv2.south();
		BlockPos lv7 = lv2.west();
		BlockPos lv8 = lv2.up();
		BlockState lv9 = lv.getBlockState(lv4);
		BlockState lv10 = lv.getBlockState(lv5);
		BlockState lv11 = lv.getBlockState(lv6);
		BlockState lv12 = lv.getBlockState(lv7);
		BlockState lv13 = lv.getBlockState(lv8);
		boolean bl = this.shouldConnectTo(lv9, lv9.isSideSolidFullSquare(lv, lv4, Direction.SOUTH), Direction.SOUTH);
		boolean bl2 = this.shouldConnectTo(lv10, lv10.isSideSolidFullSquare(lv, lv5, Direction.WEST), Direction.WEST);
		boolean bl3 = this.shouldConnectTo(lv11, lv11.isSideSolidFullSquare(lv, lv6, Direction.NORTH), Direction.NORTH);
		boolean bl4 = this.shouldConnectTo(lv12, lv12.isSideSolidFullSquare(lv, lv7, Direction.EAST), Direction.EAST);
		BlockState lv14 = this.getDefaultState().with(WATERLOGGED, Boolean.valueOf(lv3.getFluid() == Fluids.WATER));
		return this.getStateWith(lv, lv14, lv8, lv13, bl, bl2, bl3, bl4);
	}

	@Override
	protected BlockState getStateForNeighborUpdate(
		BlockState state,
		WorldView world,
		ScheduledTickView tickView,
		BlockPos pos,
		Direction direction,
		BlockPos neighborPos,
		BlockState neighborState,
		Random random
	) {
		if ((Boolean)state.get(WATERLOGGED)) {
			tickView.scheduleFluidTick(pos, Fluids.WATER, Fluids.WATER.getTickRate(world));
		}

		if (direction == Direction.DOWN) {
			return super.getStateForNeighborUpdate(state, world, tickView, pos, direction, neighborPos, neighborState, random);
		} else {
			return direction == Direction.UP
				? this.getStateAt(world, state, neighborPos, neighborState)
				: this.getStateWithNeighbor(world, pos, state, neighborPos, neighborState, direction);
		}
	}

	private static boolean isConnected(BlockState state, Property<WallShape> property) {
		return state.get(property) != WallShape.NONE;
	}

	private static boolean shouldUseTallShape(VoxelShape aboveShape, VoxelShape tallShape) {
		return !VoxelShapes.matchesAnywhere(tallShape, aboveShape, BooleanBiFunction.ONLY_FIRST);
	}

	private BlockState getStateAt(WorldView world, BlockState state, BlockPos pos, BlockState aboveState) {
		boolean bl = isConnected(state, field_55816);
		boolean bl2 = isConnected(state, field_55815);
		boolean bl3 = isConnected(state, field_55817);
		boolean bl4 = isConnected(state, field_55818);
		return this.getStateWith(world, state, pos, aboveState, bl, bl2, bl3, bl4);
	}

	private BlockState getStateWithNeighbor(WorldView world, BlockPos pos, BlockState state, BlockPos neighborPos, BlockState neighborState, Direction direction) {
		Direction lv = direction.getOpposite();
		boolean bl = direction == Direction.NORTH
			? this.shouldConnectTo(neighborState, neighborState.isSideSolidFullSquare(world, neighborPos, lv), lv)
			: isConnected(state, field_55816);
		boolean bl2 = direction == Direction.EAST
			? this.shouldConnectTo(neighborState, neighborState.isSideSolidFullSquare(world, neighborPos, lv), lv)
			: isConnected(state, field_55815);
		boolean bl3 = direction == Direction.SOUTH
			? this.shouldConnectTo(neighborState, neighborState.isSideSolidFullSquare(world, neighborPos, lv), lv)
			: isConnected(state, field_55817);
		boolean bl4 = direction == Direction.WEST
			? this.shouldConnectTo(neighborState, neighborState.isSideSolidFullSquare(world, neighborPos, lv), lv)
			: isConnected(state, field_55818);
		BlockPos lv2 = pos.up();
		BlockState lv3 = world.getBlockState(lv2);
		return this.getStateWith(world, state, lv2, lv3, bl, bl2, bl3, bl4);
	}

	private BlockState getStateWith(
		WorldView world, BlockState state, BlockPos pos, BlockState aboveState, boolean north, boolean east, boolean south, boolean west
	) {
		VoxelShape lv = aboveState.getCollisionShape(world, pos).getFace(Direction.DOWN);
		BlockState lv2 = this.getStateWith(state, north, east, south, west, lv);
		return lv2.with(UP, Boolean.valueOf(this.shouldHavePost(lv2, aboveState, lv)));
	}

	private boolean shouldHavePost(BlockState state, BlockState aboveState, VoxelShape aboveShape) {
		boolean bl = aboveState.getBlock() instanceof WallBlock && (Boolean)aboveState.get(UP);
		if (bl) {
			return true;
		} else {
			WallShape lv = state.get(field_55816);
			WallShape lv2 = state.get(field_55817);
			WallShape lv3 = state.get(field_55815);
			WallShape lv4 = state.get(field_55818);
			boolean bl2 = lv2 == WallShape.NONE;
			boolean bl3 = lv4 == WallShape.NONE;
			boolean bl4 = lv3 == WallShape.NONE;
			boolean bl5 = lv == WallShape.NONE;
			boolean bl6 = bl5 && bl2 && bl3 && bl4 || bl5 != bl2 || bl3 != bl4;
			if (bl6) {
				return true;
			} else {
				boolean bl7 = lv == WallShape.TALL && lv2 == WallShape.TALL || lv3 == WallShape.TALL && lv4 == WallShape.TALL;
				return bl7 ? false : aboveState.isIn(BlockTags.WALL_POST_OVERRIDE) || shouldUseTallShape(aboveShape, field_55813);
			}
		}
	}

	private BlockState getStateWith(BlockState state, boolean north, boolean east, boolean south, boolean west, VoxelShape aboveShape) {
		return state.with(field_55816, this.getWallShape(north, aboveShape, (VoxelShape)field_55814.get(Direction.NORTH)))
			.with(field_55815, this.getWallShape(east, aboveShape, (VoxelShape)field_55814.get(Direction.EAST)))
			.with(field_55817, this.getWallShape(south, aboveShape, (VoxelShape)field_55814.get(Direction.SOUTH)))
			.with(field_55818, this.getWallShape(west, aboveShape, (VoxelShape)field_55814.get(Direction.WEST)));
	}

	private WallShape getWallShape(boolean connected, VoxelShape aboveShape, VoxelShape tallShape) {
		if (connected) {
			return shouldUseTallShape(aboveShape, tallShape) ? WallShape.TALL : WallShape.LOW;
		} else {
			return WallShape.NONE;
		}
	}

	@Override
	protected FluidState getFluidState(BlockState state) {
		return state.get(WATERLOGGED) ? Fluids.WATER.getStill(false) : super.getFluidState(state);
	}

	@Override
	protected boolean isTransparent(BlockState state) {
		return !(Boolean)state.get(WATERLOGGED);
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(UP, field_55816, field_55815, field_55818, field_55817, WATERLOGGED);
	}

	@Override
	protected BlockState rotate(BlockState state, BlockRotation rotation) {
		switch (rotation) {
			case CLOCKWISE_180:
				return state.with(field_55816, (WallShape)state.get(field_55817))
					.with(field_55815, (WallShape)state.get(field_55818))
					.with(field_55817, (WallShape)state.get(field_55816))
					.with(field_55818, (WallShape)state.get(field_55815));
			case COUNTERCLOCKWISE_90:
				return state.with(field_55816, (WallShape)state.get(field_55815))
					.with(field_55815, (WallShape)state.get(field_55817))
					.with(field_55817, (WallShape)state.get(field_55818))
					.with(field_55818, (WallShape)state.get(field_55816));
			case CLOCKWISE_90:
				return state.with(field_55816, (WallShape)state.get(field_55818))
					.with(field_55815, (WallShape)state.get(field_55816))
					.with(field_55817, (WallShape)state.get(field_55815))
					.with(field_55818, (WallShape)state.get(field_55817));
			default:
				return state;
		}
	}

	@Override
	protected BlockState mirror(BlockState state, BlockMirror mirror) {
		switch (mirror) {
			case LEFT_RIGHT:
				return state.with(field_55816, (WallShape)state.get(field_55817)).with(field_55817, (WallShape)state.get(field_55816));
			case FRONT_BACK:
				return state.with(field_55815, (WallShape)state.get(field_55818)).with(field_55818, (WallShape)state.get(field_55815));
			default:
				return super.mirror(state, mirror);
		}
	}
}
