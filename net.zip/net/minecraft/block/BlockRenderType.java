package net.minecraft.block;

public enum BlockRenderType {
	INVISIBLE,
	MODEL;
}
