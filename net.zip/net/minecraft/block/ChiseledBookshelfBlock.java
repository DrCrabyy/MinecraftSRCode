package net.minecraft.block;

import com.mojang.serialization.MapCodec;
import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;
import javax.annotation.Nullable;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChiseledBookshelfBlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.state.StateManager.Builder;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Hand;
import net.minecraft.util.ItemScatterer;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;

public class ChiseledBookshelfBlock extends BlockWithEntity {
	public static final MapCodec<ChiseledBookshelfBlock> CODEC = createCodec(ChiseledBookshelfBlock::new);
	private static final int MAX_BOOK_COUNT = 6;
	public static final int BOOK_HEIGHT = 3;
	public static final List<BooleanProperty> SLOT_OCCUPIED_PROPERTIES = List.of(
		Properties.SLOT_0_OCCUPIED,
		Properties.SLOT_1_OCCUPIED,
		Properties.SLOT_2_OCCUPIED,
		Properties.SLOT_3_OCCUPIED,
		Properties.SLOT_4_OCCUPIED,
		Properties.SLOT_5_OCCUPIED
	);

	@Override
	public MapCodec<ChiseledBookshelfBlock> getCodec() {
		return CODEC;
	}

	public ChiseledBookshelfBlock(Settings settings) {
		super(settings);
		BlockState lv = this.stateManager.getDefaultState().with(HorizontalFacingBlock.FACING, Direction.NORTH);

		for (BooleanProperty lv2 : SLOT_OCCUPIED_PROPERTIES) {
			lv = lv.with(lv2, Boolean.valueOf(false));
		}

		this.setDefaultState(lv);
	}

	@Override
	protected ActionResult onUseWithItem(ItemStack stack, BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
		if (world.getBlockEntity(pos) instanceof ChiseledBookshelfBlockEntity lv) {
			if (!stack.isIn(ItemTags.BOOKSHELF_BOOKS)) {
				return ActionResult.PASS_TO_DEFAULT_BLOCK_ACTION;
			} else {
				OptionalInt optionalInt = this.getSlotForHitPos(hit, state);
				if (optionalInt.isEmpty()) {
					return ActionResult.PASS;
				} else if ((Boolean)state.get((Property)SLOT_OCCUPIED_PROPERTIES.get(optionalInt.getAsInt()))) {
					return ActionResult.PASS_TO_DEFAULT_BLOCK_ACTION;
				} else {
					tryAddBook(world, pos, player, lv, stack, optionalInt.getAsInt());
					return ActionResult.SUCCESS;
				}
			}
		} else {
			return ActionResult.PASS;
		}
	}

	@Override
	protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
		if (world.getBlockEntity(pos) instanceof ChiseledBookshelfBlockEntity lv) {
			OptionalInt optionalInt = this.getSlotForHitPos(hit, state);
			if (optionalInt.isEmpty()) {
				return ActionResult.PASS;
			} else if (!(Boolean)state.get((Property)SLOT_OCCUPIED_PROPERTIES.get(optionalInt.getAsInt()))) {
				return ActionResult.CONSUME;
			} else {
				tryRemoveBook(world, pos, player, lv, optionalInt.getAsInt());
				return ActionResult.SUCCESS;
			}
		} else {
			return ActionResult.PASS;
		}
	}

	private OptionalInt getSlotForHitPos(BlockHitResult hit, BlockState state) {
		return (OptionalInt)getHitPos(hit, state.get(HorizontalFacingBlock.FACING)).map(hitPos -> {
			int i = hitPos.y >= 0.5F ? 0 : 1;
			int j = getColumn(hitPos.x);
			return OptionalInt.of(j + i * 3);
		}).orElseGet(OptionalInt::empty);
	}

	private static Optional<Vec2f> getHitPos(BlockHitResult hit, Direction facing) {
		Direction lv = hit.getSide();
		if (facing != lv) {
			return Optional.empty();
		} else {
			BlockPos lv2 = hit.getBlockPos().offset(lv);
			Vec3d lv3 = hit.getPos().subtract((double)lv2.getX(), (double)lv2.getY(), (double)lv2.getZ());
			double d = lv3.getX();
			double e = lv3.getY();
			double f = lv3.getZ();

			return switch (lv) {
				case NORTH -> Optional.of(new Vec2f((float)(1.0 - d), (float)e));
				case SOUTH -> Optional.of(new Vec2f((float)d, (float)e));
				case WEST -> Optional.of(new Vec2f((float)f, (float)e));
				case EAST -> Optional.of(new Vec2f((float)(1.0 - f), (float)e));
				case DOWN, UP -> Optional.empty();
				default -> throw new MatchException(null, null);
			};
		}
	}

	private static int getColumn(float x) {
		float g = 0.0625F;
		float h = 0.375F;
		if (x < 0.375F) {
			return 0;
		} else {
			float i = 0.6875F;
			return x < 0.6875F ? 1 : 2;
		}
	}

	private static void tryAddBook(World world, BlockPos pos, PlayerEntity player, ChiseledBookshelfBlockEntity blockEntity, ItemStack stack, int slot) {
		if (!world.isClient) {
			player.incrementStat(Stats.USED.getOrCreateStat(stack.getItem()));
			SoundEvent lv = stack.isOf(Items.ENCHANTED_BOOK) ? SoundEvents.BLOCK_CHISELED_BOOKSHELF_INSERT_ENCHANTED : SoundEvents.BLOCK_CHISELED_BOOKSHELF_INSERT;
			blockEntity.setStack(slot, stack.splitUnlessCreative(1, player));
			world.playSound(null, pos, lv, SoundCategory.BLOCKS, 1.0F, 1.0F);
		}
	}

	private static void tryRemoveBook(World world, BlockPos pos, PlayerEntity player, ChiseledBookshelfBlockEntity blockEntity, int slot) {
		if (!world.isClient) {
			ItemStack lv = blockEntity.removeStack(slot, 1);
			SoundEvent lv2 = lv.isOf(Items.ENCHANTED_BOOK) ? SoundEvents.BLOCK_CHISELED_BOOKSHELF_PICKUP_ENCHANTED : SoundEvents.BLOCK_CHISELED_BOOKSHELF_PICKUP;
			world.playSound(null, pos, lv2, SoundCategory.BLOCKS, 1.0F, 1.0F);
			if (!player.getInventory().insertStack(lv)) {
				player.dropItem(lv, false);
			}

			world.emitGameEvent(player, GameEvent.BLOCK_CHANGE, pos);
		}
	}

	@Nullable
	@Override
	public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
		return new ChiseledBookshelfBlockEntity(pos, state);
	}

	@Override
	protected void appendProperties(Builder<Block, BlockState> builder) {
		builder.add(HorizontalFacingBlock.FACING);
		SLOT_OCCUPIED_PROPERTIES.forEach(property -> builder.add(property));
	}

	@Override
	protected void onStateReplaced(BlockState state, ServerWorld world, BlockPos pos, boolean moved) {
		ItemScatterer.onStateReplaced(state, world, pos);
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		return this.getDefaultState().with(HorizontalFacingBlock.FACING, ctx.getHorizontalPlayerFacing().getOpposite());
	}

	@Override
	public BlockState rotate(BlockState state, BlockRotation rotation) {
		return state.with(HorizontalFacingBlock.FACING, rotation.rotate(state.get(HorizontalFacingBlock.FACING)));
	}

	@Override
	public BlockState mirror(BlockState state, BlockMirror mirror) {
		return state.rotate(mirror.getRotation(state.get(HorizontalFacingBlock.FACING)));
	}

	@Override
	protected boolean hasComparatorOutput(BlockState state) {
		return true;
	}

	@Override
	protected int getComparatorOutput(BlockState state, World world, BlockPos pos) {
		if (world.isClient()) {
			return 0;
		} else {
			return world.getBlockEntity(pos) instanceof ChiseledBookshelfBlockEntity lv ? lv.getLastInteractedSlot() + 1 : 0;
		}
	}
}
