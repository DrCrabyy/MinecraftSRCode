package net.minecraft.block.spawner;

import com.google.common.annotations.VisibleForTesting;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectListIterator;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.TrialSpawnerBlock;
import net.minecraft.block.dispenser.ItemDispenserBehavior;
import net.minecraft.block.enums.TrialSpawnerState;
import net.minecraft.block.spawner.EntityDetector.Selector;
import net.minecraft.block.spawner.MobSpawnerEntry.CustomSpawnRules;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.loot.context.LootWorldContext;
import net.minecraft.loot.context.LootWorldContext.Builder;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Difficulty;
import net.minecraft.world.GameRules;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import net.minecraft.world.event.GameEvent;

public final class TrialSpawnerLogic {
	public static final String NORMAL_CONFIG_NBT_KEY = "normal_config";
	public static final String OMINOUS_CONFIG_NBT_KEY = "ominous_config";
	public static final int field_47358 = 40;
	private static final int DEFAULT_COOLDOWN_LENGTH = 36000;
	private static final int DEFAULT_ENTITY_DETECTION_RANGE = 14;
	private static final int MAX_ENTITY_DISTANCE = 47;
	private static final int MAX_ENTITY_DISTANCE_SQUARED = MathHelper.square(47);
	private static final float SOUND_RATE_PER_TICK = 0.02F;
	private RegistryEntry<TrialSpawnerConfig> normalConfig;
	private RegistryEntry<TrialSpawnerConfig> ominousConfig;
	private final TrialSpawnerData data;
	private final int entityDetectionRange;
	private final int cooldownLength;
	private final TrialSpawnerLogic.TrialSpawner trialSpawner;
	private EntityDetector entityDetector;
	private final Selector entitySelector;
	private boolean forceActivate;
	private boolean ominous;

	public Codec<TrialSpawnerLogic> codec() {
		return RecordCodecBuilder.create(
			instance -> instance.group(
						TrialSpawnerConfig.ENTRY_CODEC.optionalFieldOf("normal_config", RegistryEntry.of(TrialSpawnerConfig.DEFAULT)).forGetter(arg -> arg.normalConfig),
						TrialSpawnerConfig.ENTRY_CODEC.optionalFieldOf("ominous_config", RegistryEntry.of(TrialSpawnerConfig.DEFAULT)).forGetter(arg -> arg.ominousConfig),
						TrialSpawnerData.codec.forGetter(TrialSpawnerLogic::getData),
						Codec.intRange(0, Integer.MAX_VALUE).optionalFieldOf("target_cooldown_length", 36000).forGetter(TrialSpawnerLogic::getCooldownLength),
						Codec.intRange(1, 128).optionalFieldOf("required_player_range", 14).forGetter(TrialSpawnerLogic::getDetectionRadius)
					)
					.apply(
						instance,
						(normalConfig, ominousConfig, data, cooldownLength, entityDetectionRange) -> new TrialSpawnerLogic(
								normalConfig, ominousConfig, data, cooldownLength, entityDetectionRange, this.trialSpawner, this.entityDetector, this.entitySelector
							)
					)
		);
	}

	public TrialSpawnerLogic(TrialSpawnerLogic.TrialSpawner trialSpawner, EntityDetector entityDetector, Selector entitySelector) {
		this(
			RegistryEntry.of(TrialSpawnerConfig.DEFAULT),
			RegistryEntry.of(TrialSpawnerConfig.DEFAULT),
			new TrialSpawnerData(),
			36000,
			14,
			trialSpawner,
			entityDetector,
			entitySelector
		);
	}

	public TrialSpawnerLogic(
		RegistryEntry<TrialSpawnerConfig> normalConfig,
		RegistryEntry<TrialSpawnerConfig> ominousConfig,
		TrialSpawnerData data,
		int cooldownLength,
		int entityDetectionRange,
		TrialSpawnerLogic.TrialSpawner trialSpawner,
		EntityDetector entityDetector,
		Selector entitySelector
	) {
		this.normalConfig = normalConfig;
		this.ominousConfig = ominousConfig;
		this.data = data;
		this.cooldownLength = cooldownLength;
		this.entityDetectionRange = entityDetectionRange;
		this.trialSpawner = trialSpawner;
		this.entityDetector = entityDetector;
		this.entitySelector = entitySelector;
	}

	public TrialSpawnerConfig getConfig() {
		return this.ominous ? this.getOminousConfig() : this.getNormalConfig();
	}

	@VisibleForTesting
	public TrialSpawnerConfig getNormalConfig() {
		return this.normalConfig.value();
	}

	@VisibleForTesting
	public TrialSpawnerConfig getOminousConfig() {
		return this.ominousConfig.value();
	}

	public void setOminous(ServerWorld world, BlockPos pos) {
		world.setBlockState(pos, world.getBlockState(pos).with(TrialSpawnerBlock.OMINOUS, Boolean.valueOf(true)), 3);
		world.syncWorldEvent(3020, pos, 1);
		this.ominous = true;
		this.data.resetAndClearMobs(this, world);
	}

	public void setNotOminous(ServerWorld world, BlockPos pos) {
		world.setBlockState(pos, world.getBlockState(pos).with(TrialSpawnerBlock.OMINOUS, Boolean.valueOf(false)), 3);
		this.ominous = false;
	}

	public boolean isOminous() {
		return this.ominous;
	}

	public TrialSpawnerData getData() {
		return this.data;
	}

	public int getCooldownLength() {
		return this.cooldownLength;
	}

	public int getDetectionRadius() {
		return this.entityDetectionRange;
	}

	public TrialSpawnerState getSpawnerState() {
		return this.trialSpawner.getSpawnerState();
	}

	public void setSpawnerState(World world, TrialSpawnerState spawnerState) {
		this.trialSpawner.setSpawnerState(world, spawnerState);
	}

	public void updateListeners() {
		this.trialSpawner.updateListeners();
	}

	public EntityDetector getEntityDetector() {
		return this.entityDetector;
	}

	public Selector getEntitySelector() {
		return this.entitySelector;
	}

	public boolean canActivate(ServerWorld world) {
		if (this.forceActivate) {
			return true;
		} else {
			return world.getDifficulty() == Difficulty.PEACEFUL ? false : world.getGameRules().getBoolean(GameRules.DO_MOB_SPAWNING);
		}
	}

	public Optional<UUID> trySpawnMob(ServerWorld world, BlockPos pos) {
		Random lv = world.getRandom();
		MobSpawnerEntry lv2 = this.data.getSpawnData(this, world.getRandom());
		NbtCompound lv3 = lv2.entity();
		NbtList lv4 = lv3.getList("Pos", 6);
		Optional<EntityType<?>> optional = EntityType.fromNbt(lv3);
		if (optional.isEmpty()) {
			return Optional.empty();
		} else {
			int i = lv4.size();
			double d = i >= 1 ? lv4.getDouble(0) : (double)pos.getX() + (lv.nextDouble() - lv.nextDouble()) * (double)this.getConfig().spawnRange() + 0.5;
			double e = i >= 2 ? lv4.getDouble(1) : (double)(pos.getY() + lv.nextInt(3) - 1);
			double f = i >= 3 ? lv4.getDouble(2) : (double)pos.getZ() + (lv.nextDouble() - lv.nextDouble()) * (double)this.getConfig().spawnRange() + 0.5;
			if (!world.isSpaceEmpty(((EntityType)optional.get()).getSpawnBox(d, e, f))) {
				return Optional.empty();
			} else {
				Vec3d lv5 = new Vec3d(d, e, f);
				if (!hasLineOfSight(world, pos.toCenterPos(), lv5)) {
					return Optional.empty();
				} else {
					BlockPos lv6 = BlockPos.ofFloored(lv5);
					if (!SpawnRestriction.canSpawn((EntityType)optional.get(), world, SpawnReason.TRIAL_SPAWNER, lv6, world.getRandom())) {
						return Optional.empty();
					} else {
						if (lv2.getCustomSpawnRules().isPresent()) {
							CustomSpawnRules lv7 = (CustomSpawnRules)lv2.getCustomSpawnRules().get();
							if (!lv7.canSpawn(lv6, world)) {
								return Optional.empty();
							}
						}

						Entity lv8 = EntityType.loadEntityWithPassengers(lv3, world, SpawnReason.TRIAL_SPAWNER, entity -> {
							entity.refreshPositionAndAngles(d, e, f, lv.nextFloat() * 360.0F, 0.0F);
							return entity;
						});
						if (lv8 == null) {
							return Optional.empty();
						} else {
							if (lv8 instanceof MobEntity lv9) {
								if (!lv9.canSpawn(world)) {
									return Optional.empty();
								}

								boolean bl = lv2.getNbt().getSize() == 1 && lv2.getNbt().contains("id", 8);
								if (bl) {
									lv9.initialize(world, world.getLocalDifficulty(lv9.getBlockPos()), SpawnReason.TRIAL_SPAWNER, null);
								}

								lv9.setPersistent();
								lv2.getEquipment().ifPresent(lv9::setEquipmentFromTable);
							}

							if (!world.spawnNewEntityAndPassengers(lv8)) {
								return Optional.empty();
							} else {
								TrialSpawnerLogic.Type lv10 = this.ominous ? TrialSpawnerLogic.Type.OMINOUS : TrialSpawnerLogic.Type.NORMAL;
								world.syncWorldEvent(3011, pos, lv10.getIndex());
								world.syncWorldEvent(3012, lv6, lv10.getIndex());
								world.emitGameEvent(lv8, GameEvent.ENTITY_PLACE, lv6);
								return Optional.of(lv8.getUuid());
							}
						}
					}
				}
			}
		}
	}

	public void ejectLootTable(ServerWorld world, BlockPos pos, RegistryKey<LootTable> lootTable) {
		LootTable lv = world.getServer().getReloadableRegistries().getLootTable(lootTable);
		LootWorldContext lv2 = new Builder(world).build(LootContextTypes.EMPTY);
		ObjectArrayList<ItemStack> objectArrayList = lv.generateLoot(lv2);
		if (!objectArrayList.isEmpty()) {
			ObjectListIterator var7 = objectArrayList.iterator();

			while (var7.hasNext()) {
				ItemStack lv3 = (ItemStack)var7.next();
				ItemDispenserBehavior.spawnItem(world, lv3, 2, Direction.UP, Vec3d.ofBottomCenter(pos).offset(Direction.UP, 1.2));
			}

			world.syncWorldEvent(3014, pos, 0);
		}
	}

	public void tickClient(World world, BlockPos pos, boolean ominous) {
		TrialSpawnerState lv = this.getSpawnerState();
		lv.emitParticles(world, pos, ominous);
		if (lv.doesDisplayRotate()) {
			double d = (double)Math.max(0L, this.data.nextMobSpawnsAt - world.getTime());
			this.data.lastDisplayEntityRotation = this.data.displayEntityRotation;
			this.data.displayEntityRotation = (this.data.displayEntityRotation + lv.getDisplayRotationSpeed() / (d + 200.0)) % 360.0;
		}

		if (lv.playsSound()) {
			Random lv2 = world.getRandom();
			if (lv2.nextFloat() <= 0.02F) {
				SoundEvent lv3 = ominous ? SoundEvents.BLOCK_TRIAL_SPAWNER_AMBIENT_OMINOUS : SoundEvents.BLOCK_TRIAL_SPAWNER_AMBIENT;
				world.playSoundAtBlockCenterClient(pos, lv3, SoundCategory.BLOCKS, lv2.nextFloat() * 0.25F + 0.75F, lv2.nextFloat() + 0.5F, false);
			}
		}
	}

	public void tickServer(ServerWorld world, BlockPos pos, boolean ominous) {
		this.ominous = ominous;
		TrialSpawnerState lv = this.getSpawnerState();
		if (this.data.spawnedMobsAlive.removeIf(uuid -> shouldRemoveMobFromData(world, pos, uuid))) {
			this.data.nextMobSpawnsAt = world.getTime() + (long)this.getConfig().ticksBetweenSpawn();
		}

		TrialSpawnerState lv2 = lv.tick(pos, this, world);
		if (lv2 != lv) {
			this.setSpawnerState(world, lv2);
		}
	}

	private static boolean shouldRemoveMobFromData(ServerWorld world, BlockPos pos, UUID uuid) {
		Entity lv = world.getEntity(uuid);
		return lv == null
			|| !lv.isAlive()
			|| !lv.getWorld().getRegistryKey().equals(world.getRegistryKey())
			|| lv.getBlockPos().getSquaredDistance(pos) > (double)MAX_ENTITY_DISTANCE_SQUARED;
	}

	private static boolean hasLineOfSight(World world, Vec3d spawnerPos, Vec3d spawnPos) {
		BlockHitResult lv = world.raycast(new RaycastContext(spawnPos, spawnerPos, ShapeType.VISUAL, FluidHandling.NONE, ShapeContext.absent()));
		return lv.getBlockPos().equals(BlockPos.ofFloored(spawnerPos)) || lv.getType() == HitResult.Type.MISS;
	}

	public static void addMobSpawnParticles(World world, BlockPos pos, Random random, SimpleParticleType particle) {
		for (int i = 0; i < 20; i++) {
			double d = (double)pos.getX() + 0.5 + (random.nextDouble() - 0.5) * 2.0;
			double e = (double)pos.getY() + 0.5 + (random.nextDouble() - 0.5) * 2.0;
			double f = (double)pos.getZ() + 0.5 + (random.nextDouble() - 0.5) * 2.0;
			world.addParticleClient(ParticleTypes.SMOKE, d, e, f, 0.0, 0.0, 0.0);
			world.addParticleClient(particle, d, e, f, 0.0, 0.0, 0.0);
		}
	}

	public static void addTrialOmenParticles(World world, BlockPos pos, Random random) {
		for (int i = 0; i < 20; i++) {
			double d = (double)pos.getX() + 0.5 + (random.nextDouble() - 0.5) * 2.0;
			double e = (double)pos.getY() + 0.5 + (random.nextDouble() - 0.5) * 2.0;
			double f = (double)pos.getZ() + 0.5 + (random.nextDouble() - 0.5) * 2.0;
			double g = random.nextGaussian() * 0.02;
			double h = random.nextGaussian() * 0.02;
			double j = random.nextGaussian() * 0.02;
			world.addParticleClient(ParticleTypes.TRIAL_OMEN, d, e, f, g, h, j);
			world.addParticleClient(ParticleTypes.SOUL_FIRE_FLAME, d, e, f, g, h, j);
		}
	}

	public static void addDetectionParticles(World world, BlockPos pos, Random random, int playerCount, ParticleEffect particle) {
		for (int j = 0; j < 30 + Math.min(playerCount, 10) * 5; j++) {
			double d = (double)(2.0F * random.nextFloat() - 1.0F) * 0.65;
			double e = (double)(2.0F * random.nextFloat() - 1.0F) * 0.65;
			double f = (double)pos.getX() + 0.5 + d;
			double g = (double)pos.getY() + 0.1 + (double)random.nextFloat() * 0.8;
			double h = (double)pos.getZ() + 0.5 + e;
			world.addParticleClient(particle, f, g, h, 0.0, 0.0, 0.0);
		}
	}

	public static void addEjectItemParticles(World world, BlockPos pos, Random random) {
		for (int i = 0; i < 20; i++) {
			double d = (double)pos.getX() + 0.4 + random.nextDouble() * 0.2;
			double e = (double)pos.getY() + 0.4 + random.nextDouble() * 0.2;
			double f = (double)pos.getZ() + 0.4 + random.nextDouble() * 0.2;
			double g = random.nextGaussian() * 0.02;
			double h = random.nextGaussian() * 0.02;
			double j = random.nextGaussian() * 0.02;
			world.addParticleClient(ParticleTypes.SMALL_FLAME, d, e, f, g, h, j * 0.25);
			world.addParticleClient(ParticleTypes.SMOKE, d, e, f, g, h, j);
		}
	}

	public void setEntityType(EntityType<?> entityType, World world) {
		this.data.reset();
		this.normalConfig = RegistryEntry.of(this.normalConfig.value().withSpawnPotential(entityType));
		this.ominousConfig = RegistryEntry.of(this.ominousConfig.value().withSpawnPotential(entityType));
		this.setSpawnerState(world, TrialSpawnerState.INACTIVE);
	}

	@Deprecated(
		forRemoval = true
	)
	@VisibleForTesting
	public void setEntityDetector(EntityDetector detector) {
		this.entityDetector = detector;
	}

	@Deprecated(
		forRemoval = true
	)
	@VisibleForTesting
	public void forceActivate() {
		this.forceActivate = true;
	}

	public interface TrialSpawner {
		void setSpawnerState(World world, TrialSpawnerState spawnerState);

		TrialSpawnerState getSpawnerState();

		void updateListeners();
	}

	public static enum Type {
		NORMAL(ParticleTypes.FLAME),
		OMINOUS(ParticleTypes.SOUL_FIRE_FLAME);

		public final SimpleParticleType particle;

		private Type(final SimpleParticleType particle) {
			this.particle = particle;
		}

		public static TrialSpawnerLogic.Type fromIndex(int index) {
			TrialSpawnerLogic.Type[] lvs = values();
			return index <= lvs.length && index >= 0 ? lvs[index] : NORMAL;
		}

		public int getIndex() {
			return this.ordinal();
		}
	}
}
