package net.minecraft.block.spawner;

import com.google.common.collect.Sets;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectListIterator;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import javax.annotation.Nullable;
import net.minecraft.block.enums.TrialSpawnerState;
import net.minecraft.block.spawner.TrialSpawnerLogic.Type;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.Entity.RemovalReason;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.loot.context.LootWorldContext;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtOps;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Util;
import net.minecraft.util.Uuids;
import net.minecraft.util.collection.Pool;
import net.minecraft.util.collection.Pool.Builder;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

public class TrialSpawnerData {
	public static final String SPAWN_DATA_KEY = "spawn_data";
	private static final String NEXT_MOB_SPAWNS_AT_KEY = "next_mob_spawns_at";
	private static final int field_50190 = 20;
	private static final int field_50191 = 18000;
	public static MapCodec<TrialSpawnerData> codec = RecordCodecBuilder.mapCodec(
		instance -> instance.group(
					Uuids.SET_CODEC.lenientOptionalFieldOf("registered_players", Sets.newHashSet()).forGetter(data -> data.players),
					Uuids.SET_CODEC.lenientOptionalFieldOf("current_mobs", Sets.newHashSet()).forGetter(data -> data.spawnedMobsAlive),
					Codec.LONG.lenientOptionalFieldOf("cooldown_ends_at", 0L).forGetter(data -> data.cooldownEnd),
					Codec.LONG.lenientOptionalFieldOf("next_mob_spawns_at", 0L).forGetter(data -> data.nextMobSpawnsAt),
					Codec.intRange(0, Integer.MAX_VALUE).lenientOptionalFieldOf("total_mobs_spawned", 0).forGetter(data -> data.totalSpawnedMobs),
					MobSpawnerEntry.CODEC.lenientOptionalFieldOf("spawn_data").forGetter(data -> data.spawnData),
					RegistryKey.createCodec(RegistryKeys.LOOT_TABLE).lenientOptionalFieldOf("ejecting_loot_table").forGetter(data -> data.rewardLootTable)
				)
				.apply(instance, TrialSpawnerData::new)
	);
	protected final Set<UUID> players = new HashSet();
	protected final Set<UUID> spawnedMobsAlive = new HashSet();
	protected long cooldownEnd;
	protected long nextMobSpawnsAt;
	protected int totalSpawnedMobs;
	protected Optional<MobSpawnerEntry> spawnData;
	protected Optional<RegistryKey<LootTable>> rewardLootTable;
	@Nullable
	protected Entity displayEntity;
	@Nullable
	private Pool<ItemStack> itemsToDropWhenOminous;
	protected double displayEntityRotation;
	protected double lastDisplayEntityRotation;

	public TrialSpawnerData() {
		this(Collections.emptySet(), Collections.emptySet(), 0L, 0L, 0, Optional.empty(), Optional.empty());
	}

	public TrialSpawnerData(
		Set<UUID> players,
		Set<UUID> spawnedMobsAlive,
		long cooldownEnd,
		long nextMobSpawnsAt,
		int totalSpawnedMobs,
		Optional<MobSpawnerEntry> spawnData,
		Optional<RegistryKey<LootTable>> rewardLootTable
	) {
		this.players.addAll(players);
		this.spawnedMobsAlive.addAll(spawnedMobsAlive);
		this.cooldownEnd = cooldownEnd;
		this.nextMobSpawnsAt = nextMobSpawnsAt;
		this.totalSpawnedMobs = totalSpawnedMobs;
		this.spawnData = spawnData;
		this.rewardLootTable = rewardLootTable;
	}

	public void reset() {
		this.spawnedMobsAlive.clear();
		this.spawnData = Optional.empty();
		this.deactivate();
	}

	public void deactivate() {
		this.players.clear();
		this.totalSpawnedMobs = 0;
		this.nextMobSpawnsAt = 0L;
		this.cooldownEnd = 0L;
	}

	public boolean hasSpawnData(TrialSpawnerLogic logic, Random random) {
		boolean bl = this.getSpawnData(logic, random).getNbt().contains("id", 8);
		return bl || !logic.getConfig().spawnPotentials().isEmpty();
	}

	public boolean hasSpawnedAllMobs(TrialSpawnerConfig config, int additionalPlayers) {
		return this.totalSpawnedMobs >= config.getTotalMobs(additionalPlayers);
	}

	public boolean areMobsDead() {
		return this.spawnedMobsAlive.isEmpty();
	}

	public boolean canSpawnMore(ServerWorld world, TrialSpawnerConfig config, int additionalPlayers) {
		return world.getTime() >= this.nextMobSpawnsAt && this.spawnedMobsAlive.size() < config.getSimultaneousMobs(additionalPlayers);
	}

	public int getAdditionalPlayers(BlockPos pos) {
		if (this.players.isEmpty()) {
			Util.logErrorOrPause("Trial Spawner at " + pos + " has no detected players");
		}

		return Math.max(0, this.players.size() - 1);
	}

	public void updatePlayers(ServerWorld world, BlockPos pos, TrialSpawnerLogic logic) {
		boolean bl = (pos.asLong() + world.getTime()) % 20L != 0L;
		if (!bl) {
			if (!logic.getSpawnerState().equals(TrialSpawnerState.COOLDOWN) || !logic.isOminous()) {
				List<UUID> list = logic.getEntityDetector().detect(world, logic.getEntitySelector(), pos, (double)logic.getDetectionRadius(), true);
				boolean bl2;
				if (!logic.isOminous() && !list.isEmpty()) {
					Optional<Pair<PlayerEntity, RegistryEntry<StatusEffect>>> optional = findPlayerWithOmen(world, list);
					optional.ifPresent(pair -> {
						PlayerEntity lv = (PlayerEntity)pair.getFirst();
						if (pair.getSecond() == StatusEffects.BAD_OMEN) {
							applyTrialOmen(lv);
						}

						world.syncWorldEvent(3020, BlockPos.ofFloored(lv.getEyePos()), 0);
						logic.setOminous(world, pos);
					});
					bl2 = optional.isPresent();
				} else {
					bl2 = false;
				}

				if (!logic.getSpawnerState().equals(TrialSpawnerState.COOLDOWN) || bl2) {
					boolean bl3 = logic.getData().players.isEmpty();
					List<UUID> list2 = bl3 ? list : logic.getEntityDetector().detect(world, logic.getEntitySelector(), pos, (double)logic.getDetectionRadius(), false);
					if (this.players.addAll(list2)) {
						this.nextMobSpawnsAt = Math.max(world.getTime() + 40L, this.nextMobSpawnsAt);
						if (!bl2) {
							int i = logic.isOminous() ? 3019 : 3013;
							world.syncWorldEvent(i, pos, this.players.size());
						}
					}
				}
			}
		}
	}

	private static Optional<Pair<PlayerEntity, RegistryEntry<StatusEffect>>> findPlayerWithOmen(ServerWorld world, List<UUID> players) {
		PlayerEntity lv = null;

		for (UUID uUID : players) {
			PlayerEntity lv2 = world.getPlayerByUuid(uUID);
			if (lv2 != null) {
				RegistryEntry<StatusEffect> lv3 = StatusEffects.TRIAL_OMEN;
				if (lv2.hasStatusEffect(lv3)) {
					return Optional.of(Pair.of(lv2, lv3));
				}

				if (lv2.hasStatusEffect(StatusEffects.BAD_OMEN)) {
					lv = lv2;
				}
			}
		}

		return Optional.ofNullable(lv).map(player -> Pair.of(player, StatusEffects.BAD_OMEN));
	}

	public void resetAndClearMobs(TrialSpawnerLogic logic, ServerWorld world) {
		this.spawnedMobsAlive.stream().map(world::getEntity).forEach(entity -> {
			if (entity != null) {
				world.syncWorldEvent(3012, entity.getBlockPos(), Type.NORMAL.getIndex());
				if (entity instanceof MobEntity lv) {
					lv.dropAllEquipment(world);
				}

				entity.remove(RemovalReason.DISCARDED);
			}
		});
		if (!logic.getOminousConfig().spawnPotentials().isEmpty()) {
			this.spawnData = Optional.empty();
		}

		this.totalSpawnedMobs = 0;
		this.spawnedMobsAlive.clear();
		this.nextMobSpawnsAt = world.getTime() + (long)logic.getOminousConfig().ticksBetweenSpawn();
		logic.updateListeners();
		this.cooldownEnd = world.getTime() + logic.getOminousConfig().getCooldownLength();
	}

	private static void applyTrialOmen(PlayerEntity player) {
		StatusEffectInstance lv = player.getStatusEffect(StatusEffects.BAD_OMEN);
		if (lv != null) {
			int i = lv.getAmplifier() + 1;
			int j = 18000 * i;
			player.removeStatusEffect(StatusEffects.BAD_OMEN);
			player.addStatusEffect(new StatusEffectInstance(StatusEffects.TRIAL_OMEN, j, 0));
		}
	}

	public boolean isCooldownPast(ServerWorld world, float f, int i) {
		long l = this.cooldownEnd - (long)i;
		return (float)world.getTime() >= (float)l + f;
	}

	public boolean isCooldownAtRepeating(ServerWorld world, float f, int i) {
		long l = this.cooldownEnd - (long)i;
		return (float)(world.getTime() - l) % f == 0.0F;
	}

	public boolean isCooldownOver(ServerWorld world) {
		return world.getTime() >= this.cooldownEnd;
	}

	protected MobSpawnerEntry getSpawnData(TrialSpawnerLogic logic, Random random) {
		if (this.spawnData.isPresent()) {
			return (MobSpawnerEntry)this.spawnData.get();
		} else {
			Pool<MobSpawnerEntry> lv = logic.getConfig().spawnPotentials();
			Optional<MobSpawnerEntry> optional = lv.isEmpty() ? this.spawnData : lv.getOrEmpty(random);
			this.spawnData = Optional.of((MobSpawnerEntry)optional.orElseGet(MobSpawnerEntry::new));
			logic.updateListeners();
			return (MobSpawnerEntry)this.spawnData.get();
		}
	}

	@Nullable
	public Entity setDisplayEntity(TrialSpawnerLogic logic, World world, TrialSpawnerState state) {
		if (!state.doesDisplayRotate()) {
			return null;
		} else {
			if (this.displayEntity == null) {
				NbtCompound lv = this.getSpawnData(logic, world.getRandom()).getNbt();
				if (lv.contains("id", 8)) {
					this.displayEntity = EntityType.loadEntityWithPassengers(lv, world, SpawnReason.TRIAL_SPAWNER, Function.identity());
				}
			}

			return this.displayEntity;
		}
	}

	public NbtCompound getSpawnDataNbt(TrialSpawnerState state) {
		NbtCompound lv = new NbtCompound();
		if (state == TrialSpawnerState.ACTIVE) {
			lv.putLong("next_mob_spawns_at", this.nextMobSpawnsAt);
		}

		this.spawnData
			.ifPresent(
				spawnData -> lv.put(
						"spawn_data",
						(NbtElement)MobSpawnerEntry.CODEC.encodeStart(NbtOps.INSTANCE, spawnData).result().orElseThrow(() -> new IllegalStateException("Invalid SpawnData"))
					)
			);
		return lv;
	}

	public double getDisplayEntityRotation() {
		return this.displayEntityRotation;
	}

	public double getLastDisplayEntityRotation() {
		return this.lastDisplayEntityRotation;
	}

	Pool<ItemStack> getItemsToDropWhenOminous(ServerWorld world, TrialSpawnerConfig config, BlockPos pos) {
		if (this.itemsToDropWhenOminous != null) {
			return this.itemsToDropWhenOminous;
		} else {
			LootTable lv = world.getServer().getReloadableRegistries().getLootTable(config.itemsToDropWhenOminous());
			LootWorldContext lv2 = new net.minecraft.loot.context.LootWorldContext.Builder(world).build(LootContextTypes.EMPTY);
			long l = getLootSeed(world, pos);
			ObjectArrayList<ItemStack> objectArrayList = lv.generateLoot(lv2, l);
			if (objectArrayList.isEmpty()) {
				return Pool.empty();
			} else {
				Builder<ItemStack> lv3 = Pool.builder();
				ObjectListIterator var10 = objectArrayList.iterator();

				while (var10.hasNext()) {
					ItemStack lv4 = (ItemStack)var10.next();
					lv3.add(lv4.copyWithCount(1), lv4.getCount());
				}

				this.itemsToDropWhenOminous = lv3.build();
				return this.itemsToDropWhenOminous;
			}
		}
	}

	private static long getLootSeed(ServerWorld world, BlockPos pos) {
		BlockPos lv = new BlockPos(
			MathHelper.floor((float)pos.getX() / 30.0F), MathHelper.floor((float)pos.getY() / 20.0F), MathHelper.floor((float)pos.getZ() / 30.0F)
		);
		return world.getSeed() + lv.asLong();
	}
}
