package net.minecraft.block.spawner;

import com.mojang.logging.LogUtils;
import java.util.Optional;
import java.util.function.Function;
import javax.annotation.Nullable;
import net.minecraft.block.spawner.MobSpawnerEntry.CustomSpawnRules;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtOps;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.TypeFilter;
import net.minecraft.util.collection.Pool;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Difficulty;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.slf4j.Logger;

public abstract class MobSpawnerLogic {
	public static final String SPAWN_DATA_KEY = "SpawnData";
	private static final Logger LOGGER = LogUtils.getLogger();
	private static final int field_30951 = 1;
	private int spawnDelay = 20;
	private Pool<MobSpawnerEntry> spawnPotentials = Pool.empty();
	@Nullable
	private MobSpawnerEntry spawnEntry;
	private double rotation;
	private double lastRotation;
	private int minSpawnDelay = 200;
	private int maxSpawnDelay = 800;
	private int spawnCount = 4;
	@Nullable
	private Entity renderedEntity;
	private int maxNearbyEntities = 6;
	private int requiredPlayerRange = 16;
	private int spawnRange = 4;

	public void setEntityId(EntityType<?> type, @Nullable World world, Random random, BlockPos pos) {
		this.getSpawnEntry(world, random, pos).getNbt().putString("id", Registries.ENTITY_TYPE.getId(type).toString());
	}

	private boolean isPlayerInRange(World world, BlockPos pos) {
		return world.isPlayerInRange((double)pos.getX() + 0.5, (double)pos.getY() + 0.5, (double)pos.getZ() + 0.5, (double)this.requiredPlayerRange);
	}

	public void clientTick(World world, BlockPos pos) {
		if (!this.isPlayerInRange(world, pos)) {
			this.lastRotation = this.rotation;
		} else if (this.renderedEntity != null) {
			Random lv = world.getRandom();
			double d = (double)pos.getX() + lv.nextDouble();
			double e = (double)pos.getY() + lv.nextDouble();
			double f = (double)pos.getZ() + lv.nextDouble();
			world.addParticleClient(ParticleTypes.SMOKE, d, e, f, 0.0, 0.0, 0.0);
			world.addParticleClient(ParticleTypes.FLAME, d, e, f, 0.0, 0.0, 0.0);
			if (this.spawnDelay > 0) {
				this.spawnDelay--;
			}

			this.lastRotation = this.rotation;
			this.rotation = (this.rotation + (double)(1000.0F / ((float)this.spawnDelay + 200.0F))) % 360.0;
		}
	}

	public void serverTick(ServerWorld world, BlockPos pos) {
		if (this.isPlayerInRange(world, pos)) {
			if (this.spawnDelay == -1) {
				this.updateSpawns(world, pos);
			}

			if (this.spawnDelay > 0) {
				this.spawnDelay--;
			} else {
				boolean bl = false;
				Random lv = world.getRandom();
				MobSpawnerEntry lv2 = this.getSpawnEntry(world, lv, pos);

				for (int i = 0; i < this.spawnCount; i++) {
					NbtCompound lv3 = lv2.getNbt();
					Optional<EntityType<?>> optional = EntityType.fromNbt(lv3);
					if (optional.isEmpty()) {
						this.updateSpawns(world, pos);
						return;
					}

					NbtList lv4 = lv3.getList("Pos", 6);
					int j = lv4.size();
					double d = j >= 1 ? lv4.getDouble(0) : (double)pos.getX() + (lv.nextDouble() - lv.nextDouble()) * (double)this.spawnRange + 0.5;
					double e = j >= 2 ? lv4.getDouble(1) : (double)(pos.getY() + lv.nextInt(3) - 1);
					double f = j >= 3 ? lv4.getDouble(2) : (double)pos.getZ() + (lv.nextDouble() - lv.nextDouble()) * (double)this.spawnRange + 0.5;
					if (world.isSpaceEmpty(((EntityType)optional.get()).getSpawnBox(d, e, f))) {
						BlockPos lv5 = BlockPos.ofFloored(d, e, f);
						if (lv2.getCustomSpawnRules().isPresent()) {
							if (!((EntityType)optional.get()).getSpawnGroup().isPeaceful() && world.getDifficulty() == Difficulty.PEACEFUL) {
								continue;
							}

							CustomSpawnRules lv6 = (CustomSpawnRules)lv2.getCustomSpawnRules().get();
							if (!lv6.canSpawn(lv5, world)) {
								continue;
							}
						} else if (!SpawnRestriction.canSpawn((EntityType)optional.get(), world, SpawnReason.SPAWNER, lv5, world.getRandom())) {
							continue;
						}

						Entity lv7 = EntityType.loadEntityWithPassengers(lv3, world, SpawnReason.SPAWNER, entity -> {
							entity.refreshPositionAndAngles(d, e, f, entity.getYaw(), entity.getPitch());
							return entity;
						});
						if (lv7 == null) {
							this.updateSpawns(world, pos);
							return;
						}

						int k = world.getEntitiesByType(
								TypeFilter.equals(lv7.getClass()),
								new Box((double)pos.getX(), (double)pos.getY(), (double)pos.getZ(), (double)(pos.getX() + 1), (double)(pos.getY() + 1), (double)(pos.getZ() + 1))
									.expand((double)this.spawnRange),
								EntityPredicates.EXCEPT_SPECTATOR
							)
							.size();
						if (k >= this.maxNearbyEntities) {
							this.updateSpawns(world, pos);
							return;
						}

						lv7.refreshPositionAndAngles(lv7.getX(), lv7.getY(), lv7.getZ(), lv.nextFloat() * 360.0F, 0.0F);
						if (lv7 instanceof MobEntity lv8) {
							if (lv2.getCustomSpawnRules().isEmpty() && !lv8.canSpawn(world, SpawnReason.SPAWNER) || !lv8.canSpawn(world)) {
								continue;
							}

							boolean bl2 = lv2.getNbt().getSize() == 1 && lv2.getNbt().contains("id", 8);
							if (bl2) {
								((MobEntity)lv7).initialize(world, world.getLocalDifficulty(lv7.getBlockPos()), SpawnReason.SPAWNER, null);
							}

							lv2.getEquipment().ifPresent(lv8::setEquipmentFromTable);
						}

						if (!world.spawnNewEntityAndPassengers(lv7)) {
							this.updateSpawns(world, pos);
							return;
						}

						world.syncWorldEvent(2004, pos, 0);
						world.emitGameEvent(lv7, GameEvent.ENTITY_PLACE, lv5);
						if (lv7 instanceof MobEntity) {
							((MobEntity)lv7).playSpawnEffects();
						}

						bl = true;
					}
				}

				if (bl) {
					this.updateSpawns(world, pos);
				}
			}
		}
	}

	private void updateSpawns(World world, BlockPos pos) {
		Random lv = world.random;
		if (this.maxSpawnDelay <= this.minSpawnDelay) {
			this.spawnDelay = this.minSpawnDelay;
		} else {
			this.spawnDelay = this.minSpawnDelay + lv.nextInt(this.maxSpawnDelay - this.minSpawnDelay);
		}

		this.spawnPotentials.getOrEmpty(lv).ifPresent(spawnPotential -> this.setSpawnEntry(world, pos, spawnPotential));
		this.sendStatus(world, pos, 1);
	}

	public void readNbt(@Nullable World world, BlockPos pos, NbtCompound nbt) {
		this.spawnDelay = nbt.getShort("Delay");
		boolean bl = nbt.contains("SpawnData", 10);
		if (bl) {
			MobSpawnerEntry lv = (MobSpawnerEntry)MobSpawnerEntry.CODEC
				.parse(NbtOps.INSTANCE, nbt.getCompound("SpawnData"))
				.resultOrPartial(error -> LOGGER.warn("Invalid SpawnData: {}", error))
				.orElseGet(MobSpawnerEntry::new);
			this.setSpawnEntry(world, pos, lv);
		}

		boolean bl2 = nbt.contains("SpawnPotentials", 9);
		if (bl2) {
			NbtList lv2 = nbt.getList("SpawnPotentials", 10);
			this.spawnPotentials = (Pool<MobSpawnerEntry>)MobSpawnerEntry.DATA_POOL_CODEC
				.parse(NbtOps.INSTANCE, lv2)
				.resultOrPartial(error -> LOGGER.warn("Invalid SpawnPotentials list: {}", error))
				.orElseGet(Pool::empty);
		} else {
			this.spawnPotentials = Pool.of(this.spawnEntry != null ? this.spawnEntry : new MobSpawnerEntry());
		}

		if (nbt.contains("MinSpawnDelay", 99)) {
			this.minSpawnDelay = nbt.getShort("MinSpawnDelay");
			this.maxSpawnDelay = nbt.getShort("MaxSpawnDelay");
			this.spawnCount = nbt.getShort("SpawnCount");
		}

		if (nbt.contains("MaxNearbyEntities", 99)) {
			this.maxNearbyEntities = nbt.getShort("MaxNearbyEntities");
			this.requiredPlayerRange = nbt.getShort("RequiredPlayerRange");
		}

		if (nbt.contains("SpawnRange", 99)) {
			this.spawnRange = nbt.getShort("SpawnRange");
		}

		this.renderedEntity = null;
	}

	public NbtCompound writeNbt(NbtCompound nbt) {
		nbt.putShort("Delay", (short)this.spawnDelay);
		nbt.putShort("MinSpawnDelay", (short)this.minSpawnDelay);
		nbt.putShort("MaxSpawnDelay", (short)this.maxSpawnDelay);
		nbt.putShort("SpawnCount", (short)this.spawnCount);
		nbt.putShort("MaxNearbyEntities", (short)this.maxNearbyEntities);
		nbt.putShort("RequiredPlayerRange", (short)this.requiredPlayerRange);
		nbt.putShort("SpawnRange", (short)this.spawnRange);
		if (this.spawnEntry != null) {
			nbt.put(
				"SpawnData",
				(NbtElement)MobSpawnerEntry.CODEC
					.encodeStart(NbtOps.INSTANCE, this.spawnEntry)
					.getOrThrow(string -> new IllegalStateException("Invalid SpawnData: " + string))
			);
		}

		nbt.put("SpawnPotentials", (NbtElement)MobSpawnerEntry.DATA_POOL_CODEC.encodeStart(NbtOps.INSTANCE, this.spawnPotentials).getOrThrow());
		return nbt;
	}

	@Nullable
	public Entity getRenderedEntity(World world, BlockPos pos) {
		if (this.renderedEntity == null) {
			NbtCompound lv = this.getSpawnEntry(world, world.getRandom(), pos).getNbt();
			if (!lv.contains("id", 8)) {
				return null;
			}

			this.renderedEntity = EntityType.loadEntityWithPassengers(lv, world, SpawnReason.SPAWNER, Function.identity());
			if (lv.getSize() == 1 && this.renderedEntity instanceof MobEntity) {
			}
		}

		return this.renderedEntity;
	}

	public boolean handleStatus(World world, int status) {
		if (status == 1) {
			if (world.isClient) {
				this.spawnDelay = this.minSpawnDelay;
			}

			return true;
		} else {
			return false;
		}
	}

	protected void setSpawnEntry(@Nullable World world, BlockPos pos, MobSpawnerEntry spawnEntry) {
		this.spawnEntry = spawnEntry;
	}

	private MobSpawnerEntry getSpawnEntry(@Nullable World world, Random random, BlockPos pos) {
		if (this.spawnEntry != null) {
			return this.spawnEntry;
		} else {
			this.setSpawnEntry(world, pos, (MobSpawnerEntry)this.spawnPotentials.getOrEmpty(random).orElseGet(MobSpawnerEntry::new));
			return this.spawnEntry;
		}
	}

	public abstract void sendStatus(World world, BlockPos pos, int status);

	public double getRotation() {
		return this.rotation;
	}

	public double getLastRotation() {
		return this.lastRotation;
	}
}
