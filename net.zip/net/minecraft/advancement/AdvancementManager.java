package net.minecraft.advancement;

import com.mojang.logging.LogUtils;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;

public class AdvancementManager {
	private static final Logger LOGGER = LogUtils.getLogger();
	private final Map<Identifier, PlacedAdvancement> advancements = new Object2ObjectOpenHashMap();
	private final Set<PlacedAdvancement> roots = new ObjectLinkedOpenHashSet();
	private final Set<PlacedAdvancement> dependents = new ObjectLinkedOpenHashSet();
	@Nullable
	private AdvancementManager.Listener listener;

	private void remove(PlacedAdvancement advancement) {
		for (PlacedAdvancement lv : advancement.getChildren()) {
			this.remove(lv);
		}

		LOGGER.info("Forgot about advancement {}", advancement.getAdvancementEntry());
		this.advancements.remove(advancement.getAdvancementEntry().id());
		if (advancement.getParent() == null) {
			this.roots.remove(advancement);
			if (this.listener != null) {
				this.listener.onRootRemoved(advancement);
			}
		} else {
			this.dependents.remove(advancement);
			if (this.listener != null) {
				this.listener.onDependentRemoved(advancement);
			}
		}
	}

	public void removeAll(Set<Identifier> advancements) {
		for (Identifier lv : advancements) {
			PlacedAdvancement lv2 = (PlacedAdvancement)this.advancements.get(lv);
			if (lv2 == null) {
				LOGGER.warn("Told to remove advancement {} but I don't know what that is", lv);
			} else {
				this.remove(lv2);
			}
		}
	}

	public void addAll(Collection<AdvancementEntry> advancements) {
		List<AdvancementEntry> list = new ArrayList(advancements);

		while (!list.isEmpty()) {
			if (!list.removeIf(this::tryAdd)) {
				LOGGER.error("Couldn't load advancements: {}", list);
				break;
			}
		}

		LOGGER.info("Loaded {} advancements", this.advancements.size());
	}

	private boolean tryAdd(AdvancementEntry advancement) {
		Optional<Identifier> optional = advancement.value().parent();
		PlacedAdvancement lv = (PlacedAdvancement)optional.map(this.advancements::get).orElse(null);
		if (lv == null && optional.isPresent()) {
			return false;
		} else {
			PlacedAdvancement lv2 = new PlacedAdvancement(advancement, lv);
			if (lv != null) {
				lv.addChild(lv2);
			}

			this.advancements.put(advancement.id(), lv2);
			if (lv == null) {
				this.roots.add(lv2);
				if (this.listener != null) {
					this.listener.onRootAdded(lv2);
				}
			} else {
				this.dependents.add(lv2);
				if (this.listener != null) {
					this.listener.onDependentAdded(lv2);
				}
			}

			return true;
		}
	}

	public void clear() {
		this.advancements.clear();
		this.roots.clear();
		this.dependents.clear();
		if (this.listener != null) {
			this.listener.onClear();
		}
	}

	public Iterable<PlacedAdvancement> getRoots() {
		return this.roots;
	}

	public Collection<PlacedAdvancement> getAdvancements() {
		return this.advancements.values();
	}

	@Nullable
	public PlacedAdvancement get(Identifier id) {
		return (PlacedAdvancement)this.advancements.get(id);
	}

	@Nullable
	public PlacedAdvancement get(AdvancementEntry advancement) {
		return (PlacedAdvancement)this.advancements.get(advancement.id());
	}

	public void setListener(@Nullable AdvancementManager.Listener listener) {
		this.listener = listener;
		if (listener != null) {
			for (PlacedAdvancement lv : this.roots) {
				listener.onRootAdded(lv);
			}

			for (PlacedAdvancement lv : this.dependents) {
				listener.onDependentAdded(lv);
			}
		}
	}

	public interface Listener {
		void onRootAdded(PlacedAdvancement root);

		void onRootRemoved(PlacedAdvancement root);

		void onDependentAdded(PlacedAdvancement dependent);

		void onDependentRemoved(PlacedAdvancement dependent);

		void onClear();
	}
}
