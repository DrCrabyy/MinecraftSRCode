package net.minecraft.advancement;

import com.google.common.annotations.VisibleForTesting;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import java.util.Set;
import javax.annotation.Nullable;

public class PlacedAdvancement {
	private final AdvancementEntry advancementEntry;
	@Nullable
	private final PlacedAdvancement parent;
	private final Set<PlacedAdvancement> children = new ReferenceOpenHashSet();

	@VisibleForTesting
	public PlacedAdvancement(AdvancementEntry advancementEntry, @Nullable PlacedAdvancement parent) {
		this.advancementEntry = advancementEntry;
		this.parent = parent;
	}

	public Advancement getAdvancement() {
		return this.advancementEntry.value();
	}

	public AdvancementEntry getAdvancementEntry() {
		return this.advancementEntry;
	}

	@Nullable
	public PlacedAdvancement getParent() {
		return this.parent;
	}

	public PlacedAdvancement getRoot() {
		return findRoot(this);
	}

	public static PlacedAdvancement findRoot(PlacedAdvancement advancement) {
		PlacedAdvancement lv = advancement;

		while (true) {
			PlacedAdvancement lv2 = lv.getParent();
			if (lv2 == null) {
				return lv;
			}

			lv = lv2;
		}
	}

	public Iterable<PlacedAdvancement> getChildren() {
		return this.children;
	}

	@VisibleForTesting
	public void addChild(PlacedAdvancement advancement) {
		this.children.add(advancement);
	}

	public boolean equals(Object o) {
		if (this == o) {
			return true;
		} else {
			if (o instanceof PlacedAdvancement lv && this.advancementEntry.equals(lv.advancementEntry)) {
				return true;
			}

			return false;
		}
	}

	public int hashCode() {
		return this.advancementEntry.hashCode();
	}

	public String toString() {
		return this.advancementEntry.id().toString();
	}
}
