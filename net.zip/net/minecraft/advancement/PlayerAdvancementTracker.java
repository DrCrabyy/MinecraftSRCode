package net.minecraft.advancement;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonParseException;
import com.google.gson.internal.Streams;
import com.google.gson.stream.JsonReader;
import com.mojang.datafixers.DataFixer;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.BiConsumer;
import javax.annotation.Nullable;
import net.minecraft.advancement.criterion.Criterion;
import net.minecraft.advancement.criterion.CriterionConditions;
import net.minecraft.advancement.criterion.CriterionProgress;
import net.minecraft.advancement.criterion.Criterion.ConditionsContainer;
import net.minecraft.datafixer.DataFixTypes;
import net.minecraft.network.packet.s2c.play.SelectAdvancementTabS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.server.PlayerManager;
import net.minecraft.server.ServerAdvancementLoader;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.PathUtil;
import net.minecraft.world.GameRules;
import org.slf4j.Logger;

public class PlayerAdvancementTracker {
	private static final Logger LOGGER = LogUtils.getLogger();
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private final PlayerManager playerManager;
	private final Path filePath;
	private AdvancementManager advancementManager;
	private final Map<AdvancementEntry, AdvancementProgress> progress = new LinkedHashMap();
	private final Set<AdvancementEntry> visibleAdvancements = new HashSet();
	private final Set<AdvancementEntry> progressUpdates = new HashSet();
	private final Set<PlacedAdvancement> updatedRoots = new HashSet();
	private ServerPlayerEntity owner;
	@Nullable
	private AdvancementEntry currentDisplayTab;
	private boolean dirty = true;
	private final Codec<PlayerAdvancementTracker.ProgressMap> progressMapCodec;

	public PlayerAdvancementTracker(
		DataFixer dataFixer, PlayerManager playerManager, ServerAdvancementLoader advancementLoader, Path filePath, ServerPlayerEntity owner
	) {
		this.playerManager = playerManager;
		this.filePath = filePath;
		this.owner = owner;
		this.advancementManager = advancementLoader.getManager();
		int i = 1343;
		this.progressMapCodec = DataFixTypes.ADVANCEMENTS.createDataFixingCodec(PlayerAdvancementTracker.ProgressMap.CODEC, dataFixer, 1343);
		this.load(advancementLoader);
	}

	public void setOwner(ServerPlayerEntity owner) {
		this.owner = owner;
	}

	public void clearCriteria() {
		for (Criterion<?> lv : Registries.CRITERION) {
			lv.endTracking(this);
		}
	}

	public void reload(ServerAdvancementLoader advancementLoader) {
		this.clearCriteria();
		this.progress.clear();
		this.visibleAdvancements.clear();
		this.updatedRoots.clear();
		this.progressUpdates.clear();
		this.dirty = true;
		this.currentDisplayTab = null;
		this.advancementManager = advancementLoader.getManager();
		this.load(advancementLoader);
	}

	private void beginTrackingAllAdvancements(ServerAdvancementLoader advancementLoader) {
		for (AdvancementEntry lv : advancementLoader.getAdvancements()) {
			this.beginTracking(lv);
		}
	}

	private void rewardEmptyAdvancements(ServerAdvancementLoader advancementLoader) {
		for (AdvancementEntry lv : advancementLoader.getAdvancements()) {
			Advancement lv2 = lv.value();
			if (lv2.criteria().isEmpty()) {
				this.grantCriterion(lv, "");
				lv2.rewards().apply(this.owner);
			}
		}
	}

	private void load(ServerAdvancementLoader advancementLoader) {
		if (Files.isRegularFile(this.filePath, new LinkOption[0])) {
			try {
				JsonReader jsonReader = new JsonReader(Files.newBufferedReader(this.filePath, StandardCharsets.UTF_8));

				try {
					jsonReader.setLenient(false);
					JsonElement jsonElement = Streams.parse(jsonReader);
					PlayerAdvancementTracker.ProgressMap lv = (PlayerAdvancementTracker.ProgressMap)this.progressMapCodec
						.parse(JsonOps.INSTANCE, jsonElement)
						.getOrThrow(JsonParseException::new);
					this.loadProgressMap(advancementLoader, lv);
				} catch (Throwable var6) {
					try {
						jsonReader.close();
					} catch (Throwable var5) {
						var6.addSuppressed(var5);
					}

					throw var6;
				}

				jsonReader.close();
			} catch (JsonIOException | IOException var7) {
				LOGGER.error("Couldn't access player advancements in {}", this.filePath, var7);
			} catch (JsonParseException var8) {
				LOGGER.error("Couldn't parse player advancements in {}", this.filePath, var8);
			}
		}

		this.rewardEmptyAdvancements(advancementLoader);
		this.beginTrackingAllAdvancements(advancementLoader);
	}

	public void save() {
		JsonElement jsonElement = (JsonElement)this.progressMapCodec.encodeStart(JsonOps.INSTANCE, this.createProgressMap()).getOrThrow();

		try {
			PathUtil.createDirectories(this.filePath.getParent());
			Writer writer = Files.newBufferedWriter(this.filePath, StandardCharsets.UTF_8);

			try {
				GSON.toJson(jsonElement, GSON.newJsonWriter(writer));
			} catch (Throwable var6) {
				if (writer != null) {
					try {
						writer.close();
					} catch (Throwable var5) {
						var6.addSuppressed(var5);
					}
				}

				throw var6;
			}

			if (writer != null) {
				writer.close();
			}
		} catch (JsonIOException | IOException var7) {
			LOGGER.error("Couldn't save player advancements to {}", this.filePath, var7);
		}
	}

	private void loadProgressMap(ServerAdvancementLoader loader, PlayerAdvancementTracker.ProgressMap progressMap) {
		progressMap.forEach((id, progress) -> {
			AdvancementEntry lv = loader.get(id);
			if (lv == null) {
				LOGGER.warn("Ignored advancement '{}' in progress file {} - it doesn't exist anymore?", id, this.filePath);
			} else {
				this.initProgress(lv, progress);
				this.progressUpdates.add(lv);
				this.onStatusUpdate(lv);
			}
		});
	}

	private PlayerAdvancementTracker.ProgressMap createProgressMap() {
		Map<Identifier, AdvancementProgress> map = new LinkedHashMap();
		this.progress.forEach((entry, progress) -> {
			if (progress.isAnyObtained()) {
				map.put(entry.id(), progress);
			}
		});
		return new PlayerAdvancementTracker.ProgressMap(map);
	}

	public boolean grantCriterion(AdvancementEntry advancement, String criterionName) {
		boolean bl = false;
		AdvancementProgress lv = this.getProgress(advancement);
		boolean bl2 = lv.isDone();
		if (lv.obtain(criterionName)) {
			this.endTrackingCompleted(advancement);
			this.progressUpdates.add(advancement);
			bl = true;
			if (!bl2 && lv.isDone()) {
				advancement.value().rewards().apply(this.owner);
				advancement.value().display().ifPresent(display -> {
					if (display.shouldAnnounceToChat() && this.owner.getServerWorld().getGameRules().getBoolean(GameRules.ANNOUNCE_ADVANCEMENTS)) {
						this.playerManager.broadcast(display.getFrame().getChatAnnouncementText(advancement, this.owner), false);
					}
				});
			}
		}

		if (!bl2 && lv.isDone()) {
			this.onStatusUpdate(advancement);
		}

		return bl;
	}

	public boolean revokeCriterion(AdvancementEntry advancement, String criterionName) {
		boolean bl = false;
		AdvancementProgress lv = this.getProgress(advancement);
		boolean bl2 = lv.isDone();
		if (lv.reset(criterionName)) {
			this.beginTracking(advancement);
			this.progressUpdates.add(advancement);
			bl = true;
		}

		if (bl2 && !lv.isDone()) {
			this.onStatusUpdate(advancement);
		}

		return bl;
	}

	private void onStatusUpdate(AdvancementEntry advancement) {
		PlacedAdvancement lv = this.advancementManager.get(advancement);
		if (lv != null) {
			this.updatedRoots.add(lv.getRoot());
		}
	}

	private void beginTracking(AdvancementEntry advancement) {
		AdvancementProgress lv = this.getProgress(advancement);
		if (!lv.isDone()) {
			for (Entry<String, AdvancementCriterion<?>> entry : advancement.value().criteria().entrySet()) {
				CriterionProgress lv2 = lv.getCriterionProgress((String)entry.getKey());
				if (lv2 != null && !lv2.isObtained()) {
					this.beginTracking(advancement, (String)entry.getKey(), (AdvancementCriterion)entry.getValue());
				}
			}
		}
	}

	private <T extends CriterionConditions> void beginTracking(AdvancementEntry advancement, String id, AdvancementCriterion<T> criterion) {
		criterion.trigger().beginTrackingCondition(this, new ConditionsContainer<>(criterion.conditions(), advancement, id));
	}

	private void endTrackingCompleted(AdvancementEntry advancement) {
		AdvancementProgress lv = this.getProgress(advancement);

		for (Entry<String, AdvancementCriterion<?>> entry : advancement.value().criteria().entrySet()) {
			CriterionProgress lv2 = lv.getCriterionProgress((String)entry.getKey());
			if (lv2 != null && (lv2.isObtained() || lv.isDone())) {
				this.endTrackingCompleted(advancement, (String)entry.getKey(), (AdvancementCriterion)entry.getValue());
			}
		}
	}

	private <T extends CriterionConditions> void endTrackingCompleted(AdvancementEntry advancement, String id, AdvancementCriterion<T> criterion) {
		criterion.trigger().endTrackingCondition(this, new ConditionsContainer<>(criterion.conditions(), advancement, id));
	}

	public void sendUpdate(ServerPlayerEntity player, boolean showToast) {
		// $VF: Couldn't be decompiled
		// Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
		//
		// Bytecode:
		// 00: aload 0
		// 01: getfield net/minecraft/advancement/PlayerAdvancementTracker.dirty Z
		// 04: ifne 1f
		// 07: aload 0
		// 08: getfield net/minecraft/advancement/PlayerAdvancementTracker.updatedRoots Ljava/util/Set;
		// 0b: invokeinterface java/util/Set.isEmpty ()Z 1
		// 10: ifeq 1f
		// 13: aload 0
		// 14: getfield net/minecraft/advancement/PlayerAdvancementTracker.progressUpdates Ljava/util/Set;
		// 17: invokeinterface java/util/Set.isEmpty ()Z 1
		// 1c: ifne fa
		// 1f: new java/util/HashMap
		// 22: dup
		// 23: invokespecial java/util/HashMap.<init> ()V
		// 26: astore 3
		// 27: new java/util/HashSet
		// 2a: dup
		// 2b: invokespecial java/util/HashSet.<init> ()V
		// 2e: astore 4
		// 30: new java/util/HashSet
		// 33: dup
		// 34: invokespecial java/util/HashSet.<init> ()V
		// 37: astore 5
		// 39: aload 0
		// 3a: getfield net/minecraft/advancement/PlayerAdvancementTracker.updatedRoots Ljava/util/Set;
		// 3d: invokeinterface java/util/Set.iterator ()Ljava/util/Iterator; 1
		// 42: astore 6
		// 44: aload 6
		// 46: invokeinterface java/util/Iterator.hasNext ()Z 1
		// 4b: ifeq 67
		// 4e: aload 6
		// 50: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
		// 55: checkcast net/minecraft/advancement/PlacedAdvancement
		// 58: astore 7
		// 5a: aload 0
		// 5b: aload 7
		// 5d: aload 4
		// 5f: aload 5
		// 61: invokevirtual net/minecraft/advancement/PlayerAdvancementTracker.calculateDisplay (Lnet/minecraft/advancement/PlacedAdvancement;Ljava/util/Set;Ljava/util/Set;)V
		// 64: goto 44
		// 67: aload 0
		// 68: getfield net/minecraft/advancement/PlayerAdvancementTracker.updatedRoots Ljava/util/Set;
		// 6b: invokeinterface java/util/Set.clear ()V 1
		// 70: aload 0
		// 71: getfield net/minecraft/advancement/PlayerAdvancementTracker.progressUpdates Ljava/util/Set;
		// 74: invokeinterface java/util/Set.iterator ()Ljava/util/Iterator; 1
		// 79: astore 6
		// 7b: aload 6
		// 7d: invokeinterface java/util/Iterator.hasNext ()Z 1
		// 82: ifeq bc
		// 85: aload 6
		// 87: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
		// 8c: checkcast net/minecraft/advancement/AdvancementEntry
		// 8f: astore 7
		// 91: aload 0
		// 92: getfield net/minecraft/advancement/PlayerAdvancementTracker.visibleAdvancements Ljava/util/Set;
		// 95: aload 7
		// 97: invokeinterface java/util/Set.contains (Ljava/lang/Object;)Z 2
		// 9c: ifeq b9
		// 9f: aload 3
		// a0: aload 7
		// a2: invokevirtual net/minecraft/advancement/AdvancementEntry.id ()Lnet/minecraft/util/Identifier;
		// a5: aload 0
		// a6: getfield net/minecraft/advancement/PlayerAdvancementTracker.progress Ljava/util/Map;
		// a9: aload 7
		// ab: invokeinterface java/util/Map.get (Ljava/lang/Object;)Ljava/lang/Object; 2
		// b0: checkcast net/minecraft/advancement/AdvancementProgress
		// b3: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
		// b8: pop
		// b9: goto 7b
		// bc: aload 0
		// bd: getfield net/minecraft/advancement/PlayerAdvancementTracker.progressUpdates Ljava/util/Set;
		// c0: invokeinterface java/util/Set.clear ()V 1
		// c5: aload 3
		// c6: invokeinterface java/util/Map.isEmpty ()Z 1
		// cb: ifeq e2
		// ce: aload 4
		// d0: invokeinterface java/util/Set.isEmpty ()Z 1
		// d5: ifeq e2
		// d8: aload 5
		// da: invokeinterface java/util/Set.isEmpty ()Z 1
		// df: ifne fa
		// e2: aload 1
		// e3: getfield net/minecraft/server/network/ServerPlayerEntity.networkHandler Lnet/minecraft/server/network/ServerPlayNetworkHandler;
		// e6: new net/minecraft/network/packet/s2c/play/AdvancementUpdateS2CPacket
		// e9: dup
		// ea: aload 0
		// eb: getfield net/minecraft/advancement/PlayerAdvancementTracker.dirty Z
		// ee: aload 4
		// f0: aload 5
		// f2: aload 3
		// f3: iload 2
		// f4: invokespecial net/minecraft/network/packet/s2c/play/AdvancementUpdateS2CPacket.<init> (ZLjava/util/Collection;Ljava/util/Set;Ljava/util/Map;Z)V
		// f7: invokevirtual net/minecraft/server/network/ServerPlayNetworkHandler.sendPacket (Lnet/minecraft/network/packet/Packet;)V
		// fa: aload 0
		// fb: bipush 0
		// fc: putfield net/minecraft/advancement/PlayerAdvancementTracker.dirty Z
		// ff: return
	}

	public void setDisplayTab(@Nullable AdvancementEntry advancement) {
		AdvancementEntry lv = this.currentDisplayTab;
		if (advancement != null && advancement.value().isRoot() && advancement.value().display().isPresent()) {
			this.currentDisplayTab = advancement;
		} else {
			this.currentDisplayTab = null;
		}

		if (lv != this.currentDisplayTab) {
			this.owner.networkHandler.sendPacket(new SelectAdvancementTabS2CPacket(this.currentDisplayTab == null ? null : this.currentDisplayTab.id()));
		}
	}

	public AdvancementProgress getProgress(AdvancementEntry advancement) {
		AdvancementProgress lv = (AdvancementProgress)this.progress.get(advancement);
		if (lv == null) {
			lv = new AdvancementProgress();
			this.initProgress(advancement, lv);
		}

		return lv;
	}

	private void initProgress(AdvancementEntry advancement, AdvancementProgress progress) {
		progress.init(advancement.value().requirements());
		this.progress.put(advancement, progress);
	}

	private void calculateDisplay(PlacedAdvancement root, Set<AdvancementEntry> added, Set<Identifier> removed) {
		AdvancementDisplays.calculateDisplay(root, advancement -> this.getProgress(advancement.getAdvancementEntry()).isDone(), (advancement, displayed) -> {
			AdvancementEntry lv = advancement.getAdvancementEntry();
			if (displayed) {
				if (this.visibleAdvancements.add(lv)) {
					added.add(lv);
					if (this.progress.containsKey(lv)) {
						this.progressUpdates.add(lv);
					}
				}
			} else if (this.visibleAdvancements.remove(lv)) {
				removed.add(lv.id());
			}
		});
	}

	static record ProgressMap(Map<Identifier, AdvancementProgress> map) {
		public static final Codec<PlayerAdvancementTracker.ProgressMap> CODEC = Codec.unboundedMap(Identifier.CODEC, AdvancementProgress.CODEC)
			.xmap(PlayerAdvancementTracker.ProgressMap::new, PlayerAdvancementTracker.ProgressMap::map);

		public void forEach(BiConsumer<Identifier, AdvancementProgress> consumer) {
			this.map
				.entrySet()
				.stream()
				.sorted(Entry.comparingByValue())
				.forEach(entry -> consumer.accept((Identifier)entry.getKey(), (AdvancementProgress)entry.getValue()));
		}
	}
}
