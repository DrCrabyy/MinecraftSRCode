package net.minecraft.advancement.criterion;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.advancement.AdvancementCriterion;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.predicate.ComponentPredicate;
import net.minecraft.predicate.NumberRange.IntRange;
import net.minecraft.predicate.entity.EntityPredicate;
import net.minecraft.predicate.entity.LootContextPredicate;
import net.minecraft.predicate.item.ItemPredicate;
import net.minecraft.predicate.item.ItemPredicate.Builder;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.server.network.ServerPlayerEntity;

public class InventoryChangedCriterion extends AbstractCriterion<InventoryChangedCriterion.Conditions> {
	@Override
	public Codec<InventoryChangedCriterion.Conditions> getConditionsCodec() {
		return InventoryChangedCriterion.Conditions.CODEC;
	}

	public void trigger(ServerPlayerEntity player, PlayerInventory inventory, ItemStack stack) {
		int i = 0;
		int j = 0;
		int k = 0;

		for (int l = 0; l < inventory.size(); l++) {
			ItemStack lv = inventory.getStack(l);
			if (lv.isEmpty()) {
				j++;
			} else {
				k++;
				if (lv.getCount() >= lv.getMaxCount()) {
					i++;
				}
			}
		}

		this.trigger(player, inventory, stack, i, j, k);
	}

	private void trigger(ServerPlayerEntity player, PlayerInventory inventory, ItemStack stack, int full, int empty, int occupied) {
		this.trigger(player, conditions -> conditions.matches(inventory, stack, full, empty, occupied));
	}

	public static record Conditions(Optional<LootContextPredicate> player, InventoryChangedCriterion.Conditions.Slots slots, List<ItemPredicate> items)
		implements net.minecraft.advancement.criterion.AbstractCriterion.Conditions {
		public static final Codec<InventoryChangedCriterion.Conditions> CODEC = RecordCodecBuilder.create(
			instance -> instance.group(
						EntityPredicate.LOOT_CONTEXT_PREDICATE_CODEC.optionalFieldOf("player").forGetter(InventoryChangedCriterion.Conditions::player),
						InventoryChangedCriterion.Conditions.Slots.CODEC
							.optionalFieldOf("slots", InventoryChangedCriterion.Conditions.Slots.ANY)
							.forGetter(InventoryChangedCriterion.Conditions::slots),
						ItemPredicate.CODEC.listOf().optionalFieldOf("items", List.of()).forGetter(InventoryChangedCriterion.Conditions::items)
					)
					.apply(instance, InventoryChangedCriterion.Conditions::new)
		);

		public static AdvancementCriterion<InventoryChangedCriterion.Conditions> items(Builder... items) {
			return items((ItemPredicate[])Stream.of(items).map(Builder::build).toArray(ItemPredicate[]::new));
		}

		public static AdvancementCriterion<InventoryChangedCriterion.Conditions> items(ItemPredicate... items) {
			return Criteria.INVENTORY_CHANGED
				.create(new InventoryChangedCriterion.Conditions(Optional.empty(), InventoryChangedCriterion.Conditions.Slots.ANY, List.of(items)));
		}

		public static AdvancementCriterion<InventoryChangedCriterion.Conditions> items(ItemConvertible... items) {
			ItemPredicate[] lvs = new ItemPredicate[items.length];

			for (int i = 0; i < items.length; i++) {
				lvs[i] = new ItemPredicate(Optional.of(RegistryEntryList.of(items[i].asItem().getRegistryEntry())), IntRange.ANY, ComponentPredicate.EMPTY, Map.of());
			}

			return items(lvs);
		}

		public boolean matches(PlayerInventory inventory, ItemStack stack, int full, int empty, int occupied) {
			if (!this.slots.test(full, empty, occupied)) {
				return false;
			} else if (this.items.isEmpty()) {
				return true;
			} else if (this.items.size() != 1) {
				List<ItemPredicate> list = new ObjectArrayList(this.items);
				int l = inventory.size();

				for (int m = 0; m < l; m++) {
					if (list.isEmpty()) {
						return true;
					}

					ItemStack lv = inventory.getStack(m);
					if (!lv.isEmpty()) {
						list.removeIf(item -> item.method_8970(lv));
					}
				}

				return list.isEmpty();
			} else {
				return !stack.isEmpty() && ((ItemPredicate)this.items.get(0)).method_8970(stack);
			}
		}

		public static record Slots(IntRange occupied, IntRange full, IntRange empty) {
			public static final Codec<InventoryChangedCriterion.Conditions.Slots> CODEC = RecordCodecBuilder.create(
				instance -> instance.group(
							IntRange.CODEC.optionalFieldOf("occupied", IntRange.ANY).forGetter(InventoryChangedCriterion.Conditions.Slots::occupied),
							IntRange.CODEC.optionalFieldOf("full", IntRange.ANY).forGetter(InventoryChangedCriterion.Conditions.Slots::full),
							IntRange.CODEC.optionalFieldOf("empty", IntRange.ANY).forGetter(InventoryChangedCriterion.Conditions.Slots::empty)
						)
						.apply(instance, InventoryChangedCriterion.Conditions.Slots::new)
			);
			public static final InventoryChangedCriterion.Conditions.Slots ANY = new InventoryChangedCriterion.Conditions.Slots(IntRange.ANY, IntRange.ANY, IntRange.ANY);

			public boolean test(int full, int empty, int occupied) {
				if (!this.full.test(full)) {
					return false;
				} else {
					return !this.empty.test(empty) ? false : this.occupied.test(occupied);
				}
			}
		}
	}
}
