package net.minecraft.advancement.criterion;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.advancement.AdvancementCriterion;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.loot.context.LootContext;
import net.minecraft.predicate.entity.EntityPredicate;
import net.minecraft.predicate.entity.LootContextPredicate;
import net.minecraft.predicate.entity.LootContextPredicateValidator;
import net.minecraft.predicate.entity.EntityPredicate.Builder;
import net.minecraft.server.network.ServerPlayerEntity;

public class BredAnimalsCriterion extends AbstractCriterion<BredAnimalsCriterion.Conditions> {
	@Override
	public Codec<BredAnimalsCriterion.Conditions> getConditionsCodec() {
		return BredAnimalsCriterion.Conditions.CODEC;
	}

	public void trigger(ServerPlayerEntity player, AnimalEntity parent, AnimalEntity partner, @Nullable PassiveEntity child) {
		LootContext lv = EntityPredicate.createAdvancementEntityLootContext(player, parent);
		LootContext lv2 = EntityPredicate.createAdvancementEntityLootContext(player, partner);
		LootContext lv3 = child != null ? EntityPredicate.createAdvancementEntityLootContext(player, child) : null;
		this.trigger(player, conditions -> conditions.matches(lv, lv2, lv3));
	}

	public static record Conditions(
		Optional<LootContextPredicate> player, Optional<LootContextPredicate> parent, Optional<LootContextPredicate> partner, Optional<LootContextPredicate> child
	) implements net.minecraft.advancement.criterion.AbstractCriterion.Conditions {
		public static final Codec<BredAnimalsCriterion.Conditions> CODEC = RecordCodecBuilder.create(
			instance -> instance.group(
						EntityPredicate.LOOT_CONTEXT_PREDICATE_CODEC.optionalFieldOf("player").forGetter(BredAnimalsCriterion.Conditions::player),
						EntityPredicate.LOOT_CONTEXT_PREDICATE_CODEC.optionalFieldOf("parent").forGetter(BredAnimalsCriterion.Conditions::parent),
						EntityPredicate.LOOT_CONTEXT_PREDICATE_CODEC.optionalFieldOf("partner").forGetter(BredAnimalsCriterion.Conditions::partner),
						EntityPredicate.LOOT_CONTEXT_PREDICATE_CODEC.optionalFieldOf("child").forGetter(BredAnimalsCriterion.Conditions::child)
					)
					.apply(instance, BredAnimalsCriterion.Conditions::new)
		);

		public static AdvancementCriterion<BredAnimalsCriterion.Conditions> any() {
			return Criteria.BRED_ANIMALS.create(new BredAnimalsCriterion.Conditions(Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty()));
		}

		public static AdvancementCriterion<BredAnimalsCriterion.Conditions> create(Builder child) {
			return Criteria.BRED_ANIMALS
				.create(
					new BredAnimalsCriterion.Conditions(
						Optional.empty(), Optional.empty(), Optional.empty(), Optional.of(EntityPredicate.contextPredicateFromEntityPredicate(child))
					)
				);
		}

		public static AdvancementCriterion<BredAnimalsCriterion.Conditions> create(
			Optional<EntityPredicate> parent, Optional<EntityPredicate> partner, Optional<EntityPredicate> child
		) {
			return Criteria.BRED_ANIMALS
				.create(
					new BredAnimalsCriterion.Conditions(
						Optional.empty(),
						EntityPredicate.contextPredicateFromEntityPredicate(parent),
						EntityPredicate.contextPredicateFromEntityPredicate(partner),
						EntityPredicate.contextPredicateFromEntityPredicate(child)
					)
				);
		}

		public boolean matches(LootContext parentContext, LootContext partnerContext, @Nullable LootContext childContext) {
			return !this.child.isPresent() || childContext != null && ((LootContextPredicate)this.child.get()).test(childContext)
				? parentMatches(this.parent, parentContext) && parentMatches(this.partner, partnerContext)
					|| parentMatches(this.parent, partnerContext) && parentMatches(this.partner, parentContext)
				: false;
		}

		private static boolean parentMatches(Optional<LootContextPredicate> parent, LootContext parentContext) {
			return parent.isEmpty() || ((LootContextPredicate)parent.get()).test(parentContext);
		}

		@Override
		public void validate(LootContextPredicateValidator validator) {
			net.minecraft.advancement.criterion.AbstractCriterion.Conditions.super.validate(validator);
			validator.validateEntityPredicate(this.parent, ".parent");
			validator.validateEntityPredicate(this.partner, ".partner");
			validator.validateEntityPredicate(this.child, ".child");
		}
	}
}
