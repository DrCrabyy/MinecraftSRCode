package net.minecraft.client.data;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Map.Entry;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.equipment.EquipmentModel;
import net.minecraft.client.render.entity.equipment.EquipmentModel.Layer;
import net.minecraft.client.render.entity.equipment.EquipmentModel.LayerType;
import net.minecraft.data.DataOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.DataWriter;
import net.minecraft.data.DataOutput.OutputType;
import net.minecraft.data.DataOutput.PathResolver;
import net.minecraft.item.equipment.EquipmentAsset;
import net.minecraft.item.equipment.EquipmentAssetKeys;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public class EquipmentAssetProvider implements DataProvider {
	private final PathResolver pathResolver;

	public EquipmentAssetProvider(DataOutput output) {
		this.pathResolver = output.getResolver(OutputType.RESOURCE_PACK, "equipment");
	}

	private static void bootstrap(BiConsumer<RegistryKey<EquipmentAsset>, EquipmentModel> equipmentBiConsumer) {
		equipmentBiConsumer.accept(
			EquipmentAssetKeys.LEATHER,
			EquipmentModel.builder()
				.addHumanoidLayers(Identifier.ofVanilla("leather"), true)
				.addHumanoidLayers(Identifier.ofVanilla("leather_overlay"), false)
				.addLayers(LayerType.HORSE_BODY, Layer.createWithLeatherColor(Identifier.ofVanilla("leather"), true))
				.build()
		);
		equipmentBiConsumer.accept(EquipmentAssetKeys.CHAINMAIL, createHumanoidOnlyModel("chainmail"));
		equipmentBiConsumer.accept(EquipmentAssetKeys.IRON, createHumanoidAndHorseModel("iron"));
		equipmentBiConsumer.accept(EquipmentAssetKeys.GOLD, createHumanoidAndHorseModel("gold"));
		equipmentBiConsumer.accept(EquipmentAssetKeys.DIAMOND, createHumanoidAndHorseModel("diamond"));
		equipmentBiConsumer.accept(
			EquipmentAssetKeys.TURTLE_SCUTE, EquipmentModel.builder().addMainHumanoidLayer(Identifier.ofVanilla("turtle_scute"), false).build()
		);
		equipmentBiConsumer.accept(EquipmentAssetKeys.NETHERITE, createHumanoidOnlyModel("netherite"));
		equipmentBiConsumer.accept(
			EquipmentAssetKeys.ARMADILLO_SCUTE,
			EquipmentModel.builder()
				.addLayers(LayerType.WOLF_BODY, Layer.create(Identifier.ofVanilla("armadillo_scute"), false))
				.addLayers(LayerType.WOLF_BODY, Layer.create(Identifier.ofVanilla("armadillo_scute_overlay"), true))
				.build()
		);
		equipmentBiConsumer.accept(
			EquipmentAssetKeys.ELYTRA, EquipmentModel.builder().addLayers(LayerType.WINGS, new Layer(Identifier.ofVanilla("elytra"), Optional.empty(), true)).build()
		);

		for (Entry<DyeColor, RegistryKey<EquipmentAsset>> entry : EquipmentAssetKeys.CARPET_FROM_COLOR.entrySet()) {
			DyeColor lv = (DyeColor)entry.getKey();
			RegistryKey<EquipmentAsset> lv2 = (RegistryKey<EquipmentAsset>)entry.getValue();
			equipmentBiConsumer.accept(lv2, EquipmentModel.builder().addLayers(LayerType.LLAMA_BODY, new Layer(Identifier.ofVanilla(lv.asString()))).build());
		}

		equipmentBiConsumer.accept(
			EquipmentAssetKeys.TRADER_LLAMA, EquipmentModel.builder().addLayers(LayerType.LLAMA_BODY, new Layer(Identifier.ofVanilla("trader_llama"))).build()
		);
	}

	private static EquipmentModel createHumanoidOnlyModel(String id) {
		return EquipmentModel.builder().addHumanoidLayers(Identifier.ofVanilla(id)).build();
	}

	private static EquipmentModel createHumanoidAndHorseModel(String id) {
		return EquipmentModel.builder()
			.addHumanoidLayers(Identifier.ofVanilla(id))
			.addLayers(LayerType.HORSE_BODY, Layer.createWithLeatherColor(Identifier.ofVanilla(id), false))
			.build();
	}

	@Override
	public CompletableFuture<?> run(DataWriter writer) {
		Map<RegistryKey<EquipmentAsset>, EquipmentModel> map = new HashMap();
		bootstrap((key, model) -> {
			if (map.putIfAbsent(key, model) != null) {
				throw new IllegalStateException("Tried to register equipment asset twice for id: " + key);
			}
		});
		return DataProvider.writeAllToPath(writer, EquipmentModel.CODEC, this.pathResolver::resolveJson, map);
	}

	@Override
	public String getName() {
		return "Equipment Asset Definitions";
	}
}
