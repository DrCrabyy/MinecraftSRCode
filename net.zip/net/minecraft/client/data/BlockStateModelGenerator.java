package net.minecraft.client.data;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.mojang.datafixers.util.Pair;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import javax.annotation.Nullable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BeehiveBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.CrafterBlock;
import net.minecraft.block.CreakingHeartBlock;
import net.minecraft.block.HangingMossBlock;
import net.minecraft.block.LeveledCauldronBlock;
import net.minecraft.block.LightBlock;
import net.minecraft.block.MultifaceBlock;
import net.minecraft.block.PaleMossCarpetBlock;
import net.minecraft.block.PitcherCropBlock;
import net.minecraft.block.PropaguleBlock;
import net.minecraft.block.SnifferEggBlock;
import net.minecraft.block.VaultBlock;
import net.minecraft.block.SkullBlock.SkullType;
import net.minecraft.block.SkullBlock.Type;
import net.minecraft.block.enums.Attachment;
import net.minecraft.block.enums.BambooLeaves;
import net.minecraft.block.enums.BlockFace;
import net.minecraft.block.enums.BlockHalf;
import net.minecraft.block.enums.ComparatorMode;
import net.minecraft.block.enums.CreakingHeartState;
import net.minecraft.block.enums.DoorHinge;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.block.enums.Orientation;
import net.minecraft.block.enums.PistonType;
import net.minecraft.block.enums.RailShape;
import net.minecraft.block.enums.SculkSensorPhase;
import net.minecraft.block.enums.SlabType;
import net.minecraft.block.enums.StairShape;
import net.minecraft.block.enums.Thickness;
import net.minecraft.block.enums.Tilt;
import net.minecraft.block.enums.WallShape;
import net.minecraft.block.enums.WireConnection;
import net.minecraft.client.data.BlockStateVariantMap.DoubleProperty;
import net.minecraft.client.data.BlockStateVariantMap.QuadrupleProperty;
import net.minecraft.client.data.BlockStateVariantMap.SingleProperty;
import net.minecraft.client.data.TexturedModel.Factory;
import net.minecraft.client.data.VariantSettings.Rotation;
import net.minecraft.client.data.When.PropertyCondition;
import net.minecraft.client.render.item.model.ItemModel.Unbaked;
import net.minecraft.client.render.item.model.special.ChestModelRenderer;
import net.minecraft.client.render.item.tint.GrassTintSource;
import net.minecraft.client.render.item.tint.TintSource;
import net.minecraft.data.family.BlockFamilies;
import net.minecraft.data.family.BlockFamily;
import net.minecraft.data.family.BlockFamily.Variant;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;

@Environment(EnvType.CLIENT)
public class BlockStateModelGenerator {
	final Consumer<BlockStateSupplier> blockStateCollector;
	final ItemModelOutput itemModelOutput;
	final BiConsumer<Identifier, ModelSupplier> modelCollector;
	final List<Block> nonOrientableTrapdoors = ImmutableList.of(Blocks.OAK_TRAPDOOR, Blocks.DARK_OAK_TRAPDOOR, Blocks.IRON_TRAPDOOR);
	final Map<Block, BlockStateModelGenerator.StateFactory> stoneStateFactories = ImmutableMap.builder()
		.put(Blocks.STONE, BlockStateModelGenerator::createStoneState)
		.put(Blocks.DEEPSLATE, BlockStateModelGenerator::createDeepslateState)
		.put(Blocks.MUD_BRICKS, BlockStateModelGenerator::createMudBrickState)
		.build();
	final Map<Block, TexturedModel> texturedModels = ImmutableMap.builder()
		.put(Blocks.SANDSTONE, TexturedModel.SIDE_TOP_BOTTOM_WALL.get(Blocks.SANDSTONE))
		.put(Blocks.RED_SANDSTONE, TexturedModel.SIDE_TOP_BOTTOM_WALL.get(Blocks.RED_SANDSTONE))
		.put(Blocks.SMOOTH_SANDSTONE, TexturedModel.getCubeAll(TextureMap.getSubId(Blocks.SANDSTONE, "_top")))
		.put(Blocks.SMOOTH_RED_SANDSTONE, TexturedModel.getCubeAll(TextureMap.getSubId(Blocks.RED_SANDSTONE, "_top")))
		.put(
			Blocks.CUT_SANDSTONE,
			TexturedModel.CUBE_COLUMN.get(Blocks.SANDSTONE).textures(textureMap -> textureMap.put(TextureKey.SIDE, TextureMap.getId(Blocks.CUT_SANDSTONE)))
		)
		.put(
			Blocks.CUT_RED_SANDSTONE,
			TexturedModel.CUBE_COLUMN.get(Blocks.RED_SANDSTONE).textures(textureMap -> textureMap.put(TextureKey.SIDE, TextureMap.getId(Blocks.CUT_RED_SANDSTONE)))
		)
		.put(Blocks.QUARTZ_BLOCK, TexturedModel.CUBE_COLUMN.get(Blocks.QUARTZ_BLOCK))
		.put(Blocks.SMOOTH_QUARTZ, TexturedModel.getCubeAll(TextureMap.getSubId(Blocks.QUARTZ_BLOCK, "_bottom")))
		.put(Blocks.BLACKSTONE, TexturedModel.SIDE_END_WALL.get(Blocks.BLACKSTONE))
		.put(Blocks.DEEPSLATE, TexturedModel.SIDE_END_WALL.get(Blocks.DEEPSLATE))
		.put(
			Blocks.CHISELED_QUARTZ_BLOCK,
			TexturedModel.CUBE_COLUMN
				.get(Blocks.CHISELED_QUARTZ_BLOCK)
				.textures(textureMap -> textureMap.put(TextureKey.SIDE, TextureMap.getId(Blocks.CHISELED_QUARTZ_BLOCK)))
		)
		.put(Blocks.CHISELED_SANDSTONE, TexturedModel.CUBE_COLUMN.get(Blocks.CHISELED_SANDSTONE).textures(textures -> {
			textures.put(TextureKey.END, TextureMap.getSubId(Blocks.SANDSTONE, "_top"));
			textures.put(TextureKey.SIDE, TextureMap.getId(Blocks.CHISELED_SANDSTONE));
		}))
		.put(Blocks.CHISELED_RED_SANDSTONE, TexturedModel.CUBE_COLUMN.get(Blocks.CHISELED_RED_SANDSTONE).textures(textures -> {
			textures.put(TextureKey.END, TextureMap.getSubId(Blocks.RED_SANDSTONE, "_top"));
			textures.put(TextureKey.SIDE, TextureMap.getId(Blocks.CHISELED_RED_SANDSTONE));
		}))
		.put(Blocks.CHISELED_TUFF_BRICKS, TexturedModel.SIDE_END_WALL.get(Blocks.CHISELED_TUFF_BRICKS))
		.put(Blocks.CHISELED_TUFF, TexturedModel.SIDE_END_WALL.get(Blocks.CHISELED_TUFF))
		.build();
	static final Map<Variant, BiConsumer<BlockStateModelGenerator.BlockTexturePool, Block>> VARIANT_POOL_FUNCTIONS = ImmutableMap.builder()
		.put(Variant.BUTTON, BlockStateModelGenerator.BlockTexturePool::button)
		.put(Variant.DOOR, BlockStateModelGenerator.BlockTexturePool::door)
		.put(Variant.CHISELED, BlockStateModelGenerator.BlockTexturePool::block)
		.put(Variant.CRACKED, BlockStateModelGenerator.BlockTexturePool::block)
		.put(Variant.CUSTOM_FENCE, BlockStateModelGenerator.BlockTexturePool::customFence)
		.put(Variant.FENCE, BlockStateModelGenerator.BlockTexturePool::fence)
		.put(Variant.CUSTOM_FENCE_GATE, BlockStateModelGenerator.BlockTexturePool::customFenceGate)
		.put(Variant.FENCE_GATE, BlockStateModelGenerator.BlockTexturePool::fenceGate)
		.put(Variant.SIGN, BlockStateModelGenerator.BlockTexturePool::sign)
		.put(Variant.SLAB, BlockStateModelGenerator.BlockTexturePool::slab)
		.put(Variant.STAIRS, BlockStateModelGenerator.BlockTexturePool::stairs)
		.put(Variant.PRESSURE_PLATE, BlockStateModelGenerator.BlockTexturePool::pressurePlate)
		.put(Variant.TRAPDOOR, BlockStateModelGenerator.BlockTexturePool::registerTrapdoor)
		.put(Variant.WALL, BlockStateModelGenerator.BlockTexturePool::wall)
		.build();
	public static final List<Pair<Direction, Function<Identifier, BlockStateVariant>>> CONNECTION_VARIANT_FUNCTIONS = List.of(
		Pair.of(Direction.NORTH, (Function)model -> BlockStateVariant.create().put(VariantSettings.MODEL, model)),
		Pair.of(
			Direction.EAST,
			(Function)model -> BlockStateVariant.create().put(VariantSettings.MODEL, model).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.UVLOCK, true)
		),
		Pair.of(
			Direction.SOUTH,
			(Function)model -> BlockStateVariant.create().put(VariantSettings.MODEL, model).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.UVLOCK, true)
		),
		Pair.of(
			Direction.WEST,
			(Function)model -> BlockStateVariant.create().put(VariantSettings.MODEL, model).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.UVLOCK, true)
		),
		Pair.of(
			Direction.UP,
			(Function)model -> BlockStateVariant.create().put(VariantSettings.MODEL, model).put(VariantSettings.X, Rotation.R270).put(VariantSettings.UVLOCK, true)
		),
		Pair.of(
			Direction.DOWN,
			(Function)model -> BlockStateVariant.create().put(VariantSettings.MODEL, model).put(VariantSettings.X, Rotation.R90).put(VariantSettings.UVLOCK, true)
		)
	);
	private static final Map<BlockStateModelGenerator.ChiseledBookshelfModelCacheKey, Identifier> CHISELED_BOOKSHELF_MODEL_CACHE = new HashMap();

	private static BlockStateSupplier createStoneState(Block block, Identifier modelId, TextureMap textures, BiConsumer<Identifier, ModelSupplier> modelCollector) {
		Identifier lv = Models.CUBE_MIRRORED_ALL.upload(block, textures, modelCollector);
		return createBlockStateWithTwoModelAndRandomInversion(block, modelId, lv);
	}

	private static BlockStateSupplier createMudBrickState(
		Block block, Identifier modelId, TextureMap textures, BiConsumer<Identifier, ModelSupplier> modelCollector
	) {
		Identifier lv = Models.CUBE_NORTH_WEST_MIRRORED_ALL.upload(block, textures, modelCollector);
		return createSingletonBlockState(block, lv);
	}

	private static BlockStateSupplier createDeepslateState(
		Block block, Identifier modelId, TextureMap textures, BiConsumer<Identifier, ModelSupplier> modelCollector
	) {
		Identifier lv = Models.CUBE_COLUMN_MIRRORED.upload(block, textures, modelCollector);
		return createBlockStateWithTwoModelAndRandomInversion(block, modelId, lv).coordinate(createAxisRotatedVariantMap());
	}

	public BlockStateModelGenerator(
		Consumer<BlockStateSupplier> blockStateCollector, ItemModelOutput itemModelOutput, BiConsumer<Identifier, ModelSupplier> modelCollector
	) {
		this.blockStateCollector = blockStateCollector;
		this.itemModelOutput = itemModelOutput;
		this.modelCollector = modelCollector;
	}

	private void registerItemModel(Item item, Identifier modelId) {
		this.itemModelOutput.accept(item, ItemModels.basic(modelId));
	}

	void registerParentedItemModel(Block block, Identifier parentModelId) {
		this.itemModelOutput.accept(block.asItem(), ItemModels.basic(parentModelId));
	}

	private void registerTintedItemModel(Block block, Identifier modelId, TintSource tint) {
		this.itemModelOutput.accept(block.asItem(), ItemModels.tinted(modelId, tint));
	}

	private Identifier uploadItemModel(Item item) {
		return Models.GENERATED.upload(ModelIds.getItemModelId(item), TextureMap.layer0(item), this.modelCollector);
	}

	Identifier uploadBlockItemModel(Item item, Block block) {
		return Models.GENERATED.upload(ModelIds.getItemModelId(item), TextureMap.layer0(block), this.modelCollector);
	}

	private Identifier uploadBlockItemModel(Item item, Block block, String textureSuffix) {
		return Models.GENERATED.upload(ModelIds.getItemModelId(item), TextureMap.layer0(TextureMap.getSubId(block, textureSuffix)), this.modelCollector);
	}

	Identifier uploadTwoLayerBlockItemModel(Item item, Block block, String layer1Suffix) {
		Identifier lv = TextureMap.getId(block);
		Identifier lv2 = TextureMap.getSubId(block, layer1Suffix);
		return Models.GENERATED_TWO_LAYERS.upload(ModelIds.getItemModelId(item), TextureMap.layered(lv, lv2), this.modelCollector);
	}

	void registerItemModel(Item item) {
		this.registerItemModel(item, this.uploadItemModel(item));
	}

	private void registerItemModel(Block block) {
		Item lv = block.asItem();
		if (lv != Items.AIR) {
			this.registerItemModel(lv, this.uploadBlockItemModel(lv, block));
		}
	}

	private void registerItemModel(Block block, String textureSuffix) {
		Item lv = block.asItem();
		if (lv != Items.AIR) {
			this.registerItemModel(lv, this.uploadBlockItemModel(lv, block, textureSuffix));
		}
	}

	private void registerTwoLayerItemModel(Block block, String layer1Suffix) {
		Item lv = block.asItem();
		if (lv != Items.AIR) {
			Identifier lv2 = this.uploadTwoLayerBlockItemModel(lv, block, layer1Suffix);
			this.registerItemModel(lv, lv2);
		}
	}

	private static BlockStateVariantMap createNorthDefaultHorizontalRotationStates() {
		return BlockStateVariantMap.create(Properties.HORIZONTAL_FACING)
			.register(Direction.EAST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R90))
			.register(Direction.SOUTH, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R180))
			.register(Direction.WEST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R270))
			.register(Direction.NORTH, BlockStateVariant.create());
	}

	private static BlockStateVariantMap createSouthDefaultHorizontalRotationStates() {
		return BlockStateVariantMap.create(Properties.HORIZONTAL_FACING)
			.register(Direction.SOUTH, BlockStateVariant.create())
			.register(Direction.WEST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R90))
			.register(Direction.NORTH, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R180))
			.register(Direction.EAST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R270));
	}

	private static BlockStateVariantMap createEastDefaultHorizontalRotationStates() {
		return BlockStateVariantMap.create(Properties.HORIZONTAL_FACING)
			.register(Direction.EAST, BlockStateVariant.create())
			.register(Direction.SOUTH, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R90))
			.register(Direction.WEST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R180))
			.register(Direction.NORTH, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R270));
	}

	private static BlockStateVariantMap createNorthDefaultRotationStates() {
		return BlockStateVariantMap.create(Properties.FACING)
			.register(Direction.DOWN, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90))
			.register(Direction.UP, BlockStateVariant.create().put(VariantSettings.X, Rotation.R270))
			.register(Direction.NORTH, BlockStateVariant.create())
			.register(Direction.SOUTH, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R180))
			.register(Direction.WEST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R270))
			.register(Direction.EAST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R90));
	}

	private static VariantsBlockStateSupplier createBlockStateWithRandomHorizontalRotations(Block block, Identifier modelId) {
		return VariantsBlockStateSupplier.create(block, createModelVariantWithRandomHorizontalRotations(modelId));
	}

	private static BlockStateVariant[] createModelVariantWithRandomHorizontalRotations(Identifier modelId) {
		return new BlockStateVariant[]{
			BlockStateVariant.create().put(VariantSettings.MODEL, modelId),
			BlockStateVariant.create().put(VariantSettings.MODEL, modelId).put(VariantSettings.Y, Rotation.R90),
			BlockStateVariant.create().put(VariantSettings.MODEL, modelId).put(VariantSettings.Y, Rotation.R180),
			BlockStateVariant.create().put(VariantSettings.MODEL, modelId).put(VariantSettings.Y, Rotation.R270)
		};
	}

	private static VariantsBlockStateSupplier createBlockStateWithTwoModelAndRandomInversion(Block block, Identifier firstModelId, Identifier secondModelId) {
		return VariantsBlockStateSupplier.create(
			block,
			BlockStateVariant.create().put(VariantSettings.MODEL, firstModelId),
			BlockStateVariant.create().put(VariantSettings.MODEL, secondModelId),
			BlockStateVariant.create().put(VariantSettings.MODEL, firstModelId).put(VariantSettings.Y, Rotation.R180),
			BlockStateVariant.create().put(VariantSettings.MODEL, secondModelId).put(VariantSettings.Y, Rotation.R180)
		);
	}

	private static BlockStateVariantMap createBooleanModelMap(BooleanProperty property, Identifier trueModel, Identifier falseModel) {
		return BlockStateVariantMap.create(property)
			.register(true, BlockStateVariant.create().put(VariantSettings.MODEL, trueModel))
			.register(false, BlockStateVariant.create().put(VariantSettings.MODEL, falseModel));
	}

	private void registerMirrorable(Block block) {
		Identifier lv = TexturedModel.CUBE_ALL.upload(block, this.modelCollector);
		Identifier lv2 = TexturedModel.CUBE_MIRRORED_ALL.upload(block, this.modelCollector);
		this.blockStateCollector.accept(createBlockStateWithTwoModelAndRandomInversion(block, lv, lv2));
	}

	private void registerRotatable(Block block) {
		Identifier lv = TexturedModel.CUBE_ALL.upload(block, this.modelCollector);
		this.blockStateCollector.accept(createBlockStateWithRandomHorizontalRotations(block, lv));
	}

	private void registerBrushableBlock(Block block) {
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(block)
					.coordinate(
						BlockStateVariantMap.create(Properties.DUSTED)
							.register(
								dusted -> {
									String string = "_" + dusted;
									Identifier lv = TextureMap.getSubId(block, string);
									return BlockStateVariant.create()
										.put(VariantSettings.MODEL, Models.CUBE_ALL.upload(block, string, new TextureMap().put(TextureKey.ALL, lv), this.modelCollector));
								}
							)
					)
			);
		this.registerParentedItemModel(block, ModelIds.getBlockSubModelId(block, "_0"));
	}

	static BlockStateSupplier createButtonBlockState(Block buttonBlock, Identifier regularModelId, Identifier pressedModelId) {
		return VariantsBlockStateSupplier.create(buttonBlock)
			.coordinate(
				BlockStateVariantMap.create(Properties.POWERED)
					.register(false, BlockStateVariant.create().put(VariantSettings.MODEL, regularModelId))
					.register(true, BlockStateVariant.create().put(VariantSettings.MODEL, pressedModelId))
			)
			.coordinate(
				BlockStateVariantMap.create(Properties.BLOCK_FACE, Properties.HORIZONTAL_FACING)
					.register(BlockFace.FLOOR, Direction.EAST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R90))
					.register(BlockFace.FLOOR, Direction.WEST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R270))
					.register(BlockFace.FLOOR, Direction.SOUTH, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R180))
					.register(BlockFace.FLOOR, Direction.NORTH, BlockStateVariant.create())
					.register(
						BlockFace.WALL,
						Direction.EAST,
						BlockStateVariant.create().put(VariantSettings.Y, Rotation.R90).put(VariantSettings.X, Rotation.R90).put(VariantSettings.UVLOCK, true)
					)
					.register(
						BlockFace.WALL,
						Direction.WEST,
						BlockStateVariant.create().put(VariantSettings.Y, Rotation.R270).put(VariantSettings.X, Rotation.R90).put(VariantSettings.UVLOCK, true)
					)
					.register(
						BlockFace.WALL,
						Direction.SOUTH,
						BlockStateVariant.create().put(VariantSettings.Y, Rotation.R180).put(VariantSettings.X, Rotation.R90).put(VariantSettings.UVLOCK, true)
					)
					.register(BlockFace.WALL, Direction.NORTH, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90).put(VariantSettings.UVLOCK, true))
					.register(BlockFace.CEILING, Direction.EAST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R270).put(VariantSettings.X, Rotation.R180))
					.register(BlockFace.CEILING, Direction.WEST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R90).put(VariantSettings.X, Rotation.R180))
					.register(BlockFace.CEILING, Direction.SOUTH, BlockStateVariant.create().put(VariantSettings.X, Rotation.R180))
					.register(BlockFace.CEILING, Direction.NORTH, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R180).put(VariantSettings.X, Rotation.R180))
			);
	}

	private static QuadrupleProperty<Direction, DoubleBlockHalf, DoorHinge, Boolean> fillDoorVariantMap(
		QuadrupleProperty<Direction, DoubleBlockHalf, DoorHinge, Boolean> variantMap,
		DoubleBlockHalf targetHalf,
		Identifier leftHingeClosedModelId,
		Identifier leftHingeOpenModelId,
		Identifier rightHingeClosedModelId,
		Identifier rightHingeOpenModelId
	) {
		return variantMap.register(Direction.EAST, targetHalf, DoorHinge.LEFT, false, BlockStateVariant.create().put(VariantSettings.MODEL, leftHingeClosedModelId))
			.register(
				Direction.SOUTH,
				targetHalf,
				DoorHinge.LEFT,
				false,
				BlockStateVariant.create().put(VariantSettings.MODEL, leftHingeClosedModelId).put(VariantSettings.Y, Rotation.R90)
			)
			.register(
				Direction.WEST,
				targetHalf,
				DoorHinge.LEFT,
				false,
				BlockStateVariant.create().put(VariantSettings.MODEL, leftHingeClosedModelId).put(VariantSettings.Y, Rotation.R180)
			)
			.register(
				Direction.NORTH,
				targetHalf,
				DoorHinge.LEFT,
				false,
				BlockStateVariant.create().put(VariantSettings.MODEL, leftHingeClosedModelId).put(VariantSettings.Y, Rotation.R270)
			)
			.register(Direction.EAST, targetHalf, DoorHinge.RIGHT, false, BlockStateVariant.create().put(VariantSettings.MODEL, rightHingeClosedModelId))
			.register(
				Direction.SOUTH,
				targetHalf,
				DoorHinge.RIGHT,
				false,
				BlockStateVariant.create().put(VariantSettings.MODEL, rightHingeClosedModelId).put(VariantSettings.Y, Rotation.R90)
			)
			.register(
				Direction.WEST,
				targetHalf,
				DoorHinge.RIGHT,
				false,
				BlockStateVariant.create().put(VariantSettings.MODEL, rightHingeClosedModelId).put(VariantSettings.Y, Rotation.R180)
			)
			.register(
				Direction.NORTH,
				targetHalf,
				DoorHinge.RIGHT,
				false,
				BlockStateVariant.create().put(VariantSettings.MODEL, rightHingeClosedModelId).put(VariantSettings.Y, Rotation.R270)
			)
			.register(
				Direction.EAST,
				targetHalf,
				DoorHinge.LEFT,
				true,
				BlockStateVariant.create().put(VariantSettings.MODEL, leftHingeOpenModelId).put(VariantSettings.Y, Rotation.R90)
			)
			.register(
				Direction.SOUTH,
				targetHalf,
				DoorHinge.LEFT,
				true,
				BlockStateVariant.create().put(VariantSettings.MODEL, leftHingeOpenModelId).put(VariantSettings.Y, Rotation.R180)
			)
			.register(
				Direction.WEST,
				targetHalf,
				DoorHinge.LEFT,
				true,
				BlockStateVariant.create().put(VariantSettings.MODEL, leftHingeOpenModelId).put(VariantSettings.Y, Rotation.R270)
			)
			.register(Direction.NORTH, targetHalf, DoorHinge.LEFT, true, BlockStateVariant.create().put(VariantSettings.MODEL, leftHingeOpenModelId))
			.register(
				Direction.EAST,
				targetHalf,
				DoorHinge.RIGHT,
				true,
				BlockStateVariant.create().put(VariantSettings.MODEL, rightHingeOpenModelId).put(VariantSettings.Y, Rotation.R270)
			)
			.register(Direction.SOUTH, targetHalf, DoorHinge.RIGHT, true, BlockStateVariant.create().put(VariantSettings.MODEL, rightHingeOpenModelId))
			.register(
				Direction.WEST,
				targetHalf,
				DoorHinge.RIGHT,
				true,
				BlockStateVariant.create().put(VariantSettings.MODEL, rightHingeOpenModelId).put(VariantSettings.Y, Rotation.R90)
			)
			.register(
				Direction.NORTH,
				targetHalf,
				DoorHinge.RIGHT,
				true,
				BlockStateVariant.create().put(VariantSettings.MODEL, rightHingeOpenModelId).put(VariantSettings.Y, Rotation.R180)
			);
	}

	private static BlockStateSupplier createDoorBlockState(
		Block doorBlock,
		Identifier bottomLeftHingeClosedModelId,
		Identifier bottomLeftHingeOpenModelId,
		Identifier bottomRightHingeClosedModelId,
		Identifier bottomRightHingeOpenModelId,
		Identifier topLeftHingeClosedModelId,
		Identifier topLeftHingeOpenModelId,
		Identifier topRightHingeClosedModelId,
		Identifier topRightHingeOpenModelId
	) {
		return VariantsBlockStateSupplier.create(doorBlock)
			.coordinate(
				fillDoorVariantMap(
					fillDoorVariantMap(
						BlockStateVariantMap.create(Properties.HORIZONTAL_FACING, Properties.DOUBLE_BLOCK_HALF, Properties.DOOR_HINGE, Properties.OPEN),
						DoubleBlockHalf.LOWER,
						bottomLeftHingeClosedModelId,
						bottomLeftHingeOpenModelId,
						bottomRightHingeClosedModelId,
						bottomRightHingeOpenModelId
					),
					DoubleBlockHalf.UPPER,
					topLeftHingeClosedModelId,
					topLeftHingeOpenModelId,
					topRightHingeClosedModelId,
					topRightHingeOpenModelId
				)
			);
	}

	static BlockStateSupplier createCustomFenceBlockState(
		Block customFenceBlock, Identifier postModelId, Identifier northModelId, Identifier eastModelId, Identifier southModelId, Identifier westModelId
	) {
		return MultipartBlockStateSupplier.create(customFenceBlock)
			.with(BlockStateVariant.create().put(VariantSettings.MODEL, postModelId))
			.with(When.create().set(Properties.NORTH, true), BlockStateVariant.create().put(VariantSettings.MODEL, northModelId).put(VariantSettings.UVLOCK, false))
			.with(When.create().set(Properties.EAST, true), BlockStateVariant.create().put(VariantSettings.MODEL, eastModelId).put(VariantSettings.UVLOCK, false))
			.with(When.create().set(Properties.SOUTH, true), BlockStateVariant.create().put(VariantSettings.MODEL, southModelId).put(VariantSettings.UVLOCK, false))
			.with(When.create().set(Properties.WEST, true), BlockStateVariant.create().put(VariantSettings.MODEL, westModelId).put(VariantSettings.UVLOCK, false));
	}

	static BlockStateSupplier createFenceBlockState(Block fenceBlock, Identifier postModelId, Identifier sideModelId) {
		return MultipartBlockStateSupplier.create(fenceBlock)
			.with(BlockStateVariant.create().put(VariantSettings.MODEL, postModelId))
			.with(When.create().set(Properties.NORTH, true), BlockStateVariant.create().put(VariantSettings.MODEL, sideModelId).put(VariantSettings.UVLOCK, true))
			.with(
				When.create().set(Properties.EAST, true),
				BlockStateVariant.create().put(VariantSettings.MODEL, sideModelId).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.UVLOCK, true)
			)
			.with(
				When.create().set(Properties.SOUTH, true),
				BlockStateVariant.create().put(VariantSettings.MODEL, sideModelId).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.UVLOCK, true)
			)
			.with(
				When.create().set(Properties.WEST, true),
				BlockStateVariant.create().put(VariantSettings.MODEL, sideModelId).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.UVLOCK, true)
			);
	}

	static BlockStateSupplier createWallBlockState(Block wallBlock, Identifier postModelId, Identifier lowSideModelId, Identifier tallSideModelId) {
		return MultipartBlockStateSupplier.create(wallBlock)
			.with(When.create().set(Properties.UP, true), BlockStateVariant.create().put(VariantSettings.MODEL, postModelId))
			.with(
				When.create().set(Properties.NORTH_WALL_SHAPE, WallShape.LOW),
				BlockStateVariant.create().put(VariantSettings.MODEL, lowSideModelId).put(VariantSettings.UVLOCK, true)
			)
			.with(
				When.create().set(Properties.EAST_WALL_SHAPE, WallShape.LOW),
				BlockStateVariant.create().put(VariantSettings.MODEL, lowSideModelId).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.UVLOCK, true)
			)
			.with(
				When.create().set(Properties.SOUTH_WALL_SHAPE, WallShape.LOW),
				BlockStateVariant.create().put(VariantSettings.MODEL, lowSideModelId).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.UVLOCK, true)
			)
			.with(
				When.create().set(Properties.WEST_WALL_SHAPE, WallShape.LOW),
				BlockStateVariant.create().put(VariantSettings.MODEL, lowSideModelId).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.UVLOCK, true)
			)
			.with(
				When.create().set(Properties.NORTH_WALL_SHAPE, WallShape.TALL),
				BlockStateVariant.create().put(VariantSettings.MODEL, tallSideModelId).put(VariantSettings.UVLOCK, true)
			)
			.with(
				When.create().set(Properties.EAST_WALL_SHAPE, WallShape.TALL),
				BlockStateVariant.create().put(VariantSettings.MODEL, tallSideModelId).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.UVLOCK, true)
			)
			.with(
				When.create().set(Properties.SOUTH_WALL_SHAPE, WallShape.TALL),
				BlockStateVariant.create().put(VariantSettings.MODEL, tallSideModelId).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.UVLOCK, true)
			)
			.with(
				When.create().set(Properties.WEST_WALL_SHAPE, WallShape.TALL),
				BlockStateVariant.create().put(VariantSettings.MODEL, tallSideModelId).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.UVLOCK, true)
			);
	}

	static BlockStateSupplier createFenceGateBlockState(
		Block fenceGateBlock, Identifier openModelId, Identifier closedModelId, Identifier openWallModelId, Identifier closedWallModelId, boolean uvlock
	) {
		return VariantsBlockStateSupplier.create(fenceGateBlock, BlockStateVariant.create().put(VariantSettings.UVLOCK, uvlock))
			.coordinate(createSouthDefaultHorizontalRotationStates())
			.coordinate(
				BlockStateVariantMap.create(Properties.IN_WALL, Properties.OPEN)
					.register(false, false, BlockStateVariant.create().put(VariantSettings.MODEL, closedModelId))
					.register(true, false, BlockStateVariant.create().put(VariantSettings.MODEL, closedWallModelId))
					.register(false, true, BlockStateVariant.create().put(VariantSettings.MODEL, openModelId))
					.register(true, true, BlockStateVariant.create().put(VariantSettings.MODEL, openWallModelId))
			);
	}

	static BlockStateSupplier createStairsBlockState(Block stairsBlock, Identifier innerModelId, Identifier regularModelId, Identifier outerModelId) {
		return VariantsBlockStateSupplier.create(stairsBlock)
			.coordinate(
				BlockStateVariantMap.create(Properties.HORIZONTAL_FACING, Properties.BLOCK_HALF, Properties.STAIR_SHAPE)
					.register(Direction.EAST, BlockHalf.BOTTOM, StairShape.STRAIGHT, BlockStateVariant.create().put(VariantSettings.MODEL, regularModelId))
					.register(
						Direction.WEST,
						BlockHalf.BOTTOM,
						StairShape.STRAIGHT,
						BlockStateVariant.create().put(VariantSettings.MODEL, regularModelId).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.SOUTH,
						BlockHalf.BOTTOM,
						StairShape.STRAIGHT,
						BlockStateVariant.create().put(VariantSettings.MODEL, regularModelId).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.NORTH,
						BlockHalf.BOTTOM,
						StairShape.STRAIGHT,
						BlockStateVariant.create().put(VariantSettings.MODEL, regularModelId).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.UVLOCK, true)
					)
					.register(Direction.EAST, BlockHalf.BOTTOM, StairShape.OUTER_RIGHT, BlockStateVariant.create().put(VariantSettings.MODEL, outerModelId))
					.register(
						Direction.WEST,
						BlockHalf.BOTTOM,
						StairShape.OUTER_RIGHT,
						BlockStateVariant.create().put(VariantSettings.MODEL, outerModelId).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.SOUTH,
						BlockHalf.BOTTOM,
						StairShape.OUTER_RIGHT,
						BlockStateVariant.create().put(VariantSettings.MODEL, outerModelId).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.NORTH,
						BlockHalf.BOTTOM,
						StairShape.OUTER_RIGHT,
						BlockStateVariant.create().put(VariantSettings.MODEL, outerModelId).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.EAST,
						BlockHalf.BOTTOM,
						StairShape.OUTER_LEFT,
						BlockStateVariant.create().put(VariantSettings.MODEL, outerModelId).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.WEST,
						BlockHalf.BOTTOM,
						StairShape.OUTER_LEFT,
						BlockStateVariant.create().put(VariantSettings.MODEL, outerModelId).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.UVLOCK, true)
					)
					.register(Direction.SOUTH, BlockHalf.BOTTOM, StairShape.OUTER_LEFT, BlockStateVariant.create().put(VariantSettings.MODEL, outerModelId))
					.register(
						Direction.NORTH,
						BlockHalf.BOTTOM,
						StairShape.OUTER_LEFT,
						BlockStateVariant.create().put(VariantSettings.MODEL, outerModelId).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.UVLOCK, true)
					)
					.register(Direction.EAST, BlockHalf.BOTTOM, StairShape.INNER_RIGHT, BlockStateVariant.create().put(VariantSettings.MODEL, innerModelId))
					.register(
						Direction.WEST,
						BlockHalf.BOTTOM,
						StairShape.INNER_RIGHT,
						BlockStateVariant.create().put(VariantSettings.MODEL, innerModelId).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.SOUTH,
						BlockHalf.BOTTOM,
						StairShape.INNER_RIGHT,
						BlockStateVariant.create().put(VariantSettings.MODEL, innerModelId).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.NORTH,
						BlockHalf.BOTTOM,
						StairShape.INNER_RIGHT,
						BlockStateVariant.create().put(VariantSettings.MODEL, innerModelId).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.EAST,
						BlockHalf.BOTTOM,
						StairShape.INNER_LEFT,
						BlockStateVariant.create().put(VariantSettings.MODEL, innerModelId).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.WEST,
						BlockHalf.BOTTOM,
						StairShape.INNER_LEFT,
						BlockStateVariant.create().put(VariantSettings.MODEL, innerModelId).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.UVLOCK, true)
					)
					.register(Direction.SOUTH, BlockHalf.BOTTOM, StairShape.INNER_LEFT, BlockStateVariant.create().put(VariantSettings.MODEL, innerModelId))
					.register(
						Direction.NORTH,
						BlockHalf.BOTTOM,
						StairShape.INNER_LEFT,
						BlockStateVariant.create().put(VariantSettings.MODEL, innerModelId).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.EAST,
						BlockHalf.TOP,
						StairShape.STRAIGHT,
						BlockStateVariant.create().put(VariantSettings.MODEL, regularModelId).put(VariantSettings.X, Rotation.R180).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.WEST,
						BlockHalf.TOP,
						StairShape.STRAIGHT,
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, regularModelId)
							.put(VariantSettings.X, Rotation.R180)
							.put(VariantSettings.Y, Rotation.R180)
							.put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.SOUTH,
						BlockHalf.TOP,
						StairShape.STRAIGHT,
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, regularModelId)
							.put(VariantSettings.X, Rotation.R180)
							.put(VariantSettings.Y, Rotation.R90)
							.put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.NORTH,
						BlockHalf.TOP,
						StairShape.STRAIGHT,
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, regularModelId)
							.put(VariantSettings.X, Rotation.R180)
							.put(VariantSettings.Y, Rotation.R270)
							.put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.EAST,
						BlockHalf.TOP,
						StairShape.OUTER_RIGHT,
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, outerModelId)
							.put(VariantSettings.X, Rotation.R180)
							.put(VariantSettings.Y, Rotation.R90)
							.put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.WEST,
						BlockHalf.TOP,
						StairShape.OUTER_RIGHT,
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, outerModelId)
							.put(VariantSettings.X, Rotation.R180)
							.put(VariantSettings.Y, Rotation.R270)
							.put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.SOUTH,
						BlockHalf.TOP,
						StairShape.OUTER_RIGHT,
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, outerModelId)
							.put(VariantSettings.X, Rotation.R180)
							.put(VariantSettings.Y, Rotation.R180)
							.put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.NORTH,
						BlockHalf.TOP,
						StairShape.OUTER_RIGHT,
						BlockStateVariant.create().put(VariantSettings.MODEL, outerModelId).put(VariantSettings.X, Rotation.R180).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.EAST,
						BlockHalf.TOP,
						StairShape.OUTER_LEFT,
						BlockStateVariant.create().put(VariantSettings.MODEL, outerModelId).put(VariantSettings.X, Rotation.R180).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.WEST,
						BlockHalf.TOP,
						StairShape.OUTER_LEFT,
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, outerModelId)
							.put(VariantSettings.X, Rotation.R180)
							.put(VariantSettings.Y, Rotation.R180)
							.put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.SOUTH,
						BlockHalf.TOP,
						StairShape.OUTER_LEFT,
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, outerModelId)
							.put(VariantSettings.X, Rotation.R180)
							.put(VariantSettings.Y, Rotation.R90)
							.put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.NORTH,
						BlockHalf.TOP,
						StairShape.OUTER_LEFT,
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, outerModelId)
							.put(VariantSettings.X, Rotation.R180)
							.put(VariantSettings.Y, Rotation.R270)
							.put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.EAST,
						BlockHalf.TOP,
						StairShape.INNER_RIGHT,
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, innerModelId)
							.put(VariantSettings.X, Rotation.R180)
							.put(VariantSettings.Y, Rotation.R90)
							.put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.WEST,
						BlockHalf.TOP,
						StairShape.INNER_RIGHT,
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, innerModelId)
							.put(VariantSettings.X, Rotation.R180)
							.put(VariantSettings.Y, Rotation.R270)
							.put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.SOUTH,
						BlockHalf.TOP,
						StairShape.INNER_RIGHT,
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, innerModelId)
							.put(VariantSettings.X, Rotation.R180)
							.put(VariantSettings.Y, Rotation.R180)
							.put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.NORTH,
						BlockHalf.TOP,
						StairShape.INNER_RIGHT,
						BlockStateVariant.create().put(VariantSettings.MODEL, innerModelId).put(VariantSettings.X, Rotation.R180).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.EAST,
						BlockHalf.TOP,
						StairShape.INNER_LEFT,
						BlockStateVariant.create().put(VariantSettings.MODEL, innerModelId).put(VariantSettings.X, Rotation.R180).put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.WEST,
						BlockHalf.TOP,
						StairShape.INNER_LEFT,
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, innerModelId)
							.put(VariantSettings.X, Rotation.R180)
							.put(VariantSettings.Y, Rotation.R180)
							.put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.SOUTH,
						BlockHalf.TOP,
						StairShape.INNER_LEFT,
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, innerModelId)
							.put(VariantSettings.X, Rotation.R180)
							.put(VariantSettings.Y, Rotation.R90)
							.put(VariantSettings.UVLOCK, true)
					)
					.register(
						Direction.NORTH,
						BlockHalf.TOP,
						StairShape.INNER_LEFT,
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, innerModelId)
							.put(VariantSettings.X, Rotation.R180)
							.put(VariantSettings.Y, Rotation.R270)
							.put(VariantSettings.UVLOCK, true)
					)
			);
	}

	private static BlockStateSupplier createOrientableTrapdoorBlockState(
		Block trapdoorBlock, Identifier topModelId, Identifier bottomModelId, Identifier openModelId
	) {
		return VariantsBlockStateSupplier.create(trapdoorBlock)
			.coordinate(
				BlockStateVariantMap.create(Properties.HORIZONTAL_FACING, Properties.BLOCK_HALF, Properties.OPEN)
					.register(Direction.NORTH, BlockHalf.BOTTOM, false, BlockStateVariant.create().put(VariantSettings.MODEL, bottomModelId))
					.register(
						Direction.SOUTH, BlockHalf.BOTTOM, false, BlockStateVariant.create().put(VariantSettings.MODEL, bottomModelId).put(VariantSettings.Y, Rotation.R180)
					)
					.register(
						Direction.EAST, BlockHalf.BOTTOM, false, BlockStateVariant.create().put(VariantSettings.MODEL, bottomModelId).put(VariantSettings.Y, Rotation.R90)
					)
					.register(
						Direction.WEST, BlockHalf.BOTTOM, false, BlockStateVariant.create().put(VariantSettings.MODEL, bottomModelId).put(VariantSettings.Y, Rotation.R270)
					)
					.register(Direction.NORTH, BlockHalf.TOP, false, BlockStateVariant.create().put(VariantSettings.MODEL, topModelId))
					.register(Direction.SOUTH, BlockHalf.TOP, false, BlockStateVariant.create().put(VariantSettings.MODEL, topModelId).put(VariantSettings.Y, Rotation.R180))
					.register(Direction.EAST, BlockHalf.TOP, false, BlockStateVariant.create().put(VariantSettings.MODEL, topModelId).put(VariantSettings.Y, Rotation.R90))
					.register(Direction.WEST, BlockHalf.TOP, false, BlockStateVariant.create().put(VariantSettings.MODEL, topModelId).put(VariantSettings.Y, Rotation.R270))
					.register(Direction.NORTH, BlockHalf.BOTTOM, true, BlockStateVariant.create().put(VariantSettings.MODEL, openModelId))
					.register(
						Direction.SOUTH, BlockHalf.BOTTOM, true, BlockStateVariant.create().put(VariantSettings.MODEL, openModelId).put(VariantSettings.Y, Rotation.R180)
					)
					.register(Direction.EAST, BlockHalf.BOTTOM, true, BlockStateVariant.create().put(VariantSettings.MODEL, openModelId).put(VariantSettings.Y, Rotation.R90))
					.register(Direction.WEST, BlockHalf.BOTTOM, true, BlockStateVariant.create().put(VariantSettings.MODEL, openModelId).put(VariantSettings.Y, Rotation.R270))
					.register(
						Direction.NORTH,
						BlockHalf.TOP,
						true,
						BlockStateVariant.create().put(VariantSettings.MODEL, openModelId).put(VariantSettings.X, Rotation.R180).put(VariantSettings.Y, Rotation.R180)
					)
					.register(
						Direction.SOUTH,
						BlockHalf.TOP,
						true,
						BlockStateVariant.create().put(VariantSettings.MODEL, openModelId).put(VariantSettings.X, Rotation.R180).put(VariantSettings.Y, Rotation.R0)
					)
					.register(
						Direction.EAST,
						BlockHalf.TOP,
						true,
						BlockStateVariant.create().put(VariantSettings.MODEL, openModelId).put(VariantSettings.X, Rotation.R180).put(VariantSettings.Y, Rotation.R270)
					)
					.register(
						Direction.WEST,
						BlockHalf.TOP,
						true,
						BlockStateVariant.create().put(VariantSettings.MODEL, openModelId).put(VariantSettings.X, Rotation.R180).put(VariantSettings.Y, Rotation.R90)
					)
			);
	}

	private static BlockStateSupplier createTrapdoorBlockState(Block trapdoorBlock, Identifier topModelId, Identifier bottomModelId, Identifier openModelId) {
		return VariantsBlockStateSupplier.create(trapdoorBlock)
			.coordinate(
				BlockStateVariantMap.create(Properties.HORIZONTAL_FACING, Properties.BLOCK_HALF, Properties.OPEN)
					.register(Direction.NORTH, BlockHalf.BOTTOM, false, BlockStateVariant.create().put(VariantSettings.MODEL, bottomModelId))
					.register(Direction.SOUTH, BlockHalf.BOTTOM, false, BlockStateVariant.create().put(VariantSettings.MODEL, bottomModelId))
					.register(Direction.EAST, BlockHalf.BOTTOM, false, BlockStateVariant.create().put(VariantSettings.MODEL, bottomModelId))
					.register(Direction.WEST, BlockHalf.BOTTOM, false, BlockStateVariant.create().put(VariantSettings.MODEL, bottomModelId))
					.register(Direction.NORTH, BlockHalf.TOP, false, BlockStateVariant.create().put(VariantSettings.MODEL, topModelId))
					.register(Direction.SOUTH, BlockHalf.TOP, false, BlockStateVariant.create().put(VariantSettings.MODEL, topModelId))
					.register(Direction.EAST, BlockHalf.TOP, false, BlockStateVariant.create().put(VariantSettings.MODEL, topModelId))
					.register(Direction.WEST, BlockHalf.TOP, false, BlockStateVariant.create().put(VariantSettings.MODEL, topModelId))
					.register(Direction.NORTH, BlockHalf.BOTTOM, true, BlockStateVariant.create().put(VariantSettings.MODEL, openModelId))
					.register(
						Direction.SOUTH, BlockHalf.BOTTOM, true, BlockStateVariant.create().put(VariantSettings.MODEL, openModelId).put(VariantSettings.Y, Rotation.R180)
					)
					.register(Direction.EAST, BlockHalf.BOTTOM, true, BlockStateVariant.create().put(VariantSettings.MODEL, openModelId).put(VariantSettings.Y, Rotation.R90))
					.register(Direction.WEST, BlockHalf.BOTTOM, true, BlockStateVariant.create().put(VariantSettings.MODEL, openModelId).put(VariantSettings.Y, Rotation.R270))
					.register(Direction.NORTH, BlockHalf.TOP, true, BlockStateVariant.create().put(VariantSettings.MODEL, openModelId))
					.register(Direction.SOUTH, BlockHalf.TOP, true, BlockStateVariant.create().put(VariantSettings.MODEL, openModelId).put(VariantSettings.Y, Rotation.R180))
					.register(Direction.EAST, BlockHalf.TOP, true, BlockStateVariant.create().put(VariantSettings.MODEL, openModelId).put(VariantSettings.Y, Rotation.R90))
					.register(Direction.WEST, BlockHalf.TOP, true, BlockStateVariant.create().put(VariantSettings.MODEL, openModelId).put(VariantSettings.Y, Rotation.R270))
			);
	}

	static VariantsBlockStateSupplier createSingletonBlockState(Block block, Identifier modelId) {
		return VariantsBlockStateSupplier.create(block, BlockStateVariant.create().put(VariantSettings.MODEL, modelId));
	}

	private static BlockStateVariantMap createAxisRotatedVariantMap() {
		return BlockStateVariantMap.create(Properties.AXIS)
			.register(Axis.Y, BlockStateVariant.create())
			.register(Axis.Z, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90))
			.register(Axis.X, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R90));
	}

	static BlockStateSupplier createUvLockedColumnBlockState(Block block, TextureMap textureMap, BiConsumer<Identifier, ModelSupplier> modelCollector) {
		Identifier lv = Models.CUBE_COLUMN_UV_LOCKED_X.upload(block, textureMap, modelCollector);
		Identifier lv2 = Models.CUBE_COLUMN_UV_LOCKED_Y.upload(block, textureMap, modelCollector);
		Identifier lv3 = Models.CUBE_COLUMN_UV_LOCKED_Z.upload(block, textureMap, modelCollector);
		Identifier lv4 = Models.CUBE_COLUMN.upload(block, textureMap, modelCollector);
		return VariantsBlockStateSupplier.create(block, BlockStateVariant.create().put(VariantSettings.MODEL, lv4))
			.coordinate(
				BlockStateVariantMap.create(Properties.AXIS)
					.register(Axis.X, BlockStateVariant.create().put(VariantSettings.MODEL, lv))
					.register(Axis.Y, BlockStateVariant.create().put(VariantSettings.MODEL, lv2))
					.register(Axis.Z, BlockStateVariant.create().put(VariantSettings.MODEL, lv3))
			);
	}

	static BlockStateSupplier createAxisRotatedBlockState(Block block, Identifier modelId) {
		return VariantsBlockStateSupplier.create(block, BlockStateVariant.create().put(VariantSettings.MODEL, modelId)).coordinate(createAxisRotatedVariantMap());
	}

	private void registerAxisRotated(Block block, Identifier modelId) {
		this.blockStateCollector.accept(createAxisRotatedBlockState(block, modelId));
	}

	public void registerAxisRotated(Block block, Factory modelFactory) {
		Identifier lv = modelFactory.upload(block, this.modelCollector);
		this.blockStateCollector.accept(createAxisRotatedBlockState(block, lv));
	}

	private void registerNorthDefaultHorizontalRotated(Block block, Factory modelFactory) {
		Identifier lv = modelFactory.upload(block, this.modelCollector);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(block, BlockStateVariant.create().put(VariantSettings.MODEL, lv))
					.coordinate(createNorthDefaultHorizontalRotationStates())
			);
	}

	static BlockStateSupplier createAxisRotatedBlockState(Block block, Identifier verticalModelId, Identifier horizontalModelId) {
		return VariantsBlockStateSupplier.create(block)
			.coordinate(
				BlockStateVariantMap.create(Properties.AXIS)
					.register(Axis.Y, BlockStateVariant.create().put(VariantSettings.MODEL, verticalModelId))
					.register(Axis.Z, BlockStateVariant.create().put(VariantSettings.MODEL, horizontalModelId).put(VariantSettings.X, Rotation.R90))
					.register(
						Axis.X,
						BlockStateVariant.create().put(VariantSettings.MODEL, horizontalModelId).put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R90)
					)
			);
	}

	private void registerAxisRotated(Block block, Factory verticalModelFactory, Factory horizontalModelFactory) {
		Identifier lv = verticalModelFactory.upload(block, this.modelCollector);
		Identifier lv2 = horizontalModelFactory.upload(block, this.modelCollector);
		this.blockStateCollector.accept(createAxisRotatedBlockState(block, lv, lv2));
	}

	private void registerCreakingHeart(Block block) {
		Identifier lv = TexturedModel.END_FOR_TOP_CUBE_COLUMN.upload(block, this.modelCollector);
		Identifier lv2 = TexturedModel.END_FOR_TOP_CUBE_COLUMN_HORIZONTAL.upload(block, this.modelCollector);
		Identifier lv3 = this.createCreakingHeartModel(TexturedModel.END_FOR_TOP_CUBE_COLUMN, block, "_awake");
		Identifier lv4 = this.createCreakingHeartModel(TexturedModel.END_FOR_TOP_CUBE_COLUMN_HORIZONTAL, block, "_awake");
		Identifier lv5 = this.createCreakingHeartModel(TexturedModel.END_FOR_TOP_CUBE_COLUMN, block, "_dormant");
		Identifier lv6 = this.createCreakingHeartModel(TexturedModel.END_FOR_TOP_CUBE_COLUMN_HORIZONTAL, block, "_dormant");
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(block)
					.coordinate(
						BlockStateVariantMap.create(Properties.AXIS, CreakingHeartBlock.ACTIVE)
							.register(Axis.Y, CreakingHeartState.UPROOTED, BlockStateVariant.create().put(VariantSettings.MODEL, lv))
							.register(Axis.Z, CreakingHeartState.UPROOTED, BlockStateVariant.create().put(VariantSettings.MODEL, lv2).put(VariantSettings.X, Rotation.R90))
							.register(
								Axis.X,
								CreakingHeartState.UPROOTED,
								BlockStateVariant.create().put(VariantSettings.MODEL, lv2).put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R90)
							)
							.register(Axis.Y, CreakingHeartState.DORMANT, BlockStateVariant.create().put(VariantSettings.MODEL, lv5))
							.register(Axis.Z, CreakingHeartState.DORMANT, BlockStateVariant.create().put(VariantSettings.MODEL, lv6).put(VariantSettings.X, Rotation.R90))
							.register(
								Axis.X,
								CreakingHeartState.DORMANT,
								BlockStateVariant.create().put(VariantSettings.MODEL, lv6).put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R90)
							)
							.register(Axis.Y, CreakingHeartState.AWAKE, BlockStateVariant.create().put(VariantSettings.MODEL, lv3))
							.register(Axis.Z, CreakingHeartState.AWAKE, BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.X, Rotation.R90))
							.register(
								Axis.X,
								CreakingHeartState.AWAKE,
								BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R90)
							)
					)
			);
	}

	private Identifier createCreakingHeartModel(Factory texturedModelFactory, Block block, String suffix) {
		return texturedModelFactory.andThen(
				textureMap -> textureMap.put(TextureKey.SIDE, TextureMap.getSubId(block, suffix)).put(TextureKey.END, TextureMap.getSubId(block, "_top" + suffix))
			)
			.upload(block, suffix, this.modelCollector);
	}

	private Identifier createSubModel(Block block, String suffix, Model model, Function<Identifier, TextureMap> texturesFactory) {
		return model.upload(block, suffix, (TextureMap)texturesFactory.apply(TextureMap.getSubId(block, suffix)), this.modelCollector);
	}

	static BlockStateSupplier createPressurePlateBlockState(Block pressurePlateBlock, Identifier upModelId, Identifier downModelId) {
		return VariantsBlockStateSupplier.create(pressurePlateBlock).coordinate(createBooleanModelMap(Properties.POWERED, downModelId, upModelId));
	}

	static BlockStateSupplier createSlabBlockState(Block slabBlock, Identifier bottomModelId, Identifier topModelId, Identifier fullModelId) {
		return VariantsBlockStateSupplier.create(slabBlock)
			.coordinate(
				BlockStateVariantMap.create(Properties.SLAB_TYPE)
					.register(SlabType.BOTTOM, BlockStateVariant.create().put(VariantSettings.MODEL, bottomModelId))
					.register(SlabType.TOP, BlockStateVariant.create().put(VariantSettings.MODEL, topModelId))
					.register(SlabType.DOUBLE, BlockStateVariant.create().put(VariantSettings.MODEL, fullModelId))
			);
	}

	public void registerSimpleCubeAll(Block block) {
		this.registerSingleton(block, TexturedModel.CUBE_ALL);
	}

	public void registerSingleton(Block block, Factory modelFactory) {
		this.blockStateCollector.accept(createSingletonBlockState(block, modelFactory.upload(block, this.modelCollector)));
	}

	public void registerTintedBlockAndItem(Block block, Factory texturedModelFactory, int tintColor) {
		Identifier lv = texturedModelFactory.upload(block, this.modelCollector);
		this.blockStateCollector.accept(createSingletonBlockState(block, lv));
		this.registerTintedItemModel(block, lv, ItemModels.constantTintSource(tintColor));
	}

	private void registerVine() {
		this.registerMultifaceBlockModel(Blocks.VINE);
		Identifier lv = this.uploadBlockItemModel(Items.VINE, Blocks.VINE);
		this.registerTintedItemModel(Blocks.VINE, lv, ItemModels.constantTintSource(-12012264));
	}

	private void registerGrassTinted(Block block) {
		Identifier lv = this.uploadBlockItemModel(block.asItem(), block);
		this.registerTintedItemModel(block, lv, new GrassTintSource());
	}

	private BlockStateModelGenerator.BlockTexturePool registerCubeAllModelTexturePool(Block block) {
		TexturedModel lv = (TexturedModel)this.texturedModels.getOrDefault(block, TexturedModel.CUBE_ALL.get(block));
		return new BlockStateModelGenerator.BlockTexturePool(lv.getTextures()).base(block, lv.getModel());
	}

	public void registerHangingSign(Block base, Block hangingSign, Block wallHangingSign) {
		Identifier lv = this.uploadParticleModel(hangingSign, base);
		this.blockStateCollector.accept(createSingletonBlockState(hangingSign, lv));
		this.blockStateCollector.accept(createSingletonBlockState(wallHangingSign, lv));
		this.registerItemModel(hangingSign.asItem());
	}

	void registerDoor(Block doorBlock) {
		TextureMap lv = TextureMap.topBottom(doorBlock);
		Identifier lv2 = Models.DOOR_BOTTOM_LEFT.upload(doorBlock, lv, this.modelCollector);
		Identifier lv3 = Models.DOOR_BOTTOM_LEFT_OPEN.upload(doorBlock, lv, this.modelCollector);
		Identifier lv4 = Models.DOOR_BOTTOM_RIGHT.upload(doorBlock, lv, this.modelCollector);
		Identifier lv5 = Models.DOOR_BOTTOM_RIGHT_OPEN.upload(doorBlock, lv, this.modelCollector);
		Identifier lv6 = Models.DOOR_TOP_LEFT.upload(doorBlock, lv, this.modelCollector);
		Identifier lv7 = Models.DOOR_TOP_LEFT_OPEN.upload(doorBlock, lv, this.modelCollector);
		Identifier lv8 = Models.DOOR_TOP_RIGHT.upload(doorBlock, lv, this.modelCollector);
		Identifier lv9 = Models.DOOR_TOP_RIGHT_OPEN.upload(doorBlock, lv, this.modelCollector);
		this.registerItemModel(doorBlock.asItem());
		this.blockStateCollector.accept(createDoorBlockState(doorBlock, lv2, lv3, lv4, lv5, lv6, lv7, lv8, lv9));
	}

	private void registerParentedDoor(Block parent, Block doorBlock) {
		Identifier lv = Models.DOOR_BOTTOM_LEFT.getBlockSubModelId(parent);
		Identifier lv2 = Models.DOOR_BOTTOM_LEFT_OPEN.getBlockSubModelId(parent);
		Identifier lv3 = Models.DOOR_BOTTOM_RIGHT.getBlockSubModelId(parent);
		Identifier lv4 = Models.DOOR_BOTTOM_RIGHT_OPEN.getBlockSubModelId(parent);
		Identifier lv5 = Models.DOOR_TOP_LEFT.getBlockSubModelId(parent);
		Identifier lv6 = Models.DOOR_TOP_LEFT_OPEN.getBlockSubModelId(parent);
		Identifier lv7 = Models.DOOR_TOP_RIGHT.getBlockSubModelId(parent);
		Identifier lv8 = Models.DOOR_TOP_RIGHT_OPEN.getBlockSubModelId(parent);
		this.itemModelOutput.acceptAlias(parent.asItem(), doorBlock.asItem());
		this.blockStateCollector.accept(createDoorBlockState(doorBlock, lv, lv2, lv3, lv4, lv5, lv6, lv7, lv8));
	}

	void registerOrientableTrapdoor(Block trapdoorBlock) {
		TextureMap lv = TextureMap.texture(trapdoorBlock);
		Identifier lv2 = Models.TEMPLATE_ORIENTABLE_TRAPDOOR_TOP.upload(trapdoorBlock, lv, this.modelCollector);
		Identifier lv3 = Models.TEMPLATE_ORIENTABLE_TRAPDOOR_BOTTOM.upload(trapdoorBlock, lv, this.modelCollector);
		Identifier lv4 = Models.TEMPLATE_ORIENTABLE_TRAPDOOR_OPEN.upload(trapdoorBlock, lv, this.modelCollector);
		this.blockStateCollector.accept(createOrientableTrapdoorBlockState(trapdoorBlock, lv2, lv3, lv4));
		this.registerParentedItemModel(trapdoorBlock, lv3);
	}

	void registerTrapdoor(Block trapdoorBlock) {
		TextureMap lv = TextureMap.texture(trapdoorBlock);
		Identifier lv2 = Models.TEMPLATE_TRAPDOOR_TOP.upload(trapdoorBlock, lv, this.modelCollector);
		Identifier lv3 = Models.TEMPLATE_TRAPDOOR_BOTTOM.upload(trapdoorBlock, lv, this.modelCollector);
		Identifier lv4 = Models.TEMPLATE_TRAPDOOR_OPEN.upload(trapdoorBlock, lv, this.modelCollector);
		this.blockStateCollector.accept(createTrapdoorBlockState(trapdoorBlock, lv2, lv3, lv4));
		this.registerParentedItemModel(trapdoorBlock, lv3);
	}

	private void registerParentedTrapdoor(Block parent, Block trapdoorBlock) {
		Identifier lv = Models.TEMPLATE_TRAPDOOR_TOP.getBlockSubModelId(parent);
		Identifier lv2 = Models.TEMPLATE_TRAPDOOR_BOTTOM.getBlockSubModelId(parent);
		Identifier lv3 = Models.TEMPLATE_TRAPDOOR_OPEN.getBlockSubModelId(parent);
		this.itemModelOutput.acceptAlias(parent.asItem(), trapdoorBlock.asItem());
		this.blockStateCollector.accept(createTrapdoorBlockState(trapdoorBlock, lv, lv2, lv3));
	}

	private void registerBigDripleaf() {
		Identifier lv = ModelIds.getBlockModelId(Blocks.BIG_DRIPLEAF);
		Identifier lv2 = ModelIds.getBlockSubModelId(Blocks.BIG_DRIPLEAF, "_partial_tilt");
		Identifier lv3 = ModelIds.getBlockSubModelId(Blocks.BIG_DRIPLEAF, "_full_tilt");
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.BIG_DRIPLEAF)
					.coordinate(createNorthDefaultHorizontalRotationStates())
					.coordinate(
						BlockStateVariantMap.create(Properties.TILT)
							.register(Tilt.NONE, BlockStateVariant.create().put(VariantSettings.MODEL, lv))
							.register(Tilt.UNSTABLE, BlockStateVariant.create().put(VariantSettings.MODEL, lv))
							.register(Tilt.PARTIAL, BlockStateVariant.create().put(VariantSettings.MODEL, lv2))
							.register(Tilt.FULL, BlockStateVariant.create().put(VariantSettings.MODEL, lv3))
					)
			);
	}

	private BlockStateModelGenerator.LogTexturePool registerLog(Block logBlock) {
		return new BlockStateModelGenerator.LogTexturePool(TextureMap.sideAndEndForTop(logBlock));
	}

	private void registerSimpleState(Block block) {
		this.registerStateWithModelReference(block, block);
	}

	private void registerStateWithModelReference(Block block, Block modelReference) {
		this.blockStateCollector.accept(createSingletonBlockState(block, ModelIds.getBlockModelId(modelReference)));
	}

	private void registerTintableCross(Block block, BlockStateModelGenerator.CrossType crossType) {
		this.registerItemModel(block.asItem(), crossType.registerItemModel(this, block));
		this.registerTintableCrossBlockState(block, crossType);
	}

	private void registerTintableCross(Block block, BlockStateModelGenerator.CrossType tintType, TextureMap texture) {
		this.registerItemModel(block);
		this.registerTintableCrossBlockState(block, tintType, texture);
	}

	private void registerTintableCrossBlockState(Block block, BlockStateModelGenerator.CrossType tintType) {
		TextureMap lv = tintType.getTextureMap(block);
		this.registerTintableCrossBlockState(block, tintType, lv);
	}

	private void registerTintableCrossBlockState(Block block, BlockStateModelGenerator.CrossType tintType, TextureMap crossTexture) {
		Identifier lv = tintType.getCrossModel().upload(block, crossTexture, this.modelCollector);
		this.blockStateCollector.accept(createSingletonBlockState(block, lv));
	}

	private void registerTintableCrossBlockStateWithStages(
		Block block, BlockStateModelGenerator.CrossType tintType, Property<Integer> stageProperty, int... stages
	) {
		if (stageProperty.getValues().size() != stages.length) {
			throw new IllegalArgumentException("missing values for property: " + stageProperty);
		} else {
			BlockStateVariantMap lv = BlockStateVariantMap.create(stageProperty).register(stage -> {
				String string = "_stage" + stages[stage];
				TextureMap lvx = TextureMap.cross(TextureMap.getSubId(block, string));
				Identifier lv2 = tintType.getCrossModel().upload(block, string, lvx, this.modelCollector);
				return BlockStateVariant.create().put(VariantSettings.MODEL, lv2);
			});
			this.registerItemModel(block.asItem());
			this.blockStateCollector.accept(VariantsBlockStateSupplier.create(block).coordinate(lv));
		}
	}

	private void registerFlowerPotPlantAndItem(Block block, Block flowerPotBlock, BlockStateModelGenerator.CrossType crossType) {
		this.registerItemModel(block.asItem(), crossType.registerItemModel(this, block));
		this.registerFlowerPotPlant(block, flowerPotBlock, crossType);
	}

	private void registerFlowerPotPlant(Block plantBlock, Block flowerPotBlock, BlockStateModelGenerator.CrossType tintType) {
		this.registerTintableCrossBlockState(plantBlock, tintType);
		TextureMap lv = tintType.getFlowerPotTextureMap(plantBlock);
		Identifier lv2 = tintType.getFlowerPotCrossModel().upload(flowerPotBlock, lv, this.modelCollector);
		this.blockStateCollector.accept(createSingletonBlockState(flowerPotBlock, lv2));
	}

	private void registerCoralFan(Block coralFanBlock, Block coralWallFanBlock) {
		TexturedModel lv = TexturedModel.CORAL_FAN.get(coralFanBlock);
		Identifier lv2 = lv.upload(coralFanBlock, this.modelCollector);
		this.blockStateCollector.accept(createSingletonBlockState(coralFanBlock, lv2));
		Identifier lv3 = Models.CORAL_WALL_FAN.upload(coralWallFanBlock, lv.getTextures(), this.modelCollector);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(coralWallFanBlock, BlockStateVariant.create().put(VariantSettings.MODEL, lv3))
					.coordinate(createNorthDefaultHorizontalRotationStates())
			);
		this.registerItemModel(coralFanBlock);
	}

	private void registerGourd(Block stemBlock, Block attachedStemBlock) {
		this.registerItemModel(stemBlock.asItem());
		TextureMap lv = TextureMap.stem(stemBlock);
		TextureMap lv2 = TextureMap.stemAndUpper(stemBlock, attachedStemBlock);
		Identifier lv3 = Models.STEM_FRUIT.upload(attachedStemBlock, lv2, this.modelCollector);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(attachedStemBlock, BlockStateVariant.create().put(VariantSettings.MODEL, lv3))
					.coordinate(
						BlockStateVariantMap.create(Properties.HORIZONTAL_FACING)
							.register(Direction.WEST, BlockStateVariant.create())
							.register(Direction.SOUTH, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R270))
							.register(Direction.NORTH, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R90))
							.register(Direction.EAST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R180))
					)
			);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(stemBlock)
					.coordinate(
						BlockStateVariantMap.create(Properties.AGE_7)
							.register(age -> BlockStateVariant.create().put(VariantSettings.MODEL, Models.STEM_GROWTH_STAGES[age].upload(stemBlock, lv, this.modelCollector)))
					)
			);
	}

	private void registerPitcherPlant() {
		Block lv = Blocks.PITCHER_PLANT;
		this.registerItemModel(lv.asItem());
		Identifier lv2 = ModelIds.getBlockSubModelId(lv, "_top");
		Identifier lv3 = ModelIds.getBlockSubModelId(lv, "_bottom");
		this.registerDoubleBlock(lv, lv2, lv3);
	}

	private void registerPitcherCrop() {
		Block lv = Blocks.PITCHER_CROP;
		this.registerItemModel(lv.asItem());
		BlockStateVariantMap lv2 = BlockStateVariantMap.create(PitcherCropBlock.AGE, Properties.DOUBLE_BLOCK_HALF).register((age, half) -> {
			return switch (half) {
				case UPPER -> BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(lv, "_top_stage_" + age));
				case LOWER -> BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(lv, "_bottom_stage_" + age));
				default -> throw new MatchException(null, null);
			};
		});
		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(lv).coordinate(lv2));
	}

	private void registerCoral(
		Block coral, Block deadCoral, Block coralBlock, Block deadCoralBlock, Block coralFan, Block deadCoralFan, Block coralWallFan, Block deadCoralWallFan
	) {
		this.registerTintableCross(coral, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerTintableCross(deadCoral, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerSimpleCubeAll(coralBlock);
		this.registerSimpleCubeAll(deadCoralBlock);
		this.registerCoralFan(coralFan, coralWallFan);
		this.registerCoralFan(deadCoralFan, deadCoralWallFan);
	}

	private void registerDoubleBlock(Block doubleBlock, BlockStateModelGenerator.CrossType tintType) {
		Identifier lv = this.createSubModel(doubleBlock, "_top", tintType.getCrossModel(), TextureMap::cross);
		Identifier lv2 = this.createSubModel(doubleBlock, "_bottom", tintType.getCrossModel(), TextureMap::cross);
		this.registerDoubleBlock(doubleBlock, lv, lv2);
	}

	private void registerDoubleBlockAndItem(Block block, BlockStateModelGenerator.CrossType crossType) {
		this.registerItemModel(block, "_top");
		this.registerDoubleBlock(block, crossType);
	}

	private void registerGrassTintedDoubleBlockAndItem(Block block) {
		Identifier lv = this.uploadBlockItemModel(block.asItem(), block, "_top");
		this.registerTintedItemModel(block, lv, new GrassTintSource());
		this.registerDoubleBlock(block, BlockStateModelGenerator.CrossType.TINTED);
	}

	private void registerSunflower() {
		this.registerItemModel(Blocks.SUNFLOWER, "_front");
		Identifier lv = ModelIds.getBlockSubModelId(Blocks.SUNFLOWER, "_top");
		Identifier lv2 = this.createSubModel(Blocks.SUNFLOWER, "_bottom", BlockStateModelGenerator.CrossType.NOT_TINTED.getCrossModel(), TextureMap::cross);
		this.registerDoubleBlock(Blocks.SUNFLOWER, lv, lv2);
	}

	private void registerTallSeagrass() {
		Identifier lv = this.createSubModel(Blocks.TALL_SEAGRASS, "_top", Models.TEMPLATE_SEAGRASS, TextureMap::texture);
		Identifier lv2 = this.createSubModel(Blocks.TALL_SEAGRASS, "_bottom", Models.TEMPLATE_SEAGRASS, TextureMap::texture);
		this.registerDoubleBlock(Blocks.TALL_SEAGRASS, lv, lv2);
	}

	private void registerSmallDripleaf() {
		Identifier lv = ModelIds.getBlockSubModelId(Blocks.SMALL_DRIPLEAF, "_top");
		Identifier lv2 = ModelIds.getBlockSubModelId(Blocks.SMALL_DRIPLEAF, "_bottom");
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.SMALL_DRIPLEAF)
					.coordinate(createNorthDefaultHorizontalRotationStates())
					.coordinate(
						BlockStateVariantMap.create(Properties.DOUBLE_BLOCK_HALF)
							.register(DoubleBlockHalf.LOWER, BlockStateVariant.create().put(VariantSettings.MODEL, lv2))
							.register(DoubleBlockHalf.UPPER, BlockStateVariant.create().put(VariantSettings.MODEL, lv))
					)
			);
	}

	private void registerDoubleBlock(Block block, Identifier upperHalfModelId, Identifier lowerHalfModelId) {
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(block)
					.coordinate(
						BlockStateVariantMap.create(Properties.DOUBLE_BLOCK_HALF)
							.register(DoubleBlockHalf.LOWER, BlockStateVariant.create().put(VariantSettings.MODEL, lowerHalfModelId))
							.register(DoubleBlockHalf.UPPER, BlockStateVariant.create().put(VariantSettings.MODEL, upperHalfModelId))
					)
			);
	}

	private void registerTurnableRail(Block rail) {
		TextureMap lv = TextureMap.rail(rail);
		TextureMap lv2 = TextureMap.rail(TextureMap.getSubId(rail, "_corner"));
		Identifier lv3 = Models.RAIL_FLAT.upload(rail, lv, this.modelCollector);
		Identifier lv4 = Models.RAIL_CURVED.upload(rail, lv2, this.modelCollector);
		Identifier lv5 = Models.TEMPLATE_RAIL_RAISED_NE.upload(rail, lv, this.modelCollector);
		Identifier lv6 = Models.TEMPLATE_RAIL_RAISED_SW.upload(rail, lv, this.modelCollector);
		this.registerItemModel(rail);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(rail)
					.coordinate(
						BlockStateVariantMap.create(Properties.RAIL_SHAPE)
							.register(RailShape.NORTH_SOUTH, BlockStateVariant.create().put(VariantSettings.MODEL, lv3))
							.register(RailShape.EAST_WEST, BlockStateVariant.create().put(VariantSettings.MODEL, lv3).put(VariantSettings.Y, Rotation.R90))
							.register(RailShape.ASCENDING_EAST, BlockStateVariant.create().put(VariantSettings.MODEL, lv5).put(VariantSettings.Y, Rotation.R90))
							.register(RailShape.ASCENDING_WEST, BlockStateVariant.create().put(VariantSettings.MODEL, lv6).put(VariantSettings.Y, Rotation.R90))
							.register(RailShape.ASCENDING_NORTH, BlockStateVariant.create().put(VariantSettings.MODEL, lv5))
							.register(RailShape.ASCENDING_SOUTH, BlockStateVariant.create().put(VariantSettings.MODEL, lv6))
							.register(RailShape.SOUTH_EAST, BlockStateVariant.create().put(VariantSettings.MODEL, lv4))
							.register(RailShape.SOUTH_WEST, BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.Y, Rotation.R90))
							.register(RailShape.NORTH_WEST, BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.Y, Rotation.R180))
							.register(RailShape.NORTH_EAST, BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.Y, Rotation.R270))
					)
			);
	}

	private void registerStraightRail(Block rail) {
		Identifier lv = this.createSubModel(rail, "", Models.RAIL_FLAT, TextureMap::rail);
		Identifier lv2 = this.createSubModel(rail, "", Models.TEMPLATE_RAIL_RAISED_NE, TextureMap::rail);
		Identifier lv3 = this.createSubModel(rail, "", Models.TEMPLATE_RAIL_RAISED_SW, TextureMap::rail);
		Identifier lv4 = this.createSubModel(rail, "_on", Models.RAIL_FLAT, TextureMap::rail);
		Identifier lv5 = this.createSubModel(rail, "_on", Models.TEMPLATE_RAIL_RAISED_NE, TextureMap::rail);
		Identifier lv6 = this.createSubModel(rail, "_on", Models.TEMPLATE_RAIL_RAISED_SW, TextureMap::rail);
		BlockStateVariantMap lv7 = BlockStateVariantMap.create(Properties.POWERED, Properties.STRAIGHT_RAIL_SHAPE).register((on, shape) -> {
			switch (shape) {
				case NORTH_SOUTH:
					return BlockStateVariant.create().put(VariantSettings.MODEL, on ? lv4 : lv);
				case EAST_WEST:
					return BlockStateVariant.create().put(VariantSettings.MODEL, on ? lv4 : lv).put(VariantSettings.Y, Rotation.R90);
				case ASCENDING_EAST:
					return BlockStateVariant.create().put(VariantSettings.MODEL, on ? lv5 : lv2).put(VariantSettings.Y, Rotation.R90);
				case ASCENDING_WEST:
					return BlockStateVariant.create().put(VariantSettings.MODEL, on ? lv6 : lv3).put(VariantSettings.Y, Rotation.R90);
				case ASCENDING_NORTH:
					return BlockStateVariant.create().put(VariantSettings.MODEL, on ? lv5 : lv2);
				case ASCENDING_SOUTH:
					return BlockStateVariant.create().put(VariantSettings.MODEL, on ? lv6 : lv3);
				default:
					throw new UnsupportedOperationException("Fix you generator!");
			}
		});
		this.registerItemModel(rail);
		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(rail).coordinate(lv7));
	}

	private void registerBuiltinWithParticle(Block block, Item particleSource) {
		Identifier lv = Models.PARTICLE.upload(block, TextureMap.particle(particleSource), this.modelCollector);
		this.blockStateCollector.accept(createSingletonBlockState(block, lv));
	}

	private void registerBuiltinWithParticle(Block block, Identifier particleSource) {
		Identifier lv = Models.PARTICLE.upload(block, TextureMap.particle(particleSource), this.modelCollector);
		this.blockStateCollector.accept(createSingletonBlockState(block, lv));
	}

	private Identifier uploadParticleModel(Block block, Block particleSource) {
		return Models.PARTICLE.upload(block, TextureMap.particle(particleSource), this.modelCollector);
	}

	public void registerBuiltinWithParticle(Block block, Block particleSource) {
		this.blockStateCollector.accept(createSingletonBlockState(block, this.uploadParticleModel(block, particleSource)));
	}

	private void registerBuiltin(Block block) {
		this.registerBuiltinWithParticle(block, block);
	}

	private void registerWoolAndCarpet(Block wool, Block carpet) {
		this.registerSimpleCubeAll(wool);
		Identifier lv = TexturedModel.CARPET.get(wool).upload(carpet, this.modelCollector);
		this.blockStateCollector.accept(createSingletonBlockState(carpet, lv));
	}

	private void registerLeafLitter(Block leafLitter) {
		Identifier lv = TexturedModel.TEMPLATE_LEAF_LITTER_1.upload(leafLitter, this.modelCollector);
		Identifier lv2 = TexturedModel.TEMPLATE_LEAF_LITTER_2.upload(leafLitter, this.modelCollector);
		Identifier lv3 = TexturedModel.TEMPLATE_LEAF_LITTER_3.upload(leafLitter, this.modelCollector);
		Identifier lv4 = TexturedModel.TEMPLATE_LEAF_LITTER_4.upload(leafLitter, this.modelCollector);
		this.registerItemModel(leafLitter);
		this.registerSegmentedBlock(leafLitter, Properties.SEGMENT_AMOUNT, lv, lv2, lv3, lv4);
	}

	private void registerFlowerbed(Block flowerbed) {
		Identifier lv = TexturedModel.FLOWERBED_1.upload(flowerbed, this.modelCollector);
		Identifier lv2 = TexturedModel.FLOWERBED_2.upload(flowerbed, this.modelCollector);
		Identifier lv3 = TexturedModel.FLOWERBED_3.upload(flowerbed, this.modelCollector);
		Identifier lv4 = TexturedModel.FLOWERBED_4.upload(flowerbed, this.modelCollector);
		this.registerItemModel(flowerbed.asItem());
		this.registerSegmentedBlock(flowerbed, Properties.FLOWER_AMOUNT, lv, lv2, lv3, lv4);
	}

	private void registerSegmentedBlock(Block block, IntProperty amountProperty, Identifier model1, Identifier model2, Identifier model3, Identifier model4) {
		this.blockStateCollector
			.accept(
				MultipartBlockStateSupplier.create(block)
					.with(
						When.create().set(amountProperty, 1, 2, 3, 4).set(Properties.HORIZONTAL_FACING, Direction.NORTH),
						BlockStateVariant.create().put(VariantSettings.MODEL, model1)
					)
					.with(
						When.create().set(amountProperty, 1, 2, 3, 4).set(Properties.HORIZONTAL_FACING, Direction.EAST),
						BlockStateVariant.create().put(VariantSettings.MODEL, model1).put(VariantSettings.Y, Rotation.R90)
					)
					.with(
						When.create().set(amountProperty, 1, 2, 3, 4).set(Properties.HORIZONTAL_FACING, Direction.SOUTH),
						BlockStateVariant.create().put(VariantSettings.MODEL, model1).put(VariantSettings.Y, Rotation.R180)
					)
					.with(
						When.create().set(amountProperty, 1, 2, 3, 4).set(Properties.HORIZONTAL_FACING, Direction.WEST),
						BlockStateVariant.create().put(VariantSettings.MODEL, model1).put(VariantSettings.Y, Rotation.R270)
					)
					.with(
						When.create().set(amountProperty, 2, 3, 4).set(Properties.HORIZONTAL_FACING, Direction.NORTH),
						BlockStateVariant.create().put(VariantSettings.MODEL, model2)
					)
					.with(
						When.create().set(amountProperty, 2, 3, 4).set(Properties.HORIZONTAL_FACING, Direction.EAST),
						BlockStateVariant.create().put(VariantSettings.MODEL, model2).put(VariantSettings.Y, Rotation.R90)
					)
					.with(
						When.create().set(amountProperty, 2, 3, 4).set(Properties.HORIZONTAL_FACING, Direction.SOUTH),
						BlockStateVariant.create().put(VariantSettings.MODEL, model2).put(VariantSettings.Y, Rotation.R180)
					)
					.with(
						When.create().set(amountProperty, 2, 3, 4).set(Properties.HORIZONTAL_FACING, Direction.WEST),
						BlockStateVariant.create().put(VariantSettings.MODEL, model2).put(VariantSettings.Y, Rotation.R270)
					)
					.with(
						When.create().set(amountProperty, 3, 4).set(Properties.HORIZONTAL_FACING, Direction.NORTH), BlockStateVariant.create().put(VariantSettings.MODEL, model3)
					)
					.with(
						When.create().set(amountProperty, 3, 4).set(Properties.HORIZONTAL_FACING, Direction.EAST),
						BlockStateVariant.create().put(VariantSettings.MODEL, model3).put(VariantSettings.Y, Rotation.R90)
					)
					.with(
						When.create().set(amountProperty, 3, 4).set(Properties.HORIZONTAL_FACING, Direction.SOUTH),
						BlockStateVariant.create().put(VariantSettings.MODEL, model3).put(VariantSettings.Y, Rotation.R180)
					)
					.with(
						When.create().set(amountProperty, 3, 4).set(Properties.HORIZONTAL_FACING, Direction.WEST),
						BlockStateVariant.create().put(VariantSettings.MODEL, model3).put(VariantSettings.Y, Rotation.R270)
					)
					.with(
						When.create().set(amountProperty, 4).set(Properties.HORIZONTAL_FACING, Direction.NORTH), BlockStateVariant.create().put(VariantSettings.MODEL, model4)
					)
					.with(
						When.create().set(amountProperty, 4).set(Properties.HORIZONTAL_FACING, Direction.EAST),
						BlockStateVariant.create().put(VariantSettings.MODEL, model4).put(VariantSettings.Y, Rotation.R90)
					)
					.with(
						When.create().set(amountProperty, 4).set(Properties.HORIZONTAL_FACING, Direction.SOUTH),
						BlockStateVariant.create().put(VariantSettings.MODEL, model4).put(VariantSettings.Y, Rotation.R180)
					)
					.with(
						When.create().set(amountProperty, 4).set(Properties.HORIZONTAL_FACING, Direction.WEST),
						BlockStateVariant.create().put(VariantSettings.MODEL, model4).put(VariantSettings.Y, Rotation.R270)
					)
			);
	}

	private void registerRandomHorizontalRotations(Factory modelFactory, Block... blocks) {
		for (Block lv : blocks) {
			Identifier lv2 = modelFactory.upload(lv, this.modelCollector);
			this.blockStateCollector.accept(createBlockStateWithRandomHorizontalRotations(lv, lv2));
		}
	}

	private void registerSouthDefaultHorizontalFacing(Factory modelFactory, Block... blocks) {
		for (Block lv : blocks) {
			Identifier lv2 = modelFactory.upload(lv, this.modelCollector);
			this.blockStateCollector
				.accept(
					VariantsBlockStateSupplier.create(lv, BlockStateVariant.create().put(VariantSettings.MODEL, lv2)).coordinate(createSouthDefaultHorizontalRotationStates())
				);
		}
	}

	private void registerGlassAndPane(Block glassBlock, Block glassPane) {
		this.registerSimpleCubeAll(glassBlock);
		TextureMap lv = TextureMap.paneAndTopForEdge(glassBlock, glassPane);
		Identifier lv2 = Models.TEMPLATE_GLASS_PANE_POST.upload(glassPane, lv, this.modelCollector);
		Identifier lv3 = Models.TEMPLATE_GLASS_PANE_SIDE.upload(glassPane, lv, this.modelCollector);
		Identifier lv4 = Models.TEMPLATE_GLASS_PANE_SIDE_ALT.upload(glassPane, lv, this.modelCollector);
		Identifier lv5 = Models.TEMPLATE_GLASS_PANE_NOSIDE.upload(glassPane, lv, this.modelCollector);
		Identifier lv6 = Models.TEMPLATE_GLASS_PANE_NOSIDE_ALT.upload(glassPane, lv, this.modelCollector);
		Item lv7 = glassPane.asItem();
		this.registerItemModel(lv7, this.uploadBlockItemModel(lv7, glassBlock));
		this.blockStateCollector
			.accept(
				MultipartBlockStateSupplier.create(glassPane)
					.with(BlockStateVariant.create().put(VariantSettings.MODEL, lv2))
					.with(When.create().set(Properties.NORTH, true), BlockStateVariant.create().put(VariantSettings.MODEL, lv3))
					.with(When.create().set(Properties.EAST, true), BlockStateVariant.create().put(VariantSettings.MODEL, lv3).put(VariantSettings.Y, Rotation.R90))
					.with(When.create().set(Properties.SOUTH, true), BlockStateVariant.create().put(VariantSettings.MODEL, lv4))
					.with(When.create().set(Properties.WEST, true), BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.Y, Rotation.R90))
					.with(When.create().set(Properties.NORTH, false), BlockStateVariant.create().put(VariantSettings.MODEL, lv5))
					.with(When.create().set(Properties.EAST, false), BlockStateVariant.create().put(VariantSettings.MODEL, lv6))
					.with(When.create().set(Properties.SOUTH, false), BlockStateVariant.create().put(VariantSettings.MODEL, lv6).put(VariantSettings.Y, Rotation.R90))
					.with(When.create().set(Properties.WEST, false), BlockStateVariant.create().put(VariantSettings.MODEL, lv5).put(VariantSettings.Y, Rotation.R270))
			);
	}

	private void registerCommandBlock(Block commandBlock) {
		TextureMap lv = TextureMap.sideFrontBack(commandBlock);
		Identifier lv2 = Models.TEMPLATE_COMMAND_BLOCK.upload(commandBlock, lv, this.modelCollector);
		Identifier lv3 = this.createSubModel(commandBlock, "_conditional", Models.TEMPLATE_COMMAND_BLOCK, id -> lv.copyAndAdd(TextureKey.SIDE, id));
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(commandBlock)
					.coordinate(createBooleanModelMap(Properties.CONDITIONAL, lv3, lv2))
					.coordinate(createNorthDefaultRotationStates())
			);
	}

	private void registerAnvil(Block anvil) {
		Identifier lv = TexturedModel.TEMPLATE_ANVIL.upload(anvil, this.modelCollector);
		this.blockStateCollector.accept(createSingletonBlockState(anvil, lv).coordinate(createSouthDefaultHorizontalRotationStates()));
	}

	private List<BlockStateVariant> getBambooBlockStateVariants(int age) {
		String string = "_age" + age;
		return (List<BlockStateVariant>)IntStream.range(1, 5)
			.mapToObj(i -> BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.BAMBOO, i + string)))
			.collect(Collectors.toList());
	}

	private void registerBamboo() {
		this.blockStateCollector
			.accept(
				MultipartBlockStateSupplier.create(Blocks.BAMBOO)
					.with(When.create().set(Properties.AGE_1, 0), this.getBambooBlockStateVariants(0))
					.with(When.create().set(Properties.AGE_1, 1), this.getBambooBlockStateVariants(1))
					.with(
						When.create().set(Properties.BAMBOO_LEAVES, BambooLeaves.SMALL),
						BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.BAMBOO, "_small_leaves"))
					)
					.with(
						When.create().set(Properties.BAMBOO_LEAVES, BambooLeaves.LARGE),
						BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.BAMBOO, "_large_leaves"))
					)
			);
	}

	private BlockStateVariantMap createUpDefaultFacingVariantMap() {
		return BlockStateVariantMap.create(Properties.FACING)
			.register(Direction.DOWN, BlockStateVariant.create().put(VariantSettings.X, Rotation.R180))
			.register(Direction.UP, BlockStateVariant.create())
			.register(Direction.NORTH, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90))
			.register(Direction.SOUTH, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R180))
			.register(Direction.WEST, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R270))
			.register(Direction.EAST, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R90));
	}

	private void registerBarrel() {
		Identifier lv = TextureMap.getSubId(Blocks.BARREL, "_top_open");
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.BARREL)
					.coordinate(this.createUpDefaultFacingVariantMap())
					.coordinate(
						BlockStateVariantMap.create(Properties.OPEN)
							.register(false, BlockStateVariant.create().put(VariantSettings.MODEL, TexturedModel.CUBE_BOTTOM_TOP.upload(Blocks.BARREL, this.modelCollector)))
							.register(
								true,
								BlockStateVariant.create()
									.put(
										VariantSettings.MODEL,
										TexturedModel.CUBE_BOTTOM_TOP.get(Blocks.BARREL).textures(arg2 -> arg2.put(TextureKey.TOP, lv)).upload(Blocks.BARREL, "_open", this.modelCollector)
									)
							)
					)
			);
	}

	private static <T extends Comparable<T>> BlockStateVariantMap createValueFencedModelMap(
		Property<T> property, T fence, Identifier higherOrEqualModelId, Identifier lowerModelId
	) {
		BlockStateVariant lv = BlockStateVariant.create().put(VariantSettings.MODEL, higherOrEqualModelId);
		BlockStateVariant lv2 = BlockStateVariant.create().put(VariantSettings.MODEL, lowerModelId);
		return BlockStateVariantMap.create(property).register(comparable2 -> {
			boolean bl = comparable2.compareTo(fence) >= 0;
			return bl ? lv : lv2;
		});
	}

	private void registerBeehive(Block beehive, Function<Block, TextureMap> texturesFactory) {
		TextureMap lv = ((TextureMap)texturesFactory.apply(beehive)).inherit(TextureKey.SIDE, TextureKey.PARTICLE);
		TextureMap lv2 = lv.copyAndAdd(TextureKey.FRONT, TextureMap.getSubId(beehive, "_front_honey"));
		Identifier lv3 = Models.ORIENTABLE_WITH_BOTTOM.upload(beehive, "_empty", lv, this.modelCollector);
		Identifier lv4 = Models.ORIENTABLE_WITH_BOTTOM.upload(beehive, "_honey", lv2, this.modelCollector);
		this.itemModelOutput.accept(beehive.asItem(), ItemModels.select(BeehiveBlock.HONEY_LEVEL, ItemModels.basic(lv3), Map.of(5, ItemModels.basic(lv4))));
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(beehive)
					.coordinate(createNorthDefaultHorizontalRotationStates())
					.coordinate(createValueFencedModelMap(BeehiveBlock.HONEY_LEVEL, 5, lv4, lv3))
			);
	}

	private void registerCrop(Block crop, Property<Integer> ageProperty, int... ageTextureIndices) {
		if (ageProperty.getValues().size() != ageTextureIndices.length) {
			throw new IllegalArgumentException();
		} else {
			Int2ObjectMap<Identifier> int2ObjectMap = new Int2ObjectOpenHashMap();
			BlockStateVariantMap lv = BlockStateVariantMap.create(ageProperty).register(integer -> {
				int i = ageTextureIndices[integer];
				Identifier lvx = (Identifier)int2ObjectMap.computeIfAbsent(i, j -> this.createSubModel(crop, "_stage" + i, Models.CROP, TextureMap::crop));
				return BlockStateVariant.create().put(VariantSettings.MODEL, lvx);
			});
			this.registerItemModel(crop.asItem());
			this.blockStateCollector.accept(VariantsBlockStateSupplier.create(crop).coordinate(lv));
		}
	}

	private void registerBell() {
		Identifier lv = ModelIds.getBlockSubModelId(Blocks.BELL, "_floor");
		Identifier lv2 = ModelIds.getBlockSubModelId(Blocks.BELL, "_ceiling");
		Identifier lv3 = ModelIds.getBlockSubModelId(Blocks.BELL, "_wall");
		Identifier lv4 = ModelIds.getBlockSubModelId(Blocks.BELL, "_between_walls");
		this.registerItemModel(Items.BELL);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.BELL)
					.coordinate(
						BlockStateVariantMap.create(Properties.HORIZONTAL_FACING, Properties.ATTACHMENT)
							.register(Direction.NORTH, Attachment.FLOOR, BlockStateVariant.create().put(VariantSettings.MODEL, lv))
							.register(Direction.SOUTH, Attachment.FLOOR, BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R180))
							.register(Direction.EAST, Attachment.FLOOR, BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R90))
							.register(Direction.WEST, Attachment.FLOOR, BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R270))
							.register(Direction.NORTH, Attachment.CEILING, BlockStateVariant.create().put(VariantSettings.MODEL, lv2))
							.register(Direction.SOUTH, Attachment.CEILING, BlockStateVariant.create().put(VariantSettings.MODEL, lv2).put(VariantSettings.Y, Rotation.R180))
							.register(Direction.EAST, Attachment.CEILING, BlockStateVariant.create().put(VariantSettings.MODEL, lv2).put(VariantSettings.Y, Rotation.R90))
							.register(Direction.WEST, Attachment.CEILING, BlockStateVariant.create().put(VariantSettings.MODEL, lv2).put(VariantSettings.Y, Rotation.R270))
							.register(Direction.NORTH, Attachment.SINGLE_WALL, BlockStateVariant.create().put(VariantSettings.MODEL, lv3).put(VariantSettings.Y, Rotation.R270))
							.register(Direction.SOUTH, Attachment.SINGLE_WALL, BlockStateVariant.create().put(VariantSettings.MODEL, lv3).put(VariantSettings.Y, Rotation.R90))
							.register(Direction.EAST, Attachment.SINGLE_WALL, BlockStateVariant.create().put(VariantSettings.MODEL, lv3))
							.register(Direction.WEST, Attachment.SINGLE_WALL, BlockStateVariant.create().put(VariantSettings.MODEL, lv3).put(VariantSettings.Y, Rotation.R180))
							.register(Direction.SOUTH, Attachment.DOUBLE_WALL, BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.Y, Rotation.R90))
							.register(Direction.NORTH, Attachment.DOUBLE_WALL, BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.Y, Rotation.R270))
							.register(Direction.EAST, Attachment.DOUBLE_WALL, BlockStateVariant.create().put(VariantSettings.MODEL, lv4))
							.register(Direction.WEST, Attachment.DOUBLE_WALL, BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.Y, Rotation.R180))
					)
			);
	}

	private void registerGrindstone() {
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.GRINDSTONE, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockModelId(Blocks.GRINDSTONE)))
					.coordinate(
						BlockStateVariantMap.create(Properties.BLOCK_FACE, Properties.HORIZONTAL_FACING)
							.register(BlockFace.FLOOR, Direction.NORTH, BlockStateVariant.create())
							.register(BlockFace.FLOOR, Direction.EAST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R90))
							.register(BlockFace.FLOOR, Direction.SOUTH, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R180))
							.register(BlockFace.FLOOR, Direction.WEST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R270))
							.register(BlockFace.WALL, Direction.NORTH, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90))
							.register(BlockFace.WALL, Direction.EAST, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R90))
							.register(BlockFace.WALL, Direction.SOUTH, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R180))
							.register(BlockFace.WALL, Direction.WEST, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R270))
							.register(BlockFace.CEILING, Direction.SOUTH, BlockStateVariant.create().put(VariantSettings.X, Rotation.R180))
							.register(BlockFace.CEILING, Direction.WEST, BlockStateVariant.create().put(VariantSettings.X, Rotation.R180).put(VariantSettings.Y, Rotation.R90))
							.register(BlockFace.CEILING, Direction.NORTH, BlockStateVariant.create().put(VariantSettings.X, Rotation.R180).put(VariantSettings.Y, Rotation.R180))
							.register(BlockFace.CEILING, Direction.EAST, BlockStateVariant.create().put(VariantSettings.X, Rotation.R180).put(VariantSettings.Y, Rotation.R270))
					)
			);
	}

	private void registerCooker(Block cooker, Factory modelFactory) {
		Identifier lv = modelFactory.upload(cooker, this.modelCollector);
		Identifier lv2 = TextureMap.getSubId(cooker, "_front_on");
		Identifier lv3 = modelFactory.get(cooker).textures(textures -> textures.put(TextureKey.FRONT, lv2)).upload(cooker, "_on", this.modelCollector);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(cooker)
					.coordinate(createBooleanModelMap(Properties.LIT, lv3, lv))
					.coordinate(createNorthDefaultHorizontalRotationStates())
			);
	}

	private void registerCampfire(Block... blocks) {
		Identifier lv = ModelIds.getMinecraftNamespacedBlock("campfire_off");

		for (Block lv2 : blocks) {
			Identifier lv3 = Models.TEMPLATE_CAMPFIRE.upload(lv2, TextureMap.campfire(lv2), this.modelCollector);
			this.registerItemModel(lv2.asItem());
			this.blockStateCollector
				.accept(
					VariantsBlockStateSupplier.create(lv2).coordinate(createBooleanModelMap(Properties.LIT, lv3, lv)).coordinate(createSouthDefaultHorizontalRotationStates())
				);
		}
	}

	private void registerAzalea(Block block) {
		Identifier lv = Models.TEMPLATE_AZALEA.upload(block, TextureMap.sideAndTop(block), this.modelCollector);
		this.blockStateCollector.accept(createSingletonBlockState(block, lv));
	}

	private void registerPottedAzaleaBush(Block block) {
		Identifier lv;
		if (block == Blocks.POTTED_FLOWERING_AZALEA_BUSH) {
			lv = Models.TEMPLATE_POTTED_FLOWERING_AZALEA_BUSH.upload(block, TextureMap.pottedAzaleaBush(block), this.modelCollector);
		} else {
			lv = Models.TEMPLATE_POTTED_AZALEA_BUSH.upload(block, TextureMap.pottedAzaleaBush(block), this.modelCollector);
		}

		this.blockStateCollector.accept(createSingletonBlockState(block, lv));
	}

	private void registerBookshelf() {
		TextureMap lv = TextureMap.sideEnd(TextureMap.getId(Blocks.BOOKSHELF), TextureMap.getId(Blocks.OAK_PLANKS));
		Identifier lv2 = Models.CUBE_COLUMN.upload(Blocks.BOOKSHELF, lv, this.modelCollector);
		this.blockStateCollector.accept(createSingletonBlockState(Blocks.BOOKSHELF, lv2));
	}

	private void registerRedstone() {
		this.registerItemModel(Items.REDSTONE);
		this.blockStateCollector
			.accept(
				MultipartBlockStateSupplier.create(Blocks.REDSTONE_WIRE)
					.with(
						When.anyOf(
							When.create()
								.set(Properties.NORTH_WIRE_CONNECTION, WireConnection.NONE)
								.set(Properties.EAST_WIRE_CONNECTION, WireConnection.NONE)
								.set(Properties.SOUTH_WIRE_CONNECTION, WireConnection.NONE)
								.set(Properties.WEST_WIRE_CONNECTION, WireConnection.NONE),
							When.create()
								.set(Properties.NORTH_WIRE_CONNECTION, WireConnection.SIDE, WireConnection.UP)
								.set(Properties.EAST_WIRE_CONNECTION, WireConnection.SIDE, WireConnection.UP),
							When.create()
								.set(Properties.EAST_WIRE_CONNECTION, WireConnection.SIDE, WireConnection.UP)
								.set(Properties.SOUTH_WIRE_CONNECTION, WireConnection.SIDE, WireConnection.UP),
							When.create()
								.set(Properties.SOUTH_WIRE_CONNECTION, WireConnection.SIDE, WireConnection.UP)
								.set(Properties.WEST_WIRE_CONNECTION, WireConnection.SIDE, WireConnection.UP),
							When.create()
								.set(Properties.WEST_WIRE_CONNECTION, WireConnection.SIDE, WireConnection.UP)
								.set(Properties.NORTH_WIRE_CONNECTION, WireConnection.SIDE, WireConnection.UP)
						),
						BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getMinecraftNamespacedBlock("redstone_dust_dot"))
					)
					.with(
						When.create().set(Properties.NORTH_WIRE_CONNECTION, WireConnection.SIDE, WireConnection.UP),
						BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getMinecraftNamespacedBlock("redstone_dust_side0"))
					)
					.with(
						When.create().set(Properties.SOUTH_WIRE_CONNECTION, WireConnection.SIDE, WireConnection.UP),
						BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getMinecraftNamespacedBlock("redstone_dust_side_alt0"))
					)
					.with(
						When.create().set(Properties.EAST_WIRE_CONNECTION, WireConnection.SIDE, WireConnection.UP),
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, ModelIds.getMinecraftNamespacedBlock("redstone_dust_side_alt1"))
							.put(VariantSettings.Y, Rotation.R270)
					)
					.with(
						When.create().set(Properties.WEST_WIRE_CONNECTION, WireConnection.SIDE, WireConnection.UP),
						BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getMinecraftNamespacedBlock("redstone_dust_side1")).put(VariantSettings.Y, Rotation.R270)
					)
					.with(
						When.create().set(Properties.NORTH_WIRE_CONNECTION, WireConnection.UP),
						BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getMinecraftNamespacedBlock("redstone_dust_up"))
					)
					.with(
						When.create().set(Properties.EAST_WIRE_CONNECTION, WireConnection.UP),
						BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getMinecraftNamespacedBlock("redstone_dust_up")).put(VariantSettings.Y, Rotation.R90)
					)
					.with(
						When.create().set(Properties.SOUTH_WIRE_CONNECTION, WireConnection.UP),
						BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getMinecraftNamespacedBlock("redstone_dust_up")).put(VariantSettings.Y, Rotation.R180)
					)
					.with(
						When.create().set(Properties.WEST_WIRE_CONNECTION, WireConnection.UP),
						BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getMinecraftNamespacedBlock("redstone_dust_up")).put(VariantSettings.Y, Rotation.R270)
					)
			);
	}

	private void registerComparator() {
		this.registerItemModel(Items.COMPARATOR);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.COMPARATOR)
					.coordinate(createSouthDefaultHorizontalRotationStates())
					.coordinate(
						BlockStateVariantMap.create(Properties.COMPARATOR_MODE, Properties.POWERED)
							.register(ComparatorMode.COMPARE, false, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockModelId(Blocks.COMPARATOR)))
							.register(ComparatorMode.COMPARE, true, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.COMPARATOR, "_on")))
							.register(
								ComparatorMode.SUBTRACT, false, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.COMPARATOR, "_subtract"))
							)
							.register(
								ComparatorMode.SUBTRACT, true, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.COMPARATOR, "_on_subtract"))
							)
					)
			);
	}

	private void registerSmoothStone() {
		TextureMap lv = TextureMap.all(Blocks.SMOOTH_STONE);
		TextureMap lv2 = TextureMap.sideEnd(TextureMap.getSubId(Blocks.SMOOTH_STONE_SLAB, "_side"), lv.getTexture(TextureKey.TOP));
		Identifier lv3 = Models.SLAB.upload(Blocks.SMOOTH_STONE_SLAB, lv2, this.modelCollector);
		Identifier lv4 = Models.SLAB_TOP.upload(Blocks.SMOOTH_STONE_SLAB, lv2, this.modelCollector);
		Identifier lv5 = Models.CUBE_COLUMN.uploadWithoutVariant(Blocks.SMOOTH_STONE_SLAB, "_double", lv2, this.modelCollector);
		this.blockStateCollector.accept(createSlabBlockState(Blocks.SMOOTH_STONE_SLAB, lv3, lv4, lv5));
		this.blockStateCollector.accept(createSingletonBlockState(Blocks.SMOOTH_STONE, Models.CUBE_ALL.upload(Blocks.SMOOTH_STONE, lv, this.modelCollector)));
	}

	private void registerBrewingStand() {
		this.registerItemModel(Items.BREWING_STAND);
		this.blockStateCollector
			.accept(
				MultipartBlockStateSupplier.create(Blocks.BREWING_STAND)
					.with(BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getId(Blocks.BREWING_STAND)))
					.with(
						When.create().set(Properties.HAS_BOTTLE_0, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.BREWING_STAND, "_bottle0"))
					)
					.with(
						When.create().set(Properties.HAS_BOTTLE_1, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.BREWING_STAND, "_bottle1"))
					)
					.with(
						When.create().set(Properties.HAS_BOTTLE_2, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.BREWING_STAND, "_bottle2"))
					)
					.with(
						When.create().set(Properties.HAS_BOTTLE_0, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.BREWING_STAND, "_empty0"))
					)
					.with(
						When.create().set(Properties.HAS_BOTTLE_1, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.BREWING_STAND, "_empty1"))
					)
					.with(
						When.create().set(Properties.HAS_BOTTLE_2, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.BREWING_STAND, "_empty2"))
					)
			);
	}

	private void registerMushroomBlock(Block mushroomBlock) {
		Identifier lv = Models.TEMPLATE_SINGLE_FACE.upload(mushroomBlock, TextureMap.texture(mushroomBlock), this.modelCollector);
		Identifier lv2 = ModelIds.getMinecraftNamespacedBlock("mushroom_block_inside");
		this.blockStateCollector
			.accept(
				MultipartBlockStateSupplier.create(mushroomBlock)
					.with(When.create().set(Properties.NORTH, true), BlockStateVariant.create().put(VariantSettings.MODEL, lv))
					.with(
						When.create().set(Properties.EAST, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.UVLOCK, true)
					)
					.with(
						When.create().set(Properties.SOUTH, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.UVLOCK, true)
					)
					.with(
						When.create().set(Properties.WEST, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.UVLOCK, true)
					)
					.with(
						When.create().set(Properties.UP, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.X, Rotation.R270).put(VariantSettings.UVLOCK, true)
					)
					.with(
						When.create().set(Properties.DOWN, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.X, Rotation.R90).put(VariantSettings.UVLOCK, true)
					)
					.with(When.create().set(Properties.NORTH, false), BlockStateVariant.create().put(VariantSettings.MODEL, lv2))
					.with(
						When.create().set(Properties.EAST, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv2).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.UVLOCK, false)
					)
					.with(
						When.create().set(Properties.SOUTH, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv2).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.UVLOCK, false)
					)
					.with(
						When.create().set(Properties.WEST, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv2).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.UVLOCK, false)
					)
					.with(
						When.create().set(Properties.UP, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv2).put(VariantSettings.X, Rotation.R270).put(VariantSettings.UVLOCK, false)
					)
					.with(
						When.create().set(Properties.DOWN, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv2).put(VariantSettings.X, Rotation.R90).put(VariantSettings.UVLOCK, false)
					)
			);
		this.registerParentedItemModel(mushroomBlock, TexturedModel.CUBE_ALL.upload(mushroomBlock, "_inventory", this.modelCollector));
	}

	private void registerCake() {
		this.registerItemModel(Items.CAKE);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.CAKE)
					.coordinate(
						BlockStateVariantMap.create(Properties.BITES)
							.register(0, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockModelId(Blocks.CAKE)))
							.register(1, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.CAKE, "_slice1")))
							.register(2, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.CAKE, "_slice2")))
							.register(3, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.CAKE, "_slice3")))
							.register(4, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.CAKE, "_slice4")))
							.register(5, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.CAKE, "_slice5")))
							.register(6, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.CAKE, "_slice6")))
					)
			);
	}

	private void registerCartographyTable() {
		TextureMap lv = new TextureMap()
			.put(TextureKey.PARTICLE, TextureMap.getSubId(Blocks.CARTOGRAPHY_TABLE, "_side3"))
			.put(TextureKey.DOWN, TextureMap.getId(Blocks.DARK_OAK_PLANKS))
			.put(TextureKey.UP, TextureMap.getSubId(Blocks.CARTOGRAPHY_TABLE, "_top"))
			.put(TextureKey.NORTH, TextureMap.getSubId(Blocks.CARTOGRAPHY_TABLE, "_side3"))
			.put(TextureKey.EAST, TextureMap.getSubId(Blocks.CARTOGRAPHY_TABLE, "_side3"))
			.put(TextureKey.SOUTH, TextureMap.getSubId(Blocks.CARTOGRAPHY_TABLE, "_side1"))
			.put(TextureKey.WEST, TextureMap.getSubId(Blocks.CARTOGRAPHY_TABLE, "_side2"));
		this.blockStateCollector.accept(createSingletonBlockState(Blocks.CARTOGRAPHY_TABLE, Models.CUBE.upload(Blocks.CARTOGRAPHY_TABLE, lv, this.modelCollector)));
	}

	private void registerSmithingTable() {
		TextureMap lv = new TextureMap()
			.put(TextureKey.PARTICLE, TextureMap.getSubId(Blocks.SMITHING_TABLE, "_front"))
			.put(TextureKey.DOWN, TextureMap.getSubId(Blocks.SMITHING_TABLE, "_bottom"))
			.put(TextureKey.UP, TextureMap.getSubId(Blocks.SMITHING_TABLE, "_top"))
			.put(TextureKey.NORTH, TextureMap.getSubId(Blocks.SMITHING_TABLE, "_front"))
			.put(TextureKey.SOUTH, TextureMap.getSubId(Blocks.SMITHING_TABLE, "_front"))
			.put(TextureKey.EAST, TextureMap.getSubId(Blocks.SMITHING_TABLE, "_side"))
			.put(TextureKey.WEST, TextureMap.getSubId(Blocks.SMITHING_TABLE, "_side"));
		this.blockStateCollector.accept(createSingletonBlockState(Blocks.SMITHING_TABLE, Models.CUBE.upload(Blocks.SMITHING_TABLE, lv, this.modelCollector)));
	}

	private void registerCubeWithCustomTextures(Block block, Block otherTextureSource, BiFunction<Block, Block, TextureMap> texturesFactory) {
		TextureMap lv = (TextureMap)texturesFactory.apply(block, otherTextureSource);
		this.blockStateCollector.accept(createSingletonBlockState(block, Models.CUBE.upload(block, lv, this.modelCollector)));
	}

	public void registerGeneric(Block block) {
		TextureMap lv = new TextureMap()
			.put(TextureKey.PARTICLE, TextureMap.getSubId(block, "_particle"))
			.put(TextureKey.DOWN, TextureMap.getSubId(block, "_down"))
			.put(TextureKey.UP, TextureMap.getSubId(block, "_up"))
			.put(TextureKey.NORTH, TextureMap.getSubId(block, "_north"))
			.put(TextureKey.SOUTH, TextureMap.getSubId(block, "_south"))
			.put(TextureKey.EAST, TextureMap.getSubId(block, "_east"))
			.put(TextureKey.WEST, TextureMap.getSubId(block, "_west"));
		this.blockStateCollector.accept(createSingletonBlockState(block, Models.CUBE.upload(block, lv, this.modelCollector)));
	}

	private void registerPumpkins() {
		TextureMap lv = TextureMap.sideEnd(Blocks.PUMPKIN);
		this.blockStateCollector.accept(createSingletonBlockState(Blocks.PUMPKIN, ModelIds.getBlockModelId(Blocks.PUMPKIN)));
		this.registerNorthDefaultHorizontalRotatable(Blocks.CARVED_PUMPKIN, lv);
		this.registerNorthDefaultHorizontalRotatable(Blocks.JACK_O_LANTERN, lv);
	}

	private void registerNorthDefaultHorizontalRotatable(Block block, TextureMap texture) {
		Identifier lv = Models.ORIENTABLE.upload(block, texture.copyAndAdd(TextureKey.FRONT, TextureMap.getId(block)), this.modelCollector);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(block, BlockStateVariant.create().put(VariantSettings.MODEL, lv))
					.coordinate(createNorthDefaultHorizontalRotationStates())
			);
	}

	private void registerCauldrons() {
		this.registerItemModel(Items.CAULDRON);
		this.registerSimpleState(Blocks.CAULDRON);
		this.blockStateCollector
			.accept(
				createSingletonBlockState(
					Blocks.LAVA_CAULDRON,
					Models.TEMPLATE_CAULDRON_FULL.upload(Blocks.LAVA_CAULDRON, TextureMap.cauldron(TextureMap.getSubId(Blocks.LAVA, "_still")), this.modelCollector)
				)
			);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.WATER_CAULDRON)
					.coordinate(
						BlockStateVariantMap.create(LeveledCauldronBlock.LEVEL)
							.register(
								1,
								BlockStateVariant.create()
									.put(
										VariantSettings.MODEL,
										Models.TEMPLATE_CAULDRON_LEVEL1
											.upload(Blocks.WATER_CAULDRON, "_level1", TextureMap.cauldron(TextureMap.getSubId(Blocks.WATER, "_still")), this.modelCollector)
									)
							)
							.register(
								2,
								BlockStateVariant.create()
									.put(
										VariantSettings.MODEL,
										Models.TEMPLATE_CAULDRON_LEVEL2
											.upload(Blocks.WATER_CAULDRON, "_level2", TextureMap.cauldron(TextureMap.getSubId(Blocks.WATER, "_still")), this.modelCollector)
									)
							)
							.register(
								3,
								BlockStateVariant.create()
									.put(
										VariantSettings.MODEL,
										Models.TEMPLATE_CAULDRON_FULL
											.upload(Blocks.WATER_CAULDRON, "_full", TextureMap.cauldron(TextureMap.getSubId(Blocks.WATER, "_still")), this.modelCollector)
									)
							)
					)
			);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.POWDER_SNOW_CAULDRON)
					.coordinate(
						BlockStateVariantMap.create(LeveledCauldronBlock.LEVEL)
							.register(
								1,
								BlockStateVariant.create()
									.put(
										VariantSettings.MODEL,
										Models.TEMPLATE_CAULDRON_LEVEL1
											.upload(Blocks.POWDER_SNOW_CAULDRON, "_level1", TextureMap.cauldron(TextureMap.getId(Blocks.POWDER_SNOW)), this.modelCollector)
									)
							)
							.register(
								2,
								BlockStateVariant.create()
									.put(
										VariantSettings.MODEL,
										Models.TEMPLATE_CAULDRON_LEVEL2
											.upload(Blocks.POWDER_SNOW_CAULDRON, "_level2", TextureMap.cauldron(TextureMap.getId(Blocks.POWDER_SNOW)), this.modelCollector)
									)
							)
							.register(
								3,
								BlockStateVariant.create()
									.put(
										VariantSettings.MODEL,
										Models.TEMPLATE_CAULDRON_FULL
											.upload(Blocks.POWDER_SNOW_CAULDRON, "_full", TextureMap.cauldron(TextureMap.getId(Blocks.POWDER_SNOW)), this.modelCollector)
									)
							)
					)
			);
	}

	private void registerChorusFlower() {
		TextureMap lv = TextureMap.texture(Blocks.CHORUS_FLOWER);
		Identifier lv2 = Models.TEMPLATE_CHORUS_FLOWER.upload(Blocks.CHORUS_FLOWER, lv, this.modelCollector);
		Identifier lv3 = this.createSubModel(Blocks.CHORUS_FLOWER, "_dead", Models.TEMPLATE_CHORUS_FLOWER, id -> lv.copyAndAdd(TextureKey.TEXTURE, id));
		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(Blocks.CHORUS_FLOWER).coordinate(createValueFencedModelMap(Properties.AGE_5, 5, lv3, lv2)));
	}

	private void registerCrafter() {
		Identifier lv = ModelIds.getBlockModelId(Blocks.CRAFTER);
		Identifier lv2 = ModelIds.getBlockSubModelId(Blocks.CRAFTER, "_triggered");
		Identifier lv3 = ModelIds.getBlockSubModelId(Blocks.CRAFTER, "_crafting");
		Identifier lv4 = ModelIds.getBlockSubModelId(Blocks.CRAFTER, "_crafting_triggered");
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.CRAFTER)
					.coordinate(
						BlockStateVariantMap.create(Properties.ORIENTATION).register(orientation -> this.addJigsawOrientationToVariant(orientation, BlockStateVariant.create()))
					)
					.coordinate(
						BlockStateVariantMap.create(Properties.TRIGGERED, CrafterBlock.CRAFTING)
							.register(false, false, BlockStateVariant.create().put(VariantSettings.MODEL, lv))
							.register(true, true, BlockStateVariant.create().put(VariantSettings.MODEL, lv4))
							.register(true, false, BlockStateVariant.create().put(VariantSettings.MODEL, lv2))
							.register(false, true, BlockStateVariant.create().put(VariantSettings.MODEL, lv3))
					)
			);
	}

	private void registerDispenserLikeOrientable(Block block) {
		TextureMap lv = new TextureMap()
			.put(TextureKey.TOP, TextureMap.getSubId(Blocks.FURNACE, "_top"))
			.put(TextureKey.SIDE, TextureMap.getSubId(Blocks.FURNACE, "_side"))
			.put(TextureKey.FRONT, TextureMap.getSubId(block, "_front"));
		TextureMap lv2 = new TextureMap()
			.put(TextureKey.SIDE, TextureMap.getSubId(Blocks.FURNACE, "_top"))
			.put(TextureKey.FRONT, TextureMap.getSubId(block, "_front_vertical"));
		Identifier lv3 = Models.ORIENTABLE.upload(block, lv, this.modelCollector);
		Identifier lv4 = Models.ORIENTABLE_VERTICAL.upload(block, lv2, this.modelCollector);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(block)
					.coordinate(
						BlockStateVariantMap.create(Properties.FACING)
							.register(Direction.DOWN, BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.X, Rotation.R180))
							.register(Direction.UP, BlockStateVariant.create().put(VariantSettings.MODEL, lv4))
							.register(Direction.NORTH, BlockStateVariant.create().put(VariantSettings.MODEL, lv3))
							.register(Direction.EAST, BlockStateVariant.create().put(VariantSettings.MODEL, lv3).put(VariantSettings.Y, Rotation.R90))
							.register(Direction.SOUTH, BlockStateVariant.create().put(VariantSettings.MODEL, lv3).put(VariantSettings.Y, Rotation.R180))
							.register(Direction.WEST, BlockStateVariant.create().put(VariantSettings.MODEL, lv3).put(VariantSettings.Y, Rotation.R270))
					)
			);
	}

	private void registerEndPortalFrame() {
		Identifier lv = ModelIds.getBlockModelId(Blocks.END_PORTAL_FRAME);
		Identifier lv2 = ModelIds.getBlockSubModelId(Blocks.END_PORTAL_FRAME, "_filled");
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.END_PORTAL_FRAME)
					.coordinate(
						BlockStateVariantMap.create(Properties.EYE)
							.register(false, BlockStateVariant.create().put(VariantSettings.MODEL, lv))
							.register(true, BlockStateVariant.create().put(VariantSettings.MODEL, lv2))
					)
					.coordinate(createSouthDefaultHorizontalRotationStates())
			);
	}

	private void registerChorusPlant() {
		Identifier lv = ModelIds.getBlockSubModelId(Blocks.CHORUS_PLANT, "_side");
		Identifier lv2 = ModelIds.getBlockSubModelId(Blocks.CHORUS_PLANT, "_noside");
		Identifier lv3 = ModelIds.getBlockSubModelId(Blocks.CHORUS_PLANT, "_noside1");
		Identifier lv4 = ModelIds.getBlockSubModelId(Blocks.CHORUS_PLANT, "_noside2");
		Identifier lv5 = ModelIds.getBlockSubModelId(Blocks.CHORUS_PLANT, "_noside3");
		this.blockStateCollector
			.accept(
				MultipartBlockStateSupplier.create(Blocks.CHORUS_PLANT)
					.with(When.create().set(Properties.NORTH, true), BlockStateVariant.create().put(VariantSettings.MODEL, lv))
					.with(
						When.create().set(Properties.EAST, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.UVLOCK, true)
					)
					.with(
						When.create().set(Properties.SOUTH, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.UVLOCK, true)
					)
					.with(
						When.create().set(Properties.WEST, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.UVLOCK, true)
					)
					.with(
						When.create().set(Properties.UP, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.X, Rotation.R270).put(VariantSettings.UVLOCK, true)
					)
					.with(
						When.create().set(Properties.DOWN, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.X, Rotation.R90).put(VariantSettings.UVLOCK, true)
					)
					.with(
						When.create().set(Properties.NORTH, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv2).put(VariantSettings.WEIGHT, 2),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv3),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv4),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv5)
					)
					.with(
						When.create().set(Properties.EAST, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv3).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.UVLOCK, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.UVLOCK, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv5).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.UVLOCK, true),
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, lv2)
							.put(VariantSettings.WEIGHT, 2)
							.put(VariantSettings.Y, Rotation.R90)
							.put(VariantSettings.UVLOCK, true)
					)
					.with(
						When.create().set(Properties.SOUTH, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.UVLOCK, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv5).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.UVLOCK, true),
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, lv2)
							.put(VariantSettings.WEIGHT, 2)
							.put(VariantSettings.Y, Rotation.R180)
							.put(VariantSettings.UVLOCK, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv3).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.UVLOCK, true)
					)
					.with(
						When.create().set(Properties.WEST, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv5).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.UVLOCK, true),
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, lv2)
							.put(VariantSettings.WEIGHT, 2)
							.put(VariantSettings.Y, Rotation.R270)
							.put(VariantSettings.UVLOCK, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv3).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.UVLOCK, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.UVLOCK, true)
					)
					.with(
						When.create().set(Properties.UP, false),
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, lv2)
							.put(VariantSettings.WEIGHT, 2)
							.put(VariantSettings.X, Rotation.R270)
							.put(VariantSettings.UVLOCK, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv5).put(VariantSettings.X, Rotation.R270).put(VariantSettings.UVLOCK, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv3).put(VariantSettings.X, Rotation.R270).put(VariantSettings.UVLOCK, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.X, Rotation.R270).put(VariantSettings.UVLOCK, true)
					)
					.with(
						When.create().set(Properties.DOWN, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv5).put(VariantSettings.X, Rotation.R90).put(VariantSettings.UVLOCK, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.X, Rotation.R90).put(VariantSettings.UVLOCK, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv3).put(VariantSettings.X, Rotation.R90).put(VariantSettings.UVLOCK, true),
						BlockStateVariant.create()
							.put(VariantSettings.MODEL, lv2)
							.put(VariantSettings.WEIGHT, 2)
							.put(VariantSettings.X, Rotation.R90)
							.put(VariantSettings.UVLOCK, true)
					)
			);
	}

	private void registerComposter() {
		this.blockStateCollector
			.accept(
				MultipartBlockStateSupplier.create(Blocks.COMPOSTER)
					.with(BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getId(Blocks.COMPOSTER)))
					.with(When.create().set(Properties.LEVEL_8, 1), BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.COMPOSTER, "_contents1")))
					.with(When.create().set(Properties.LEVEL_8, 2), BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.COMPOSTER, "_contents2")))
					.with(When.create().set(Properties.LEVEL_8, 3), BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.COMPOSTER, "_contents3")))
					.with(When.create().set(Properties.LEVEL_8, 4), BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.COMPOSTER, "_contents4")))
					.with(When.create().set(Properties.LEVEL_8, 5), BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.COMPOSTER, "_contents5")))
					.with(When.create().set(Properties.LEVEL_8, 6), BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.COMPOSTER, "_contents6")))
					.with(When.create().set(Properties.LEVEL_8, 7), BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.COMPOSTER, "_contents7")))
					.with(
						When.create().set(Properties.LEVEL_8, 8), BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.COMPOSTER, "_contents_ready"))
					)
			);
	}

	private void registerCopperBulb(Block copperBulbBlock) {
		Identifier lv = Models.CUBE_ALL.upload(copperBulbBlock, TextureMap.all(copperBulbBlock), this.modelCollector);
		Identifier lv2 = this.createSubModel(copperBulbBlock, "_powered", Models.CUBE_ALL, TextureMap::all);
		Identifier lv3 = this.createSubModel(copperBulbBlock, "_lit", Models.CUBE_ALL, TextureMap::all);
		Identifier lv4 = this.createSubModel(copperBulbBlock, "_lit_powered", Models.CUBE_ALL, TextureMap::all);
		this.blockStateCollector.accept(this.createCopperBulbBlockState(copperBulbBlock, lv, lv3, lv2, lv4));
	}

	private BlockStateSupplier createCopperBulbBlockState(
		Block copperBulbBlock, Identifier modelId, Identifier litModelId, Identifier poweredModelId, Identifier litPoweredModelId
	) {
		return VariantsBlockStateSupplier.create(copperBulbBlock)
			.coordinate(
				BlockStateVariantMap.create(Properties.LIT, Properties.POWERED)
					.register(
						(lit, powered) -> lit
								? BlockStateVariant.create().put(VariantSettings.MODEL, powered ? litPoweredModelId : litModelId)
								: BlockStateVariant.create().put(VariantSettings.MODEL, powered ? poweredModelId : modelId)
					)
			);
	}

	private void registerWaxedCopperBulb(Block unwaxedCopperBulbBlock, Block waxedCopperBulbBlock) {
		Identifier lv = ModelIds.getBlockModelId(unwaxedCopperBulbBlock);
		Identifier lv2 = ModelIds.getBlockSubModelId(unwaxedCopperBulbBlock, "_powered");
		Identifier lv3 = ModelIds.getBlockSubModelId(unwaxedCopperBulbBlock, "_lit");
		Identifier lv4 = ModelIds.getBlockSubModelId(unwaxedCopperBulbBlock, "_lit_powered");
		this.itemModelOutput.acceptAlias(unwaxedCopperBulbBlock.asItem(), waxedCopperBulbBlock.asItem());
		this.blockStateCollector.accept(this.createCopperBulbBlockState(waxedCopperBulbBlock, lv, lv3, lv2, lv4));
	}

	private void registerAmethyst(Block block) {
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(
						block, BlockStateVariant.create().put(VariantSettings.MODEL, Models.CROSS.upload(block, TextureMap.cross(block), this.modelCollector))
					)
					.coordinate(this.createUpDefaultFacingVariantMap())
			);
	}

	private void registerAmethysts() {
		this.registerAmethyst(Blocks.SMALL_AMETHYST_BUD);
		this.registerAmethyst(Blocks.MEDIUM_AMETHYST_BUD);
		this.registerAmethyst(Blocks.LARGE_AMETHYST_BUD);
		this.registerAmethyst(Blocks.AMETHYST_CLUSTER);
	}

	private void registerPointedDripstone() {
		DoubleProperty<Direction, Thickness> lv = BlockStateVariantMap.create(Properties.VERTICAL_DIRECTION, Properties.THICKNESS);

		for (Thickness lv2 : Thickness.values()) {
			lv.register(Direction.UP, lv2, this.getDripstoneVariant(Direction.UP, lv2));
		}

		for (Thickness lv2 : Thickness.values()) {
			lv.register(Direction.DOWN, lv2, this.getDripstoneVariant(Direction.DOWN, lv2));
		}

		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(Blocks.POINTED_DRIPSTONE).coordinate(lv));
	}

	private BlockStateVariant getDripstoneVariant(Direction direction, Thickness thickness) {
		String string = "_" + direction.asString() + "_" + thickness.asString();
		TextureMap lv = TextureMap.cross(TextureMap.getSubId(Blocks.POINTED_DRIPSTONE, string));
		return BlockStateVariant.create().put(VariantSettings.MODEL, Models.POINTED_DRIPSTONE.upload(Blocks.POINTED_DRIPSTONE, string, lv, this.modelCollector));
	}

	private void registerNetherrackBottomCustomTop(Block block) {
		TextureMap lv = new TextureMap()
			.put(TextureKey.BOTTOM, TextureMap.getId(Blocks.NETHERRACK))
			.put(TextureKey.TOP, TextureMap.getId(block))
			.put(TextureKey.SIDE, TextureMap.getSubId(block, "_side"));
		this.blockStateCollector.accept(createSingletonBlockState(block, Models.CUBE_BOTTOM_TOP.upload(block, lv, this.modelCollector)));
	}

	private void registerDaylightDetector() {
		Identifier lv = TextureMap.getSubId(Blocks.DAYLIGHT_DETECTOR, "_side");
		TextureMap lv2 = new TextureMap().put(TextureKey.TOP, TextureMap.getSubId(Blocks.DAYLIGHT_DETECTOR, "_top")).put(TextureKey.SIDE, lv);
		TextureMap lv3 = new TextureMap().put(TextureKey.TOP, TextureMap.getSubId(Blocks.DAYLIGHT_DETECTOR, "_inverted_top")).put(TextureKey.SIDE, lv);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.DAYLIGHT_DETECTOR)
					.coordinate(
						BlockStateVariantMap.create(Properties.INVERTED)
							.register(
								false,
								BlockStateVariant.create().put(VariantSettings.MODEL, Models.TEMPLATE_DAYLIGHT_DETECTOR.upload(Blocks.DAYLIGHT_DETECTOR, lv2, this.modelCollector))
							)
							.register(
								true,
								BlockStateVariant.create()
									.put(
										VariantSettings.MODEL,
										Models.TEMPLATE_DAYLIGHT_DETECTOR.upload(ModelIds.getBlockSubModelId(Blocks.DAYLIGHT_DETECTOR, "_inverted"), lv3, this.modelCollector)
									)
							)
					)
			);
	}

	private void registerRod(Block block) {
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(block, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockModelId(block)))
					.coordinate(this.createUpDefaultFacingVariantMap())
			);
	}

	private void registerLightningRod() {
		Block lv = Blocks.LIGHTNING_ROD;
		Identifier lv2 = ModelIds.getBlockSubModelId(lv, "_on");
		Identifier lv3 = ModelIds.getBlockModelId(lv);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(lv, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockModelId(lv)))
					.coordinate(this.createUpDefaultFacingVariantMap())
					.coordinate(createBooleanModelMap(Properties.POWERED, lv2, lv3))
			);
	}

	private void registerFarmland() {
		TextureMap lv = new TextureMap().put(TextureKey.DIRT, TextureMap.getId(Blocks.DIRT)).put(TextureKey.TOP, TextureMap.getId(Blocks.FARMLAND));
		TextureMap lv2 = new TextureMap().put(TextureKey.DIRT, TextureMap.getId(Blocks.DIRT)).put(TextureKey.TOP, TextureMap.getSubId(Blocks.FARMLAND, "_moist"));
		Identifier lv3 = Models.TEMPLATE_FARMLAND.upload(Blocks.FARMLAND, lv, this.modelCollector);
		Identifier lv4 = Models.TEMPLATE_FARMLAND.upload(TextureMap.getSubId(Blocks.FARMLAND, "_moist"), lv2, this.modelCollector);
		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(Blocks.FARMLAND).coordinate(createValueFencedModelMap(Properties.MOISTURE, 7, lv4, lv3)));
	}

	private List<Identifier> getFireFloorModels(Block texture) {
		Identifier lv = Models.TEMPLATE_FIRE_FLOOR.upload(ModelIds.getBlockSubModelId(texture, "_floor0"), TextureMap.fire0(texture), this.modelCollector);
		Identifier lv2 = Models.TEMPLATE_FIRE_FLOOR.upload(ModelIds.getBlockSubModelId(texture, "_floor1"), TextureMap.fire1(texture), this.modelCollector);
		return ImmutableList.of(lv, lv2);
	}

	private List<Identifier> getFireSideModels(Block texture) {
		Identifier lv = Models.TEMPLATE_FIRE_SIDE.upload(ModelIds.getBlockSubModelId(texture, "_side0"), TextureMap.fire0(texture), this.modelCollector);
		Identifier lv2 = Models.TEMPLATE_FIRE_SIDE.upload(ModelIds.getBlockSubModelId(texture, "_side1"), TextureMap.fire1(texture), this.modelCollector);
		Identifier lv3 = Models.TEMPLATE_FIRE_SIDE_ALT.upload(ModelIds.getBlockSubModelId(texture, "_side_alt0"), TextureMap.fire0(texture), this.modelCollector);
		Identifier lv4 = Models.TEMPLATE_FIRE_SIDE_ALT.upload(ModelIds.getBlockSubModelId(texture, "_side_alt1"), TextureMap.fire1(texture), this.modelCollector);
		return ImmutableList.of(lv, lv2, lv3, lv4);
	}

	private List<Identifier> getFireUpModels(Block texture) {
		Identifier lv = Models.TEMPLATE_FIRE_UP.upload(ModelIds.getBlockSubModelId(texture, "_up0"), TextureMap.fire0(texture), this.modelCollector);
		Identifier lv2 = Models.TEMPLATE_FIRE_UP.upload(ModelIds.getBlockSubModelId(texture, "_up1"), TextureMap.fire1(texture), this.modelCollector);
		Identifier lv3 = Models.TEMPLATE_FIRE_UP_ALT.upload(ModelIds.getBlockSubModelId(texture, "_up_alt0"), TextureMap.fire0(texture), this.modelCollector);
		Identifier lv4 = Models.TEMPLATE_FIRE_UP_ALT.upload(ModelIds.getBlockSubModelId(texture, "_up_alt1"), TextureMap.fire1(texture), this.modelCollector);
		return ImmutableList.of(lv, lv2, lv3, lv4);
	}

	private static List<BlockStateVariant> buildBlockStateVariants(List<Identifier> modelIds, UnaryOperator<BlockStateVariant> processor) {
		return (List<BlockStateVariant>)modelIds.stream()
			.map(modelId -> BlockStateVariant.create().put(VariantSettings.MODEL, modelId))
			.map(processor)
			.collect(Collectors.toList());
	}

	private void registerFire() {
		When lv = When.create()
			.set(Properties.NORTH, false)
			.set(Properties.EAST, false)
			.set(Properties.SOUTH, false)
			.set(Properties.WEST, false)
			.set(Properties.UP, false);
		List<Identifier> list = this.getFireFloorModels(Blocks.FIRE);
		List<Identifier> list2 = this.getFireSideModels(Blocks.FIRE);
		List<Identifier> list3 = this.getFireUpModels(Blocks.FIRE);
		this.blockStateCollector
			.accept(
				MultipartBlockStateSupplier.create(Blocks.FIRE)
					.with(lv, buildBlockStateVariants(list, variant -> variant))
					.with(When.anyOf(When.create().set(Properties.NORTH, true), lv), buildBlockStateVariants(list2, variant -> variant))
					.with(When.anyOf(When.create().set(Properties.EAST, true), lv), buildBlockStateVariants(list2, variant -> variant.put(VariantSettings.Y, Rotation.R90)))
					.with(When.anyOf(When.create().set(Properties.SOUTH, true), lv), buildBlockStateVariants(list2, variant -> variant.put(VariantSettings.Y, Rotation.R180)))
					.with(When.anyOf(When.create().set(Properties.WEST, true), lv), buildBlockStateVariants(list2, variant -> variant.put(VariantSettings.Y, Rotation.R270)))
					.with(When.create().set(Properties.UP, true), buildBlockStateVariants(list3, variant -> variant))
			);
	}

	private void registerSoulFire() {
		List<Identifier> list = this.getFireFloorModels(Blocks.SOUL_FIRE);
		List<Identifier> list2 = this.getFireSideModels(Blocks.SOUL_FIRE);
		this.blockStateCollector
			.accept(
				MultipartBlockStateSupplier.create(Blocks.SOUL_FIRE)
					.with(buildBlockStateVariants(list, variant -> variant))
					.with(buildBlockStateVariants(list2, variant -> variant))
					.with(buildBlockStateVariants(list2, variant -> variant.put(VariantSettings.Y, Rotation.R90)))
					.with(buildBlockStateVariants(list2, variant -> variant.put(VariantSettings.Y, Rotation.R180)))
					.with(buildBlockStateVariants(list2, variant -> variant.put(VariantSettings.Y, Rotation.R270)))
			);
	}

	private void registerLantern(Block lantern) {
		Identifier lv = TexturedModel.TEMPLATE_LANTERN.upload(lantern, this.modelCollector);
		Identifier lv2 = TexturedModel.TEMPLATE_HANGING_LANTERN.upload(lantern, this.modelCollector);
		this.registerItemModel(lantern.asItem());
		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(lantern).coordinate(createBooleanModelMap(Properties.HANGING, lv2, lv)));
	}

	private void registerMuddyMangroveRoots() {
		TextureMap lv = TextureMap.sideEnd(TextureMap.getSubId(Blocks.MUDDY_MANGROVE_ROOTS, "_side"), TextureMap.getSubId(Blocks.MUDDY_MANGROVE_ROOTS, "_top"));
		Identifier lv2 = Models.CUBE_COLUMN.upload(Blocks.MUDDY_MANGROVE_ROOTS, lv, this.modelCollector);
		this.blockStateCollector.accept(createAxisRotatedBlockState(Blocks.MUDDY_MANGROVE_ROOTS, lv2));
	}

	private void registerMangrovePropagule() {
		this.registerItemModel(Items.MANGROVE_PROPAGULE);
		Block lv = Blocks.MANGROVE_PROPAGULE;
		DoubleProperty<Boolean, Integer> lv2 = BlockStateVariantMap.create(PropaguleBlock.HANGING, PropaguleBlock.AGE);
		Identifier lv3 = ModelIds.getBlockModelId(lv);

		for (int i = 0; i <= 4; i++) {
			Identifier lv4 = ModelIds.getBlockSubModelId(lv, "_hanging_" + i);
			lv2.register(true, i, BlockStateVariant.create().put(VariantSettings.MODEL, lv4));
			lv2.register(false, i, BlockStateVariant.create().put(VariantSettings.MODEL, lv3));
		}

		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(Blocks.MANGROVE_PROPAGULE).coordinate(lv2));
	}

	private void registerFrostedIce() {
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.FROSTED_ICE)
					.coordinate(
						BlockStateVariantMap.create(Properties.AGE_3)
							.register(0, BlockStateVariant.create().put(VariantSettings.MODEL, this.createSubModel(Blocks.FROSTED_ICE, "_0", Models.CUBE_ALL, TextureMap::all)))
							.register(1, BlockStateVariant.create().put(VariantSettings.MODEL, this.createSubModel(Blocks.FROSTED_ICE, "_1", Models.CUBE_ALL, TextureMap::all)))
							.register(2, BlockStateVariant.create().put(VariantSettings.MODEL, this.createSubModel(Blocks.FROSTED_ICE, "_2", Models.CUBE_ALL, TextureMap::all)))
							.register(3, BlockStateVariant.create().put(VariantSettings.MODEL, this.createSubModel(Blocks.FROSTED_ICE, "_3", Models.CUBE_ALL, TextureMap::all)))
					)
			);
	}

	private void registerTopSoils() {
		Identifier lv = TextureMap.getId(Blocks.DIRT);
		TextureMap lv2 = new TextureMap()
			.put(TextureKey.BOTTOM, lv)
			.inherit(TextureKey.BOTTOM, TextureKey.PARTICLE)
			.put(TextureKey.TOP, TextureMap.getSubId(Blocks.GRASS_BLOCK, "_top"))
			.put(TextureKey.SIDE, TextureMap.getSubId(Blocks.GRASS_BLOCK, "_snow"));
		BlockStateVariant lv3 = BlockStateVariant.create()
			.put(VariantSettings.MODEL, Models.CUBE_BOTTOM_TOP.upload(Blocks.GRASS_BLOCK, "_snow", lv2, this.modelCollector));
		this.registerTopSoil(Blocks.GRASS_BLOCK, ModelIds.getBlockModelId(Blocks.GRASS_BLOCK), lv3);
		this.registerTintedItemModel(Blocks.GRASS_BLOCK, ModelIds.getBlockModelId(Blocks.GRASS_BLOCK), new GrassTintSource());
		Identifier lv4 = TexturedModel.CUBE_BOTTOM_TOP
			.get(Blocks.MYCELIUM)
			.textures(textures -> textures.put(TextureKey.BOTTOM, lv))
			.upload(Blocks.MYCELIUM, this.modelCollector);
		this.registerTopSoil(Blocks.MYCELIUM, lv4, lv3);
		Identifier lv5 = TexturedModel.CUBE_BOTTOM_TOP
			.get(Blocks.PODZOL)
			.textures(textures -> textures.put(TextureKey.BOTTOM, lv))
			.upload(Blocks.PODZOL, this.modelCollector);
		this.registerTopSoil(Blocks.PODZOL, lv5, lv3);
	}

	private void registerTopSoil(Block topSoil, Identifier modelId, BlockStateVariant snowyVariant) {
		List<BlockStateVariant> list = Arrays.asList(createModelVariantWithRandomHorizontalRotations(modelId));
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(topSoil).coordinate(BlockStateVariantMap.create(Properties.SNOWY).register(true, snowyVariant).register(false, list))
			);
	}

	private void registerCocoa() {
		this.registerItemModel(Items.COCOA_BEANS);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.COCOA)
					.coordinate(
						BlockStateVariantMap.create(Properties.AGE_2)
							.register(0, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.COCOA, "_stage0")))
							.register(1, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.COCOA, "_stage1")))
							.register(2, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.COCOA, "_stage2")))
					)
					.coordinate(createSouthDefaultHorizontalRotationStates())
			);
	}

	private void registerDirtPath() {
		this.blockStateCollector.accept(createBlockStateWithRandomHorizontalRotations(Blocks.DIRT_PATH, ModelIds.getBlockModelId(Blocks.DIRT_PATH)));
	}

	private void registerWeightedPressurePlate(Block weightedPressurePlate, Block textureSource) {
		TextureMap lv = TextureMap.texture(textureSource);
		Identifier lv2 = Models.PRESSURE_PLATE_UP.upload(weightedPressurePlate, lv, this.modelCollector);
		Identifier lv3 = Models.PRESSURE_PLATE_DOWN.upload(weightedPressurePlate, lv, this.modelCollector);
		this.blockStateCollector
			.accept(VariantsBlockStateSupplier.create(weightedPressurePlate).coordinate(createValueFencedModelMap(Properties.POWER, 1, lv3, lv2)));
	}

	private void registerHopper() {
		Identifier lv = ModelIds.getBlockModelId(Blocks.HOPPER);
		Identifier lv2 = ModelIds.getBlockSubModelId(Blocks.HOPPER, "_side");
		this.registerItemModel(Items.HOPPER);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.HOPPER)
					.coordinate(
						BlockStateVariantMap.create(Properties.HOPPER_FACING)
							.register(Direction.DOWN, BlockStateVariant.create().put(VariantSettings.MODEL, lv))
							.register(Direction.NORTH, BlockStateVariant.create().put(VariantSettings.MODEL, lv2))
							.register(Direction.EAST, BlockStateVariant.create().put(VariantSettings.MODEL, lv2).put(VariantSettings.Y, Rotation.R90))
							.register(Direction.SOUTH, BlockStateVariant.create().put(VariantSettings.MODEL, lv2).put(VariantSettings.Y, Rotation.R180))
							.register(Direction.WEST, BlockStateVariant.create().put(VariantSettings.MODEL, lv2).put(VariantSettings.Y, Rotation.R270))
					)
			);
	}

	private void registerParented(Block modelSource, Block child) {
		Identifier lv = ModelIds.getBlockModelId(modelSource);
		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(child, BlockStateVariant.create().put(VariantSettings.MODEL, lv)));
		this.itemModelOutput.acceptAlias(modelSource.asItem(), child.asItem());
	}

	private void registerIronBars() {
		Identifier lv = ModelIds.getBlockSubModelId(Blocks.IRON_BARS, "_post_ends");
		Identifier lv2 = ModelIds.getBlockSubModelId(Blocks.IRON_BARS, "_post");
		Identifier lv3 = ModelIds.getBlockSubModelId(Blocks.IRON_BARS, "_cap");
		Identifier lv4 = ModelIds.getBlockSubModelId(Blocks.IRON_BARS, "_cap_alt");
		Identifier lv5 = ModelIds.getBlockSubModelId(Blocks.IRON_BARS, "_side");
		Identifier lv6 = ModelIds.getBlockSubModelId(Blocks.IRON_BARS, "_side_alt");
		this.blockStateCollector
			.accept(
				MultipartBlockStateSupplier.create(Blocks.IRON_BARS)
					.with(BlockStateVariant.create().put(VariantSettings.MODEL, lv))
					.with(
						When.create().set(Properties.NORTH, false).set(Properties.EAST, false).set(Properties.SOUTH, false).set(Properties.WEST, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv2)
					)
					.with(
						When.create().set(Properties.NORTH, true).set(Properties.EAST, false).set(Properties.SOUTH, false).set(Properties.WEST, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv3)
					)
					.with(
						When.create().set(Properties.NORTH, false).set(Properties.EAST, true).set(Properties.SOUTH, false).set(Properties.WEST, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv3).put(VariantSettings.Y, Rotation.R90)
					)
					.with(
						When.create().set(Properties.NORTH, false).set(Properties.EAST, false).set(Properties.SOUTH, true).set(Properties.WEST, false),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv4)
					)
					.with(
						When.create().set(Properties.NORTH, false).set(Properties.EAST, false).set(Properties.SOUTH, false).set(Properties.WEST, true),
						BlockStateVariant.create().put(VariantSettings.MODEL, lv4).put(VariantSettings.Y, Rotation.R90)
					)
					.with(When.create().set(Properties.NORTH, true), BlockStateVariant.create().put(VariantSettings.MODEL, lv5))
					.with(When.create().set(Properties.EAST, true), BlockStateVariant.create().put(VariantSettings.MODEL, lv5).put(VariantSettings.Y, Rotation.R90))
					.with(When.create().set(Properties.SOUTH, true), BlockStateVariant.create().put(VariantSettings.MODEL, lv6))
					.with(When.create().set(Properties.WEST, true), BlockStateVariant.create().put(VariantSettings.MODEL, lv6).put(VariantSettings.Y, Rotation.R90))
			);
		this.registerItemModel(Blocks.IRON_BARS);
	}

	private void registerNorthDefaultHorizontalRotation(Block block) {
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(block, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockModelId(block)))
					.coordinate(createNorthDefaultHorizontalRotationStates())
			);
	}

	private void registerLever() {
		Identifier lv = ModelIds.getBlockModelId(Blocks.LEVER);
		Identifier lv2 = ModelIds.getBlockSubModelId(Blocks.LEVER, "_on");
		this.registerItemModel(Blocks.LEVER);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.LEVER)
					.coordinate(createBooleanModelMap(Properties.POWERED, lv, lv2))
					.coordinate(
						BlockStateVariantMap.create(Properties.BLOCK_FACE, Properties.HORIZONTAL_FACING)
							.register(BlockFace.CEILING, Direction.NORTH, BlockStateVariant.create().put(VariantSettings.X, Rotation.R180).put(VariantSettings.Y, Rotation.R180))
							.register(BlockFace.CEILING, Direction.EAST, BlockStateVariant.create().put(VariantSettings.X, Rotation.R180).put(VariantSettings.Y, Rotation.R270))
							.register(BlockFace.CEILING, Direction.SOUTH, BlockStateVariant.create().put(VariantSettings.X, Rotation.R180))
							.register(BlockFace.CEILING, Direction.WEST, BlockStateVariant.create().put(VariantSettings.X, Rotation.R180).put(VariantSettings.Y, Rotation.R90))
							.register(BlockFace.FLOOR, Direction.NORTH, BlockStateVariant.create())
							.register(BlockFace.FLOOR, Direction.EAST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R90))
							.register(BlockFace.FLOOR, Direction.SOUTH, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R180))
							.register(BlockFace.FLOOR, Direction.WEST, BlockStateVariant.create().put(VariantSettings.Y, Rotation.R270))
							.register(BlockFace.WALL, Direction.NORTH, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90))
							.register(BlockFace.WALL, Direction.EAST, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R90))
							.register(BlockFace.WALL, Direction.SOUTH, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R180))
							.register(BlockFace.WALL, Direction.WEST, BlockStateVariant.create().put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R270))
					)
			);
	}

	private void registerLilyPad() {
		Identifier lv = this.uploadBlockItemModel(Items.LILY_PAD, Blocks.LILY_PAD);
		this.registerTintedItemModel(Blocks.LILY_PAD, lv, ItemModels.constantTintSource(-9321636));
		this.blockStateCollector.accept(createBlockStateWithRandomHorizontalRotations(Blocks.LILY_PAD, ModelIds.getBlockModelId(Blocks.LILY_PAD)));
	}

	private void registerFrogspawn() {
		this.registerItemModel(Blocks.FROGSPAWN);
		this.blockStateCollector.accept(createSingletonBlockState(Blocks.FROGSPAWN, ModelIds.getBlockModelId(Blocks.FROGSPAWN)));
	}

	private void registerNetherPortal() {
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.NETHER_PORTAL)
					.coordinate(
						BlockStateVariantMap.create(Properties.HORIZONTAL_AXIS)
							.register(Axis.X, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.NETHER_PORTAL, "_ns")))
							.register(Axis.Z, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.NETHER_PORTAL, "_ew")))
					)
			);
	}

	private void registerNetherrack() {
		Identifier lv = TexturedModel.CUBE_ALL.upload(Blocks.NETHERRACK, this.modelCollector);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(
					Blocks.NETHERRACK,
					BlockStateVariant.create().put(VariantSettings.MODEL, lv),
					BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.X, Rotation.R90),
					BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.X, Rotation.R180),
					BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.X, Rotation.R270),
					BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R90),
					BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.X, Rotation.R90),
					BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.X, Rotation.R180),
					BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R90).put(VariantSettings.X, Rotation.R270),
					BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R180),
					BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.X, Rotation.R90),
					BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.X, Rotation.R180),
					BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R180).put(VariantSettings.X, Rotation.R270),
					BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R270),
					BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.X, Rotation.R90),
					BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.X, Rotation.R180),
					BlockStateVariant.create().put(VariantSettings.MODEL, lv).put(VariantSettings.Y, Rotation.R270).put(VariantSettings.X, Rotation.R270)
				)
			);
	}

	private void registerObserver() {
		Identifier lv = ModelIds.getBlockModelId(Blocks.OBSERVER);
		Identifier lv2 = ModelIds.getBlockSubModelId(Blocks.OBSERVER, "_on");
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.OBSERVER)
					.coordinate(createBooleanModelMap(Properties.POWERED, lv2, lv))
					.coordinate(createNorthDefaultRotationStates())
			);
	}

	private void registerPistons() {
		TextureMap lv = new TextureMap()
			.put(TextureKey.BOTTOM, TextureMap.getSubId(Blocks.PISTON, "_bottom"))
			.put(TextureKey.SIDE, TextureMap.getSubId(Blocks.PISTON, "_side"));
		Identifier lv2 = TextureMap.getSubId(Blocks.PISTON, "_top_sticky");
		Identifier lv3 = TextureMap.getSubId(Blocks.PISTON, "_top");
		TextureMap lv4 = lv.copyAndAdd(TextureKey.PLATFORM, lv2);
		TextureMap lv5 = lv.copyAndAdd(TextureKey.PLATFORM, lv3);
		Identifier lv6 = ModelIds.getBlockSubModelId(Blocks.PISTON, "_base");
		this.registerPiston(Blocks.PISTON, lv6, lv5);
		this.registerPiston(Blocks.STICKY_PISTON, lv6, lv4);
		Identifier lv7 = Models.CUBE_BOTTOM_TOP.upload(Blocks.PISTON, "_inventory", lv.copyAndAdd(TextureKey.TOP, lv3), this.modelCollector);
		Identifier lv8 = Models.CUBE_BOTTOM_TOP.upload(Blocks.STICKY_PISTON, "_inventory", lv.copyAndAdd(TextureKey.TOP, lv2), this.modelCollector);
		this.registerParentedItemModel(Blocks.PISTON, lv7);
		this.registerParentedItemModel(Blocks.STICKY_PISTON, lv8);
	}

	private void registerPiston(Block piston, Identifier extendedModelId, TextureMap textures) {
		Identifier lv = Models.TEMPLATE_PISTON.upload(piston, textures, this.modelCollector);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(piston)
					.coordinate(createBooleanModelMap(Properties.EXTENDED, extendedModelId, lv))
					.coordinate(createNorthDefaultRotationStates())
			);
	}

	private void registerPistonHead() {
		TextureMap lv = new TextureMap()
			.put(TextureKey.UNSTICKY, TextureMap.getSubId(Blocks.PISTON, "_top"))
			.put(TextureKey.SIDE, TextureMap.getSubId(Blocks.PISTON, "_side"));
		TextureMap lv2 = lv.copyAndAdd(TextureKey.PLATFORM, TextureMap.getSubId(Blocks.PISTON, "_top_sticky"));
		TextureMap lv3 = lv.copyAndAdd(TextureKey.PLATFORM, TextureMap.getSubId(Blocks.PISTON, "_top"));
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.PISTON_HEAD)
					.coordinate(
						BlockStateVariantMap.create(Properties.SHORT, Properties.PISTON_TYPE)
							.register(
								false,
								PistonType.DEFAULT,
								BlockStateVariant.create().put(VariantSettings.MODEL, Models.TEMPLATE_PISTON_HEAD.upload(Blocks.PISTON, "_head", lv3, this.modelCollector))
							)
							.register(
								false,
								PistonType.STICKY,
								BlockStateVariant.create().put(VariantSettings.MODEL, Models.TEMPLATE_PISTON_HEAD.upload(Blocks.PISTON, "_head_sticky", lv2, this.modelCollector))
							)
							.register(
								true,
								PistonType.DEFAULT,
								BlockStateVariant.create().put(VariantSettings.MODEL, Models.TEMPLATE_PISTON_HEAD_SHORT.upload(Blocks.PISTON, "_head_short", lv3, this.modelCollector))
							)
							.register(
								true,
								PistonType.STICKY,
								BlockStateVariant.create()
									.put(VariantSettings.MODEL, Models.TEMPLATE_PISTON_HEAD_SHORT.upload(Blocks.PISTON, "_head_short_sticky", lv2, this.modelCollector))
							)
					)
					.coordinate(createNorthDefaultRotationStates())
			);
	}

	private void registerTrialSpawner() {
		Block lv = Blocks.TRIAL_SPAWNER;
		TextureMap lv2 = TextureMap.trialSpawner(lv, "_side_inactive", "_top_inactive");
		TextureMap lv3 = TextureMap.trialSpawner(lv, "_side_active", "_top_active");
		TextureMap lv4 = TextureMap.trialSpawner(lv, "_side_active", "_top_ejecting_reward");
		TextureMap lv5 = TextureMap.trialSpawner(lv, "_side_inactive_ominous", "_top_inactive_ominous");
		TextureMap lv6 = TextureMap.trialSpawner(lv, "_side_active_ominous", "_top_active_ominous");
		TextureMap lv7 = TextureMap.trialSpawner(lv, "_side_active_ominous", "_top_ejecting_reward_ominous");
		Identifier lv8 = Models.CUBE_BOTTOM_TOP_INNER_FACES.upload(lv, lv2, this.modelCollector);
		Identifier lv9 = Models.CUBE_BOTTOM_TOP_INNER_FACES.upload(lv, "_active", lv3, this.modelCollector);
		Identifier lv10 = Models.CUBE_BOTTOM_TOP_INNER_FACES.upload(lv, "_ejecting_reward", lv4, this.modelCollector);
		Identifier lv11 = Models.CUBE_BOTTOM_TOP_INNER_FACES.upload(lv, "_inactive_ominous", lv5, this.modelCollector);
		Identifier lv12 = Models.CUBE_BOTTOM_TOP_INNER_FACES.upload(lv, "_active_ominous", lv6, this.modelCollector);
		Identifier lv13 = Models.CUBE_BOTTOM_TOP_INNER_FACES.upload(lv, "_ejecting_reward_ominous", lv7, this.modelCollector);
		this.registerParentedItemModel(lv, lv8);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(lv)
					.coordinate(BlockStateVariantMap.create(Properties.TRIAL_SPAWNER_STATE, Properties.OMINOUS).register((spawnerState, ominous) -> {
						return switch (spawnerState) {
							case INACTIVE, COOLDOWN -> BlockStateVariant.create().put(VariantSettings.MODEL, ominous ? lv11 : lv8);
							case WAITING_FOR_PLAYERS, ACTIVE, WAITING_FOR_REWARD_EJECTION -> BlockStateVariant.create().put(VariantSettings.MODEL, ominous ? lv12 : lv9);
							case EJECTING_REWARD -> BlockStateVariant.create().put(VariantSettings.MODEL, ominous ? lv13 : lv10);
							default -> throw new MatchException(null, null);
						};
					}))
			);
	}

	private void registerVault() {
		Block lv = Blocks.VAULT;
		TextureMap lv2 = TextureMap.vault(lv, "_front_off", "_side_off", "_top", "_bottom");
		TextureMap lv3 = TextureMap.vault(lv, "_front_on", "_side_on", "_top", "_bottom");
		TextureMap lv4 = TextureMap.vault(lv, "_front_ejecting", "_side_on", "_top", "_bottom");
		TextureMap lv5 = TextureMap.vault(lv, "_front_ejecting", "_side_on", "_top_ejecting", "_bottom");
		Identifier lv6 = Models.TEMPLATE_VAULT.upload(lv, lv2, this.modelCollector);
		Identifier lv7 = Models.TEMPLATE_VAULT.upload(lv, "_active", lv3, this.modelCollector);
		Identifier lv8 = Models.TEMPLATE_VAULT.upload(lv, "_unlocking", lv4, this.modelCollector);
		Identifier lv9 = Models.TEMPLATE_VAULT.upload(lv, "_ejecting_reward", lv5, this.modelCollector);
		TextureMap lv10 = TextureMap.vault(lv, "_front_off_ominous", "_side_off_ominous", "_top_ominous", "_bottom_ominous");
		TextureMap lv11 = TextureMap.vault(lv, "_front_on_ominous", "_side_on_ominous", "_top_ominous", "_bottom_ominous");
		TextureMap lv12 = TextureMap.vault(lv, "_front_ejecting_ominous", "_side_on_ominous", "_top_ominous", "_bottom_ominous");
		TextureMap lv13 = TextureMap.vault(lv, "_front_ejecting_ominous", "_side_on_ominous", "_top_ejecting_ominous", "_bottom_ominous");
		Identifier lv14 = Models.TEMPLATE_VAULT.upload(lv, "_ominous", lv10, this.modelCollector);
		Identifier lv15 = Models.TEMPLATE_VAULT.upload(lv, "_active_ominous", lv11, this.modelCollector);
		Identifier lv16 = Models.TEMPLATE_VAULT.upload(lv, "_unlocking_ominous", lv12, this.modelCollector);
		Identifier lv17 = Models.TEMPLATE_VAULT.upload(lv, "_ejecting_reward_ominous", lv13, this.modelCollector);
		this.registerParentedItemModel(lv, lv6);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(lv)
					.coordinate(createNorthDefaultHorizontalRotationStates())
					.coordinate(BlockStateVariantMap.create(VaultBlock.VAULT_STATE, VaultBlock.OMINOUS).register((vaultState, ominous) -> {
						return switch (vaultState) {
							case INACTIVE -> BlockStateVariant.create().put(VariantSettings.MODEL, ominous ? lv14 : lv6);
							case ACTIVE -> BlockStateVariant.create().put(VariantSettings.MODEL, ominous ? lv15 : lv7);
							case UNLOCKING -> BlockStateVariant.create().put(VariantSettings.MODEL, ominous ? lv16 : lv8);
							case EJECTING -> BlockStateVariant.create().put(VariantSettings.MODEL, ominous ? lv17 : lv9);
							default -> throw new MatchException(null, null);
						};
					}))
			);
	}

	private void registerSculkSensor() {
		Identifier lv = ModelIds.getBlockSubModelId(Blocks.SCULK_SENSOR, "_inactive");
		Identifier lv2 = ModelIds.getBlockSubModelId(Blocks.SCULK_SENSOR, "_active");
		this.registerParentedItemModel(Blocks.SCULK_SENSOR, lv);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.SCULK_SENSOR)
					.coordinate(
						BlockStateVariantMap.create(Properties.SCULK_SENSOR_PHASE)
							.register(
								phase -> BlockStateVariant.create().put(VariantSettings.MODEL, phase != SculkSensorPhase.ACTIVE && phase != SculkSensorPhase.COOLDOWN ? lv : lv2)
							)
					)
			);
	}

	private void registerCalibratedSculkSensor() {
		Identifier lv = ModelIds.getBlockSubModelId(Blocks.CALIBRATED_SCULK_SENSOR, "_inactive");
		Identifier lv2 = ModelIds.getBlockSubModelId(Blocks.CALIBRATED_SCULK_SENSOR, "_active");
		this.registerParentedItemModel(Blocks.CALIBRATED_SCULK_SENSOR, lv);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.CALIBRATED_SCULK_SENSOR)
					.coordinate(
						BlockStateVariantMap.create(Properties.SCULK_SENSOR_PHASE)
							.register(
								phase -> BlockStateVariant.create().put(VariantSettings.MODEL, phase != SculkSensorPhase.ACTIVE && phase != SculkSensorPhase.COOLDOWN ? lv : lv2)
							)
					)
					.coordinate(createNorthDefaultHorizontalRotationStates())
			);
	}

	private void registerSculkShrieker() {
		Identifier lv = Models.TEMPLATE_SCULK_SHRIEKER.upload(Blocks.SCULK_SHRIEKER, TextureMap.sculkShrieker(false), this.modelCollector);
		Identifier lv2 = Models.TEMPLATE_SCULK_SHRIEKER.upload(Blocks.SCULK_SHRIEKER, "_can_summon", TextureMap.sculkShrieker(true), this.modelCollector);
		this.registerParentedItemModel(Blocks.SCULK_SHRIEKER, lv);
		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(Blocks.SCULK_SHRIEKER).coordinate(createBooleanModelMap(Properties.CAN_SUMMON, lv2, lv)));
	}

	private void registerScaffolding() {
		Identifier lv = ModelIds.getBlockSubModelId(Blocks.SCAFFOLDING, "_stable");
		Identifier lv2 = ModelIds.getBlockSubModelId(Blocks.SCAFFOLDING, "_unstable");
		this.registerParentedItemModel(Blocks.SCAFFOLDING, lv);
		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(Blocks.SCAFFOLDING).coordinate(createBooleanModelMap(Properties.BOTTOM, lv2, lv)));
	}

	private void registerCaveVines() {
		Identifier lv = this.createSubModel(Blocks.CAVE_VINES, "", Models.CROSS, TextureMap::cross);
		Identifier lv2 = this.createSubModel(Blocks.CAVE_VINES, "_lit", Models.CROSS, TextureMap::cross);
		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(Blocks.CAVE_VINES).coordinate(createBooleanModelMap(Properties.BERRIES, lv2, lv)));
		Identifier lv3 = this.createSubModel(Blocks.CAVE_VINES_PLANT, "", Models.CROSS, TextureMap::cross);
		Identifier lv4 = this.createSubModel(Blocks.CAVE_VINES_PLANT, "_lit", Models.CROSS, TextureMap::cross);
		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(Blocks.CAVE_VINES_PLANT).coordinate(createBooleanModelMap(Properties.BERRIES, lv4, lv3)));
	}

	private void registerRedstoneLamp() {
		Identifier lv = TexturedModel.CUBE_ALL.upload(Blocks.REDSTONE_LAMP, this.modelCollector);
		Identifier lv2 = this.createSubModel(Blocks.REDSTONE_LAMP, "_on", Models.CUBE_ALL, TextureMap::all);
		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(Blocks.REDSTONE_LAMP).coordinate(createBooleanModelMap(Properties.LIT, lv2, lv)));
	}

	private void registerTorch(Block torch, Block wallTorch) {
		TextureMap lv = TextureMap.torch(torch);
		this.blockStateCollector.accept(createSingletonBlockState(torch, Models.TEMPLATE_TORCH.upload(torch, lv, this.modelCollector)));
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(
						wallTorch, BlockStateVariant.create().put(VariantSettings.MODEL, Models.TEMPLATE_TORCH_WALL.upload(wallTorch, lv, this.modelCollector))
					)
					.coordinate(createEastDefaultHorizontalRotationStates())
			);
		this.registerItemModel(torch);
	}

	private void registerRedstoneTorch() {
		TextureMap lv = TextureMap.torch(Blocks.REDSTONE_TORCH);
		TextureMap lv2 = TextureMap.torch(TextureMap.getSubId(Blocks.REDSTONE_TORCH, "_off"));
		Identifier lv3 = Models.TEMPLATE_REDSTONE_TORCH.upload(Blocks.REDSTONE_TORCH, lv, this.modelCollector);
		Identifier lv4 = Models.TEMPLATE_TORCH_UNLIT.upload(Blocks.REDSTONE_TORCH, "_off", lv2, this.modelCollector);
		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(Blocks.REDSTONE_TORCH).coordinate(createBooleanModelMap(Properties.LIT, lv3, lv4)));
		Identifier lv5 = Models.TEMPLATE_REDSTONE_TORCH_WALL.upload(Blocks.REDSTONE_WALL_TORCH, lv, this.modelCollector);
		Identifier lv6 = Models.TEMPLATE_TORCH_WALL_UNLIT.upload(Blocks.REDSTONE_WALL_TORCH, "_off", lv2, this.modelCollector);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.REDSTONE_WALL_TORCH)
					.coordinate(createBooleanModelMap(Properties.LIT, lv5, lv6))
					.coordinate(createEastDefaultHorizontalRotationStates())
			);
		this.registerItemModel(Blocks.REDSTONE_TORCH);
	}

	private void registerRepeater() {
		this.registerItemModel(Items.REPEATER);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.REPEATER)
					.coordinate(BlockStateVariantMap.create(Properties.DELAY, Properties.LOCKED, Properties.POWERED).register((tick, locked, on) -> {
						StringBuilder stringBuilder = new StringBuilder();
						stringBuilder.append('_').append(tick).append("tick");
						if (on) {
							stringBuilder.append("_on");
						}
			
						if (locked) {
							stringBuilder.append("_locked");
						}
			
						return BlockStateVariant.create().put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.REPEATER, stringBuilder.toString()));
					}))
					.coordinate(createSouthDefaultHorizontalRotationStates())
			);
	}

	private void registerSeaPickle() {
		this.registerItemModel(Items.SEA_PICKLE);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.SEA_PICKLE)
					.coordinate(
						BlockStateVariantMap.create(Properties.PICKLES, Properties.WATERLOGGED)
							.register(1, false, Arrays.asList(createModelVariantWithRandomHorizontalRotations(ModelIds.getMinecraftNamespacedBlock("dead_sea_pickle"))))
							.register(2, false, Arrays.asList(createModelVariantWithRandomHorizontalRotations(ModelIds.getMinecraftNamespacedBlock("two_dead_sea_pickles"))))
							.register(3, false, Arrays.asList(createModelVariantWithRandomHorizontalRotations(ModelIds.getMinecraftNamespacedBlock("three_dead_sea_pickles"))))
							.register(4, false, Arrays.asList(createModelVariantWithRandomHorizontalRotations(ModelIds.getMinecraftNamespacedBlock("four_dead_sea_pickles"))))
							.register(1, true, Arrays.asList(createModelVariantWithRandomHorizontalRotations(ModelIds.getMinecraftNamespacedBlock("sea_pickle"))))
							.register(2, true, Arrays.asList(createModelVariantWithRandomHorizontalRotations(ModelIds.getMinecraftNamespacedBlock("two_sea_pickles"))))
							.register(3, true, Arrays.asList(createModelVariantWithRandomHorizontalRotations(ModelIds.getMinecraftNamespacedBlock("three_sea_pickles"))))
							.register(4, true, Arrays.asList(createModelVariantWithRandomHorizontalRotations(ModelIds.getMinecraftNamespacedBlock("four_sea_pickles"))))
					)
			);
	}

	private void registerSnows() {
		TextureMap lv = TextureMap.all(Blocks.SNOW);
		Identifier lv2 = Models.CUBE_ALL.upload(Blocks.SNOW_BLOCK, lv, this.modelCollector);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.SNOW)
					.coordinate(
						BlockStateVariantMap.create(Properties.LAYERS)
							.register(
								height -> BlockStateVariant.create().put(VariantSettings.MODEL, height < 8 ? ModelIds.getBlockSubModelId(Blocks.SNOW, "_height" + height * 2) : lv2)
							)
					)
			);
		this.registerParentedItemModel(Blocks.SNOW, ModelIds.getBlockSubModelId(Blocks.SNOW, "_height2"));
		this.blockStateCollector.accept(createSingletonBlockState(Blocks.SNOW_BLOCK, lv2));
	}

	private void registerStonecutter() {
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.STONECUTTER, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockModelId(Blocks.STONECUTTER)))
					.coordinate(createNorthDefaultHorizontalRotationStates())
			);
	}

	private void registerStructureBlock() {
		Identifier lv = TexturedModel.CUBE_ALL.upload(Blocks.STRUCTURE_BLOCK, this.modelCollector);
		this.registerParentedItemModel(Blocks.STRUCTURE_BLOCK, lv);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.STRUCTURE_BLOCK)
					.coordinate(
						BlockStateVariantMap.create(Properties.STRUCTURE_BLOCK_MODE)
							.register(
								mode -> BlockStateVariant.create()
										.put(VariantSettings.MODEL, this.createSubModel(Blocks.STRUCTURE_BLOCK, "_" + mode.asString(), Models.CUBE_ALL, TextureMap::all))
							)
					)
			);
	}

	private void registerSweetBerryBush() {
		this.registerItemModel(Items.SWEET_BERRIES);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.SWEET_BERRY_BUSH)
					.coordinate(
						BlockStateVariantMap.create(Properties.AGE_3)
							.register(
								stage -> BlockStateVariant.create()
										.put(VariantSettings.MODEL, this.createSubModel(Blocks.SWEET_BERRY_BUSH, "_stage" + stage, Models.CROSS, TextureMap::cross))
							)
					)
			);
	}

	private void registerTripwire() {
		this.registerItemModel(Items.STRING);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.TRIPWIRE)
					.coordinate(
						BlockStateVariantMap.create(Properties.ATTACHED, Properties.EAST, Properties.NORTH, Properties.SOUTH, Properties.WEST)
							.register(false, false, false, false, false, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_ns")))
							.register(
								false,
								true,
								false,
								false,
								false,
								BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_n")).put(VariantSettings.Y, Rotation.R90)
							)
							.register(false, false, true, false, false, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_n")))
							.register(
								false,
								false,
								false,
								true,
								false,
								BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_n")).put(VariantSettings.Y, Rotation.R180)
							)
							.register(
								false,
								false,
								false,
								false,
								true,
								BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_n")).put(VariantSettings.Y, Rotation.R270)
							)
							.register(false, true, true, false, false, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_ne")))
							.register(
								false,
								true,
								false,
								true,
								false,
								BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_ne")).put(VariantSettings.Y, Rotation.R90)
							)
							.register(
								false,
								false,
								false,
								true,
								true,
								BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_ne")).put(VariantSettings.Y, Rotation.R180)
							)
							.register(
								false,
								false,
								true,
								false,
								true,
								BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_ne")).put(VariantSettings.Y, Rotation.R270)
							)
							.register(false, false, true, true, false, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_ns")))
							.register(
								false,
								true,
								false,
								false,
								true,
								BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_ns")).put(VariantSettings.Y, Rotation.R90)
							)
							.register(false, true, true, true, false, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_nse")))
							.register(
								false,
								true,
								false,
								true,
								true,
								BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_nse")).put(VariantSettings.Y, Rotation.R90)
							)
							.register(
								false,
								false,
								true,
								true,
								true,
								BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_nse")).put(VariantSettings.Y, Rotation.R180)
							)
							.register(
								false,
								true,
								true,
								false,
								true,
								BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_nse")).put(VariantSettings.Y, Rotation.R270)
							)
							.register(false, true, true, true, true, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_nsew")))
							.register(
								true, false, false, false, false, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_ns"))
							)
							.register(
								true, false, true, false, false, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_n"))
							)
							.register(
								true,
								false,
								false,
								true,
								false,
								BlockStateVariant.create()
									.put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_n"))
									.put(VariantSettings.Y, Rotation.R180)
							)
							.register(
								true,
								true,
								false,
								false,
								false,
								BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_n")).put(VariantSettings.Y, Rotation.R90)
							)
							.register(
								true,
								false,
								false,
								false,
								true,
								BlockStateVariant.create()
									.put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_n"))
									.put(VariantSettings.Y, Rotation.R270)
							)
							.register(
								true, true, true, false, false, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_ne"))
							)
							.register(
								true,
								true,
								false,
								true,
								false,
								BlockStateVariant.create()
									.put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_ne"))
									.put(VariantSettings.Y, Rotation.R90)
							)
							.register(
								true,
								false,
								false,
								true,
								true,
								BlockStateVariant.create()
									.put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_ne"))
									.put(VariantSettings.Y, Rotation.R180)
							)
							.register(
								true,
								false,
								true,
								false,
								true,
								BlockStateVariant.create()
									.put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_ne"))
									.put(VariantSettings.Y, Rotation.R270)
							)
							.register(
								true, false, true, true, false, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_ns"))
							)
							.register(
								true,
								true,
								false,
								false,
								true,
								BlockStateVariant.create()
									.put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_ns"))
									.put(VariantSettings.Y, Rotation.R90)
							)
							.register(
								true, true, true, true, false, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_nse"))
							)
							.register(
								true,
								true,
								false,
								true,
								true,
								BlockStateVariant.create()
									.put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_nse"))
									.put(VariantSettings.Y, Rotation.R90)
							)
							.register(
								true,
								false,
								true,
								true,
								true,
								BlockStateVariant.create()
									.put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_nse"))
									.put(VariantSettings.Y, Rotation.R180)
							)
							.register(
								true,
								true,
								true,
								false,
								true,
								BlockStateVariant.create()
									.put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_nse"))
									.put(VariantSettings.Y, Rotation.R270)
							)
							.register(
								true, true, true, true, true, BlockStateVariant.create().put(VariantSettings.MODEL, ModelIds.getBlockSubModelId(Blocks.TRIPWIRE, "_attached_nsew"))
							)
					)
			);
	}

	private void registerTripwireHook() {
		this.registerItemModel(Blocks.TRIPWIRE_HOOK);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.TRIPWIRE_HOOK)
					.coordinate(
						BlockStateVariantMap.create(Properties.ATTACHED, Properties.POWERED)
							.register(
								(attached, on) -> BlockStateVariant.create()
										.put(VariantSettings.MODEL, TextureMap.getSubId(Blocks.TRIPWIRE_HOOK, (attached ? "_attached" : "") + (on ? "_on" : "")))
							)
					)
					.coordinate(createNorthDefaultHorizontalRotationStates())
			);
	}

	private Identifier getTurtleEggModel(int eggs, String prefix, TextureMap textures) {
		switch (eggs) {
			case 1:
				return Models.TEMPLATE_TURTLE_EGG.upload(ModelIds.getMinecraftNamespacedBlock(prefix + "turtle_egg"), textures, this.modelCollector);
			case 2:
				return Models.TEMPLATE_TWO_TURTLE_EGGS.upload(ModelIds.getMinecraftNamespacedBlock("two_" + prefix + "turtle_eggs"), textures, this.modelCollector);
			case 3:
				return Models.TEMPLATE_THREE_TURTLE_EGGS.upload(ModelIds.getMinecraftNamespacedBlock("three_" + prefix + "turtle_eggs"), textures, this.modelCollector);
			case 4:
				return Models.TEMPLATE_FOUR_TURTLE_EGGS.upload(ModelIds.getMinecraftNamespacedBlock("four_" + prefix + "turtle_eggs"), textures, this.modelCollector);
			default:
				throw new UnsupportedOperationException();
		}
	}

	private Identifier getTurtleEggModel(Integer eggs, Integer hatch) {
		switch (hatch) {
			case 0:
				return this.getTurtleEggModel(eggs, "", TextureMap.all(TextureMap.getId(Blocks.TURTLE_EGG)));
			case 1:
				return this.getTurtleEggModel(eggs, "slightly_cracked_", TextureMap.all(TextureMap.getSubId(Blocks.TURTLE_EGG, "_slightly_cracked")));
			case 2:
				return this.getTurtleEggModel(eggs, "very_cracked_", TextureMap.all(TextureMap.getSubId(Blocks.TURTLE_EGG, "_very_cracked")));
			default:
				throw new UnsupportedOperationException();
		}
	}

	private void registerTurtleEgg() {
		this.registerItemModel(Items.TURTLE_EGG);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.TURTLE_EGG)
					.coordinate(
						BlockStateVariantMap.create(Properties.EGGS, Properties.HATCH)
							.registerVariants((eggs, hatch) -> Arrays.asList(createModelVariantWithRandomHorizontalRotations(this.getTurtleEggModel(eggs, hatch))))
					)
			);
	}

	private void registerSnifferEgg() {
		this.registerItemModel(Items.SNIFFER_EGG);
		Function<Integer, Identifier> function = hatch -> {
			String string = switch (hatch) {
				case 1 -> "_slightly_cracked";
				case 2 -> "_very_cracked";
				default -> "_not_cracked";
			};
			TextureMap lv = TextureMap.snifferEgg(string);
			return Models.SNIFFER_EGG.upload(Blocks.SNIFFER_EGG, string, lv, this.modelCollector);
		};
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.SNIFFER_EGG)
					.coordinate(
						BlockStateVariantMap.create(SnifferEggBlock.HATCH)
							.register(hatch -> BlockStateVariant.create().put(VariantSettings.MODEL, (Identifier)function.apply(hatch)))
					)
			);
	}

	private void registerMultifaceBlock(Block block) {
		this.registerItemModel(block);
		this.registerMultifaceBlockModel(block);
	}

	private void registerMultifaceBlock(Block block, Item item) {
		this.registerItemModel(item);
		this.registerMultifaceBlockModel(block);
	}

	private void registerMultifaceBlockModel(Block block) {
		Identifier lv = ModelIds.getBlockModelId(block);
		MultipartBlockStateSupplier lv2 = MultipartBlockStateSupplier.create(block);
		PropertyCondition lv3 = Util.make(
			When.create(), arg2 -> CONNECTION_VARIANT_FUNCTIONS.stream().map(Pair::getFirst).map(MultifaceBlock::getProperty).forEach(property -> {
					if (block.getDefaultState().contains(property)) {
						arg2.set(property, false);
					}
				})
		);

		for (Pair<Direction, Function<Identifier, BlockStateVariant>> pair : CONNECTION_VARIANT_FUNCTIONS) {
			BooleanProperty lv4 = MultifaceBlock.getProperty((Direction)pair.getFirst());
			Function<Identifier, BlockStateVariant> function = (Function<Identifier, BlockStateVariant>)pair.getSecond();
			if (block.getDefaultState().contains(lv4)) {
				lv2.with(When.create().set(lv4, true), (BlockStateVariant)function.apply(lv));
				lv2.with(lv3, (BlockStateVariant)function.apply(lv));
			}
		}

		this.blockStateCollector.accept(lv2);
	}

	private void registerPaleMossCarpet(Block block) {
		Identifier lv = TexturedModel.CARPET.upload(block, this.modelCollector);
		Identifier lv2 = TexturedModel.MOSSY_CARPET_SIDE
			.get(block)
			.textures(textureMap -> textureMap.put(TextureKey.SIDE, TextureMap.getSubId(block, "_side_tall")))
			.upload(block, "_side_tall", this.modelCollector);
		Identifier lv3 = TexturedModel.MOSSY_CARPET_SIDE
			.get(block)
			.textures(textureMap -> textureMap.put(TextureKey.SIDE, TextureMap.getSubId(block, "_side_small")))
			.upload(block, "_side_small", this.modelCollector);
		MultipartBlockStateSupplier lv4 = MultipartBlockStateSupplier.create(block);
		PropertyCondition lv5 = When.create().set(PaleMossCarpetBlock.BOTTOM, false);
		lv4.with(When.create().set(PaleMossCarpetBlock.BOTTOM, true), BlockStateVariant.create().put(VariantSettings.MODEL, lv));
		lv4.with(lv5, BlockStateVariant.create().put(VariantSettings.MODEL, lv));
		CONNECTION_VARIANT_FUNCTIONS.stream().map(Pair::getFirst).forEach(direction -> {
			EnumProperty<WallShape> lvx = PaleMossCarpetBlock.getWallShape(direction);
			if (lvx != null && block.getDefaultState().contains(lvx)) {
				lv5.set(lvx, WallShape.NONE);
			}
		});

		for (Pair<Direction, Function<Identifier, BlockStateVariant>> pair : CONNECTION_VARIANT_FUNCTIONS) {
			Direction lv6 = (Direction)pair.getFirst();
			EnumProperty<WallShape> lv7 = PaleMossCarpetBlock.getWallShape(lv6);
			if (lv7 != null) {
				Function<Identifier, BlockStateVariant> function = (Function<Identifier, BlockStateVariant>)pair.getSecond();
				lv4.with(When.create().set(lv7, WallShape.TALL), (BlockStateVariant)function.apply(lv2));
				lv4.with(When.create().set(lv7, WallShape.LOW), (BlockStateVariant)function.apply(lv3));
				lv4.with(lv5, (BlockStateVariant)function.apply(lv2));
			}
		}

		this.blockStateCollector.accept(lv4);
	}

	private void registerHangingMoss(Block block) {
		BlockStateVariantMap lv = BlockStateVariantMap.create(HangingMossBlock.TIP).register(tip -> {
			String string = tip ? "_tip" : "";
			TextureMap lvx = TextureMap.cross(TextureMap.getSubId(block, string));
			Identifier lv2 = BlockStateModelGenerator.CrossType.NOT_TINTED.getCrossModel().upload(block, string, lvx, this.modelCollector);
			return BlockStateVariant.create().put(VariantSettings.MODEL, lv2);
		});
		this.registerItemModel(block);
		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(block).coordinate(lv));
	}

	private void registerSculkCatalyst() {
		Identifier lv = TextureMap.getSubId(Blocks.SCULK_CATALYST, "_bottom");
		TextureMap lv2 = new TextureMap()
			.put(TextureKey.BOTTOM, lv)
			.put(TextureKey.TOP, TextureMap.getSubId(Blocks.SCULK_CATALYST, "_top"))
			.put(TextureKey.SIDE, TextureMap.getSubId(Blocks.SCULK_CATALYST, "_side"));
		TextureMap lv3 = new TextureMap()
			.put(TextureKey.BOTTOM, lv)
			.put(TextureKey.TOP, TextureMap.getSubId(Blocks.SCULK_CATALYST, "_top_bloom"))
			.put(TextureKey.SIDE, TextureMap.getSubId(Blocks.SCULK_CATALYST, "_side_bloom"));
		Identifier lv4 = Models.CUBE_BOTTOM_TOP.upload(Blocks.SCULK_CATALYST, "", lv2, this.modelCollector);
		Identifier lv5 = Models.CUBE_BOTTOM_TOP.upload(Blocks.SCULK_CATALYST, "_bloom", lv3, this.modelCollector);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.SCULK_CATALYST)
					.coordinate(BlockStateVariantMap.create(Properties.BLOOM).register(bloom -> BlockStateVariant.create().put(VariantSettings.MODEL, bloom ? lv5 : lv4)))
			);
		this.registerParentedItemModel(Blocks.SCULK_CATALYST, lv4);
	}

	private void registerChiseledBookshelf() {
		Block lv = Blocks.CHISELED_BOOKSHELF;
		Identifier lv2 = ModelIds.getBlockModelId(lv);
		MultipartBlockStateSupplier lv3 = MultipartBlockStateSupplier.create(lv);
		List.of(
				Pair.of(Direction.NORTH, Rotation.R0),
				Pair.of(Direction.EAST, Rotation.R90),
				Pair.of(Direction.SOUTH, Rotation.R180),
				Pair.of(Direction.WEST, Rotation.R270)
			)
			.forEach(pair -> {
				Direction lvx = (Direction)pair.getFirst();
				Rotation lv2x = (Rotation)pair.getSecond();
				PropertyCondition lv3x = When.create().set(Properties.HORIZONTAL_FACING, lvx);
				lv3.with(lv3x, BlockStateVariant.create().put(VariantSettings.MODEL, lv2).put(VariantSettings.Y, lv2x).put(VariantSettings.UVLOCK, true));
				this.supplyChiseledBookshelfModels(lv3, lv3x, lv2x);
			});
		this.blockStateCollector.accept(lv3);
		this.registerParentedItemModel(lv, ModelIds.getBlockSubModelId(lv, "_inventory"));
		CHISELED_BOOKSHELF_MODEL_CACHE.clear();
	}

	private void supplyChiseledBookshelfModels(MultipartBlockStateSupplier blockStateSupplier, PropertyCondition facingCondition, Rotation rotation) {
		List.of(
				Pair.of(Properties.SLOT_0_OCCUPIED, Models.TEMPLATE_CHISELED_BOOKSHELF_SLOT_TOP_LEFT),
				Pair.of(Properties.SLOT_1_OCCUPIED, Models.TEMPLATE_CHISELED_BOOKSHELF_SLOT_TOP_MID),
				Pair.of(Properties.SLOT_2_OCCUPIED, Models.TEMPLATE_CHISELED_BOOKSHELF_SLOT_TOP_RIGHT),
				Pair.of(Properties.SLOT_3_OCCUPIED, Models.TEMPLATE_CHISELED_BOOKSHELF_SLOT_BOTTOM_LEFT),
				Pair.of(Properties.SLOT_4_OCCUPIED, Models.TEMPLATE_CHISELED_BOOKSHELF_SLOT_BOTTOM_MID),
				Pair.of(Properties.SLOT_5_OCCUPIED, Models.TEMPLATE_CHISELED_BOOKSHELF_SLOT_BOTTOM_RIGHT)
			)
			.forEach(pair -> {
				BooleanProperty lv = (BooleanProperty)pair.getFirst();
				Model lv2 = (Model)pair.getSecond();
				this.supplyChiseledBookshelfModel(blockStateSupplier, facingCondition, rotation, lv, lv2, true);
				this.supplyChiseledBookshelfModel(blockStateSupplier, facingCondition, rotation, lv, lv2, false);
			});
	}

	private void supplyChiseledBookshelfModel(
		MultipartBlockStateSupplier blockStateSupplier, PropertyCondition facingCondition, Rotation rotation, BooleanProperty property, Model model, boolean occupied
	) {
		String string = occupied ? "_occupied" : "_empty";
		TextureMap lv = new TextureMap().put(TextureKey.TEXTURE, TextureMap.getSubId(Blocks.CHISELED_BOOKSHELF, string));
		BlockStateModelGenerator.ChiseledBookshelfModelCacheKey lv2 = new BlockStateModelGenerator.ChiseledBookshelfModelCacheKey(model, string);
		Identifier lv3 = (Identifier)CHISELED_BOOKSHELF_MODEL_CACHE.computeIfAbsent(
			lv2, key -> model.upload(Blocks.CHISELED_BOOKSHELF, string, lv, this.modelCollector)
		);
		blockStateSupplier.with(
			When.allOf(facingCondition, When.create().set(property, occupied)),
			BlockStateVariant.create().put(VariantSettings.MODEL, lv3).put(VariantSettings.Y, rotation)
		);
	}

	private void registerMagmaBlock() {
		this.blockStateCollector
			.accept(
				createSingletonBlockState(
					Blocks.MAGMA_BLOCK, Models.CUBE_ALL.upload(Blocks.MAGMA_BLOCK, TextureMap.all(ModelIds.getMinecraftNamespacedBlock("magma")), this.modelCollector)
				)
			);
	}

	private void registerShulkerBox(Block shulkerBox, @Nullable DyeColor arg2) {
		this.registerBuiltin(shulkerBox);
		Item lv = shulkerBox.asItem();
		Identifier lv2 = Models.TEMPLATE_SHULKER_BOX.upload(lv, TextureMap.particle(shulkerBox), this.modelCollector);
		Unbaked lv3 = arg2 != null
			? ItemModels.special(lv2, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked(arg2))
			: ItemModels.special(lv2, new net.minecraft.client.render.item.model.special.ShulkerBoxModelRenderer.Unbaked());
		this.itemModelOutput.accept(lv, lv3);
	}

	private void registerPlantPart(Block plant, Block plantStem, BlockStateModelGenerator.CrossType tintType) {
		this.registerTintableCrossBlockState(plant, tintType);
		this.registerTintableCrossBlockState(plantStem, tintType);
	}

	private void registerInfestedStone() {
		Identifier lv = ModelIds.getBlockModelId(Blocks.STONE);
		Identifier lv2 = ModelIds.getBlockSubModelId(Blocks.STONE, "_mirrored");
		this.blockStateCollector.accept(createBlockStateWithTwoModelAndRandomInversion(Blocks.INFESTED_STONE, lv, lv2));
		this.registerParentedItemModel(Blocks.INFESTED_STONE, lv);
	}

	private void registerInfestedDeepslate() {
		Identifier lv = ModelIds.getBlockModelId(Blocks.DEEPSLATE);
		Identifier lv2 = ModelIds.getBlockSubModelId(Blocks.DEEPSLATE, "_mirrored");
		this.blockStateCollector.accept(createBlockStateWithTwoModelAndRandomInversion(Blocks.INFESTED_DEEPSLATE, lv, lv2).coordinate(createAxisRotatedVariantMap()));
		this.registerParentedItemModel(Blocks.INFESTED_DEEPSLATE, lv);
	}

	private void registerRoots(Block root, Block pottedRoot) {
		this.registerTintableCross(root, BlockStateModelGenerator.CrossType.NOT_TINTED);
		TextureMap lv = TextureMap.plant(TextureMap.getSubId(root, "_pot"));
		Identifier lv2 = BlockStateModelGenerator.CrossType.NOT_TINTED.getFlowerPotCrossModel().upload(pottedRoot, lv, this.modelCollector);
		this.blockStateCollector.accept(createSingletonBlockState(pottedRoot, lv2));
	}

	private void registerRespawnAnchor() {
		Identifier lv = TextureMap.getSubId(Blocks.RESPAWN_ANCHOR, "_bottom");
		Identifier lv2 = TextureMap.getSubId(Blocks.RESPAWN_ANCHOR, "_top_off");
		Identifier lv3 = TextureMap.getSubId(Blocks.RESPAWN_ANCHOR, "_top");
		Identifier[] lvs = new Identifier[5];

		for (int i = 0; i < 5; i++) {
			TextureMap lv4 = new TextureMap()
				.put(TextureKey.BOTTOM, lv)
				.put(TextureKey.TOP, i == 0 ? lv2 : lv3)
				.put(TextureKey.SIDE, TextureMap.getSubId(Blocks.RESPAWN_ANCHOR, "_side" + i));
			lvs[i] = Models.CUBE_BOTTOM_TOP.upload(Blocks.RESPAWN_ANCHOR, "_" + i, lv4, this.modelCollector);
		}

		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.RESPAWN_ANCHOR)
					.coordinate(BlockStateVariantMap.create(Properties.CHARGES).register(charges -> BlockStateVariant.create().put(VariantSettings.MODEL, lvs[charges])))
			);
		this.registerParentedItemModel(Blocks.RESPAWN_ANCHOR, lvs[0]);
	}

	private BlockStateVariant addJigsawOrientationToVariant(Orientation orientation, BlockStateVariant variant) {
		switch (orientation) {
			case DOWN_NORTH:
				return variant.put(VariantSettings.X, Rotation.R90);
			case DOWN_SOUTH:
				return variant.put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R180);
			case DOWN_WEST:
				return variant.put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R270);
			case DOWN_EAST:
				return variant.put(VariantSettings.X, Rotation.R90).put(VariantSettings.Y, Rotation.R90);
			case UP_NORTH:
				return variant.put(VariantSettings.X, Rotation.R270).put(VariantSettings.Y, Rotation.R180);
			case UP_SOUTH:
				return variant.put(VariantSettings.X, Rotation.R270);
			case UP_WEST:
				return variant.put(VariantSettings.X, Rotation.R270).put(VariantSettings.Y, Rotation.R90);
			case UP_EAST:
				return variant.put(VariantSettings.X, Rotation.R270).put(VariantSettings.Y, Rotation.R270);
			case NORTH_UP:
				return variant;
			case SOUTH_UP:
				return variant.put(VariantSettings.Y, Rotation.R180);
			case WEST_UP:
				return variant.put(VariantSettings.Y, Rotation.R270);
			case EAST_UP:
				return variant.put(VariantSettings.Y, Rotation.R90);
			default:
				throw new UnsupportedOperationException("Rotation " + orientation + " can't be expressed with existing x and y values");
		}
	}

	private void registerJigsaw() {
		Identifier lv = TextureMap.getSubId(Blocks.JIGSAW, "_top");
		Identifier lv2 = TextureMap.getSubId(Blocks.JIGSAW, "_bottom");
		Identifier lv3 = TextureMap.getSubId(Blocks.JIGSAW, "_side");
		Identifier lv4 = TextureMap.getSubId(Blocks.JIGSAW, "_lock");
		TextureMap lv5 = new TextureMap()
			.put(TextureKey.DOWN, lv3)
			.put(TextureKey.WEST, lv3)
			.put(TextureKey.EAST, lv3)
			.put(TextureKey.PARTICLE, lv)
			.put(TextureKey.NORTH, lv)
			.put(TextureKey.SOUTH, lv2)
			.put(TextureKey.UP, lv4);
		Identifier lv6 = Models.CUBE_DIRECTIONAL.upload(Blocks.JIGSAW, lv5, this.modelCollector);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(Blocks.JIGSAW, BlockStateVariant.create().put(VariantSettings.MODEL, lv6))
					.coordinate(
						BlockStateVariantMap.create(Properties.ORIENTATION).register(orientation -> this.addJigsawOrientationToVariant(orientation, BlockStateVariant.create()))
					)
			);
	}

	private void registerPetrifiedOakSlab() {
		Block lv = Blocks.OAK_PLANKS;
		Identifier lv2 = ModelIds.getBlockModelId(lv);
		TexturedModel lv3 = TexturedModel.CUBE_ALL.get(lv);
		Block lv4 = Blocks.PETRIFIED_OAK_SLAB;
		Identifier lv5 = Models.SLAB.upload(lv4, lv3.getTextures(), this.modelCollector);
		Identifier lv6 = Models.SLAB_TOP.upload(lv4, lv3.getTextures(), this.modelCollector);
		this.blockStateCollector.accept(createSlabBlockState(lv4, lv5, lv6, lv2));
	}

	private void registerSkull(Block block, Block wallBlock, SkullType type, Identifier baseModelId) {
		Identifier lv = ModelIds.getMinecraftNamespacedBlock("skull");
		this.blockStateCollector.accept(createSingletonBlockState(block, lv));
		this.blockStateCollector.accept(createSingletonBlockState(wallBlock, lv));
		this.itemModelOutput
			.accept(block.asItem(), ItemModels.special(baseModelId, new net.minecraft.client.render.item.model.special.HeadModelRenderer.Unbaked(type)));
	}

	private void registerSkulls() {
		Identifier lv = ModelIds.getMinecraftNamespacedItem("template_skull");
		this.registerSkull(Blocks.CREEPER_HEAD, Blocks.CREEPER_WALL_HEAD, Type.CREEPER, lv);
		this.registerSkull(Blocks.PLAYER_HEAD, Blocks.PLAYER_WALL_HEAD, Type.PLAYER, lv);
		this.registerSkull(Blocks.ZOMBIE_HEAD, Blocks.ZOMBIE_WALL_HEAD, Type.ZOMBIE, lv);
		this.registerSkull(Blocks.SKELETON_SKULL, Blocks.SKELETON_WALL_SKULL, Type.SKELETON, lv);
		this.registerSkull(Blocks.WITHER_SKELETON_SKULL, Blocks.WITHER_SKELETON_WALL_SKULL, Type.WITHER_SKELETON, lv);
		this.registerSkull(Blocks.PIGLIN_HEAD, Blocks.PIGLIN_WALL_HEAD, Type.PIGLIN, lv);
		this.registerSkull(Blocks.DRAGON_HEAD, Blocks.DRAGON_WALL_HEAD, Type.DRAGON, ModelIds.getItemModelId(Items.DRAGON_HEAD));
	}

	private void registerBanner(Block block, Block wallBlock, DyeColor color) {
		Identifier lv = ModelIds.getMinecraftNamespacedBlock("banner");
		Identifier lv2 = ModelIds.getMinecraftNamespacedItem("template_banner");
		this.blockStateCollector.accept(createSingletonBlockState(block, lv));
		this.blockStateCollector.accept(createSingletonBlockState(wallBlock, lv));
		Item lv3 = block.asItem();
		this.itemModelOutput.accept(lv3, ItemModels.special(lv2, new net.minecraft.client.render.item.model.special.BannerModelRenderer.Unbaked(color)));
	}

	private void registerBanners() {
		this.registerBanner(Blocks.WHITE_BANNER, Blocks.WHITE_WALL_BANNER, DyeColor.WHITE);
		this.registerBanner(Blocks.ORANGE_BANNER, Blocks.ORANGE_WALL_BANNER, DyeColor.ORANGE);
		this.registerBanner(Blocks.MAGENTA_BANNER, Blocks.MAGENTA_WALL_BANNER, DyeColor.MAGENTA);
		this.registerBanner(Blocks.LIGHT_BLUE_BANNER, Blocks.LIGHT_BLUE_WALL_BANNER, DyeColor.LIGHT_BLUE);
		this.registerBanner(Blocks.YELLOW_BANNER, Blocks.YELLOW_WALL_BANNER, DyeColor.YELLOW);
		this.registerBanner(Blocks.LIME_BANNER, Blocks.LIME_WALL_BANNER, DyeColor.LIME);
		this.registerBanner(Blocks.PINK_BANNER, Blocks.PINK_WALL_BANNER, DyeColor.PINK);
		this.registerBanner(Blocks.GRAY_BANNER, Blocks.GRAY_WALL_BANNER, DyeColor.GRAY);
		this.registerBanner(Blocks.LIGHT_GRAY_BANNER, Blocks.LIGHT_GRAY_WALL_BANNER, DyeColor.LIGHT_GRAY);
		this.registerBanner(Blocks.CYAN_BANNER, Blocks.CYAN_WALL_BANNER, DyeColor.CYAN);
		this.registerBanner(Blocks.PURPLE_BANNER, Blocks.PURPLE_WALL_BANNER, DyeColor.PURPLE);
		this.registerBanner(Blocks.BLUE_BANNER, Blocks.BLUE_WALL_BANNER, DyeColor.BLUE);
		this.registerBanner(Blocks.BROWN_BANNER, Blocks.BROWN_WALL_BANNER, DyeColor.BROWN);
		this.registerBanner(Blocks.GREEN_BANNER, Blocks.GREEN_WALL_BANNER, DyeColor.GREEN);
		this.registerBanner(Blocks.RED_BANNER, Blocks.RED_WALL_BANNER, DyeColor.RED);
		this.registerBanner(Blocks.BLACK_BANNER, Blocks.BLACK_WALL_BANNER, DyeColor.BLACK);
	}

	private void registerChest(Block block, Block particleSource, Identifier texture, boolean christmas) {
		this.registerBuiltinWithParticle(block, particleSource);
		Item lv = block.asItem();
		Identifier lv2 = Models.TEMPLATE_CHEST.upload(lv, TextureMap.particle(particleSource), this.modelCollector);
		Unbaked lv3 = ItemModels.special(lv2, new net.minecraft.client.render.item.model.special.ChestModelRenderer.Unbaked(texture));
		if (christmas) {
			Unbaked lv4 = ItemModels.special(lv2, new net.minecraft.client.render.item.model.special.ChestModelRenderer.Unbaked(ChestModelRenderer.CHRISTMAS_ID));
			this.itemModelOutput.accept(lv, ItemModels.christmasSelect(lv4, lv3));
		} else {
			this.itemModelOutput.accept(lv, lv3);
		}
	}

	private void registerChests() {
		this.registerChest(Blocks.CHEST, Blocks.OAK_PLANKS, ChestModelRenderer.NORMAL_ID, true);
		this.registerChest(Blocks.TRAPPED_CHEST, Blocks.OAK_PLANKS, ChestModelRenderer.TRAPPED_ID, true);
		this.registerChest(Blocks.ENDER_CHEST, Blocks.OBSIDIAN, ChestModelRenderer.ENDER_ID, false);
	}

	private void registerBed(Block block, Block particleSource, DyeColor color) {
		Identifier lv = ModelIds.getMinecraftNamespacedBlock("bed");
		this.blockStateCollector.accept(createSingletonBlockState(block, lv));
		Item lv2 = block.asItem();
		Identifier lv3 = Models.TEMPLATE_BED.upload(ModelIds.getItemModelId(lv2), TextureMap.particle(particleSource), this.modelCollector);
		this.itemModelOutput.accept(lv2, ItemModels.special(lv3, new net.minecraft.client.render.item.model.special.BedModelRenderer.Unbaked(color)));
	}

	private void registerBeds() {
		this.registerBed(Blocks.WHITE_BED, Blocks.WHITE_WOOL, DyeColor.WHITE);
		this.registerBed(Blocks.ORANGE_BED, Blocks.ORANGE_WOOL, DyeColor.ORANGE);
		this.registerBed(Blocks.MAGENTA_BED, Blocks.MAGENTA_WOOL, DyeColor.MAGENTA);
		this.registerBed(Blocks.LIGHT_BLUE_BED, Blocks.LIGHT_BLUE_WOOL, DyeColor.LIGHT_BLUE);
		this.registerBed(Blocks.YELLOW_BED, Blocks.YELLOW_WOOL, DyeColor.YELLOW);
		this.registerBed(Blocks.LIME_BED, Blocks.LIME_WOOL, DyeColor.LIME);
		this.registerBed(Blocks.PINK_BED, Blocks.PINK_WOOL, DyeColor.PINK);
		this.registerBed(Blocks.GRAY_BED, Blocks.GRAY_WOOL, DyeColor.GRAY);
		this.registerBed(Blocks.LIGHT_GRAY_BED, Blocks.LIGHT_GRAY_WOOL, DyeColor.LIGHT_GRAY);
		this.registerBed(Blocks.CYAN_BED, Blocks.CYAN_WOOL, DyeColor.CYAN);
		this.registerBed(Blocks.PURPLE_BED, Blocks.PURPLE_WOOL, DyeColor.PURPLE);
		this.registerBed(Blocks.BLUE_BED, Blocks.BLUE_WOOL, DyeColor.BLUE);
		this.registerBed(Blocks.BROWN_BED, Blocks.BROWN_WOOL, DyeColor.BROWN);
		this.registerBed(Blocks.GREEN_BED, Blocks.GREEN_WOOL, DyeColor.GREEN);
		this.registerBed(Blocks.RED_BED, Blocks.RED_WOOL, DyeColor.RED);
		this.registerBed(Blocks.BLACK_BED, Blocks.BLACK_WOOL, DyeColor.BLACK);
	}

	private void registerSpecialItemModel(Block block, net.minecraft.client.render.item.model.special.SpecialModelRenderer.Unbaked specialModel) {
		Item lv = block.asItem();
		Identifier lv2 = ModelIds.getItemModelId(lv);
		this.itemModelOutput.accept(lv, ItemModels.special(lv2, specialModel));
	}

	public void register() {
		BlockFamilies.getFamilies()
			.filter(BlockFamily::shouldGenerateModels)
			.forEach(family -> this.registerCubeAllModelTexturePool(family.getBaseBlock()).family(family));
		this.registerCubeAllModelTexturePool(Blocks.CUT_COPPER)
			.family(BlockFamilies.CUT_COPPER)
			.parented(Blocks.CUT_COPPER, Blocks.WAXED_CUT_COPPER)
			.parented(Blocks.CHISELED_COPPER, Blocks.WAXED_CHISELED_COPPER)
			.family(BlockFamilies.WAXED_CUT_COPPER);
		this.registerCubeAllModelTexturePool(Blocks.EXPOSED_CUT_COPPER)
			.family(BlockFamilies.EXPOSED_CUT_COPPER)
			.parented(Blocks.EXPOSED_CUT_COPPER, Blocks.WAXED_EXPOSED_CUT_COPPER)
			.parented(Blocks.EXPOSED_CHISELED_COPPER, Blocks.WAXED_EXPOSED_CHISELED_COPPER)
			.family(BlockFamilies.WAXED_EXPOSED_CUT_COPPER);
		this.registerCubeAllModelTexturePool(Blocks.WEATHERED_CUT_COPPER)
			.family(BlockFamilies.WEATHERED_CUT_COPPER)
			.parented(Blocks.WEATHERED_CUT_COPPER, Blocks.WAXED_WEATHERED_CUT_COPPER)
			.parented(Blocks.WEATHERED_CHISELED_COPPER, Blocks.WAXED_WEATHERED_CHISELED_COPPER)
			.family(BlockFamilies.WAXED_WEATHERED_CUT_COPPER);
		this.registerCubeAllModelTexturePool(Blocks.OXIDIZED_CUT_COPPER)
			.family(BlockFamilies.OXIDIZED_CUT_COPPER)
			.parented(Blocks.OXIDIZED_CUT_COPPER, Blocks.WAXED_OXIDIZED_CUT_COPPER)
			.parented(Blocks.OXIDIZED_CHISELED_COPPER, Blocks.WAXED_OXIDIZED_CHISELED_COPPER)
			.family(BlockFamilies.WAXED_OXIDIZED_CUT_COPPER);
		this.registerCopperBulb(Blocks.COPPER_BULB);
		this.registerCopperBulb(Blocks.EXPOSED_COPPER_BULB);
		this.registerCopperBulb(Blocks.WEATHERED_COPPER_BULB);
		this.registerCopperBulb(Blocks.OXIDIZED_COPPER_BULB);
		this.registerWaxedCopperBulb(Blocks.COPPER_BULB, Blocks.WAXED_COPPER_BULB);
		this.registerWaxedCopperBulb(Blocks.EXPOSED_COPPER_BULB, Blocks.WAXED_EXPOSED_COPPER_BULB);
		this.registerWaxedCopperBulb(Blocks.WEATHERED_COPPER_BULB, Blocks.WAXED_WEATHERED_COPPER_BULB);
		this.registerWaxedCopperBulb(Blocks.OXIDIZED_COPPER_BULB, Blocks.WAXED_OXIDIZED_COPPER_BULB);
		this.registerSimpleState(Blocks.AIR);
		this.registerStateWithModelReference(Blocks.CAVE_AIR, Blocks.AIR);
		this.registerStateWithModelReference(Blocks.VOID_AIR, Blocks.AIR);
		this.registerSimpleState(Blocks.BEACON);
		this.registerSimpleState(Blocks.CACTUS);
		this.registerStateWithModelReference(Blocks.BUBBLE_COLUMN, Blocks.WATER);
		this.registerSimpleState(Blocks.DRAGON_EGG);
		this.registerSimpleState(Blocks.DRIED_KELP_BLOCK);
		this.registerSimpleState(Blocks.ENCHANTING_TABLE);
		this.registerSimpleState(Blocks.FLOWER_POT);
		this.registerItemModel(Items.FLOWER_POT);
		this.registerSimpleState(Blocks.HONEY_BLOCK);
		this.registerSimpleState(Blocks.WATER);
		this.registerSimpleState(Blocks.LAVA);
		this.registerSimpleState(Blocks.SLIME_BLOCK);
		this.registerItemModel(Items.CHAIN);
		this.registerCandle(Blocks.WHITE_CANDLE, Blocks.WHITE_CANDLE_CAKE);
		this.registerCandle(Blocks.ORANGE_CANDLE, Blocks.ORANGE_CANDLE_CAKE);
		this.registerCandle(Blocks.MAGENTA_CANDLE, Blocks.MAGENTA_CANDLE_CAKE);
		this.registerCandle(Blocks.LIGHT_BLUE_CANDLE, Blocks.LIGHT_BLUE_CANDLE_CAKE);
		this.registerCandle(Blocks.YELLOW_CANDLE, Blocks.YELLOW_CANDLE_CAKE);
		this.registerCandle(Blocks.LIME_CANDLE, Blocks.LIME_CANDLE_CAKE);
		this.registerCandle(Blocks.PINK_CANDLE, Blocks.PINK_CANDLE_CAKE);
		this.registerCandle(Blocks.GRAY_CANDLE, Blocks.GRAY_CANDLE_CAKE);
		this.registerCandle(Blocks.LIGHT_GRAY_CANDLE, Blocks.LIGHT_GRAY_CANDLE_CAKE);
		this.registerCandle(Blocks.CYAN_CANDLE, Blocks.CYAN_CANDLE_CAKE);
		this.registerCandle(Blocks.PURPLE_CANDLE, Blocks.PURPLE_CANDLE_CAKE);
		this.registerCandle(Blocks.BLUE_CANDLE, Blocks.BLUE_CANDLE_CAKE);
		this.registerCandle(Blocks.BROWN_CANDLE, Blocks.BROWN_CANDLE_CAKE);
		this.registerCandle(Blocks.GREEN_CANDLE, Blocks.GREEN_CANDLE_CAKE);
		this.registerCandle(Blocks.RED_CANDLE, Blocks.RED_CANDLE_CAKE);
		this.registerCandle(Blocks.BLACK_CANDLE, Blocks.BLACK_CANDLE_CAKE);
		this.registerCandle(Blocks.CANDLE, Blocks.CANDLE_CAKE);
		this.registerSimpleState(Blocks.POTTED_BAMBOO);
		this.registerSimpleState(Blocks.POTTED_CACTUS);
		this.registerSimpleState(Blocks.POWDER_SNOW);
		this.registerSimpleState(Blocks.SPORE_BLOSSOM);
		this.registerAzalea(Blocks.AZALEA);
		this.registerAzalea(Blocks.FLOWERING_AZALEA);
		this.registerPottedAzaleaBush(Blocks.POTTED_AZALEA_BUSH);
		this.registerPottedAzaleaBush(Blocks.POTTED_FLOWERING_AZALEA_BUSH);
		this.registerCaveVines();
		this.registerWoolAndCarpet(Blocks.MOSS_BLOCK, Blocks.MOSS_CARPET);
		this.registerPaleMossCarpet(Blocks.PALE_MOSS_CARPET);
		this.registerHangingMoss(Blocks.PALE_HANGING_MOSS);
		this.registerSimpleCubeAll(Blocks.PALE_MOSS_BLOCK);
		this.registerFlowerbed(Blocks.PINK_PETALS);
		this.registerFlowerbed(Blocks.WILDFLOWERS);
		this.registerLeafLitter(Blocks.LEAF_LITTER);
		this.registerBuiltinWithParticle(Blocks.BARRIER, Items.BARRIER);
		this.registerItemModel(Items.BARRIER);
		this.registerLightBlock();
		this.registerBuiltinWithParticle(Blocks.STRUCTURE_VOID, Items.STRUCTURE_VOID);
		this.registerItemModel(Items.STRUCTURE_VOID);
		this.registerBuiltinWithParticle(Blocks.MOVING_PISTON, TextureMap.getSubId(Blocks.PISTON, "_side"));
		this.registerSimpleCubeAll(Blocks.COAL_ORE);
		this.registerSimpleCubeAll(Blocks.DEEPSLATE_COAL_ORE);
		this.registerSimpleCubeAll(Blocks.COAL_BLOCK);
		this.registerSimpleCubeAll(Blocks.DIAMOND_ORE);
		this.registerSimpleCubeAll(Blocks.DEEPSLATE_DIAMOND_ORE);
		this.registerSimpleCubeAll(Blocks.DIAMOND_BLOCK);
		this.registerSimpleCubeAll(Blocks.EMERALD_ORE);
		this.registerSimpleCubeAll(Blocks.DEEPSLATE_EMERALD_ORE);
		this.registerSimpleCubeAll(Blocks.EMERALD_BLOCK);
		this.registerSimpleCubeAll(Blocks.GOLD_ORE);
		this.registerSimpleCubeAll(Blocks.NETHER_GOLD_ORE);
		this.registerSimpleCubeAll(Blocks.DEEPSLATE_GOLD_ORE);
		this.registerSimpleCubeAll(Blocks.GOLD_BLOCK);
		this.registerSimpleCubeAll(Blocks.IRON_ORE);
		this.registerSimpleCubeAll(Blocks.DEEPSLATE_IRON_ORE);
		this.registerSimpleCubeAll(Blocks.IRON_BLOCK);
		this.registerSingleton(Blocks.ANCIENT_DEBRIS, TexturedModel.CUBE_COLUMN);
		this.registerSimpleCubeAll(Blocks.NETHERITE_BLOCK);
		this.registerSimpleCubeAll(Blocks.LAPIS_ORE);
		this.registerSimpleCubeAll(Blocks.DEEPSLATE_LAPIS_ORE);
		this.registerSimpleCubeAll(Blocks.LAPIS_BLOCK);
		this.registerSimpleCubeAll(Blocks.RESIN_BLOCK);
		this.registerSimpleCubeAll(Blocks.NETHER_QUARTZ_ORE);
		this.registerSimpleCubeAll(Blocks.REDSTONE_ORE);
		this.registerSimpleCubeAll(Blocks.DEEPSLATE_REDSTONE_ORE);
		this.registerSimpleCubeAll(Blocks.REDSTONE_BLOCK);
		this.registerSimpleCubeAll(Blocks.GILDED_BLACKSTONE);
		this.registerSimpleCubeAll(Blocks.BLUE_ICE);
		this.registerSimpleCubeAll(Blocks.CLAY);
		this.registerSimpleCubeAll(Blocks.COARSE_DIRT);
		this.registerSimpleCubeAll(Blocks.CRYING_OBSIDIAN);
		this.registerSimpleCubeAll(Blocks.END_STONE);
		this.registerSimpleCubeAll(Blocks.GLOWSTONE);
		this.registerSimpleCubeAll(Blocks.GRAVEL);
		this.registerSimpleCubeAll(Blocks.HONEYCOMB_BLOCK);
		this.registerSimpleCubeAll(Blocks.ICE);
		this.registerSingleton(Blocks.JUKEBOX, TexturedModel.CUBE_TOP);
		this.registerSingleton(Blocks.LODESTONE, TexturedModel.CUBE_COLUMN);
		this.registerSingleton(Blocks.MELON, TexturedModel.CUBE_COLUMN);
		this.registerSimpleState(Blocks.MANGROVE_ROOTS);
		this.registerSimpleState(Blocks.POTTED_MANGROVE_PROPAGULE);
		this.registerSimpleCubeAll(Blocks.NETHER_WART_BLOCK);
		this.registerSimpleCubeAll(Blocks.NOTE_BLOCK);
		this.registerSimpleCubeAll(Blocks.PACKED_ICE);
		this.registerSimpleCubeAll(Blocks.OBSIDIAN);
		this.registerSimpleCubeAll(Blocks.QUARTZ_BRICKS);
		this.registerSimpleCubeAll(Blocks.SEA_LANTERN);
		this.registerSimpleCubeAll(Blocks.SHROOMLIGHT);
		this.registerSimpleCubeAll(Blocks.SOUL_SAND);
		this.registerSimpleCubeAll(Blocks.SOUL_SOIL);
		this.registerSingleton(Blocks.SPAWNER, TexturedModel.CUBE_ALL_INNER_FACES);
		this.registerCreakingHeart(Blocks.CREAKING_HEART);
		this.registerSimpleCubeAll(Blocks.SPONGE);
		this.registerSingleton(Blocks.SEAGRASS, TexturedModel.TEMPLATE_SEAGRASS);
		this.registerItemModel(Items.SEAGRASS);
		this.registerSingleton(Blocks.TNT, TexturedModel.CUBE_BOTTOM_TOP);
		this.registerSingleton(Blocks.TARGET, TexturedModel.CUBE_COLUMN);
		this.registerSimpleCubeAll(Blocks.WARPED_WART_BLOCK);
		this.registerSimpleCubeAll(Blocks.WET_SPONGE);
		this.registerSimpleCubeAll(Blocks.AMETHYST_BLOCK);
		this.registerSimpleCubeAll(Blocks.BUDDING_AMETHYST);
		this.registerSimpleCubeAll(Blocks.CALCITE);
		this.registerSimpleCubeAll(Blocks.DRIPSTONE_BLOCK);
		this.registerSimpleCubeAll(Blocks.RAW_IRON_BLOCK);
		this.registerSimpleCubeAll(Blocks.RAW_COPPER_BLOCK);
		this.registerSimpleCubeAll(Blocks.RAW_GOLD_BLOCK);
		this.registerMirrorable(Blocks.SCULK);
		this.registerSimpleState(Blocks.HEAVY_CORE);
		this.registerPetrifiedOakSlab();
		this.registerSimpleCubeAll(Blocks.COPPER_ORE);
		this.registerSimpleCubeAll(Blocks.DEEPSLATE_COPPER_ORE);
		this.registerSimpleCubeAll(Blocks.COPPER_BLOCK);
		this.registerSimpleCubeAll(Blocks.EXPOSED_COPPER);
		this.registerSimpleCubeAll(Blocks.WEATHERED_COPPER);
		this.registerSimpleCubeAll(Blocks.OXIDIZED_COPPER);
		this.registerParented(Blocks.COPPER_BLOCK, Blocks.WAXED_COPPER_BLOCK);
		this.registerParented(Blocks.EXPOSED_COPPER, Blocks.WAXED_EXPOSED_COPPER);
		this.registerParented(Blocks.WEATHERED_COPPER, Blocks.WAXED_WEATHERED_COPPER);
		this.registerParented(Blocks.OXIDIZED_COPPER, Blocks.WAXED_OXIDIZED_COPPER);
		this.registerDoor(Blocks.COPPER_DOOR);
		this.registerDoor(Blocks.EXPOSED_COPPER_DOOR);
		this.registerDoor(Blocks.WEATHERED_COPPER_DOOR);
		this.registerDoor(Blocks.OXIDIZED_COPPER_DOOR);
		this.registerParentedDoor(Blocks.COPPER_DOOR, Blocks.WAXED_COPPER_DOOR);
		this.registerParentedDoor(Blocks.EXPOSED_COPPER_DOOR, Blocks.WAXED_EXPOSED_COPPER_DOOR);
		this.registerParentedDoor(Blocks.WEATHERED_COPPER_DOOR, Blocks.WAXED_WEATHERED_COPPER_DOOR);
		this.registerParentedDoor(Blocks.OXIDIZED_COPPER_DOOR, Blocks.WAXED_OXIDIZED_COPPER_DOOR);
		this.registerTrapdoor(Blocks.COPPER_TRAPDOOR);
		this.registerTrapdoor(Blocks.EXPOSED_COPPER_TRAPDOOR);
		this.registerTrapdoor(Blocks.WEATHERED_COPPER_TRAPDOOR);
		this.registerTrapdoor(Blocks.OXIDIZED_COPPER_TRAPDOOR);
		this.registerParentedTrapdoor(Blocks.COPPER_TRAPDOOR, Blocks.WAXED_COPPER_TRAPDOOR);
		this.registerParentedTrapdoor(Blocks.EXPOSED_COPPER_TRAPDOOR, Blocks.WAXED_EXPOSED_COPPER_TRAPDOOR);
		this.registerParentedTrapdoor(Blocks.WEATHERED_COPPER_TRAPDOOR, Blocks.WAXED_WEATHERED_COPPER_TRAPDOOR);
		this.registerParentedTrapdoor(Blocks.OXIDIZED_COPPER_TRAPDOOR, Blocks.WAXED_OXIDIZED_COPPER_TRAPDOOR);
		this.registerSimpleCubeAll(Blocks.COPPER_GRATE);
		this.registerSimpleCubeAll(Blocks.EXPOSED_COPPER_GRATE);
		this.registerSimpleCubeAll(Blocks.WEATHERED_COPPER_GRATE);
		this.registerSimpleCubeAll(Blocks.OXIDIZED_COPPER_GRATE);
		this.registerParented(Blocks.COPPER_GRATE, Blocks.WAXED_COPPER_GRATE);
		this.registerParented(Blocks.EXPOSED_COPPER_GRATE, Blocks.WAXED_EXPOSED_COPPER_GRATE);
		this.registerParented(Blocks.WEATHERED_COPPER_GRATE, Blocks.WAXED_WEATHERED_COPPER_GRATE);
		this.registerParented(Blocks.OXIDIZED_COPPER_GRATE, Blocks.WAXED_OXIDIZED_COPPER_GRATE);
		this.registerWeightedPressurePlate(Blocks.LIGHT_WEIGHTED_PRESSURE_PLATE, Blocks.GOLD_BLOCK);
		this.registerWeightedPressurePlate(Blocks.HEAVY_WEIGHTED_PRESSURE_PLATE, Blocks.IRON_BLOCK);
		this.registerAmethysts();
		this.registerBookshelf();
		this.registerChiseledBookshelf();
		this.registerBrewingStand();
		this.registerCake();
		this.registerCampfire(Blocks.CAMPFIRE, Blocks.SOUL_CAMPFIRE);
		this.registerCartographyTable();
		this.registerCauldrons();
		this.registerChorusFlower();
		this.registerChorusPlant();
		this.registerComposter();
		this.registerDaylightDetector();
		this.registerEndPortalFrame();
		this.registerRod(Blocks.END_ROD);
		this.registerLightningRod();
		this.registerFarmland();
		this.registerFire();
		this.registerSoulFire();
		this.registerFrostedIce();
		this.registerTopSoils();
		this.registerCocoa();
		this.registerDirtPath();
		this.registerGrindstone();
		this.registerHopper();
		this.registerIronBars();
		this.registerLever();
		this.registerLilyPad();
		this.registerNetherPortal();
		this.registerNetherrack();
		this.registerObserver();
		this.registerPistons();
		this.registerPistonHead();
		this.registerScaffolding();
		this.registerRedstoneTorch();
		this.registerRedstoneLamp();
		this.registerRepeater();
		this.registerSeaPickle();
		this.registerSmithingTable();
		this.registerSnows();
		this.registerStonecutter();
		this.registerStructureBlock();
		this.registerSweetBerryBush();
		this.registerTripwire();
		this.registerTripwireHook();
		this.registerTurtleEgg();
		this.registerSnifferEgg();
		this.registerVine();
		this.registerMultifaceBlock(Blocks.GLOW_LICHEN);
		this.registerMultifaceBlock(Blocks.SCULK_VEIN);
		this.registerMultifaceBlock(Blocks.RESIN_CLUMP, Items.RESIN_CLUMP);
		this.registerMagmaBlock();
		this.registerJigsaw();
		this.registerSculkSensor();
		this.registerCalibratedSculkSensor();
		this.registerSculkShrieker();
		this.registerFrogspawn();
		this.registerMangrovePropagule();
		this.registerMuddyMangroveRoots();
		this.registerTrialSpawner();
		this.registerVault();
		this.registerNorthDefaultHorizontalRotation(Blocks.LADDER);
		this.registerItemModel(Blocks.LADDER);
		this.registerNorthDefaultHorizontalRotation(Blocks.LECTERN);
		this.registerBigDripleaf();
		this.registerNorthDefaultHorizontalRotation(Blocks.BIG_DRIPLEAF_STEM);
		this.registerTorch(Blocks.TORCH, Blocks.WALL_TORCH);
		this.registerTorch(Blocks.SOUL_TORCH, Blocks.SOUL_WALL_TORCH);
		this.registerCubeWithCustomTextures(Blocks.CRAFTING_TABLE, Blocks.OAK_PLANKS, TextureMap::frontSideWithCustomBottom);
		this.registerCubeWithCustomTextures(Blocks.FLETCHING_TABLE, Blocks.BIRCH_PLANKS, TextureMap::frontTopSide);
		this.registerNetherrackBottomCustomTop(Blocks.CRIMSON_NYLIUM);
		this.registerNetherrackBottomCustomTop(Blocks.WARPED_NYLIUM);
		this.registerDispenserLikeOrientable(Blocks.DISPENSER);
		this.registerDispenserLikeOrientable(Blocks.DROPPER);
		this.registerCrafter();
		this.registerLantern(Blocks.LANTERN);
		this.registerLantern(Blocks.SOUL_LANTERN);
		this.registerAxisRotated(Blocks.CHAIN, ModelIds.getBlockModelId(Blocks.CHAIN));
		this.registerAxisRotated(Blocks.BASALT, TexturedModel.CUBE_COLUMN);
		this.registerAxisRotated(Blocks.POLISHED_BASALT, TexturedModel.CUBE_COLUMN);
		this.registerSimpleCubeAll(Blocks.SMOOTH_BASALT);
		this.registerAxisRotated(Blocks.BONE_BLOCK, TexturedModel.CUBE_COLUMN);
		this.registerRotatable(Blocks.DIRT);
		this.registerRotatable(Blocks.ROOTED_DIRT);
		this.registerRotatable(Blocks.SAND);
		this.registerBrushableBlock(Blocks.SUSPICIOUS_SAND);
		this.registerBrushableBlock(Blocks.SUSPICIOUS_GRAVEL);
		this.registerRotatable(Blocks.RED_SAND);
		this.registerMirrorable(Blocks.BEDROCK);
		this.registerSingleton(Blocks.REINFORCED_DEEPSLATE, TexturedModel.CUBE_BOTTOM_TOP);
		this.registerAxisRotated(Blocks.HAY_BLOCK, TexturedModel.CUBE_COLUMN, TexturedModel.CUBE_COLUMN_HORIZONTAL);
		this.registerAxisRotated(Blocks.PURPUR_PILLAR, TexturedModel.END_FOR_TOP_CUBE_COLUMN, TexturedModel.END_FOR_TOP_CUBE_COLUMN_HORIZONTAL);
		this.registerAxisRotated(Blocks.QUARTZ_PILLAR, TexturedModel.END_FOR_TOP_CUBE_COLUMN, TexturedModel.END_FOR_TOP_CUBE_COLUMN_HORIZONTAL);
		this.registerAxisRotated(Blocks.OCHRE_FROGLIGHT, TexturedModel.CUBE_COLUMN, TexturedModel.CUBE_COLUMN_HORIZONTAL);
		this.registerAxisRotated(Blocks.VERDANT_FROGLIGHT, TexturedModel.CUBE_COLUMN, TexturedModel.CUBE_COLUMN_HORIZONTAL);
		this.registerAxisRotated(Blocks.PEARLESCENT_FROGLIGHT, TexturedModel.CUBE_COLUMN, TexturedModel.CUBE_COLUMN_HORIZONTAL);
		this.registerNorthDefaultHorizontalRotated(Blocks.LOOM, TexturedModel.ORIENTABLE_WITH_BOTTOM);
		this.registerPumpkins();
		this.registerBeehive(Blocks.BEE_NEST, TextureMap::sideFrontTopBottom);
		this.registerBeehive(Blocks.BEEHIVE, TextureMap::sideFrontEnd);
		this.registerCrop(Blocks.BEETROOTS, Properties.AGE_3, 0, 1, 2, 3);
		this.registerCrop(Blocks.CARROTS, Properties.AGE_7, 0, 0, 1, 1, 2, 2, 2, 3);
		this.registerCrop(Blocks.NETHER_WART, Properties.AGE_3, 0, 1, 1, 2);
		this.registerCrop(Blocks.POTATOES, Properties.AGE_7, 0, 0, 1, 1, 2, 2, 2, 3);
		this.registerCrop(Blocks.WHEAT, Properties.AGE_7, 0, 1, 2, 3, 4, 5, 6, 7);
		this.registerTintableCrossBlockStateWithStages(Blocks.TORCHFLOWER_CROP, BlockStateModelGenerator.CrossType.NOT_TINTED, Properties.AGE_1, 0, 1);
		this.registerPitcherCrop();
		this.registerPitcherPlant();
		this.registerBanners();
		this.registerBeds();
		this.registerSkulls();
		this.registerChests();
		this.registerShulkerBox(Blocks.SHULKER_BOX, null);
		this.registerShulkerBox(Blocks.WHITE_SHULKER_BOX, DyeColor.WHITE);
		this.registerShulkerBox(Blocks.ORANGE_SHULKER_BOX, DyeColor.ORANGE);
		this.registerShulkerBox(Blocks.MAGENTA_SHULKER_BOX, DyeColor.MAGENTA);
		this.registerShulkerBox(Blocks.LIGHT_BLUE_SHULKER_BOX, DyeColor.LIGHT_BLUE);
		this.registerShulkerBox(Blocks.YELLOW_SHULKER_BOX, DyeColor.YELLOW);
		this.registerShulkerBox(Blocks.LIME_SHULKER_BOX, DyeColor.LIME);
		this.registerShulkerBox(Blocks.PINK_SHULKER_BOX, DyeColor.PINK);
		this.registerShulkerBox(Blocks.GRAY_SHULKER_BOX, DyeColor.GRAY);
		this.registerShulkerBox(Blocks.LIGHT_GRAY_SHULKER_BOX, DyeColor.LIGHT_GRAY);
		this.registerShulkerBox(Blocks.CYAN_SHULKER_BOX, DyeColor.CYAN);
		this.registerShulkerBox(Blocks.PURPLE_SHULKER_BOX, DyeColor.PURPLE);
		this.registerShulkerBox(Blocks.BLUE_SHULKER_BOX, DyeColor.BLUE);
		this.registerShulkerBox(Blocks.BROWN_SHULKER_BOX, DyeColor.BROWN);
		this.registerShulkerBox(Blocks.GREEN_SHULKER_BOX, DyeColor.GREEN);
		this.registerShulkerBox(Blocks.RED_SHULKER_BOX, DyeColor.RED);
		this.registerShulkerBox(Blocks.BLACK_SHULKER_BOX, DyeColor.BLACK);
		this.registerBuiltin(Blocks.CONDUIT);
		this.registerSpecialItemModel(Blocks.CONDUIT, new net.minecraft.client.render.item.model.special.ConduitModelRenderer.Unbaked());
		this.registerBuiltinWithParticle(Blocks.DECORATED_POT, Blocks.TERRACOTTA);
		this.registerSpecialItemModel(Blocks.DECORATED_POT, new net.minecraft.client.render.item.model.special.DecoratedPotModelRenderer.Unbaked());
		this.registerBuiltinWithParticle(Blocks.END_PORTAL, Blocks.OBSIDIAN);
		this.registerBuiltinWithParticle(Blocks.END_GATEWAY, Blocks.OBSIDIAN);
		this.registerSimpleCubeAll(Blocks.AZALEA_LEAVES);
		this.registerSimpleCubeAll(Blocks.FLOWERING_AZALEA_LEAVES);
		this.registerSimpleCubeAll(Blocks.WHITE_CONCRETE);
		this.registerSimpleCubeAll(Blocks.ORANGE_CONCRETE);
		this.registerSimpleCubeAll(Blocks.MAGENTA_CONCRETE);
		this.registerSimpleCubeAll(Blocks.LIGHT_BLUE_CONCRETE);
		this.registerSimpleCubeAll(Blocks.YELLOW_CONCRETE);
		this.registerSimpleCubeAll(Blocks.LIME_CONCRETE);
		this.registerSimpleCubeAll(Blocks.PINK_CONCRETE);
		this.registerSimpleCubeAll(Blocks.GRAY_CONCRETE);
		this.registerSimpleCubeAll(Blocks.LIGHT_GRAY_CONCRETE);
		this.registerSimpleCubeAll(Blocks.CYAN_CONCRETE);
		this.registerSimpleCubeAll(Blocks.PURPLE_CONCRETE);
		this.registerSimpleCubeAll(Blocks.BLUE_CONCRETE);
		this.registerSimpleCubeAll(Blocks.BROWN_CONCRETE);
		this.registerSimpleCubeAll(Blocks.GREEN_CONCRETE);
		this.registerSimpleCubeAll(Blocks.RED_CONCRETE);
		this.registerSimpleCubeAll(Blocks.BLACK_CONCRETE);
		this.registerRandomHorizontalRotations(
			TexturedModel.CUBE_ALL,
			Blocks.WHITE_CONCRETE_POWDER,
			Blocks.ORANGE_CONCRETE_POWDER,
			Blocks.MAGENTA_CONCRETE_POWDER,
			Blocks.LIGHT_BLUE_CONCRETE_POWDER,
			Blocks.YELLOW_CONCRETE_POWDER,
			Blocks.LIME_CONCRETE_POWDER,
			Blocks.PINK_CONCRETE_POWDER,
			Blocks.GRAY_CONCRETE_POWDER,
			Blocks.LIGHT_GRAY_CONCRETE_POWDER,
			Blocks.CYAN_CONCRETE_POWDER,
			Blocks.PURPLE_CONCRETE_POWDER,
			Blocks.BLUE_CONCRETE_POWDER,
			Blocks.BROWN_CONCRETE_POWDER,
			Blocks.GREEN_CONCRETE_POWDER,
			Blocks.RED_CONCRETE_POWDER,
			Blocks.BLACK_CONCRETE_POWDER
		);
		this.registerSimpleCubeAll(Blocks.TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.WHITE_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.ORANGE_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.MAGENTA_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.LIGHT_BLUE_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.YELLOW_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.LIME_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.PINK_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.GRAY_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.LIGHT_GRAY_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.CYAN_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.PURPLE_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.BLUE_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.BROWN_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.GREEN_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.RED_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.BLACK_TERRACOTTA);
		this.registerSimpleCubeAll(Blocks.TINTED_GLASS);
		this.registerGlassAndPane(Blocks.GLASS, Blocks.GLASS_PANE);
		this.registerGlassAndPane(Blocks.WHITE_STAINED_GLASS, Blocks.WHITE_STAINED_GLASS_PANE);
		this.registerGlassAndPane(Blocks.ORANGE_STAINED_GLASS, Blocks.ORANGE_STAINED_GLASS_PANE);
		this.registerGlassAndPane(Blocks.MAGENTA_STAINED_GLASS, Blocks.MAGENTA_STAINED_GLASS_PANE);
		this.registerGlassAndPane(Blocks.LIGHT_BLUE_STAINED_GLASS, Blocks.LIGHT_BLUE_STAINED_GLASS_PANE);
		this.registerGlassAndPane(Blocks.YELLOW_STAINED_GLASS, Blocks.YELLOW_STAINED_GLASS_PANE);
		this.registerGlassAndPane(Blocks.LIME_STAINED_GLASS, Blocks.LIME_STAINED_GLASS_PANE);
		this.registerGlassAndPane(Blocks.PINK_STAINED_GLASS, Blocks.PINK_STAINED_GLASS_PANE);
		this.registerGlassAndPane(Blocks.GRAY_STAINED_GLASS, Blocks.GRAY_STAINED_GLASS_PANE);
		this.registerGlassAndPane(Blocks.LIGHT_GRAY_STAINED_GLASS, Blocks.LIGHT_GRAY_STAINED_GLASS_PANE);
		this.registerGlassAndPane(Blocks.CYAN_STAINED_GLASS, Blocks.CYAN_STAINED_GLASS_PANE);
		this.registerGlassAndPane(Blocks.PURPLE_STAINED_GLASS, Blocks.PURPLE_STAINED_GLASS_PANE);
		this.registerGlassAndPane(Blocks.BLUE_STAINED_GLASS, Blocks.BLUE_STAINED_GLASS_PANE);
		this.registerGlassAndPane(Blocks.BROWN_STAINED_GLASS, Blocks.BROWN_STAINED_GLASS_PANE);
		this.registerGlassAndPane(Blocks.GREEN_STAINED_GLASS, Blocks.GREEN_STAINED_GLASS_PANE);
		this.registerGlassAndPane(Blocks.RED_STAINED_GLASS, Blocks.RED_STAINED_GLASS_PANE);
		this.registerGlassAndPane(Blocks.BLACK_STAINED_GLASS, Blocks.BLACK_STAINED_GLASS_PANE);
		this.registerSouthDefaultHorizontalFacing(
			TexturedModel.TEMPLATE_GLAZED_TERRACOTTA,
			Blocks.WHITE_GLAZED_TERRACOTTA,
			Blocks.ORANGE_GLAZED_TERRACOTTA,
			Blocks.MAGENTA_GLAZED_TERRACOTTA,
			Blocks.LIGHT_BLUE_GLAZED_TERRACOTTA,
			Blocks.YELLOW_GLAZED_TERRACOTTA,
			Blocks.LIME_GLAZED_TERRACOTTA,
			Blocks.PINK_GLAZED_TERRACOTTA,
			Blocks.GRAY_GLAZED_TERRACOTTA,
			Blocks.LIGHT_GRAY_GLAZED_TERRACOTTA,
			Blocks.CYAN_GLAZED_TERRACOTTA,
			Blocks.PURPLE_GLAZED_TERRACOTTA,
			Blocks.BLUE_GLAZED_TERRACOTTA,
			Blocks.BROWN_GLAZED_TERRACOTTA,
			Blocks.GREEN_GLAZED_TERRACOTTA,
			Blocks.RED_GLAZED_TERRACOTTA,
			Blocks.BLACK_GLAZED_TERRACOTTA
		);
		this.registerWoolAndCarpet(Blocks.WHITE_WOOL, Blocks.WHITE_CARPET);
		this.registerWoolAndCarpet(Blocks.ORANGE_WOOL, Blocks.ORANGE_CARPET);
		this.registerWoolAndCarpet(Blocks.MAGENTA_WOOL, Blocks.MAGENTA_CARPET);
		this.registerWoolAndCarpet(Blocks.LIGHT_BLUE_WOOL, Blocks.LIGHT_BLUE_CARPET);
		this.registerWoolAndCarpet(Blocks.YELLOW_WOOL, Blocks.YELLOW_CARPET);
		this.registerWoolAndCarpet(Blocks.LIME_WOOL, Blocks.LIME_CARPET);
		this.registerWoolAndCarpet(Blocks.PINK_WOOL, Blocks.PINK_CARPET);
		this.registerWoolAndCarpet(Blocks.GRAY_WOOL, Blocks.GRAY_CARPET);
		this.registerWoolAndCarpet(Blocks.LIGHT_GRAY_WOOL, Blocks.LIGHT_GRAY_CARPET);
		this.registerWoolAndCarpet(Blocks.CYAN_WOOL, Blocks.CYAN_CARPET);
		this.registerWoolAndCarpet(Blocks.PURPLE_WOOL, Blocks.PURPLE_CARPET);
		this.registerWoolAndCarpet(Blocks.BLUE_WOOL, Blocks.BLUE_CARPET);
		this.registerWoolAndCarpet(Blocks.BROWN_WOOL, Blocks.BROWN_CARPET);
		this.registerWoolAndCarpet(Blocks.GREEN_WOOL, Blocks.GREEN_CARPET);
		this.registerWoolAndCarpet(Blocks.RED_WOOL, Blocks.RED_CARPET);
		this.registerWoolAndCarpet(Blocks.BLACK_WOOL, Blocks.BLACK_CARPET);
		this.registerSimpleCubeAll(Blocks.MUD);
		this.registerSimpleCubeAll(Blocks.PACKED_MUD);
		this.registerFlowerPotPlant(Blocks.FERN, Blocks.POTTED_FERN, BlockStateModelGenerator.CrossType.TINTED);
		this.registerGrassTinted(Blocks.FERN);
		this.registerFlowerPotPlantAndItem(Blocks.DANDELION, Blocks.POTTED_DANDELION, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.POPPY, Blocks.POTTED_POPPY, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.OPEN_EYEBLOSSOM, Blocks.POTTED_OPEN_EYEBLOSSOM, BlockStateModelGenerator.CrossType.EMISSIVE_NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.CLOSED_EYEBLOSSOM, Blocks.POTTED_CLOSED_EYEBLOSSOM, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.BLUE_ORCHID, Blocks.POTTED_BLUE_ORCHID, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.ALLIUM, Blocks.POTTED_ALLIUM, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.AZURE_BLUET, Blocks.POTTED_AZURE_BLUET, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.RED_TULIP, Blocks.POTTED_RED_TULIP, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.ORANGE_TULIP, Blocks.POTTED_ORANGE_TULIP, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.WHITE_TULIP, Blocks.POTTED_WHITE_TULIP, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.PINK_TULIP, Blocks.POTTED_PINK_TULIP, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.OXEYE_DAISY, Blocks.POTTED_OXEYE_DAISY, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.CORNFLOWER, Blocks.POTTED_CORNFLOWER, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.LILY_OF_THE_VALLEY, Blocks.POTTED_LILY_OF_THE_VALLEY, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.WITHER_ROSE, Blocks.POTTED_WITHER_ROSE, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.RED_MUSHROOM, Blocks.POTTED_RED_MUSHROOM, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.BROWN_MUSHROOM, Blocks.POTTED_BROWN_MUSHROOM, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.DEAD_BUSH, Blocks.POTTED_DEAD_BUSH, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerFlowerPotPlantAndItem(Blocks.TORCHFLOWER, Blocks.POTTED_TORCHFLOWER, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerPointedDripstone();
		this.registerMushroomBlock(Blocks.BROWN_MUSHROOM_BLOCK);
		this.registerMushroomBlock(Blocks.RED_MUSHROOM_BLOCK);
		this.registerMushroomBlock(Blocks.MUSHROOM_STEM);
		this.registerTintableCrossBlockState(Blocks.SHORT_GRASS, BlockStateModelGenerator.CrossType.TINTED);
		this.registerGrassTinted(Blocks.SHORT_GRASS);
		this.registerTintableCrossBlockState(Blocks.SUGAR_CANE, BlockStateModelGenerator.CrossType.TINTED);
		this.registerItemModel(Items.SUGAR_CANE);
		this.registerPlantPart(Blocks.KELP, Blocks.KELP_PLANT, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerItemModel(Items.KELP);
		this.registerTintableCrossBlockState(Blocks.HANGING_ROOTS, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerPlantPart(Blocks.WEEPING_VINES, Blocks.WEEPING_VINES_PLANT, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerPlantPart(Blocks.TWISTING_VINES, Blocks.TWISTING_VINES_PLANT, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerItemModel(Blocks.WEEPING_VINES, "_plant");
		this.registerItemModel(Blocks.TWISTING_VINES, "_plant");
		this.registerTintableCross(Blocks.BAMBOO_SAPLING, BlockStateModelGenerator.CrossType.TINTED, TextureMap.cross(TextureMap.getSubId(Blocks.BAMBOO, "_stage0")));
		this.registerBamboo();
		this.registerTintableCross(Blocks.COBWEB, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerDoubleBlockAndItem(Blocks.LILAC, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerDoubleBlockAndItem(Blocks.ROSE_BUSH, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerDoubleBlockAndItem(Blocks.PEONY, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerGrassTintedDoubleBlockAndItem(Blocks.TALL_GRASS);
		this.registerGrassTintedDoubleBlockAndItem(Blocks.LARGE_FERN);
		this.registerSunflower();
		this.registerTallSeagrass();
		this.registerSmallDripleaf();
		this.registerCoral(
			Blocks.TUBE_CORAL,
			Blocks.DEAD_TUBE_CORAL,
			Blocks.TUBE_CORAL_BLOCK,
			Blocks.DEAD_TUBE_CORAL_BLOCK,
			Blocks.TUBE_CORAL_FAN,
			Blocks.DEAD_TUBE_CORAL_FAN,
			Blocks.TUBE_CORAL_WALL_FAN,
			Blocks.DEAD_TUBE_CORAL_WALL_FAN
		);
		this.registerCoral(
			Blocks.BRAIN_CORAL,
			Blocks.DEAD_BRAIN_CORAL,
			Blocks.BRAIN_CORAL_BLOCK,
			Blocks.DEAD_BRAIN_CORAL_BLOCK,
			Blocks.BRAIN_CORAL_FAN,
			Blocks.DEAD_BRAIN_CORAL_FAN,
			Blocks.BRAIN_CORAL_WALL_FAN,
			Blocks.DEAD_BRAIN_CORAL_WALL_FAN
		);
		this.registerCoral(
			Blocks.BUBBLE_CORAL,
			Blocks.DEAD_BUBBLE_CORAL,
			Blocks.BUBBLE_CORAL_BLOCK,
			Blocks.DEAD_BUBBLE_CORAL_BLOCK,
			Blocks.BUBBLE_CORAL_FAN,
			Blocks.DEAD_BUBBLE_CORAL_FAN,
			Blocks.BUBBLE_CORAL_WALL_FAN,
			Blocks.DEAD_BUBBLE_CORAL_WALL_FAN
		);
		this.registerCoral(
			Blocks.FIRE_CORAL,
			Blocks.DEAD_FIRE_CORAL,
			Blocks.FIRE_CORAL_BLOCK,
			Blocks.DEAD_FIRE_CORAL_BLOCK,
			Blocks.FIRE_CORAL_FAN,
			Blocks.DEAD_FIRE_CORAL_FAN,
			Blocks.FIRE_CORAL_WALL_FAN,
			Blocks.DEAD_FIRE_CORAL_WALL_FAN
		);
		this.registerCoral(
			Blocks.HORN_CORAL,
			Blocks.DEAD_HORN_CORAL,
			Blocks.HORN_CORAL_BLOCK,
			Blocks.DEAD_HORN_CORAL_BLOCK,
			Blocks.HORN_CORAL_FAN,
			Blocks.DEAD_HORN_CORAL_FAN,
			Blocks.HORN_CORAL_WALL_FAN,
			Blocks.DEAD_HORN_CORAL_WALL_FAN
		);
		this.registerGourd(Blocks.MELON_STEM, Blocks.ATTACHED_MELON_STEM);
		this.registerGourd(Blocks.PUMPKIN_STEM, Blocks.ATTACHED_PUMPKIN_STEM);
		this.registerLog(Blocks.MANGROVE_LOG).log(Blocks.MANGROVE_LOG).wood(Blocks.MANGROVE_WOOD);
		this.registerLog(Blocks.STRIPPED_MANGROVE_LOG).log(Blocks.STRIPPED_MANGROVE_LOG).wood(Blocks.STRIPPED_MANGROVE_WOOD);
		this.registerHangingSign(Blocks.STRIPPED_MANGROVE_LOG, Blocks.MANGROVE_HANGING_SIGN, Blocks.MANGROVE_WALL_HANGING_SIGN);
		this.registerTintedBlockAndItem(Blocks.MANGROVE_LEAVES, TexturedModel.LEAVES, -7158200);
		this.registerLog(Blocks.ACACIA_LOG).log(Blocks.ACACIA_LOG).wood(Blocks.ACACIA_WOOD);
		this.registerLog(Blocks.STRIPPED_ACACIA_LOG).log(Blocks.STRIPPED_ACACIA_LOG).wood(Blocks.STRIPPED_ACACIA_WOOD);
		this.registerHangingSign(Blocks.STRIPPED_ACACIA_LOG, Blocks.ACACIA_HANGING_SIGN, Blocks.ACACIA_WALL_HANGING_SIGN);
		this.registerFlowerPotPlantAndItem(Blocks.ACACIA_SAPLING, Blocks.POTTED_ACACIA_SAPLING, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerTintedBlockAndItem(Blocks.ACACIA_LEAVES, TexturedModel.LEAVES, -12012264);
		this.registerLog(Blocks.CHERRY_LOG).uvLockedLog(Blocks.CHERRY_LOG).wood(Blocks.CHERRY_WOOD);
		this.registerLog(Blocks.STRIPPED_CHERRY_LOG).uvLockedLog(Blocks.STRIPPED_CHERRY_LOG).wood(Blocks.STRIPPED_CHERRY_WOOD);
		this.registerHangingSign(Blocks.STRIPPED_CHERRY_LOG, Blocks.CHERRY_HANGING_SIGN, Blocks.CHERRY_WALL_HANGING_SIGN);
		this.registerFlowerPotPlantAndItem(Blocks.CHERRY_SAPLING, Blocks.POTTED_CHERRY_SAPLING, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerSingleton(Blocks.CHERRY_LEAVES, TexturedModel.LEAVES);
		this.registerLog(Blocks.BIRCH_LOG).log(Blocks.BIRCH_LOG).wood(Blocks.BIRCH_WOOD);
		this.registerLog(Blocks.STRIPPED_BIRCH_LOG).log(Blocks.STRIPPED_BIRCH_LOG).wood(Blocks.STRIPPED_BIRCH_WOOD);
		this.registerHangingSign(Blocks.STRIPPED_BIRCH_LOG, Blocks.BIRCH_HANGING_SIGN, Blocks.BIRCH_WALL_HANGING_SIGN);
		this.registerFlowerPotPlantAndItem(Blocks.BIRCH_SAPLING, Blocks.POTTED_BIRCH_SAPLING, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerTintedBlockAndItem(Blocks.BIRCH_LEAVES, TexturedModel.LEAVES, -8345771);
		this.registerLog(Blocks.OAK_LOG).log(Blocks.OAK_LOG).wood(Blocks.OAK_WOOD);
		this.registerLog(Blocks.STRIPPED_OAK_LOG).log(Blocks.STRIPPED_OAK_LOG).wood(Blocks.STRIPPED_OAK_WOOD);
		this.registerHangingSign(Blocks.STRIPPED_OAK_LOG, Blocks.OAK_HANGING_SIGN, Blocks.OAK_WALL_HANGING_SIGN);
		this.registerFlowerPotPlantAndItem(Blocks.OAK_SAPLING, Blocks.POTTED_OAK_SAPLING, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerTintedBlockAndItem(Blocks.OAK_LEAVES, TexturedModel.LEAVES, -12012264);
		this.registerLog(Blocks.SPRUCE_LOG).log(Blocks.SPRUCE_LOG).wood(Blocks.SPRUCE_WOOD);
		this.registerLog(Blocks.STRIPPED_SPRUCE_LOG).log(Blocks.STRIPPED_SPRUCE_LOG).wood(Blocks.STRIPPED_SPRUCE_WOOD);
		this.registerHangingSign(Blocks.STRIPPED_SPRUCE_LOG, Blocks.SPRUCE_HANGING_SIGN, Blocks.SPRUCE_WALL_HANGING_SIGN);
		this.registerFlowerPotPlantAndItem(Blocks.SPRUCE_SAPLING, Blocks.POTTED_SPRUCE_SAPLING, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerTintedBlockAndItem(Blocks.SPRUCE_LEAVES, TexturedModel.LEAVES, -10380959);
		this.registerLog(Blocks.DARK_OAK_LOG).log(Blocks.DARK_OAK_LOG).wood(Blocks.DARK_OAK_WOOD);
		this.registerLog(Blocks.STRIPPED_DARK_OAK_LOG).log(Blocks.STRIPPED_DARK_OAK_LOG).wood(Blocks.STRIPPED_DARK_OAK_WOOD);
		this.registerHangingSign(Blocks.STRIPPED_DARK_OAK_LOG, Blocks.DARK_OAK_HANGING_SIGN, Blocks.DARK_OAK_WALL_HANGING_SIGN);
		this.registerFlowerPotPlantAndItem(Blocks.DARK_OAK_SAPLING, Blocks.POTTED_DARK_OAK_SAPLING, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerTintedBlockAndItem(Blocks.DARK_OAK_LEAVES, TexturedModel.LEAVES, -12012264);
		this.registerLog(Blocks.PALE_OAK_LOG).log(Blocks.PALE_OAK_LOG).wood(Blocks.PALE_OAK_WOOD);
		this.registerLog(Blocks.STRIPPED_PALE_OAK_LOG).log(Blocks.STRIPPED_PALE_OAK_LOG).wood(Blocks.STRIPPED_PALE_OAK_WOOD);
		this.registerHangingSign(Blocks.STRIPPED_PALE_OAK_LOG, Blocks.PALE_OAK_HANGING_SIGN, Blocks.PALE_OAK_WALL_HANGING_SIGN);
		this.registerFlowerPotPlantAndItem(Blocks.PALE_OAK_SAPLING, Blocks.POTTED_PALE_OAK_SAPLING, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerSingleton(Blocks.PALE_OAK_LEAVES, TexturedModel.LEAVES);
		this.registerLog(Blocks.JUNGLE_LOG).log(Blocks.JUNGLE_LOG).wood(Blocks.JUNGLE_WOOD);
		this.registerLog(Blocks.STRIPPED_JUNGLE_LOG).log(Blocks.STRIPPED_JUNGLE_LOG).wood(Blocks.STRIPPED_JUNGLE_WOOD);
		this.registerHangingSign(Blocks.STRIPPED_JUNGLE_LOG, Blocks.JUNGLE_HANGING_SIGN, Blocks.JUNGLE_WALL_HANGING_SIGN);
		this.registerFlowerPotPlantAndItem(Blocks.JUNGLE_SAPLING, Blocks.POTTED_JUNGLE_SAPLING, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerTintedBlockAndItem(Blocks.JUNGLE_LEAVES, TexturedModel.LEAVES, -12012264);
		this.registerLog(Blocks.CRIMSON_STEM).stem(Blocks.CRIMSON_STEM).wood(Blocks.CRIMSON_HYPHAE);
		this.registerLog(Blocks.STRIPPED_CRIMSON_STEM).stem(Blocks.STRIPPED_CRIMSON_STEM).wood(Blocks.STRIPPED_CRIMSON_HYPHAE);
		this.registerHangingSign(Blocks.STRIPPED_CRIMSON_STEM, Blocks.CRIMSON_HANGING_SIGN, Blocks.CRIMSON_WALL_HANGING_SIGN);
		this.registerFlowerPotPlantAndItem(Blocks.CRIMSON_FUNGUS, Blocks.POTTED_CRIMSON_FUNGUS, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerRoots(Blocks.CRIMSON_ROOTS, Blocks.POTTED_CRIMSON_ROOTS);
		this.registerLog(Blocks.WARPED_STEM).stem(Blocks.WARPED_STEM).wood(Blocks.WARPED_HYPHAE);
		this.registerLog(Blocks.STRIPPED_WARPED_STEM).stem(Blocks.STRIPPED_WARPED_STEM).wood(Blocks.STRIPPED_WARPED_HYPHAE);
		this.registerHangingSign(Blocks.STRIPPED_WARPED_STEM, Blocks.WARPED_HANGING_SIGN, Blocks.WARPED_WALL_HANGING_SIGN);
		this.registerFlowerPotPlantAndItem(Blocks.WARPED_FUNGUS, Blocks.POTTED_WARPED_FUNGUS, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerRoots(Blocks.WARPED_ROOTS, Blocks.POTTED_WARPED_ROOTS);
		this.registerLog(Blocks.BAMBOO_BLOCK).uvLockedLog(Blocks.BAMBOO_BLOCK);
		this.registerLog(Blocks.STRIPPED_BAMBOO_BLOCK).uvLockedLog(Blocks.STRIPPED_BAMBOO_BLOCK);
		this.registerHangingSign(Blocks.BAMBOO_PLANKS, Blocks.BAMBOO_HANGING_SIGN, Blocks.BAMBOO_WALL_HANGING_SIGN);
		this.registerTintableCrossBlockState(Blocks.NETHER_SPROUTS, BlockStateModelGenerator.CrossType.NOT_TINTED);
		this.registerItemModel(Items.NETHER_SPROUTS);
		this.registerDoor(Blocks.IRON_DOOR);
		this.registerTrapdoor(Blocks.IRON_TRAPDOOR);
		this.registerSmoothStone();
		this.registerTurnableRail(Blocks.RAIL);
		this.registerStraightRail(Blocks.POWERED_RAIL);
		this.registerStraightRail(Blocks.DETECTOR_RAIL);
		this.registerStraightRail(Blocks.ACTIVATOR_RAIL);
		this.registerComparator();
		this.registerCommandBlock(Blocks.COMMAND_BLOCK);
		this.registerCommandBlock(Blocks.REPEATING_COMMAND_BLOCK);
		this.registerCommandBlock(Blocks.CHAIN_COMMAND_BLOCK);
		this.registerAnvil(Blocks.ANVIL);
		this.registerAnvil(Blocks.CHIPPED_ANVIL);
		this.registerAnvil(Blocks.DAMAGED_ANVIL);
		this.registerBarrel();
		this.registerBell();
		this.registerCooker(Blocks.FURNACE, TexturedModel.ORIENTABLE);
		this.registerCooker(Blocks.BLAST_FURNACE, TexturedModel.ORIENTABLE);
		this.registerCooker(Blocks.SMOKER, TexturedModel.ORIENTABLE_WITH_BOTTOM);
		this.registerRedstone();
		this.registerRespawnAnchor();
		this.registerSculkCatalyst();
		this.registerParented(Blocks.CHISELED_STONE_BRICKS, Blocks.INFESTED_CHISELED_STONE_BRICKS);
		this.registerParented(Blocks.COBBLESTONE, Blocks.INFESTED_COBBLESTONE);
		this.registerParented(Blocks.CRACKED_STONE_BRICKS, Blocks.INFESTED_CRACKED_STONE_BRICKS);
		this.registerParented(Blocks.MOSSY_STONE_BRICKS, Blocks.INFESTED_MOSSY_STONE_BRICKS);
		this.registerInfestedStone();
		this.registerParented(Blocks.STONE_BRICKS, Blocks.INFESTED_STONE_BRICKS);
		this.registerInfestedDeepslate();
	}

	private void registerLightBlock() {
		Unbaked lv = ItemModels.basic(this.uploadItemModel(Items.LIGHT));
		Map<Integer, Unbaked> map = new HashMap(16);
		SingleProperty<Integer> lv2 = BlockStateVariantMap.create(Properties.LEVEL_15);

		for (int i = 0; i <= 15; i++) {
			String string = String.format(Locale.ROOT, "_%02d", i);
			Identifier lv3 = TextureMap.getSubId(Items.LIGHT, string);
			lv2.register(
				i, BlockStateVariant.create().put(VariantSettings.MODEL, Models.PARTICLE.upload(Blocks.LIGHT, string, TextureMap.particle(lv3), this.modelCollector))
			);
			Unbaked lv4 = ItemModels.basic(Models.GENERATED.upload(ModelIds.getItemSubModelId(Items.LIGHT, string), TextureMap.layer0(lv3), this.modelCollector));
			map.put(i, lv4);
		}

		this.itemModelOutput.accept(Items.LIGHT, ItemModels.select(LightBlock.LEVEL_15, lv, map));
		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(Blocks.LIGHT).coordinate(lv2));
	}

	private void registerCandle(Block candle, Block cake) {
		this.registerItemModel(candle.asItem());
		TextureMap lv = TextureMap.all(TextureMap.getId(candle));
		TextureMap lv2 = TextureMap.all(TextureMap.getSubId(candle, "_lit"));
		Identifier lv3 = Models.TEMPLATE_CANDLE.upload(candle, "_one_candle", lv, this.modelCollector);
		Identifier lv4 = Models.TEMPLATE_TWO_CANDLES.upload(candle, "_two_candles", lv, this.modelCollector);
		Identifier lv5 = Models.TEMPLATE_THREE_CANDLES.upload(candle, "_three_candles", lv, this.modelCollector);
		Identifier lv6 = Models.TEMPLATE_FOUR_CANDLES.upload(candle, "_four_candles", lv, this.modelCollector);
		Identifier lv7 = Models.TEMPLATE_CANDLE.upload(candle, "_one_candle_lit", lv2, this.modelCollector);
		Identifier lv8 = Models.TEMPLATE_TWO_CANDLES.upload(candle, "_two_candles_lit", lv2, this.modelCollector);
		Identifier lv9 = Models.TEMPLATE_THREE_CANDLES.upload(candle, "_three_candles_lit", lv2, this.modelCollector);
		Identifier lv10 = Models.TEMPLATE_FOUR_CANDLES.upload(candle, "_four_candles_lit", lv2, this.modelCollector);
		this.blockStateCollector
			.accept(
				VariantsBlockStateSupplier.create(candle)
					.coordinate(
						BlockStateVariantMap.create(Properties.CANDLES, Properties.LIT)
							.register(1, false, BlockStateVariant.create().put(VariantSettings.MODEL, lv3))
							.register(2, false, BlockStateVariant.create().put(VariantSettings.MODEL, lv4))
							.register(3, false, BlockStateVariant.create().put(VariantSettings.MODEL, lv5))
							.register(4, false, BlockStateVariant.create().put(VariantSettings.MODEL, lv6))
							.register(1, true, BlockStateVariant.create().put(VariantSettings.MODEL, lv7))
							.register(2, true, BlockStateVariant.create().put(VariantSettings.MODEL, lv8))
							.register(3, true, BlockStateVariant.create().put(VariantSettings.MODEL, lv9))
							.register(4, true, BlockStateVariant.create().put(VariantSettings.MODEL, lv10))
					)
			);
		Identifier lv11 = Models.TEMPLATE_CAKE_WITH_CANDLE.upload(cake, TextureMap.candleCake(candle, false), this.modelCollector);
		Identifier lv12 = Models.TEMPLATE_CAKE_WITH_CANDLE.upload(cake, "_lit", TextureMap.candleCake(candle, true), this.modelCollector);
		this.blockStateCollector.accept(VariantsBlockStateSupplier.create(cake).coordinate(createBooleanModelMap(Properties.LIT, lv12, lv11)));
	}

	@Environment(EnvType.CLIENT)
	class BlockTexturePool {
		private final TextureMap textures;
		private final Map<Model, Identifier> knownModels = Maps.newHashMap();
		@Nullable
		private BlockFamily family;
		@Nullable
		private Identifier baseModelId;
		private final Set<Block> children = new HashSet();

		public BlockTexturePool(final TextureMap textures) {
			this.textures = textures;
		}

		public BlockStateModelGenerator.BlockTexturePool base(Block block, Model model) {
			this.baseModelId = model.upload(block, this.textures, BlockStateModelGenerator.this.modelCollector);
			if (BlockStateModelGenerator.this.stoneStateFactories.containsKey(block)) {
				BlockStateModelGenerator.this.blockStateCollector
					.accept(
						((BlockStateModelGenerator.StateFactory)BlockStateModelGenerator.this.stoneStateFactories.get(block))
							.create(block, this.baseModelId, this.textures, BlockStateModelGenerator.this.modelCollector)
					);
			} else {
				BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createSingletonBlockState(block, this.baseModelId));
			}

			return this;
		}

		public BlockStateModelGenerator.BlockTexturePool parented(Block parent, Block child) {
			Identifier lv = ModelIds.getBlockModelId(parent);
			BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createSingletonBlockState(child, lv));
			BlockStateModelGenerator.this.itemModelOutput.acceptAlias(parent.asItem(), child.asItem());
			this.children.add(child);
			return this;
		}

		public BlockStateModelGenerator.BlockTexturePool button(Block buttonBlock) {
			Identifier lv = Models.BUTTON.upload(buttonBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			Identifier lv2 = Models.BUTTON_PRESSED.upload(buttonBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createButtonBlockState(buttonBlock, lv, lv2));
			Identifier lv3 = Models.BUTTON_INVENTORY.upload(buttonBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			BlockStateModelGenerator.this.registerParentedItemModel(buttonBlock, lv3);
			return this;
		}

		public BlockStateModelGenerator.BlockTexturePool wall(Block wallBlock) {
			Identifier lv = Models.TEMPLATE_WALL_POST.upload(wallBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			Identifier lv2 = Models.TEMPLATE_WALL_SIDE.upload(wallBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			Identifier lv3 = Models.TEMPLATE_WALL_SIDE_TALL.upload(wallBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createWallBlockState(wallBlock, lv, lv2, lv3));
			Identifier lv4 = Models.WALL_INVENTORY.upload(wallBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			BlockStateModelGenerator.this.registerParentedItemModel(wallBlock, lv4);
			return this;
		}

		public BlockStateModelGenerator.BlockTexturePool customFence(Block customFenceBlock) {
			TextureMap lv = TextureMap.textureParticle(customFenceBlock);
			Identifier lv2 = Models.CUSTOM_FENCE_POST.upload(customFenceBlock, lv, BlockStateModelGenerator.this.modelCollector);
			Identifier lv3 = Models.CUSTOM_FENCE_SIDE_NORTH.upload(customFenceBlock, lv, BlockStateModelGenerator.this.modelCollector);
			Identifier lv4 = Models.CUSTOM_FENCE_SIDE_EAST.upload(customFenceBlock, lv, BlockStateModelGenerator.this.modelCollector);
			Identifier lv5 = Models.CUSTOM_FENCE_SIDE_SOUTH.upload(customFenceBlock, lv, BlockStateModelGenerator.this.modelCollector);
			Identifier lv6 = Models.CUSTOM_FENCE_SIDE_WEST.upload(customFenceBlock, lv, BlockStateModelGenerator.this.modelCollector);
			BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createCustomFenceBlockState(customFenceBlock, lv2, lv3, lv4, lv5, lv6));
			Identifier lv7 = Models.CUSTOM_FENCE_INVENTORY.upload(customFenceBlock, lv, BlockStateModelGenerator.this.modelCollector);
			BlockStateModelGenerator.this.registerParentedItemModel(customFenceBlock, lv7);
			return this;
		}

		public BlockStateModelGenerator.BlockTexturePool fence(Block fenceBlock) {
			Identifier lv = Models.FENCE_POST.upload(fenceBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			Identifier lv2 = Models.FENCE_SIDE.upload(fenceBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createFenceBlockState(fenceBlock, lv, lv2));
			Identifier lv3 = Models.FENCE_INVENTORY.upload(fenceBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			BlockStateModelGenerator.this.registerParentedItemModel(fenceBlock, lv3);
			return this;
		}

		public BlockStateModelGenerator.BlockTexturePool customFenceGate(Block customFenceGateBlock) {
			TextureMap lv = TextureMap.textureParticle(customFenceGateBlock);
			Identifier lv2 = Models.TEMPLATE_CUSTOM_FENCE_GATE_OPEN.upload(customFenceGateBlock, lv, BlockStateModelGenerator.this.modelCollector);
			Identifier lv3 = Models.TEMPLATE_CUSTOM_FENCE_GATE.upload(customFenceGateBlock, lv, BlockStateModelGenerator.this.modelCollector);
			Identifier lv4 = Models.TEMPLATE_CUSTOM_FENCE_GATE_WALL_OPEN.upload(customFenceGateBlock, lv, BlockStateModelGenerator.this.modelCollector);
			Identifier lv5 = Models.TEMPLATE_CUSTOM_FENCE_GATE_WALL.upload(customFenceGateBlock, lv, BlockStateModelGenerator.this.modelCollector);
			BlockStateModelGenerator.this.blockStateCollector
				.accept(BlockStateModelGenerator.createFenceGateBlockState(customFenceGateBlock, lv2, lv3, lv4, lv5, false));
			return this;
		}

		public BlockStateModelGenerator.BlockTexturePool fenceGate(Block fenceGateBlock) {
			Identifier lv = Models.TEMPLATE_FENCE_GATE_OPEN.upload(fenceGateBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			Identifier lv2 = Models.TEMPLATE_FENCE_GATE.upload(fenceGateBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			Identifier lv3 = Models.TEMPLATE_FENCE_GATE_WALL_OPEN.upload(fenceGateBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			Identifier lv4 = Models.TEMPLATE_FENCE_GATE_WALL.upload(fenceGateBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createFenceGateBlockState(fenceGateBlock, lv, lv2, lv3, lv4, true));
			return this;
		}

		public BlockStateModelGenerator.BlockTexturePool pressurePlate(Block pressurePlateBlock) {
			Identifier lv = Models.PRESSURE_PLATE_UP.upload(pressurePlateBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			Identifier lv2 = Models.PRESSURE_PLATE_DOWN.upload(pressurePlateBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createPressurePlateBlockState(pressurePlateBlock, lv, lv2));
			return this;
		}

		public BlockStateModelGenerator.BlockTexturePool sign(Block signBlock) {
			if (this.family == null) {
				throw new IllegalStateException("Family not defined");
			} else {
				Block lv = (Block)this.family.getVariants().get(Variant.WALL_SIGN);
				Identifier lv2 = Models.PARTICLE.upload(signBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
				BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createSingletonBlockState(signBlock, lv2));
				BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createSingletonBlockState(lv, lv2));
				BlockStateModelGenerator.this.registerItemModel(signBlock.asItem());
				return this;
			}
		}

		public BlockStateModelGenerator.BlockTexturePool slab(Block block) {
			if (this.baseModelId == null) {
				throw new IllegalStateException("Full block not generated yet");
			} else {
				Identifier lv = this.ensureModel(Models.SLAB, block);
				Identifier lv2 = this.ensureModel(Models.SLAB_TOP, block);
				BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createSlabBlockState(block, lv, lv2, this.baseModelId));
				BlockStateModelGenerator.this.registerParentedItemModel(block, lv);
				return this;
			}
		}

		public BlockStateModelGenerator.BlockTexturePool stairs(Block block) {
			Identifier lv = this.ensureModel(Models.INNER_STAIRS, block);
			Identifier lv2 = this.ensureModel(Models.STAIRS, block);
			Identifier lv3 = this.ensureModel(Models.OUTER_STAIRS, block);
			BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createStairsBlockState(block, lv, lv2, lv3));
			BlockStateModelGenerator.this.registerParentedItemModel(block, lv2);
			return this;
		}

		private BlockStateModelGenerator.BlockTexturePool block(Block block) {
			TexturedModel lv = (TexturedModel)BlockStateModelGenerator.this.texturedModels.getOrDefault(block, TexturedModel.CUBE_ALL.get(block));
			Identifier lv2 = lv.upload(block, BlockStateModelGenerator.this.modelCollector);
			BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createSingletonBlockState(block, lv2));
			return this;
		}

		private BlockStateModelGenerator.BlockTexturePool door(Block block) {
			BlockStateModelGenerator.this.registerDoor(block);
			return this;
		}

		private void registerTrapdoor(Block block) {
			if (BlockStateModelGenerator.this.nonOrientableTrapdoors.contains(block)) {
				BlockStateModelGenerator.this.registerTrapdoor(block);
			} else {
				BlockStateModelGenerator.this.registerOrientableTrapdoor(block);
			}
		}

		private Identifier ensureModel(Model model, Block block) {
			return (Identifier)this.knownModels.computeIfAbsent(model, newModel -> newModel.upload(block, this.textures, BlockStateModelGenerator.this.modelCollector));
		}

		public BlockStateModelGenerator.BlockTexturePool family(BlockFamily family) {
			this.family = family;
			family.getVariants()
				.forEach(
					(variant, block) -> {
						if (!this.children.contains(block)) {
							BiConsumer<BlockStateModelGenerator.BlockTexturePool, Block> biConsumer = (BiConsumer<BlockStateModelGenerator.BlockTexturePool, Block>)BlockStateModelGenerator.VARIANT_POOL_FUNCTIONS
								.get(variant);
							if (biConsumer != null) {
								biConsumer.accept(this, block);
							}
						}
					}
				);
			return this;
		}
	}

	@Environment(EnvType.CLIENT)
	static record ChiseledBookshelfModelCacheKey(Model template, String modelSuffix) {
	}

	@Environment(EnvType.CLIENT)
	static enum CrossType {
		TINTED(Models.TINTED_CROSS, Models.TINTED_FLOWER_POT_CROSS, false),
		NOT_TINTED(Models.CROSS, Models.FLOWER_POT_CROSS, false),
		EMISSIVE_NOT_TINTED(Models.CROSS_EMISSIVE, Models.FLOWER_POT_CROSS_EMISSIVE, true);

		private final Model model;
		private final Model flowerPotModel;
		private final boolean emissive;

		private CrossType(final Model model, final Model flowerPotModel, final boolean emissive) {
			this.model = model;
			this.flowerPotModel = flowerPotModel;
			this.emissive = emissive;
		}

		public Model getCrossModel() {
			return this.model;
		}

		public Model getFlowerPotCrossModel() {
			return this.flowerPotModel;
		}

		public Identifier registerItemModel(BlockStateModelGenerator modelGenerator, Block block) {
			Item lv = block.asItem();
			return this.emissive ? modelGenerator.uploadTwoLayerBlockItemModel(lv, block, "_emissive") : modelGenerator.uploadBlockItemModel(lv, block);
		}

		public TextureMap getTextureMap(Block block) {
			return this.emissive ? TextureMap.crossAndCrossEmissive(block) : TextureMap.cross(block);
		}

		public TextureMap getFlowerPotTextureMap(Block block) {
			return this.emissive ? TextureMap.plantAndCrossEmissive(block) : TextureMap.plant(block);
		}
	}

	@Environment(EnvType.CLIENT)
	class LogTexturePool {
		private final TextureMap textures;

		public LogTexturePool(final TextureMap textures) {
			this.textures = textures;
		}

		public BlockStateModelGenerator.LogTexturePool wood(Block woodBlock) {
			TextureMap lv = this.textures.copyAndAdd(TextureKey.END, this.textures.getTexture(TextureKey.SIDE));
			Identifier lv2 = Models.CUBE_COLUMN.upload(woodBlock, lv, BlockStateModelGenerator.this.modelCollector);
			BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createAxisRotatedBlockState(woodBlock, lv2));
			return this;
		}

		public BlockStateModelGenerator.LogTexturePool stem(Block stemBlock) {
			Identifier lv = Models.CUBE_COLUMN.upload(stemBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createAxisRotatedBlockState(stemBlock, lv));
			return this;
		}

		public BlockStateModelGenerator.LogTexturePool log(Block logBlock) {
			Identifier lv = Models.CUBE_COLUMN.upload(logBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			Identifier lv2 = Models.CUBE_COLUMN_HORIZONTAL.upload(logBlock, this.textures, BlockStateModelGenerator.this.modelCollector);
			BlockStateModelGenerator.this.blockStateCollector.accept(BlockStateModelGenerator.createAxisRotatedBlockState(logBlock, lv, lv2));
			return this;
		}

		public BlockStateModelGenerator.LogTexturePool uvLockedLog(Block logBlock) {
			BlockStateModelGenerator.this.blockStateCollector
				.accept(BlockStateModelGenerator.createUvLockedColumnBlockState(logBlock, this.textures, BlockStateModelGenerator.this.modelCollector));
			return this;
		}
	}

	@FunctionalInterface
	@Environment(EnvType.CLIENT)
	interface StateFactory {
		BlockStateSupplier create(Block block, Identifier modelId, TextureMap textures, BiConsumer<Identifier, ModelSupplier> modelCollector);
	}
}
