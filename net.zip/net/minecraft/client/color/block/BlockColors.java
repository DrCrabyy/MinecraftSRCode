package net.minecraft.client.color.block;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.MapColor;
import net.minecraft.block.RedstoneWireBlock;
import net.minecraft.block.StemBlock;
import net.minecraft.block.TallPlantBlock;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.client.color.world.BiomeColors;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;
import net.minecraft.util.collection.IdList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.world.BlockRenderView;
import net.minecraft.world.World;
import net.minecraft.world.biome.GrassColors;

@Environment(EnvType.CLIENT)
public class BlockColors {
	private static final int NO_COLOR = -1;
	public static final int PLACED_LILY_PAD = -14647248;
	public static final int LILY_PAD = -9321636;
	private final IdList<BlockColorProvider> providers = new IdList<>(32);
	private final Map<Block, Set<Property<?>>> properties = Maps.newHashMap();

	public static BlockColors create() {
		BlockColors lv = new BlockColors();
		lv.registerColorProvider(
			(state, world, pos, tintIndex) -> world != null && pos != null
					? BiomeColors.getGrassColor(world, state.get(TallPlantBlock.HALF) == DoubleBlockHalf.UPPER ? pos.down() : pos)
					: GrassColors.getDefaultColor(),
			Blocks.LARGE_FERN,
			Blocks.TALL_GRASS
		);
		lv.registerColorProperty(TallPlantBlock.HALF, Blocks.LARGE_FERN, Blocks.TALL_GRASS);
		lv.registerColorProvider(
			(state, world, pos, tintIndex) -> world != null && pos != null ? BiomeColors.getGrassColor(world, pos) : GrassColors.getDefaultColor(),
			Blocks.GRASS_BLOCK,
			Blocks.FERN,
			Blocks.SHORT_GRASS,
			Blocks.POTTED_FERN
		);
		lv.registerColorProvider((state, world, pos, tintIndex) -> {
			if (tintIndex != 0) {
				return world != null && pos != null ? BiomeColors.getGrassColor(world, pos) : GrassColors.getDefaultColor();
			} else {
				return -1;
			}
		}, Blocks.PINK_PETALS, Blocks.WILDFLOWERS);
		lv.registerColorProvider((state, world, pos, tintIndex) -> -10380959, Blocks.SPRUCE_LEAVES);
		lv.registerColorProvider((state, world, pos, tintIndex) -> -8345771, Blocks.BIRCH_LEAVES);
		lv.registerColorProvider((state, world, pos, tintIndex) -> -9399763, Blocks.AZALEA_LEAVES, Blocks.FLOWERING_AZALEA_LEAVES);
		lv.registerColorProvider(
			(state, world, pos, tintIndex) -> world != null && pos != null ? BiomeColors.getFoliageColor(world, pos) : -12012264,
			Blocks.OAK_LEAVES,
			Blocks.JUNGLE_LEAVES,
			Blocks.ACACIA_LEAVES,
			Blocks.DARK_OAK_LEAVES,
			Blocks.VINE,
			Blocks.MANGROVE_LEAVES
		);
		lv.registerColorProvider(
			(state, world, pos, tintIndex) -> world != null && pos != null ? BiomeColors.getWaterColor(world, pos) : -1,
			Blocks.WATER,
			Blocks.BUBBLE_COLUMN,
			Blocks.WATER_CAULDRON
		);
		lv.registerColorProvider((state, world, pos, tintIndex) -> RedstoneWireBlock.getWireColor((Integer)state.get(RedstoneWireBlock.POWER)), Blocks.REDSTONE_WIRE);
		lv.registerColorProperty(RedstoneWireBlock.POWER, Blocks.REDSTONE_WIRE);
		lv.registerColorProvider((state, world, pos, tintIndex) -> world != null && pos != null ? BiomeColors.getGrassColor(world, pos) : -1, Blocks.SUGAR_CANE);
		lv.registerColorProvider((state, world, pos, tintIndex) -> -2046180, Blocks.ATTACHED_MELON_STEM, Blocks.ATTACHED_PUMPKIN_STEM);
		lv.registerColorProvider((state, world, pos, tintIndex) -> {
			int j = (Integer)state.get(StemBlock.AGE);
			return ColorHelper.getArgb(j * 32, 255 - j * 8, j * 4);
		}, Blocks.MELON_STEM, Blocks.PUMPKIN_STEM);
		lv.registerColorProperty(StemBlock.AGE, Blocks.MELON_STEM, Blocks.PUMPKIN_STEM);
		lv.registerColorProvider((state, world, pos, tintIndex) -> world != null && pos != null ? -14647248 : -9321636, Blocks.LILY_PAD);
		return lv;
	}

	public int getParticleColor(BlockState state, World world, BlockPos pos) {
		BlockColorProvider lv = this.providers.get(Registries.BLOCK.getRawId(state.getBlock()));
		if (lv != null) {
			return lv.getColor(state, null, null, 0);
		} else {
			MapColor lv2 = state.getMapColor(world, pos);
			return lv2 != null ? lv2.color : -1;
		}
	}

	public int getColor(BlockState state, @Nullable BlockRenderView world, @Nullable BlockPos pos, int tintIndex) {
		BlockColorProvider lv = this.providers.get(Registries.BLOCK.getRawId(state.getBlock()));
		return lv == null ? -1 : lv.getColor(state, world, pos, tintIndex);
	}

	public void registerColorProvider(BlockColorProvider provider, Block... blocks) {
		for (Block lv : blocks) {
			this.providers.set(provider, Registries.BLOCK.getRawId(lv));
		}
	}

	private void registerColorProperties(Set<Property<?>> properties, Block... blocks) {
		for (Block lv : blocks) {
			this.properties.put(lv, properties);
		}
	}

	private void registerColorProperty(Property<?> property, Block... blocks) {
		this.registerColorProperties(ImmutableSet.of(property), blocks);
	}

	public Set<Property<?>> getProperties(Block block) {
		return (Set<Property<?>>)this.properties.getOrDefault(block, ImmutableSet.of());
	}
}
